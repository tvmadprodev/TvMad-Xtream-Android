package com.tvmad.connect;

import android.app.AppOpsManager;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.PointerIcon;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public class OverlayService extends Service {
    public static final String ACTION_REFRESH = "com.tvmad.connect.action.REFRESH";
    public static final String ACTION_UI_OPEN = "com.tvmad.connect.action.UI_OPEN";
    public static final String ACTION_UI_CLOSED = "com.tvmad.connect.action.UI_CLOSED";

    private static final String TAG = "TvMadConnect";
    private static final String XTREAM_PACKAGE = "pl.tvmad.xtream.tv";
    private static final String XTREAM_SPLASH_CLASS = "pl.tvmad.xtream.PhoneSplashActivity";
    private static final long XTREAM_BACKGROUND_GRACE_MS = 1800L;
    private static final long XTREAM_ROOT_PROBE_INTERVAL_MS = 650L;
    private static final int XTREAM_FOCUS_MISSES_REQUIRED = 2;
    private static final long HDMI_OFF_GUARD_MIN_INTERVAL_MS = 1200L;
    private static final long HDMI_OFF_RECOVERY_DELAY_MS = 900L;

    private WindowManager windowManager;
    private View overlayView;
    private DisplayManager displayManager;
    private UsageStatsManager usageStatsManager;
    private Handler handler;
    private boolean uiOpen = false;

    private boolean xtreamPhoneSplashActive = false;
    private long usageCursorMs = 0L;
    private long xtreamLastResumeMs = 0L;
    private long xtreamLastPauseMs = 0L;
    private long xtreamLastStopMs = 0L;
    private long xtreamLastRootProbeElapsedMs = 0L;
    private boolean xtreamRootProbeRunning = false;
    private int xtreamFocusMisses = 0;

    private volatile boolean hdmiOffGuardRunning = false;
    private long lastHdmiOffGuardElapsedMs = 0L;
    // One extra OFF pulse is allowed after a software-OFF request if Samsung
    // republishes the external display. Never keep pulsing dp_test=6 forever:
    // on LineageOS that creates an HPD add/remove loop and makes the monitor icon
    // flash continuously on the phone.
    private boolean hdmiOffRecoveryUsed = false;
    private boolean hdmiOffRecoveryScheduled = false;

    // Android 12+ blocks pass-through clicks through an opaque untrusted overlay.
    // On this rooted FloydROM device we temporarily switch that system policy off
    // only while TvMad Connect's overlay is active, then restore the previous value.
    private boolean touchPolicyOverrideActive = false;
    private String previousBlockUntrustedTouches = null;
    private String previousMaximumObscuringOpacity = null;

    private final DisplayManager.DisplayListener displayListener = new DisplayManager.DisplayListener() {
        @Override public void onDisplayAdded(int displayId) {
            // Samsung may briefly republish the DP display after dp_test=6 while the
            // adapter is still physically attached. Allow ONE delayed recovery pulse
            // only. Repeating OFF on every callback creates an HPD reconnect loop on
            // LineageOS (the monitor icon flashes forever).
            scheduleOneShotHdmiOffRecoveryIfNeeded();
            scheduleRefresh(80);
        }
        @Override public void onDisplayRemoved(int displayId) { scheduleRefresh(80); }
        @Override public void onDisplayChanged(int displayId) {
            // Never write dp_test from DisplayChanged. The OFF command itself causes
            // DisplayChanged callbacks; feeding those back into another OFF write is
            // exactly what creates the reconnect storm.
            scheduleRefresh(80);
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        displayManager = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
        usageStatsManager = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
        if (displayManager != null) {
            displayManager.registerDisplayListener(displayListener, handler);
        }
        rebuildXtreamStateSinceBoot();
        enforceSoftwareHdmiOffIfNeeded();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        if (ACTION_UI_OPEN.equals(action)) {
            uiOpen = true;
            removeOverlay();
        } else if (ACTION_UI_CLOSED.equals(action)) {
            uiOpen = false;
        }
        scheduleRefresh(30);
        return START_STICKY;
    }

    private void scheduleRefresh(long delayMs) {
        if (handler == null) return;
        handler.removeCallbacks(refreshRunnable);
        handler.postDelayed(refreshRunnable, delayMs);
    }

    private final Runnable refreshRunnable = new Runnable() {
        @Override
        public void run() {
            refreshState();
            if (Prefs.isEnabled(OverlayService.this)) {
                boolean softwareHdmiOn = Prefs.isHdmiSoftwareEnabled(OverlayService.this);
                // While widget HDMI is OFF, poll only the Android display state at a
                // short interval. No root write is issued unless the external display
                // actually reappears. This catches Samsung's automatic HPD re-publish
                // quickly enough to keep the TV output down without affecting the phone UI.
                long nextDelay = !softwareHdmiOn
                        ? 300L
                        : (isExternalDisplayConnected() ? 220L : 900L);
                handler.postDelayed(this, nextDelay);
            }
        }
    };

    private void refreshState() {
        boolean enabled = Prefs.isEnabled(this);
        if (!enabled || !Settings.canDrawOverlays(this)) {
            removeOverlay();
            if (!enabled) stopSelf();
            return;
        }

        // Widget OFF is authoritative. The Samsung DP stack can keep the external
        // Display object alive briefly after a software HPD-low/unplug operation. If we
        // looked only at DisplayManager during that window, Connect would alternate
        // between the AMOLED logo and the launcher. Never show the overlay while the
        // user-selected software HDMI state is OFF.
        if (!Prefs.isHdmiSoftwareEnabled(this)) {
            removeOverlay();
            // Prefer the stable framebuffer blank backend when this kernel exposes it.
            // Re-applying FB blank does NOT create HPD add/remove churn, so it can safely
            // hold HDMI dark even if the display stack refreshes the framebuffer state.
            // Only use the old one-shot dp_test recovery on kernels without fb1/fb2/fb3.
            if (HdmiControl.hasStableBlankControl()) {
                enforceSoftwareHdmiOffIfNeeded();
            } else {
                scheduleOneShotHdmiOffRecoveryIfNeeded();
            }
            return;
        }

        // HDMI is intentionally ON again; arm the one-shot recovery for the next OFF.
        hdmiOffRecoveryUsed = false;
        hdmiOffRecoveryScheduled = false;

        updateXtreamStateIncremental();
        if (Prefs.isXtreamPriority(this) && xtreamPhoneSplashActive) {
            maybeProbeXtreamWindowFocus();
        }

        boolean hdmi = isExternalDisplayConnected();
        boolean xtreamOwnsPhone = Prefs.isXtreamPriority(this)
                && hasUsageAccess()
                && xtreamPhoneSplashActive;

        boolean shouldShow = hdmi && !uiOpen && !xtreamOwnsPhone;
        if (shouldShow) {
            if (overlayView == null) {
                showOverlay();
            } else {
                // Android 12/13 may restore the WindowState alpha after a WM traversal.
                // Keep the compositor surface itself fully opaque while leaving
                // FLAG_NOT_TOUCHABLE untouched so the TV/Nova input behaviour stays the same.
                applyOpaqueSkipScreenshotSurface();
            }
        } else {
            removeOverlay();
        }
    }

    private boolean isExternalDisplayConnected() {
        if (displayManager == null) return false;
        Display[] displays = displayManager.getDisplays();
        if (displays == null) return false;
        for (Display display : displays) {
            if (display == null) continue;
            if (display.getDisplayId() == Display.DEFAULT_DISPLAY) continue;
            if (!display.isValid()) continue;
            if (display.getState() == Display.STATE_OFF) continue;
            return true;
        }
        return false;
    }

    private boolean hasUsageAccess() {
        try {
            AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
            if (appOps == null) return false;
            int mode = appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(), getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * TvMad-Xtream ma na AMOLED własną PhoneSplashActivity. Nie sprawdzamy już
     * "ostatniej aplikacji na pierwszym planie", bo ruch air-mouse / Nova może zmienić
     * kolejność globalnych UsageEvents. Śledzimy WYŁĄCZNIE stan tej konkretnej Activity.
     */
    private void rebuildXtreamStateSinceBoot() {
        if (!hasUsageAccess() || usageStatsManager == null) {
            usageCursorMs = System.currentTimeMillis();
            xtreamPhoneSplashActive = false;
            return;
        }
        long now = System.currentTimeMillis();
        long bootWall = now - SystemClock.elapsedRealtime() - 5000L;
        xtreamPhoneSplashActive = false;
        xtreamLastResumeMs = 0L;
        xtreamLastPauseMs = 0L;
        xtreamLastStopMs = 0L;
        xtreamFocusMisses = 0;
        scanXtreamEvents(Math.max(0L, bootWall), now);
        usageCursorMs = now;
    }

    private void updateXtreamStateIncremental() {
        if (!hasUsageAccess() || usageStatsManager == null) {
            xtreamPhoneSplashActive = false;
            usageCursorMs = System.currentTimeMillis();
            return;
        }
        long now = System.currentTimeMillis();
        if (usageCursorMs <= 0L || usageCursorMs > now) {
            rebuildXtreamStateSinceBoot();
            return;
        }
        scanXtreamEvents(Math.max(0L, usageCursorMs - 1000L), now);
        usageCursorMs = now;
    }

    private void scanXtreamEvents(long begin, long end) {
        try {
            UsageEvents events = usageStatsManager.queryEvents(begin, end);
            if (events == null) return;
            UsageEvents.Event event = new UsageEvents.Event();
            while (events.hasNextEvent()) {
                events.getNextEvent(event);
                if (!XTREAM_PACKAGE.equals(event.getPackageName())) continue;
                String cls = event.getClassName();
                if (cls == null || !XTREAM_SPLASH_CLASS.equals(cls)) continue;

                int type = event.getEventType();
                long when = event.getTimeStamp();
                if (type == UsageEvents.Event.ACTIVITY_RESUMED) {
                    xtreamLastResumeMs = Math.max(xtreamLastResumeMs, when);
                    xtreamFocusMisses = 0;
                    xtreamPhoneSplashActive = true;
                } else if (type == UsageEvents.Event.ACTIVITY_STOPPED) {
                    xtreamLastStopMs = Math.max(xtreamLastStopMs, when);
                    xtreamFocusMisses = 0;
                    xtreamPhoneSplashActive = false;
                } else if (type == UsageEvents.Event.ACTIVITY_PAUSED) {
                    // Some Android/FloydROM exit paths do not promptly emit STOPPED.
                    // Remember the pause/background timestamp and only consider Xtream
                    // gone if it stays backgrounded for a short grace period. This keeps
                    // brief focus changes/system windows from bringing Connect over Xtream.
                    xtreamLastPauseMs = Math.max(xtreamLastPauseMs, when);
                }
            }

            if (xtreamLastStopMs >= xtreamLastResumeMs && xtreamLastStopMs > 0L) {
                xtreamPhoneSplashActive = false;
            } else if (xtreamLastResumeMs > xtreamLastStopMs) {
                if (xtreamLastPauseMs > xtreamLastResumeMs
                        && end - xtreamLastPauseMs >= XTREAM_BACKGROUND_GRACE_MS) {
                    xtreamPhoneSplashActive = false;
                } else {
                    xtreamPhoneSplashActive = true;
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "UsageEvents scan failed", t);
        }
    }

    /**
     * UsageStats can occasionally keep the last RESUMED state when PhoneSplashActivity
     * is removed from its task on this multi-display ROM. While Xtream owns the phone,
     * verify the real ActivityManager task list in the background. When the activity is
     * actually gone, record an authoritative synthetic stop timestamp so the old RESUMED
     * event cannot make the state true again on the next UsageEvents scan.
     */
    private void maybeProbeXtreamWindowFocus() {
        long nowElapsed = SystemClock.elapsedRealtime();
        if (xtreamRootProbeRunning
                || nowElapsed - xtreamLastRootProbeElapsedMs < XTREAM_ROOT_PROBE_INTERVAL_MS) {
            return;
        }

        xtreamRootProbeRunning = true;
        xtreamLastRootProbeElapsedMs = nowElapsed;
        final long probeStartedWallMs = System.currentTimeMillis();

        Thread probeThread = new Thread(() -> {
            /*
             * Do not use task history or mFocusedApp as the authority here. On Samsung
             * multi-display those records may outlive the actual TvMad-Xtream session.
             * Android 10+ can have one RESUMED activity per display, so ask
             * ActivityManager for its current resumed records. WindowManager's
             * mCurrentFocus is kept only as a fallback for ROMs whose dumpsys format
             * does not expose mResumedActivity/topResumedActivity.
             */
            String command =
                    "echo ===ACT===; "
                    + "(/system/bin/dumpsys activity activities 2>/dev/null "
                    + "| /system/bin/grep -E 'mResumedActivity|topResumedActivity' || true); "
                    + "echo ===WIN===; "
                    + "(/system/bin/dumpsys window displays 2>/dev/null "
                    + "| /system/bin/grep 'mCurrentFocus=' || true); exit 0";
            RootResult result = runRootCommand(command);

            boolean sawActivityState = false;
            boolean xtreamResumed = false;
            boolean xtreamCurrentFocus = false;
            if (result.exitCode == 0 && result.output != null) {
                int section = 0; // 1 = ActivityManager, 2 = WindowManager fallback
                String[] lines = result.output.split("\\n");
                for (String line : lines) {
                    if (line == null) continue;
                    if (line.contains("===ACT===")) {
                        section = 1;
                        continue;
                    }
                    if (line.contains("===WIN===")) {
                        section = 2;
                        continue;
                    }
                    if (section == 1 && (line.contains("mResumedActivity")
                            || line.contains("topResumedActivity"))) {
                        sawActivityState = true;
                        if (line.contains(XTREAM_PACKAGE)) {
                            xtreamResumed = true;
                        }
                    } else if (section == 2 && line.contains("mCurrentFocus=")) {
                        if (line.contains(XTREAM_PACKAGE)) {
                            xtreamCurrentFocus = true;
                        }
                    }
                }
            }

            // ActivityManager's current RESUMED state is authoritative when present.
            // Only fall back to WindowManager focus if this ROM did not print any
            // resumed-activity state at all.
            final boolean activeNow = sawActivityState ? xtreamResumed : xtreamCurrentFocus;
            final boolean probeOk = result.exitCode == 0;
            Handler h = handler;
            if (h == null) return;
            h.post(() -> {
                xtreamRootProbeRunning = false;
                if (!probeOk) return;

                if (activeNow) {
                    xtreamFocusMisses = 0;
                    xtreamPhoneSplashActive = true;
                    return;
                }

                // Two consecutive misses protect against a short transition/dialog,
                // while still restoring Connect quickly after Xtream has really exited.
                xtreamFocusMisses++;
                if (xtreamFocusMisses < XTREAM_FOCUS_MISSES_REQUIRED) {
                    return;
                }

                if (xtreamLastResumeMs <= probeStartedWallMs) {
                    long confirmedGoneMs = System.currentTimeMillis();
                    xtreamLastStopMs = Math.max(xtreamLastStopMs, confirmedGoneMs);
                    xtreamLastPauseMs = Math.max(xtreamLastPauseMs, confirmedGoneMs);
                    usageCursorMs = Math.max(usageCursorMs, confirmedGoneMs);
                    xtreamPhoneSplashActive = false;
                    xtreamFocusMisses = 0;
                    // Mirror the useful effect of manually opening/leaving TvMad Connect:
                    // make sure a stale UI-open flag cannot hold the overlay down, then
                    // immediately run the normal refresh path.
                    uiOpen = false;
                    scheduleRefresh(0);
                }
            });
        }, "TvMad-XtreamResumedProbe");
        probeThread.setDaemon(true);
        probeThread.start();
    }

    /**
     * LineageOS/Exynos can republish the external display immediately after dp_test=6.
     * Give that race one extra OFF pulse, but never enter a permanent HPD feedback loop.
     */
    private void scheduleOneShotHdmiOffRecoveryIfNeeded() {
        if (handler == null || Prefs.isHdmiSoftwareEnabled(this)) return;
        if (hdmiOffRecoveryUsed || hdmiOffRecoveryScheduled) return;

        hdmiOffRecoveryScheduled = true;
        handler.postDelayed(() -> {
            hdmiOffRecoveryScheduled = false;
            if (Prefs.isHdmiSoftwareEnabled(OverlayService.this)) return;
            if (!isExternalDisplayConnected()) return;

            hdmiOffRecoveryUsed = true;
            enforceSoftwareHdmiOffIfNeeded();
        }, HDMI_OFF_RECOVERY_DELAY_MS);
    }

    /**
     * If the home-screen widget was left in software HDMI OFF, a later physical HPD
     * event may need one corrective unplug request. The one-shot scheduler above makes
     * sure this method cannot be called continuously by display-state churn.
     */
    private void enforceSoftwareHdmiOffIfNeeded() {
        if (Prefs.isHdmiSoftwareEnabled(this)) return;
        long now = SystemClock.elapsedRealtime();
        if (hdmiOffGuardRunning
                || now - lastHdmiOffGuardElapsedMs < HDMI_OFF_GUARD_MIN_INTERVAL_MS) {
            return;
        }
        hdmiOffGuardRunning = true;
        lastHdmiOffGuardElapsedMs = now;
        Thread t = new Thread(() -> {
            try {
                HdmiControl.setEnabled(false);
            } finally {
                hdmiOffGuardRunning = false;
            }
        }, "TvMad-HdmiOffGuard");
        t.setDaemon(true);
        t.start();
    }

    private void showOverlay() {
        try {
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (windowManager == null) return;

            // Android 12+ intentionally blocks clicks that pass through an opaque
            // TYPE_APPLICATION_OVERLAY. This phone is rooted, so use Android's own
            // block_untrusted_touches switch while our overlay is present. Do this
            // BEFORE adding the overlay so the first click is not lost.
            enableTouchPassThroughPolicy();

            // Match the proven TvMad-Xtream AMOLED splash construction: the window root
            // is real #000000 and the full-screen image itself is an opaque RGB bitmap
            // with #000000 baked into its background. No view-level transparency is used.
            FrameLayout root = new FrameLayout(this);
            root.setBackgroundColor(Color.BLACK);
            root.setAlpha(1.0f);

            ImageView logo = new ImageView(this);
            logo.setImageResource(R.drawable.overlay_logo_transparent);
            // The approved replacement logo is a full AMOLED splash image with true
            // #000000 already baked into the bitmap. Render it edge-to-edge so the
            // phone shows the new crisp splash exactly as designed.
            logo.setScaleType(ImageView.ScaleType.FIT_XY);
            logo.setBackgroundColor(Color.BLACK);
            logo.setAlpha(1.0f);
            root.addView(logo, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    Gravity.CENTER));

            try {
                PointerIcon none = PointerIcon.getSystemIcon(this, PointerIcon.TYPE_NULL);
                root.setPointerIcon(none);
                logo.setPointerIcon(none);
            } catch (Throwable ignored) {}

            int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                    | WindowManager.LayoutParams.FLAG_FULLSCREEN;

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    flags,
                    PixelFormat.OPAQUE);
            lp.gravity = Gravity.TOP | Gravity.START;
            // Root policy below raises Android's obscuring-opacity limit to 1.0 while
            // this overlay exists, so the AMOLED layer can stay genuinely opaque without
            // blocking real mouse/air-mouse clicks to the app underneath.
            lp.alpha = 1.0f;
            lp.dimAmount = 0f;
            lp.setTitle("TvMadConnectOverlay");

            // Android 17 / LineageOS: FLAG_NOT_TOUCHABLE alone can still leave this
            // untrusted overlay represented in InputDispatcher's window list. That is
            // enough to break a real BTN_MOUSE click from the air-mouse even though
            // DPAD navigation continues to work. Tell WindowManager not to create an
            // input channel for this visual-only overlay at all. This is the hidden
            // INPUT_FEATURE_NO_INPUT_CHANNEL flag (0x00000002).
            applyNoInputChannel(lp);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            }

            applyImmersiveUi(root);
            root.setOnSystemUiVisibilityChangeListener(visibility -> applyImmersiveUi(root));

            overlayView = root;
            windowManager.addView(overlayView, lp);

            applyImmersiveUi(overlayView);
            overlayView.post(() -> applyImmersiveUi(overlayView));
            handler.postDelayed(() -> applyImmersiveUi(overlayView), 60L);
            handler.postDelayed(() -> applyImmersiveUi(overlayView), 180L);
            handler.postDelayed(() -> applyImmersiveUi(overlayView), 500L);
            handler.postDelayed(() -> applyImmersiveUi(overlayView), 1200L);

            hideSystemPointerBestEffort();

            // Android 12/13 caps a NOT_TOUCHABLE SAW to the maximum obscuring opacity
            // inside WindowManager. We must keep NOT_TOUCHABLE for the already-working
            // Nova/TV input path, so after WindowManager attaches the layer we restore
            // the compositor plane alpha directly on SurfaceControl. SKIP_SCREENSHOT is
            // applied in the same transaction, exactly to keep the overlay off HDMI.
            overlayView.post(this::applyOpaqueSkipScreenshotSurface);
            handler.postDelayed(this::applyOpaqueSkipScreenshotSurface, 60L);
            handler.postDelayed(this::applyOpaqueSkipScreenshotSurface, 180L);
            handler.postDelayed(this::applyOpaqueSkipScreenshotSurface, 500L);
            handler.postDelayed(this::applyOpaqueSkipScreenshotSurface, 1200L);
        } catch (Throwable t) {
            Log.e(TAG, "showOverlay failed", t);
            removeOverlay();
        }
    }

    /**
     * This overlay is display-only. It must never participate in input dispatch.
     * WindowManager.LayoutParams.inputFeatures is hidden from the public SDK, so set
     * INPUT_FEATURE_NO_INPUT_CHANNEL (0x2) reflectively before addView(). If a future
     * ROM blocks access to the hidden field we keep the existing NOT_TOUCHABLE path
     * and log the failure rather than crashing the service.
     */
    private void applyNoInputChannel(WindowManager.LayoutParams lp) {
        if (lp == null) return;
        try {
            Field field = WindowManager.LayoutParams.class.getDeclaredField("inputFeatures");
            field.setAccessible(true);
            int current = field.getInt(lp);
            field.setInt(lp, current | 0x00000002);
            Log.i(TAG, "Overlay INPUT_FEATURE_NO_INPUT_CHANNEL enabled");
        } catch (Throwable t) {
            Log.e(TAG, "Could not enable NO_INPUT_CHANNEL for overlay", t);
        }
    }

    private void enableTouchPassThroughPolicy() {
        if (touchPolicyOverrideActive) return;
        try {
            RootResult currentBlock = runRootCommand(
                    "/system/bin/settings get global block_untrusted_touches");
            RootResult currentOpacity = runRootCommand(
                    "/system/bin/settings get global maximum_obscuring_opacity_for_touch");
            if (currentBlock.exitCode != 0 || currentOpacity.exitCode != 0) {
                Log.w(TAG, "Root unavailable; overlay touch policy unchanged");
                return;
            }

            previousBlockUntrustedTouches = currentBlock.output == null
                    ? "" : currentBlock.output.trim();
            previousMaximumObscuringOpacity = currentOpacity.output == null
                    ? "" : currentOpacity.output.trim();

            // Android 12+ has TWO relevant gates for pass-through touches:
            // block_untrusted_touches and maximum_obscuring_opacity_for_touch (default .8).
            // Android 17 can still reject BTN_MOUSE through a fully opaque SAW when only
            // the first switch is disabled. Root lets us temporarily set both.
            RootResult blockChanged = runRootCommand(
                    "/system/bin/settings put global block_untrusted_touches 0");
            RootResult opacityChanged = runRootCommand(
                    "/system/bin/settings put global maximum_obscuring_opacity_for_touch 1.0");

            if (blockChanged.exitCode == 0 && opacityChanged.exitCode == 0) {
                touchPolicyOverrideActive = true;
                Log.i(TAG, "Opaque overlay pass-through policy enabled (block=0, maxOpacity=1.0)");
            } else {
                Log.w(TAG, "Could not configure full pass-through policy: "
                        + blockChanged.output + " / " + opacityChanged.output);
            }
        } catch (Throwable t) {
            Log.e(TAG, "enableTouchPassThroughPolicy failed", t);
        }
    }

    private void restoreTouchPassThroughPolicy() {
        if (!touchPolicyOverrideActive) return;
        try {
            restoreGlobalSetting("block_untrusted_touches", previousBlockUntrustedTouches);
            restoreGlobalSetting("maximum_obscuring_opacity_for_touch",
                    previousMaximumObscuringOpacity);
            Log.i(TAG, "Previous overlay touch policy restored");
        } catch (Throwable t) {
            Log.e(TAG, "restoreTouchPassThroughPolicy failed", t);
        } finally {
            touchPolicyOverrideActive = false;
            previousBlockUntrustedTouches = null;
            previousMaximumObscuringOpacity = null;
        }
    }

    private void restoreGlobalSetting(String key, String oldValue) {
        String old = oldValue == null ? "" : oldValue.trim();
        if (old.isEmpty() || "null".equalsIgnoreCase(old)) {
            runRootCommand("/system/bin/settings delete global " + key);
        } else {
            runRootCommand("/system/bin/settings put global " + key + " " + old);
        }
    }

    private void removeOverlay() {
        boolean hadOverlay = overlayView != null;
        if (windowManager != null && overlayView != null) {
            try { windowManager.removeView(overlayView); } catch (Throwable ignored) {}
        }
        overlayView = null;
        restoreSystemPointerBestEffort();
        if (hadOverlay || touchPolicyOverrideActive) {
            restoreTouchPassThroughPolicy();
        }
    }

    @Override
    public void onDestroy() {
        if (displayManager != null) {
            try { displayManager.unregisterDisplayListener(displayListener); } catch (Throwable ignored) {}
        }
        if (handler != null) handler.removeCallbacksAndMessages(null);
        removeOverlay();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
