TvMad Galaxy 0.1 beta
Package: pl.tvmad.galaxy

Designed for Galaxy S9+ / FloydROM HDMI use.
- HDMI present: phone shows AMOLED TvMad Galaxy screen, launcher opens on external display.
- HDMI absent: normal phone remains unchanged; manually opening TvMad Galaxy shows "Podłącz HDMI" and closes.
- TV launcher: clock, full Polish date with year, CPU temp, CPU usage, free/total RAM.
- Tiles can be added from installed apps; long-press a pinned app tile to remove it.
- Apps launched from the TV launcher return to normal Samsung mirroring so regular apps/settings remain operable with the remote.
- Returning from an app reopens TvMad Galaxy on HDMI.
- Foreground HDMI monitor service supports auto-start; if Android blocks a background activity launch, the app can fall back to KernelSU `su` activity launch when permission is granted.
- TvMad-Xtream package pl.tvmad.xtream.tv can coexist with this launcher.
