plugins { id("com.android.application") }

android {
    namespace = "com.tvmad.hdmitest"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.tvmad.hdmitest"
        minSdk = 29
        targetSdk = 28
        versionCode = 1
        versionName = "0.1-test"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
