plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "pl.tvmad.xtream"
    compileSdk = 35
    defaultConfig {
        applicationId = "pl.tvmad.xtream.beta"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-beta"
    }
}
