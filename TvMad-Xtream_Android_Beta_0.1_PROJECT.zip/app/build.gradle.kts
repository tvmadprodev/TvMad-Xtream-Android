plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "pl.tvmad.xtream"
    compileSdk = 35
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
        isCoreLibraryDesugaringEnabled = true
    }
    kotlinOptions { jvmTarget = "17" }
    defaultConfig {
        applicationId = "pl.tvmad.xtream.tv"
        minSdk = 26
        targetSdk = 35
        versionCode = 24
        versionName = "1.14-tv-fullscreen-panels-beta"
    }
}

dependencies {
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-ui:1.3.1")
    implementation("org.jellyfin.media3:media3-ffmpeg-decoder:1.3.1+2")
    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:2.1.4")
}
