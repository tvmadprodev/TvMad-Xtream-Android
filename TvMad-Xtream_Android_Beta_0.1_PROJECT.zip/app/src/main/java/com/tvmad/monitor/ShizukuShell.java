package com.tvmad.monitor;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;

import rikka.shizuku.Shizuku;

final class ShizukuShell {
    private ShizukuShell() {}

    static int run(String command) throws Exception {
        if (!Shizuku.pingBinder()) {
            throw new IllegalStateException("Shizuku is not running");
        }

        // Shizuku 13 keeps newProcess internally for transition from su-based apps.
        // Reflection keeps this tiny app simple while executing only our fixed command.
        Method method = Shizuku.class.getDeclaredMethod(
                "newProcess", String[].class, String[].class, String.class);
        method.setAccessible(true);
        Object result = method.invoke(null,
                new Object[]{new String[]{"sh", "-c", command}, null, null});

        if (!(result instanceof Process)) {
            throw new IllegalStateException("Unexpected Shizuku process type");
        }

        Process p = (Process) result;
        try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
            while (br.readLine() != null) { /* drain stdout */ }
        }
        try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getErrorStream()))) {
            while (br.readLine() != null) { /* drain stderr */ }
        }
        return p.waitFor();
    }
}
