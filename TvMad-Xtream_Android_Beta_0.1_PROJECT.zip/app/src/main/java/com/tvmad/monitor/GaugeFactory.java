package com.tvmad.monitor;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;

final class GaugeFactory {
    static final int TYPE_RAM = 0;
    static final int TYPE_STORAGE = 1;
    static final int TYPE_BATTERY = 2;
    static final int TYPE_TEMP = 3;

    private GaugeFactory() {}

    static Bitmap create(int percent, int type) {
        int size = 128;
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(bitmap);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

        float stroke = 13f;
        RectF arc = new RectF(15, 15, size - 15, size - 15);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(stroke);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setColor(Color.argb(105, 255, 255, 255));
        c.drawArc(arc, -90, 360, false, p);

        p.setColor(colorFor(percent, type));
        c.drawArc(arc, -90, 360f * Math.max(0, Math.min(100, percent)) / 100f, false, p);

        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(5f);
        p.setColor(Color.WHITE);
        drawIcon(c, p, type, size / 2f, size / 2f);
        return bitmap;
    }

    private static int colorFor(int percent, int type) {
        if (type == TYPE_TEMP) {
            if (percent >= 80) return Color.rgb(255, 92, 92);
            if (percent >= 60) return Color.rgb(255, 190, 70);
            return Color.rgb(48, 214, 123);
        }
        if (type == TYPE_BATTERY && percent <= 20) return Color.rgb(255, 92, 92);
        return Color.rgb(48, 214, 123);
    }

    private static void drawIcon(Canvas c, Paint p, int type, float cx, float cy) {
        switch (type) {
            case TYPE_RAM: {
                RectF r = new RectF(cx - 18, cy - 16, cx + 18, cy + 16);
                c.drawRoundRect(r, 4, 4, p);
                for (int i = -12; i <= 12; i += 8) {
                    c.drawLine(cx + i, cy - 24, cx + i, cy - 16, p);
                    c.drawLine(cx + i, cy + 16, cx + i, cy + 24, p);
                }
                c.drawLine(cx - 26, cy - 8, cx - 18, cy - 8, p);
                c.drawLine(cx - 26, cy + 8, cx - 18, cy + 8, p);
                c.drawLine(cx + 18, cy - 8, cx + 26, cy - 8, p);
                c.drawLine(cx + 18, cy + 8, cx + 26, cy + 8, p);
                break;
            }
            case TYPE_STORAGE: {
                RectF d = new RectF(cx - 23, cy - 16, cx + 23, cy + 16);
                c.drawRoundRect(d, 5, 5, p);
                c.drawCircle(cx + 13, cy + 8, 2.5f, p);
                c.drawLine(cx - 14, cy + 7, cx + 5, cy + 7, p);
                break;
            }
            case TYPE_BATTERY: {
                RectF b = new RectF(cx - 24, cy - 13, cx + 19, cy + 13);
                c.drawRoundRect(b, 4, 4, p);
                c.drawLine(cx + 22, cy - 6, cx + 22, cy + 6, p);
                c.drawLine(cx + 19, cy - 6, cx + 25, cy - 6, p);
                c.drawLine(cx + 19, cy + 6, cx + 25, cy + 6, p);
                break;
            }
            case TYPE_TEMP: {
                c.drawCircle(cx, cy + 13, 10, p);
                c.drawLine(cx, cy + 5, cx, cy - 23, p);
                c.drawRoundRect(new RectF(cx - 6, cy - 27, cx + 6, cy + 7), 6, 6, p);
                break;
            }
        }
    }
}
