package com.tvmad.monitor;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class CleanRamReceiver extends BroadcastReceiver {
    static final String ACTION_CLEAN = "com.tvmad.monitor.CLEAN_RAM";
    private static final String ACTION_CLEAR = "com.tvmad.monitor.CLEAR_STATUS";
    private static final int CLEAR_REQUEST = 2202;

    @Override
    public void onReceive(Context context, Intent intent) {
        if (ACTION_CLEAR.equals(intent.getAction())) {
            setStatus(context, "Kliknij widget, aby wyczyścić RAM");
            WidgetUpdater.updateAll(context);
            return;
        }
        if (!ACTION_CLEAN.equals(intent.getAction())) return;

        final PendingResult pending = goAsync();
        Context app = context.getApplicationContext();
        new Thread(() -> {
            try {
                long before = SystemStats.read(app).availableRamBytes;
                int exit = runRoot("am kill-all");
                if (exit != 0) {
                    setStatus(app, "Brak dostępu root — zezwól w Magisk");
                } else {
                    Thread.sleep(1200L);
                    long after = SystemStats.read(app).availableRamBytes;
                    long freedMb = Math.max(0L, (after - before) / (1024L * 1024L));
                    setStatus(app, "✓ Zwolniono " + freedMb + " MB");
                }
            } catch (Exception e) {
                setStatus(app, "Nie udało się wyczyścić RAM");
            }
            WidgetUpdater.updateAll(app);
            scheduleStatusClear(app);
            pending.finish();
        }, "TvMadRamCleaner").start();
    }

    private static int runRoot(String command) throws Exception {
        Process p = new ProcessBuilder("su", "-c", command).redirectErrorStream(true).start();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
            while (br.readLine() != null) { /* drain */ }
        }
        return p.waitFor();
    }

    private static void setStatus(Context context, String text) {
        context.getSharedPreferences("state", Context.MODE_PRIVATE)
                .edit().putString("status", text).apply();
    }

    private static void scheduleStatusClear(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        Intent i = new Intent(context, CleanRamReceiver.class).setAction(ACTION_CLEAR);
        PendingIntent pi = PendingIntent.getBroadcast(context, CLEAR_REQUEST, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        am.set(AlarmManager.ELAPSED_REALTIME, SystemClock.elapsedRealtime() + 8_000L, pi);
    }
}
