package com.tvmad.monitor;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.content.pm.PackageManager;

import rikka.shizuku.Shizuku;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

public class MainActivity extends Activity {
    private static final int SHIZUKU_PERMISSION_REQUEST = 7001;
    private LinearLayout root;

    private final Shizuku.OnBinderReceivedListener binderReceivedListener = this::ensureShizukuPermission;
    private final Shizuku.OnRequestPermissionResultListener permissionResultListener = (requestCode, grantResult) -> {
        if (requestCode == SHIZUKU_PERMISSION_REQUEST) {
            WidgetUpdater.updateAll(this);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        Shizuku.addBinderReceivedListenerSticky(binderReceivedListener);
        Shizuku.addRequestPermissionResultListener(permissionResultListener);
    }

    @Override
    protected void onDestroy() {
        Shizuku.removeBinderReceivedListener(binderReceivedListener);
        Shizuku.removeRequestPermissionResultListener(permissionResultListener);
        super.onDestroy();
    }

    private void ensureShizukuPermission() {
        try {
            if (!Shizuku.pingBinder()) return;
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) return;
            if (!Shizuku.shouldShowRequestPermissionRationale()) {
                Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST);
            }
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshInfo();
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(32), dp(28), dp(32), dp(28));
        root.setBackgroundColor(Color.rgb(16, 18, 23));

        TextView title = text("TvMad Monitor", 28, true);
        root.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView sub = text("Widget systemowy: RAM • pamięć • bateria • temperatura • zegar", 15, false);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        subLp.topMargin = dp(8);
        root.addView(sub, subLp);

        TextView hint = text("Dodaj widget „TvMad Monitor” z menu widgetów launchera.\nZegar i data odświeżają się na bieżąco. Dane systemowe co około 5 minut.\nKliknięcie widgetu czyści bezpiecznie procesy tła przez Shizuku i pokazuje ile RAM zwolniono.", 14, false);
        hint.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(dp(620), ViewGroup.LayoutParams.WRAP_CONTENT);
        hintLp.topMargin = dp(22);
        root.addView(hint, hintLp);

        Button refresh = new Button(this);
        refresh.setText("Odśwież widget teraz");
        refresh.setOnClickListener(v -> {
            WidgetUpdater.updateAll(this);
            RefreshScheduler.schedule(this);
            refreshInfo();
        });
        LinearLayout.LayoutParams btnLp = new LinearLayout.LayoutParams(dp(260), dp(56));
        btnLp.topMargin = dp(24);
        root.addView(refresh, btnLp);

        setContentView(root);
        refreshInfo();
    }

    private void refreshInfo() {
        if (root == null) return;
        if (root.getChildCount() > 4) root.removeViews(4, root.getChildCount() - 4);
        SystemStats s = SystemStats.read(this);
        String temp = Float.isNaN(s.batteryTempC) ? "--" : String.format(Locale.getDefault(), "%.1f°C", s.batteryTempC);
        TextView now = text("RAM " + s.ramPercent + "%   •   Pamięć " + s.storagePercent + "%   •   Bateria " + s.batteryPercent + "%   •   " + temp, 16, true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(20);
        root.addView(now, lp);
    }

    private TextView text(String value, int sp, boolean bold) {
        TextView tv = new TextView(this);
        tv.setText(value);
        tv.setTextColor(Color.WHITE);
        tv.setTextSize(sp);
        if (bold) tv.setTypeface(tv.getTypeface(), android.graphics.Typeface.BOLD);
        return tv;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
