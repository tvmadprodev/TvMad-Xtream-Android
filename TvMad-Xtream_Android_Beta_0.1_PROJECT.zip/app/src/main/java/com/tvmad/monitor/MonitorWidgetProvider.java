package com.tvmad.monitor;

import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;

public class MonitorWidgetProvider extends AppWidgetProvider {
    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        WidgetUpdater.updateAll(context);
        RefreshScheduler.schedule(context);
    }

    @Override
    public void onEnabled(Context context) {
        WidgetUpdater.updateAll(context);
        RefreshScheduler.schedule(context);
    }

    @Override
    public void onDisabled(Context context) {
        RefreshScheduler.cancel(context);
    }
}
