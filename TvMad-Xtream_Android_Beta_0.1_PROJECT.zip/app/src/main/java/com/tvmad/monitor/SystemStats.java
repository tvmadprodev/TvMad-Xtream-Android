package com.tvmad.monitor;

import android.app.ActivityManager;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Environment;
import android.os.StatFs;

final class SystemStats {
    final int ramPercent;
    final int storagePercent;
    final int batteryPercent;
    final float batteryTempC;
    final long availableRamBytes;

    private SystemStats(int ramPercent, int storagePercent, int batteryPercent,
                        float batteryTempC, long availableRamBytes) {
        this.ramPercent = ramPercent;
        this.storagePercent = storagePercent;
        this.batteryPercent = batteryPercent;
        this.batteryTempC = batteryTempC;
        this.availableRamBytes = availableRamBytes;
    }

    static SystemStats read(Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        long total = Math.max(1L, mi.totalMem);
        int ram = clamp((int) Math.round((total - mi.availMem) * 100.0 / total));

        StatFs stat = new StatFs(Environment.getDataDirectory().getAbsolutePath());
        long storageTotal = Math.max(1L, stat.getTotalBytes());
        long storageAvail = stat.getAvailableBytes();
        int storage = clamp((int) Math.round((storageTotal - storageAvail) * 100.0 / storageTotal));

        Intent battery = context.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int batteryPct = 0;
        float temp = Float.NaN;
        if (battery != null) {
            int level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            if (level >= 0 && scale > 0) batteryPct = clamp(Math.round(level * 100f / scale));
            int rawTemp = battery.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Integer.MIN_VALUE);
            if (rawTemp != Integer.MIN_VALUE) temp = rawTemp / 10f;
        }

        return new SystemStats(ram, storage, batteryPct, temp, mi.availMem);
    }

    private static int clamp(int v) {
        return Math.max(0, Math.min(100, v));
    }
}
