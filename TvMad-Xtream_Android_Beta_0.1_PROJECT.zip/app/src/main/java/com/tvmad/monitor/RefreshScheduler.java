package com.tvmad.monitor;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.SystemClock;

final class RefreshScheduler {
    private static final long INTERVAL_MS = 10L * 60L * 1000L;
    private static final int REQUEST_REFRESH = 1001;

    private RefreshScheduler() {}

    static void schedule(Context context) {
        int[] ids = AppWidgetManager.getInstance(context)
                .getAppWidgetIds(new ComponentName(context, MonitorWidgetProvider.class));
        if (ids == null || ids.length == 0) {
            cancel(context);
            return;
        }
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi = refreshIntent(context);
        long when = SystemClock.elapsedRealtime() + INTERVAL_MS;
        am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, when, pi);
    }

    static void cancel(Context context) {
        AlarmManager am = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        am.cancel(refreshIntent(context));
    }

    private static PendingIntent refreshIntent(Context context) {
        Intent i = new Intent(context, RefreshReceiver.class).setAction(RefreshReceiver.ACTION_REFRESH);
        return PendingIntent.getBroadcast(context, REQUEST_REFRESH, i,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
}
