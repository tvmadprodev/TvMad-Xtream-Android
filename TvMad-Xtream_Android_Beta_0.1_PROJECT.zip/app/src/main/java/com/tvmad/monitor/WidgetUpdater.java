package com.tvmad.monitor;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

import java.util.Locale;

final class WidgetUpdater {
    private WidgetUpdater() {}

    static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName component = new ComponentName(context, MonitorWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(component);
        if (ids == null || ids.length == 0) return;

        SystemStats stats = SystemStats.read(context);
        String status = context.getSharedPreferences("state", Context.MODE_PRIVATE)
                .getString("status", "Kliknij widget, aby wyczyścić RAM");

        int tempGauge = Float.isNaN(stats.batteryTempC)
                ? 0 : Math.max(0, Math.min(100, Math.round((stats.batteryTempC - 20f) * 100f / 30f)));

        for (int id : ids) {
            RemoteViews rv = new RemoteViews(context.getPackageName(), R.layout.widget_monitor);
            rv.setTextViewText(R.id.value_ram, stats.ramPercent + "%");
            rv.setTextViewText(R.id.value_storage, stats.storagePercent + "%");
            rv.setTextViewText(R.id.value_battery, stats.batteryPercent + "%");
            rv.setTextViewText(R.id.value_temp, Float.isNaN(stats.batteryTempC)
                    ? "--°C" : String.format(Locale.getDefault(), "%.1f°C", stats.batteryTempC));
            rv.setTextViewText(R.id.status, status);

            rv.setImageViewBitmap(R.id.gauge_ram, GaugeFactory.create(stats.ramPercent, GaugeFactory.TYPE_RAM));
            rv.setImageViewBitmap(R.id.gauge_storage, GaugeFactory.create(stats.storagePercent, GaugeFactory.TYPE_STORAGE));
            rv.setImageViewBitmap(R.id.gauge_battery, GaugeFactory.create(stats.batteryPercent, GaugeFactory.TYPE_BATTERY));
            rv.setImageViewBitmap(R.id.gauge_temp, GaugeFactory.create(tempGauge, GaugeFactory.TYPE_TEMP));

            Intent clean = new Intent(context, CleanRamReceiver.class).setAction(CleanRamReceiver.ACTION_CLEAN);
            PendingIntent pi = PendingIntent.getBroadcast(context, id, clean,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            rv.setOnClickPendingIntent(R.id.widget_root, pi);
            manager.updateAppWidget(id, rv);
        }
    }
}
