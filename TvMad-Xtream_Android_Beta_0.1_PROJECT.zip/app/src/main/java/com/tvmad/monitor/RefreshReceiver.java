package com.tvmad.monitor;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class RefreshReceiver extends BroadcastReceiver {
    static final String ACTION_REFRESH = "com.tvmad.monitor.REFRESH";

    @Override
    public void onReceive(Context context, Intent intent) {
        WidgetUpdater.updateAll(context);
        RefreshScheduler.schedule(context);
    }
}
