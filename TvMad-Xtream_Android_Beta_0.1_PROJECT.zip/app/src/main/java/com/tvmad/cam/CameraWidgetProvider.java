package com.tvmad.cam;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;

public class CameraWidgetProvider extends AppWidgetProvider {
    static final String WIDGET_PREFS = "tvmad_cam_widgets";

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] appWidgetIds) {
        for (int id : appWidgetIds) updateWidget(context, manager, id);
    }

    @Override
    public void onDeleted(Context context, int[] appWidgetIds) {
        var e = context.getSharedPreferences(WIDGET_PREFS, Context.MODE_PRIVATE).edit();
        for (int id : appWidgetIds) e.remove("camera_" + id);
        e.apply();
    }

    public static void bindCamera(Context context, int widgetId, String cameraId) {
        context.getSharedPreferences(WIDGET_PREFS, Context.MODE_PRIVATE)
                .edit().putString("camera_" + widgetId, cameraId).apply();
        updateWidget(context, AppWidgetManager.getInstance(context), widgetId);
    }

    public static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        android.content.ComponentName component = new android.content.ComponentName(context, CameraWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(component);
        for (int id : ids) updateWidget(context, manager, id);
    }

    static void updateWidget(Context context, AppWidgetManager manager, int widgetId) {
        String cameraId = context.getSharedPreferences(WIDGET_PREFS, Context.MODE_PRIVATE)
                .getString("camera_" + widgetId, null);
        CameraItem camera = new CameraStore(context).find(cameraId);
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_camera);

        Intent intent;
        if (camera != null) {
            views.setTextViewText(R.id.widget_name, camera.name);
            views.setTextViewText(R.id.widget_hint, "Dotknij, aby otworzyć fullscreen");
            intent = new Intent(context, MainActivity.class);
            intent.putExtra(MainActivity.EXTRA_CAMERA_ID, camera.id);
            intent.putExtra(MainActivity.EXTRA_OPEN_FULLSCREEN, true);
        } else {
            views.setTextViewText(R.id.widget_name, "TvMad Cam");
            views.setTextViewText(R.id.widget_hint, "Dodaj lub wybierz kamerę");
            intent = new Intent(context, MainActivity.class);
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(context, widgetId, intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, pi);
        manager.updateAppWidget(widgetId, views);
    }
}
