package com.tvmad.cam;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class HomeServerClient {
    private static final String PREFS = "tvmad_home_server";
    private static final String K_BASE = "base";
    private static final String K_USER = "user";
    private static final String K_PASS = "pass";

    public static class Settings {
        public String base = "https://tvmadhome.stream";
        public String username = "";
        public String password = "";
    }

    public static class RemoteCamera {
        public final String id, name;
        RemoteCamera(String id, String name) { this.id = id; this.name = name; }
    }

    public static class StreamSession {
        public final String id, playlist, cookie;
        StreamSession(String id, String playlist, String cookie) {
            this.id = id; this.playlist = playlist; this.cookie = cookie;
        }
    }

    public interface Result<T> { void done(T value, String error); }

    private final SharedPreferences prefs;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService pool = Executors.newFixedThreadPool(4);
    private final Object loginLock = new Object();
    private volatile String sessionCookie = "";

    public HomeServerClient(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public Settings loadSettings() {
        Settings s = new Settings();
        s.base = prefs.getString(K_BASE, s.base);
        s.username = prefs.getString(K_USER, "");
        s.password = prefs.getString(K_PASS, "");
        return s;
    }

    public void saveSettings(String base, String username, String password) {
        String normalized = normalizeBase(base);
        Settings old = loadSettings();
        if (!normalized.equals(normalizeBase(old.base)) || !username.equals(old.username) || !password.equals(old.password)) {
            sessionCookie = "";
        }
        prefs.edit().putString(K_BASE, normalized).putString(K_USER, username)
                .putString(K_PASS, password).apply();
    }

    public static String normalizeBase(String raw) {
        String s = raw == null ? "" : raw.trim();
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }

    public void fetchCameras(Result<List<RemoteCamera>> cb) {
        pool.execute(() -> {
            try {
                Settings s = loadSettings();
                ensureLogin(s);
                JSONObject o;
                try {
                    o = requestJson("GET", s.base + "/api/tvmad-cam/cameras", null, sessionCookie, true);
                } catch (AuthException ex) {
                    sessionCookie = "";
                    ensureLogin(s);
                    o = requestJson("GET", s.base + "/api/tvmad-cam/cameras", null, sessionCookie, true);
                }
                JSONArray a = o.optJSONArray("cameras");
                List<RemoteCamera> list = new ArrayList<>();
                if (a != null) for (int i = 0; i < a.length(); i++) {
                    JSONObject c = a.optJSONObject(i);
                    if (c != null) list.add(new RemoteCamera(c.optString("id"), c.optString("name", "Kamera")));
                }
                post(cb, list, null);
            } catch (Exception e) { post(cb, null, friendly(e)); }
        });
    }

    public void startCamera(CameraItem camera, Result<StreamSession> cb) {
        pool.execute(() -> {
            try {
                Settings s = loadSettings();
                String base = normalizeBase(camera.serverBase);
                if (base.isEmpty()) base = normalizeBase(s.base);
                if (!base.equals(normalizeBase(s.base))) throw new Exception("Kamera należy do innego serwera TvMad Home. Pobierz listę kamer ponownie.");
                ensureLogin(s);
                JSONObject o;
                try {
                    o = requestJson("POST", base + "/api/cameras/" + encPath(camera.remoteId) + "/start", "{}", sessionCookie, true);
                } catch (AuthException ex) {
                    sessionCookie = "";
                    ensureLogin(s);
                    o = requestJson("POST", base + "/api/cameras/" + encPath(camera.remoteId) + "/start", "{}", sessionCookie, true);
                }
                String sid = o.optString("session");
                String playlist = absolute(base, o.optString("playlist"));
                if (sid.isEmpty() || playlist.isEmpty()) throw new Exception("Serwer nie zwrócił streamu kamery");
                post(cb, new StreamSession(sid, playlist, sessionCookie), null);
            } catch (Exception e) { post(cb, null, friendly(e)); }
        });
    }

    public void stopSession(String serverBase, String sessionId) {
        if (sessionId == null || sessionId.isEmpty()) return;
        pool.execute(() -> {
            try {
                Settings s = loadSettings();
                if (sessionCookie.isEmpty()) return;
                String base = normalizeBase(serverBase);
                if (base.isEmpty()) base = normalizeBase(s.base);
                requestJson("POST", base + "/api/live/" + encPath(sessionId) + "/stop", "{}", sessionCookie, false);
            } catch (Exception ignored) { }
        });
    }

    public String currentCookie() { return sessionCookie; }

    public void shutdown() { pool.shutdownNow(); }

    private void ensureLogin(Settings s) throws Exception {
        if (!sessionCookie.isEmpty()) return;
        synchronized (loginLock) {
            if (!sessionCookie.isEmpty()) return;
            if (normalizeBase(s.base).isEmpty()) throw new Exception("Podaj adres TvMad Home");
            if (s.username.trim().isEmpty() || s.password.isEmpty()) throw new Exception("Podaj login i hasło TvMad Home");
            JSONObject body = new JSONObject();
            body.put("username", s.username.trim());
            body.put("password", s.password);
            HttpResult r = raw("POST", normalizeBase(s.base) + "/api/auth/login", body.toString(), "");
            if (r.code < 200 || r.code >= 300) {
                String msg = jsonError(r.body);
                throw new Exception(msg.isEmpty() ? "Logowanie do TvMad Home nie powiodło się (HTTP " + r.code + ")" : msg);
            }
            String set = r.setCookie == null ? "" : r.setCookie;
            String found = "";
            for (String part : set.split(";")) {
                String p = part.trim();
                if (p.startsWith("tvmad_session=")) { found = p; break; }
            }
            if (found.isEmpty()) throw new Exception("TvMad Home nie zwrócił sesji logowania");
            sessionCookie = found;
        }
    }

    private JSONObject requestJson(String method, String url, String body, String cookie, boolean throwAuth) throws Exception {
        HttpResult r = raw(method, url, body, cookie);
        if (throwAuth && r.code == 401) throw new AuthException();
        JSONObject o;
        try { o = new JSONObject(r.body.isEmpty() ? "{}" : r.body); }
        catch (Exception e) { throw new Exception("Nieprawidłowa odpowiedź TvMad Home (HTTP " + r.code + ")"); }
        if (r.code < 200 || r.code >= 300) {
            String err = o.optString("error", "HTTP " + r.code);
            throw new Exception(err);
        }
        return o;
    }

    private HttpResult raw(String method, String urlText, String body, String cookie) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(urlText).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(20000);
        c.setRequestMethod(method);
        c.setRequestProperty("Accept", "application/json");
        c.setRequestProperty("User-Agent", "TvMad-Cam/0.2");
        if (cookie != null && !cookie.isEmpty()) c.setRequestProperty("Cookie", cookie);
        if (body != null) {
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json; charset=utf-8");
            byte[] b = body.getBytes(StandardCharsets.UTF_8);
            try (OutputStream os = c.getOutputStream()) { os.write(b); }
        }
        int code = c.getResponseCode();
        InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
        StringBuilder sb = new StringBuilder();
        if (in != null) try (BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line; while ((line = br.readLine()) != null) sb.append(line);
        }
        String setCookie = c.getHeaderField("Set-Cookie");
        c.disconnect();
        return new HttpResult(code, sb.toString(), setCookie);
    }

    private static class HttpResult {
        final int code; final String body, setCookie;
        HttpResult(int code, String body, String setCookie) { this.code = code; this.body = body; this.setCookie = setCookie; }
    }
    private static class AuthException extends Exception { }

    private <T> void post(Result<T> cb, T value, String err) { main.post(() -> cb.done(value, err)); }
    private static String friendly(Exception e) {
        String m = e.getMessage();
        return (m == null || m.trim().isEmpty()) ? "Nie udało się połączyć z TvMad Home" : m;
    }
    private static String jsonError(String raw) {
        try { return new JSONObject(raw).optString("error", ""); } catch (Exception ignored) { return ""; }
    }
    private static String absolute(String base, String path) {
        if (path == null || path.isEmpty()) return "";
        if (path.startsWith("http://") || path.startsWith("https://")) return path;
        return normalizeBase(base) + (path.startsWith("/") ? path : "/" + path);
    }
    private static String encPath(String v) {
        try { return java.net.URLEncoder.encode(v == null ? "" : v, "UTF-8").replace("+", "%20"); }
        catch (Exception e) { return v; }
    }
}
