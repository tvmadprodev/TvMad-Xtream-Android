package com.tvmad.cam;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

public class CameraWidgetConfigActivity extends Activity {
    private int widgetId = AppWidgetManager.INVALID_APPWIDGET_ID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setResult(RESULT_CANCELED);
        Intent intent = getIntent();
        Bundle extras = intent.getExtras();
        if (extras != null) widgetId = extras.getInt(AppWidgetManager.EXTRA_APPWIDGET_ID,
                AppWidgetManager.INVALID_APPWIDGET_ID);
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish();
            return;
        }
        showChooser();
    }

    private void showChooser() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(20), dp(20), dp(20));
        box.setBackgroundColor(Color.rgb(11,17,24));

        TextView title = new TextView(this);
        title.setText("TvMad Cam\nWybierz kamerę dla widgetu");
        title.setTextColor(Color.WHITE);
        title.setTextSize(20);
        title.setGravity(Gravity.CENTER);
        title.setPadding(0, 0, 0, dp(16));
        box.addView(title);

        List<CameraItem> cameras = new CameraStore(this).load();
        if (cameras.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("Najpierw dodaj kamerę w aplikacji TvMad Cam.");
            empty.setTextColor(Color.LTGRAY);
            empty.setTextSize(15);
            empty.setGravity(Gravity.CENTER);
            box.addView(empty, new LinearLayout.LayoutParams(-1, dp(80)));
            Button open = button("OTWÓRZ TvMad Cam");
            open.setOnClickListener(v -> startActivity(new Intent(this, MainActivity.class)));
            box.addView(open);
        } else {
            for (CameraItem c : cameras) {
                Button b = button(c.name);
                b.setOnClickListener(v -> select(c.id));
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(52));
                lp.setMargins(0, dp(5), 0, dp(5));
                box.addView(b, lp);
            }
        }

        ScrollView scroll = new ScrollView(this);
        scroll.addView(box);
        setContentView(scroll);
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.rgb(25, 53, 60));
        return b;
    }

    private void select(String cameraId) {
        CameraWidgetProvider.bindCamera(this, widgetId, cameraId);
        Intent result = new Intent();
        result.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        setResult(RESULT_OK, result);
        finish();
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
