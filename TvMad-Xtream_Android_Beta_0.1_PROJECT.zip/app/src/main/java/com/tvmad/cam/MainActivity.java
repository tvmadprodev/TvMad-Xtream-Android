package com.tvmad.cam;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.DragEvent;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.WindowInsets;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.rtsp.RtspMediaSource;
import androidx.media3.exoplayer.hls.HlsMediaSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@UnstableApi
public class MainActivity extends Activity {
    public static final String EXTRA_CAMERA_ID = "camera_id";
    public static final String EXTRA_OPEN_FULLSCREEN = "open_fullscreen";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Map<String, ExoPlayer> players = new HashMap<>();
    private final Map<String, TextView> statusViews = new HashMap<>();
    private final Map<String, FrameLayout> tileViews = new HashMap<>();
    private final Map<String, HomeServerClient.StreamSession> homeSessions = new HashMap<>();

    private CameraStore store;
    private HomeServerClient homeClient;
    private List<CameraItem> cameras = new ArrayList<>();
    private LinearLayout root;
    private LinearLayout topBar;
    private LinearLayout grid;
    private TextView titleText;
    private TextView audioButton;
    private boolean audioEnabled = false;
    private boolean fullscreen = false;
    private String fullscreenId = null;
    private String pendingFullscreenId = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        store = new CameraStore(this);
        homeClient = new HomeServerClient(this);
        audioEnabled = getSharedPreferences("tvmad_cam", MODE_PRIVATE).getBoolean("audio", false);

        if (savedInstanceState != null) {
            fullscreen = savedInstanceState.getBoolean("fullscreen", false);
            fullscreenId = savedInstanceState.getString("fullscreenId");
        }

        Intent i = getIntent();
        if (i != null && i.getBooleanExtra(EXTRA_OPEN_FULLSCREEN, false)) {
            pendingFullscreenId = i.getStringExtra(EXTRA_CAMERA_ID);
        }

        buildBaseUi();
        reloadCameras(true);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent.getBooleanExtra(EXTRA_OPEN_FULLSCREEN, false)) {
            String id = intent.getStringExtra(EXTRA_CAMERA_ID);
            if (store.find(id) != null) enterFullscreen(id);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        outState.putBoolean("fullscreen", fullscreen);
        outState.putString("fullscreenId", fullscreenId);
        super.onSaveInstanceState(outState);
    }

    private void buildBaseUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(11,17,24));
        setContentView(root);
        installSafeInsets();

        topBar = new LinearLayout(this);
        topBar.setOrientation(LinearLayout.HORIZONTAL);
        topBar.setGravity(Gravity.CENTER_VERTICAL);
        topBar.setPadding(dp(12), dp(6), dp(8), dp(6));
        topBar.setBackgroundColor(Color.rgb(17,26,35));
        root.addView(topBar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(62)));

        TextView logo = makeTopButton("◉");
        logo.setTextSize(22);
        logo.setTextColor(Color.rgb(33,212,163));
        logo.setOnClickListener(v -> Toast.makeText(this, "TvMad Cam", Toast.LENGTH_SHORT).show());
        topBar.addView(logo, new LinearLayout.LayoutParams(dp(38), dp(44)));

        titleText = new TextView(this);
        titleText.setText("TvMad Cam");
        titleText.setTextColor(Color.WHITE);
        titleText.setTextSize(18);
        titleText.setGravity(Gravity.CENTER_VERTICAL);
        titleText.setPadding(dp(6), 0, 0, 0);
        topBar.addView(titleText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        audioButton = makeTopButton(audioEnabled ? "🔊" : "🔇");
        audioButton.setContentDescription("Dźwięk");
        audioButton.setOnClickListener(v -> toggleAudio());
        topBar.addView(audioButton, new LinearLayout.LayoutParams(dp(46), dp(44)));

        TextView home = makeTopButton("NUC");
        home.setTextSize(12);
        home.setContentDescription("TvMad Home");
        home.setOnClickListener(v -> showHomeServerDialog());
        LinearLayout.LayoutParams homeLp = new LinearLayout.LayoutParams(dp(54), dp(44));
        homeLp.setMargins(dp(4), 0, dp(4), 0);
        topBar.addView(home, homeLp);

        TextView add = makeTopButton("＋");
        add.setTextSize(28);
        add.setContentDescription("Dodaj kamerę");
        add.setOnClickListener(v -> showCameraDialog(null));
        topBar.addView(add, new LinearLayout.LayoutParams(dp(46), dp(44)));

        grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        grid.setPadding(dp(5), dp(5), dp(5), dp(5));
        root.addView(grid, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
    }

    private TextView makeTopButton(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(20);
        t.setGravity(Gravity.CENTER);
        t.setBackground(makeRounded(Color.rgb(25,36,47), 12, Color.TRANSPARENT, 0));
        return t;
    }

    private void reloadCameras(boolean firstLoad) {
        cameras = store.load();
        syncPlayers();
        if (fullscreen && fullscreenId != null && store.find(fullscreenId) != null) {
            buildFullscreen();
        } else {
            fullscreen = false;
            fullscreenId = null;
            buildGrid();
        }
        updateTitle();
        CameraWidgetProvider.updateAll(this);

        if (firstLoad && pendingFullscreenId != null && store.find(pendingFullscreenId) != null) {
            String id = pendingFullscreenId;
            pendingFullscreenId = null;
            handler.postDelayed(() -> enterFullscreen(id), 250);
        }
    }

    private void syncPlayers() {
        List<String> valid = new ArrayList<>();
        for (CameraItem c : cameras) valid.add(c.id);
        List<String> existing = new ArrayList<>(players.keySet());
        for (String id : existing) {
            if (!valid.contains(id)) releasePlayer(id);
        }
        for (CameraItem c : cameras) {
            if (!players.containsKey(c.id)) players.put(c.id, createPlayer(c));
        }
    }

    private ExoPlayer createPlayer(CameraItem camera) {
        ExoPlayer player = new ExoPlayer.Builder(this).build();
        player.setVolume(0f);
        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                TextView s = statusViews.get(camera.id);
                if (s == null) return;
                if (state == Player.STATE_BUFFERING) setStatus(s, "Łączenie…", Color.rgb(255,193,7));
                else if (state == Player.STATE_READY) setStatus(s, "● LIVE", Color.rgb(33,212,163));
                else if (state == Player.STATE_ENDED) setStatus(s, "Ponowne łączenie…", Color.rgb(255,193,7));
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                TextView s = statusViews.get(camera.id);
                if (s != null) setStatus(s, "Brak sygnału • ponawiam", Color.rgb(255,110,110));
                scheduleReconnect(camera.id);
            }
        });
        startStream(camera, player);
        return player;
    }

    private void startStream(CameraItem camera, ExoPlayer player) {
        if (camera == null || player == null) return;
        if (camera.isHome()) {
            startHomeStream(camera, player);
            return;
        }
        try {
            MediaItem item = MediaItem.fromUri(Uri.parse(camera.url));
            RtspMediaSource source = new RtspMediaSource.Factory()
                    .setForceUseRtpTcp(true)
                    .createMediaSource(item);
            player.setMediaSource(source);
            player.prepare();
            player.play();
        } catch (Exception e) {
            scheduleReconnect(camera.id);
        }
    }

    private void startHomeStream(CameraItem camera, ExoPlayer player) {
        stopHomeSession(camera.id);
        TextView s = statusViews.get(camera.id);
        if (s != null) setStatus(s, "NUC • uruchamiam…", Color.rgb(255,193,7));
        homeClient.startCamera(camera, (session, error) -> {
            if (isFinishing() || isDestroyed()) return;
            CameraItem current = store.find(camera.id);
            ExoPlayer currentPlayer = players.get(camera.id);
            if (current == null || currentPlayer != player || !current.isHome()) {
                if (session != null) homeClient.stopSession(camera.serverBase, session.id);
                return;
            }
            if (error != null) {
                TextView status = statusViews.get(camera.id);
                if (status != null) setStatus(status, "NUC • " + shortError(error), Color.rgb(255,110,110));
                scheduleReconnect(camera.id);
                return;
            }
            try {
                homeSessions.put(camera.id, session);
                java.util.Map<String, String> headers = new java.util.HashMap<>();
                headers.put("Cookie", session.cookie);
                DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                        .setDefaultRequestProperties(headers)
                        .setConnectTimeoutMs(8000)
                        .setReadTimeoutMs(15000)
                        .setUserAgent("TvMad-Cam/0.2");
                HlsMediaSource source = new HlsMediaSource.Factory(http)
                        .createMediaSource(MediaItem.fromUri(session.playlist));
                player.setMediaSource(source);
                player.prepare();
                player.play();
            } catch (Exception e) {
                scheduleReconnect(camera.id);
            }
        });
    }

    private String shortError(String e) {
        if (e == null) return "błąd";
        String x = e.replace("\n", " ").trim();
        return x.length() > 34 ? x.substring(0, 34) + "…" : x;
    }

    private void scheduleReconnect(String cameraId) {
        handler.postDelayed(() -> {
            CameraItem current = store.find(cameraId);
            ExoPlayer player = players.get(cameraId);
            if (current != null && player != null) {
                if (current.isHome()) stopHomeSession(cameraId);
                startStream(current, player);
            }
        }, 2500);
    }

    private void setStatus(TextView view, String text, int color) {
        view.setText(text);
        view.setTextColor(color);
    }

    private void buildGrid() {
        showSystemUi();
        requestedOrientationForGrid();
        topBar.setVisibility(View.VISIBLE);
        grid.setVisibility(View.VISIBLE);
        grid.removeAllViews();
        statusViews.clear();
        tileViews.clear();

        for (Map.Entry<String, ExoPlayer> e : players.entrySet()) {
            e.getValue().setVolume(0f);
            e.getValue().play();
        }

        if (cameras.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("Brak kamer\n\n＋  dodaj RTSP     •     NUC  pobierz z TvMad Home");
            empty.setTextColor(Color.rgb(184,194,204));
            empty.setTextSize(18);
            empty.setGravity(Gravity.CENTER);
            grid.addView(empty, new LinearLayout.LayoutParams(-1, -1));
            return;
        }

        boolean landscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        int cols;
        if (cameras.size() == 1) cols = 1;
        else if (landscape && cameras.size() >= 5) cols = 3;
        else cols = 2;
        int rows = (int) Math.ceil(cameras.size() / (double) cols);

        int index = 0;
        for (int r = 0; r < rows; r++) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER);
            grid.addView(row, new LinearLayout.LayoutParams(-1, 0, 1f));

            for (int c = 0; c < cols; c++) {
                if (index < cameras.size()) {
                    CameraItem camera = cameras.get(index++);
                    FrameLayout tile = createTile(camera);
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1f);
                    lp.setMargins(dp(3), dp(3), dp(3), dp(3));
                    row.addView(tile, lp);
                } else {
                    View spacer = new View(this);
                    row.addView(spacer, new LinearLayout.LayoutParams(0, -1, 1f));
                }
            }
        }
    }

    private FrameLayout createTile(CameraItem camera) {
        FrameLayout tile = new FrameLayout(this);
        tile.setTag(camera.id);
        tile.setBackground(makeRounded(Color.BLACK, 12, Color.rgb(45,62,74), 1));
        tile.setClipToOutline(true);
        tileViews.put(camera.id, tile);

        PlayerView pv = new PlayerView(this);
        pv.setUseController(false);
        pv.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        pv.setShutterBackgroundColor(Color.BLACK);
        pv.setPlayer(players.get(camera.id));
        tile.addView(pv, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(7), dp(4), dp(4), dp(4));
        header.setBackgroundColor(Color.argb(170, 8, 13, 18));
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-1, dp(38), Gravity.TOP);
        tile.addView(header, hp);

        TextView drag = new TextView(this);
        drag.setText("≡");
        drag.setTextColor(Color.LTGRAY);
        drag.setTextSize(20);
        drag.setGravity(Gravity.CENTER);
        drag.setContentDescription("Przeciągnij, aby zmienić kolejność");
        header.addView(drag, new LinearLayout.LayoutParams(dp(32), -1));

        TextView name = new TextView(this);
        name.setText(camera.name + (camera.isHome() ? "  • NUC" : ""));
        name.setTextColor(Color.WHITE);
        name.setTextSize(14);
        name.setSingleLine(true);
        header.addView(name, new LinearLayout.LayoutParams(0, -1, 1f));

        TextView menu = new TextView(this);
        menu.setText("⋮");
        menu.setTextColor(Color.WHITE);
        menu.setTextSize(24);
        menu.setGravity(Gravity.CENTER);
        menu.setContentDescription("Opcje kamery");
        menu.setOnClickListener(v -> showTileMenu(camera));
        header.addView(menu, new LinearLayout.LayoutParams(dp(38), -1));

        TextView status = new TextView(this);
        status.setText("Łączenie…");
        status.setTextColor(Color.rgb(255,193,7));
        status.setTextSize(11);
        status.setPadding(dp(7), dp(3), dp(7), dp(3));
        status.setBackground(makeRounded(Color.argb(170, 8,13,18), 10, Color.TRANSPARENT, 0));
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-2, dp(26), Gravity.BOTTOM | Gravity.LEFT);
        sp.setMargins(dp(7), 0, 0, dp(7));
        tile.addView(status, sp);
        statusViews.put(camera.id, status);
        ExoPlayer currentPlayer = players.get(camera.id);
        if (currentPlayer != null) {
            int state = currentPlayer.getPlaybackState();
            if (state == Player.STATE_READY) setStatus(status, "● LIVE", Color.rgb(33,212,163));
            else if (state == Player.STATE_BUFFERING) setStatus(status, "Łączenie…", Color.rgb(255,193,7));
        }

        GestureDetector detector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }
            @Override public boolean onDoubleTap(MotionEvent e) {
                enterFullscreen(camera.id);
                return true;
            }
        });
        pv.setOnTouchListener((v, event) -> detector.onTouchEvent(event));

        drag.setOnLongClickListener(v -> {
            ClipData data = ClipData.newPlainText("camera", camera.id);
            View.DragShadowBuilder shadow = new View.DragShadowBuilder(tile);
            if (android.os.Build.VERSION.SDK_INT >= 24) tile.startDragAndDrop(data, shadow, camera.id, 0);
            else tile.startDrag(data, shadow, camera.id, 0);
            return true;
        });

        tile.setOnDragListener((v, event) -> handleDrop(tile, event));
        return tile;
    }

    private boolean handleDrop(FrameLayout target, DragEvent event) {
        if (event.getAction() == DragEvent.ACTION_DRAG_STARTED) return event.getLocalState() instanceof String;
        if (event.getAction() == DragEvent.ACTION_DRAG_ENTERED) {
            target.setAlpha(0.7f);
            return true;
        }
        if (event.getAction() == DragEvent.ACTION_DRAG_EXITED) {
            target.setAlpha(1f);
            return true;
        }
        if (event.getAction() == DragEvent.ACTION_DROP) {
            target.setAlpha(1f);
            Object local = event.getLocalState();
            String targetId = String.valueOf(target.getTag());
            if (local instanceof String && !targetId.equals(local)) {
                store.swap((String) local, targetId);
                cameras = store.load();
                buildGrid();
                CameraWidgetProvider.updateAll(this);
            }
            return true;
        }
        if (event.getAction() == DragEvent.ACTION_DRAG_ENDED) {
            target.setAlpha(1f);
            return true;
        }
        return true;
    }

    private void showTileMenu(CameraItem camera) {
        String[] options = camera.isHome()
                ? new String[]{"Odśwież z TvMad Home", "Usuń z aplikacji", "Otwórz fullscreen"}
                : new String[]{"Edytuj", "Usuń", "Otwórz fullscreen"};
        new AlertDialog.Builder(this)
                .setTitle(camera.name + (camera.isHome() ? "  •  NUC" : ""))
                .setItems(options, (dialog, which) -> {
                    if (camera.isHome()) {
                        if (which == 0) syncHomeCameras();
                        else if (which == 1) confirmDelete(camera);
                        else enterFullscreen(camera.id);
                    } else {
                        if (which == 0) showCameraDialog(camera);
                        else if (which == 1) confirmDelete(camera);
                        else enterFullscreen(camera.id);
                    }
                }).show();
    }

    private void showHomeServerDialog() {
        HomeServerClient.Settings saved = homeClient.loadSettings();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(6), dp(20), 0);

        EditText base = new EditText(this);
        base.setHint("https://tvmadhome.stream");
        base.setSingleLine(true);
        base.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        base.setText(saved.base);
        box.addView(base, new LinearLayout.LayoutParams(-1, dp(58)));

        EditText user = new EditText(this);
        user.setHint("Login TvMad Home");
        user.setSingleLine(true);
        user.setText(saved.username);
        box.addView(user, new LinearLayout.LayoutParams(-1, dp(58)));

        EditText pass = new EditText(this);
        pass.setHint("Hasło TvMad Home");
        pass.setSingleLine(true);
        pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        pass.setText(saved.password);
        box.addView(pass, new LinearLayout.LayoutParams(-1, dp(58)));

        TextView info = new TextView(this);
        info.setText("Aplikacja pobierze nazwy kamer z NUC-a. Lokalne adresy RTSP nie są przesyłane do telefonu. Stream idzie przez HTTPS/HLS z TvMad Home.");
        info.setTextColor(Color.LTGRAY);
        info.setTextSize(12);
        info.setPadding(0, dp(8), 0, dp(4));
        box.addView(info, new LinearLayout.LayoutParams(-1, -2));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("TvMad Home")
                .setView(box)
                .setNegativeButton("Anuluj", null)
                .setNeutralButton("Usuń kamery NUC", null)
                .setPositiveButton("Połącz i pobierz", null)
                .create();
        dialog.setOnShowListener(x -> {
            dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
                String b = HomeServerClient.normalizeBase(base.getText().toString());
                String u = user.getText().toString().trim();
                String pw = pass.getText().toString();
                if (!(b.startsWith("https://") || b.startsWith("http://"))) { base.setError("Adres musi zaczynać się od https://"); return; }
                if (u.isEmpty()) { user.setError("Podaj login"); return; }
                if (pw.isEmpty()) { pass.setError("Podaj hasło"); return; }
                homeClient.saveSettings(b, u, pw);
                dialog.getButton(DialogInterface.BUTTON_POSITIVE).setEnabled(false);
                dialog.getButton(DialogInterface.BUTTON_POSITIVE).setText("Łączenie…");
                homeClient.fetchCameras((list, error) -> {
                    if (error != null) {
                        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setEnabled(true);
                        dialog.getButton(DialogInterface.BUTTON_POSITIVE).setText("Połącz i pobierz");
                        Toast.makeText(this, "TvMad Home: " + error, Toast.LENGTH_LONG).show();
                        return;
                    }
                    store.replaceHomeCameras(b, list);
                    dialog.dismiss();
                    reloadCameras(false);
                    Toast.makeText(this, "Pobrano kamer: " + list.size(), Toast.LENGTH_SHORT).show();
                });
            });
            dialog.getButton(DialogInterface.BUTTON_NEUTRAL).setOnClickListener(v -> {
                String b = HomeServerClient.normalizeBase(base.getText().toString());
                store.removeHomeCameras(b);
                dialog.dismiss();
                reloadCameras(false);
                Toast.makeText(this, "Usunięto kamery TvMad Home z aplikacji", Toast.LENGTH_SHORT).show();
            });
        });
        dialog.show();
    }

    private void syncHomeCameras() {
        HomeServerClient.Settings s = homeClient.loadSettings();
        if (s.username.trim().isEmpty() || s.password.isEmpty()) { showHomeServerDialog(); return; }
        Toast.makeText(this, "Odświeżam kamery z TvMad Home…", Toast.LENGTH_SHORT).show();
        homeClient.fetchCameras((list, error) -> {
            if (error != null) { Toast.makeText(this, "TvMad Home: " + error, Toast.LENGTH_LONG).show(); return; }
            store.replaceHomeCameras(s.base, list);
            reloadCameras(false);
            Toast.makeText(this, "Pobrano kamer: " + list.size(), Toast.LENGTH_SHORT).show();
        });
    }

    private void showCameraDialog(CameraItem editing) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(6), dp(20), 0);

        EditText name = new EditText(this);
        name.setHint("Nazwa kamerki");
        name.setSingleLine(true);
        name.setText(editing == null ? "" : editing.name);
        box.addView(name, new LinearLayout.LayoutParams(-1, dp(58)));

        EditText url = new EditText(this);
        url.setHint("rtsp://użytkownik:hasło@adres:port/...");
        url.setSingleLine(false);
        url.setMinLines(2);
        url.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        url.setText(editing == null ? "" : editing.url);
        box.addView(url, new LinearLayout.LayoutParams(-1, dp(94)));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle(editing == null ? "Dodaj kamerę RTSP" : "Edytuj kamerę")
                .setView(box)
                .setNegativeButton("Anuluj", null)
                .setPositiveButton("Zapisz", null)
                .create();
        dialog.setOnShowListener(x -> dialog.getButton(DialogInterface.BUTTON_POSITIVE).setOnClickListener(v -> {
            String n = name.getText().toString().trim();
            String u = url.getText().toString().trim();
            if (n.isEmpty()) {
                name.setError("Podaj nazwę");
                return;
            }
            if (!u.toLowerCase().startsWith("rtsp://")) {
                url.setError("Adres musi zaczynać się od rtsp://");
                return;
            }
            if (editing == null) store.add(n, u);
            else {
                store.update(editing.id, n, u);
                releasePlayer(editing.id);
            }
            dialog.dismiss();
            reloadCameras(false);
        }));
        dialog.show();
    }

    private void confirmDelete(CameraItem camera) {
        new AlertDialog.Builder(this)
                .setTitle("Usunąć kamerę?")
                .setMessage(camera.name)
                .setNegativeButton("Anuluj", null)
                .setPositiveButton("Usuń", (d, w) -> {
                    releasePlayer(camera.id);
                    store.delete(camera.id);
                    reloadCameras(false);
                }).show();
    }

    private void enterFullscreen(String cameraId) {
        if (store.find(cameraId) == null) return;
        fullscreen = true;
        fullscreenId = cameraId;
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        buildFullscreen();
    }

    private void buildFullscreen() {
        CameraItem camera = store.find(fullscreenId);
        ExoPlayer selected = players.get(fullscreenId);
        if (camera == null || selected == null) {
            exitFullscreen();
            return;
        }
        hideSystemUi();
        topBar.setVisibility(View.GONE);
        grid.removeAllViews();
        statusViews.clear();

        for (Map.Entry<String, ExoPlayer> e : players.entrySet()) {
            if (e.getKey().equals(fullscreenId)) {
                e.getValue().setVolume(audioEnabled ? 1f : 0f);
                e.getValue().play();
            } else {
                e.getValue().pause();
                e.getValue().setVolume(0f);
            }
        }

        FrameLayout full = new FrameLayout(this);
        full.setBackgroundColor(Color.BLACK);
        grid.addView(full, new LinearLayout.LayoutParams(-1, -1));

        PlayerView pv = new PlayerView(this);
        pv.setUseController(false);
        pv.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        pv.setShutterBackgroundColor(Color.BLACK);
        pv.setPlayer(selected);
        full.addView(pv, new FrameLayout.LayoutParams(-1, -1));

        TextView label = new TextView(this);
        label.setText(camera.name + (audioEnabled ? "   🔊" : "   🔇"));
        label.setTextColor(Color.WHITE);
        label.setTextSize(16);
        label.setPadding(dp(12), dp(7), dp(12), dp(7));
        label.setBackground(makeRounded(Color.argb(150, 0,0,0), 12, Color.TRANSPARENT, 0));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(-2, dp(40), Gravity.TOP | Gravity.LEFT);
        lp.setMargins(dp(12), dp(12), 0, 0);
        full.addView(label, lp);

        GestureDetector detector = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(MotionEvent e) { return true; }
            @Override public boolean onDoubleTap(MotionEvent e) { exitFullscreen(); return true; }
            @Override public boolean onSingleTapConfirmed(MotionEvent e) {
                label.setVisibility(label.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
                return true;
            }
        });
        pv.setOnTouchListener((v, event) -> detector.onTouchEvent(event));
        handler.postDelayed(() -> { if (fullscreen && label.getParent() != null) label.setVisibility(View.GONE); }, 2500);
    }

    private void exitFullscreen() {
        fullscreen = false;
        fullscreenId = null;
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        buildGrid();
        updateTitle();
    }

    private void toggleAudio() {
        audioEnabled = !audioEnabled;
        getSharedPreferences("tvmad_cam", MODE_PRIVATE).edit().putBoolean("audio", audioEnabled).apply();
        audioButton.setText(audioEnabled ? "🔊" : "🔇");
        if (fullscreen && fullscreenId != null) {
            ExoPlayer p = players.get(fullscreenId);
            if (p != null) p.setVolume(audioEnabled ? 1f : 0f);
        }
        Toast.makeText(this, audioEnabled ? "Dźwięk w fullscreen: WŁ." : "Dźwięk w fullscreen: WYŁ.", Toast.LENGTH_SHORT).show();
    }

    private void updateTitle() {
        if (titleText != null) titleText.setText("TvMad Cam   •   " + cameras.size() + (cameras.size() == 1 ? " kamera" : " kamer"));
    }

    private void requestedOrientationForGrid() {
        if (!fullscreen && getRequestedOrientation() == ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        }
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        handler.postDelayed(() -> {
            if (fullscreen) buildFullscreen();
            else buildGrid();
        }, 120);
    }

    @Override
    public void onBackPressed() {
        if (fullscreen) exitFullscreen();
        else finish();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (!isChangingConfigurations()) {
            for (ExoPlayer p : players.values()) p.pause();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!fullscreen) {
            for (ExoPlayer p : players.values()) p.play();
        } else {
            ExoPlayer p = players.get(fullscreenId);
            if (p != null) p.play();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (!isChangingConfigurations()) {
            releaseAll();
            if (homeClient != null) homeClient.shutdown();
        }
    }

    private void releasePlayer(String id) {
        stopHomeSession(id);
        ExoPlayer p = players.remove(id);
        if (p != null) {
            try { p.stop(); } catch (Exception ignored) { }
            p.release();
        }
        statusViews.remove(id);
        tileViews.remove(id);
    }

    private void stopHomeSession(String cameraId) {
        HomeServerClient.StreamSession s = homeSessions.remove(cameraId);
        CameraItem c = store == null ? null : store.find(cameraId);
        if (s != null) homeClient.stopSession(c == null ? "" : c.serverBase, s.id);
    }

    private void releaseAll() {
        for (String id : new ArrayList<>(homeSessions.keySet())) stopHomeSession(id);
        for (ExoPlayer p : players.values()) {
            try { p.stop(); } catch (Exception ignored) { }
            p.release();
        }
        players.clear();
    }

    private void installSafeInsets() {
        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = 0, bottom = 0;
            if (!fullscreen) {
                if (android.os.Build.VERSION.SDK_INT >= 30) {
                    android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.statusBars() | WindowInsets.Type.displayCutout());
                    android.graphics.Insets nav = insets.getInsets(WindowInsets.Type.navigationBars());
                    top = bars.top;
                    bottom = nav.bottom;
                } else {
                    top = insets.getSystemWindowInsetTop();
                    bottom = insets.getSystemWindowInsetBottom();
                }
            }
            v.setPadding(0, top, 0, bottom);
            return insets;
        });
        root.requestApplyInsets();
    }

    private void hideSystemUi() {
        if (root != null) { root.setPadding(0,0,0,0); root.requestApplyInsets(); }
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    private void showSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        if (root != null) root.requestApplyInsets();
    }

    private GradientDrawable makeRounded(int fill, int radiusDp, int stroke, int strokeDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radiusDp));
        if (strokeDp > 0) d.setStroke(dp(strokeDp), stroke);
        return d;
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
