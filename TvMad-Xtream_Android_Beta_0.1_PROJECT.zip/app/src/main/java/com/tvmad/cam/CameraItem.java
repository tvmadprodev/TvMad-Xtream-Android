package com.tvmad.cam;

import org.json.JSONException;
import org.json.JSONObject;

public class CameraItem {
    public static final String SOURCE_RTSP = "rtsp";
    public static final String SOURCE_HOME = "home";

    public final String id;
    public String name;
    public String url;
    public String source;
    public String remoteId;
    public String serverBase;

    public CameraItem(String id, String name, String url) {
        this(id, name, url, SOURCE_RTSP, "", "");
    }

    public CameraItem(String id, String name, String url, String source, String remoteId, String serverBase) {
        this.id = id;
        this.name = name;
        this.url = url == null ? "" : url;
        this.source = SOURCE_HOME.equals(source) ? SOURCE_HOME : SOURCE_RTSP;
        this.remoteId = remoteId == null ? "" : remoteId;
        this.serverBase = serverBase == null ? "" : serverBase;
    }

    public boolean isHome() { return SOURCE_HOME.equals(source); }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("name", name);
        o.put("url", url);
        o.put("source", source);
        o.put("remoteId", remoteId);
        o.put("serverBase", serverBase);
        return o;
    }

    public static CameraItem fromJson(JSONObject o) {
        return new CameraItem(
                o.optString("id", java.util.UUID.randomUUID().toString()),
                o.optString("name", "Kamera"),
                o.optString("url", ""),
                o.optString("source", SOURCE_RTSP),
                o.optString("remoteId", ""),
                o.optString("serverBase", ""));
    }
}
