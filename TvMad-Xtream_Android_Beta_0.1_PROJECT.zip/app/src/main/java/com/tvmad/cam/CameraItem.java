package com.tvmad.cam;

import org.json.JSONException;
import org.json.JSONObject;

public class CameraItem {
    public final String id;
    public String name;
    public String url;

    public CameraItem(String id, String name, String url) {
        this.id = id;
        this.name = name;
        this.url = url;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject o = new JSONObject();
        o.put("id", id);
        o.put("name", name);
        o.put("url", url);
        return o;
    }

    public static CameraItem fromJson(JSONObject o) {
        return new CameraItem(
                o.optString("id", java.util.UUID.randomUUID().toString()),
                o.optString("name", "Kamera"),
                o.optString("url", ""));
    }
}
