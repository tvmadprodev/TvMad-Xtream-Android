package com.tvmad.cam;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;

public class CameraStore {
    private static final String PREFS = "tvmad_cam";
    private static final String KEY_CAMERAS = "cameras";
    private final SharedPreferences prefs;

    public CameraStore(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public List<CameraItem> load() {
        List<CameraItem> out = new ArrayList<>();
        String raw = prefs.getString(KEY_CAMERAS, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o != null) out.add(CameraItem.fromJson(o));
            }
        } catch (Exception ignored) { }
        return out;
    }

    public void save(List<CameraItem> cameras) {
        JSONArray arr = new JSONArray();
        try {
            for (CameraItem c : cameras) arr.put(c.toJson());
        } catch (Exception ignored) { }
        prefs.edit().putString(KEY_CAMERAS, arr.toString()).apply();
    }

    public CameraItem add(String name, String url) {
        List<CameraItem> list = load();
        CameraItem item = new CameraItem(UUID.randomUUID().toString(), name, url);
        list.add(item);
        save(list);
        return item;
    }

    public CameraItem find(String id) {
        if (id == null) return null;
        for (CameraItem c : load()) if (id.equals(c.id)) return c;
        return null;
    }

    public void update(String id, String name, String url) {
        List<CameraItem> list = load();
        for (CameraItem c : list) {
            if (c.id.equals(id)) {
                c.name = name;
                c.url = url;
                break;
            }
        }
        save(list);
    }

    public void delete(String id) {
        List<CameraItem> list = load();
        list.removeIf(c -> c.id.equals(id));
        save(list);
    }

    public void swap(String firstId, String secondId) {
        List<CameraItem> list = load();
        int a = -1, b = -1;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id.equals(firstId)) a = i;
            if (list.get(i).id.equals(secondId)) b = i;
        }
        if (a >= 0 && b >= 0 && a != b) {
            Collections.swap(list, a, b);
            save(list);
        }
    }
}
