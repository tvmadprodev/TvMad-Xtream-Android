package com.tvmad.connect;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.provider.Settings;
import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * Restarts TvMad Connect's display monitor after boot/update and when the USB-C/HDMI
 * connection becomes active. The user's main switch in Prefs remains the single source
 * of truth: if it was ON before reboot, the monitor comes back without opening the app.
 */
public class AutoStartReceiver extends BroadcastReceiver {
    private static final String TAG = "TvMadConnect";

    @Override
    public void onReceive(Context context, Intent intent) {
        final Context appContext = context.getApplicationContext();
        if (!Prefs.isEnabled(appContext)) return;
        if (!Settings.canDrawOverlays(appContext)) return;

        final BroadcastReceiver.PendingResult pending = goAsync();
        Thread t = new Thread(() -> {
            try {
                startMonitor(appContext);
            } finally {
                pending.finish();
            }
        }, "TvMad-AutoStart");
        t.setDaemon(true);
        t.start();
    }

    private static void startMonitor(Context context) {
        Intent service = new Intent(context, OverlayService.class)
                .setAction(OverlayService.ACTION_REFRESH);
        try {
            context.startService(service);
            Log.i(TAG, "Overlay monitor started automatically");
            return;
        } catch (Throwable directFailure) {
            Log.w(TAG, "Direct background service start blocked; trying granted root", directFailure);
        }

        // Android may reject a normal background-service start after BOOT_COMPLETED on
        // newer releases. This app already uses granted Magisk root for its overlay input
        // policy, so use ActivityManager through su only as a fallback. No DP/HDMI sysfs is
        // touched here.
        java.lang.Process process = null;
        try {
            String component = context.getPackageName() + "/.OverlayService";
            String command = "/system/bin/am startservice --user 0 -n " + component
                    + " -a " + OverlayService.ACTION_REFRESH;
            process = new ProcessBuilder("su", "-c", command)
                    .redirectErrorStream(true)
                    .start();
            StringBuilder out = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = r.readLine()) != null) {
                    if (out.length() > 0) out.append('\n');
                    out.append(line);
                }
            }
            int code = process.waitFor();
            if (code == 0) {
                Log.i(TAG, "Overlay monitor started automatically through root");
            } else {
                Log.e(TAG, "Root auto-start failed: " + code + " " + out);
            }
        } catch (Throwable t) {
            Log.e(TAG, "Auto-start failed", t);
        } finally {
            if (process != null) {
                try { process.destroy(); } catch (Throwable ignored) {}
            }
        }
    }
}
