package com.tvmad.connect;

import android.app.Activity;
import android.app.AppOpsManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Process;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQ_OVERLAY = 1001;

    private Switch mainSwitch;
    private Switch xtreamSwitch;
    private TextView status;
    private Button usageButton;
    private boolean openingSettings = false;
    private CompoundButton.OnCheckedChangeListener mainListener;
    private CompoundButton.OnCheckedChangeListener xtreamListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        root.setPadding(dp(28), dp(22), dp(28), dp(22));
        root.setBackgroundColor(Color.BLACK);

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.app_icon);
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(108), dp(108));
        iconLp.bottomMargin = dp(10);
        root.addView(icon, iconLp);

        TextView title = new TextView(this);
        title.setText("TvMad Connect");
        title.setTextColor(Color.WHITE);
        title.setTextSize(26f);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView subtitle = new TextView(this);
        subtitle.setText("AMOLED logo tylko na telefonie • TV zostaje na normalnym pulpicie");
        subtitle.setTextColor(Color.rgb(160, 170, 185));
        subtitle.setTextSize(14f);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        subLp.topMargin = dp(8);
        subLp.bottomMargin = dp(20);
        root.addView(subtitle, subLp);

        mainSwitch = new Switch(this);
        mainSwitch.setText("Logo TvMad Connect przy HDMI");
        mainSwitch.setTextColor(Color.WHITE);
        mainSwitch.setTextSize(19f);
        root.addView(mainSwitch, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        xtreamSwitch = new Switch(this);
        xtreamSwitch.setText("TvMad-Xtream ma pierwszeństwo");
        xtreamSwitch.setTextColor(Color.WHITE);
        xtreamSwitch.setTextSize(17f);
        LinearLayout.LayoutParams exLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        exLp.topMargin = dp(14);
        root.addView(xtreamSwitch, exLp);

        TextView exInfo = new TextView(this);
        exInfo.setText("ON: gdy uruchomisz TvMad-Xtream, logo Connect znika. Po wyjściu wraca automatycznie.");
        exInfo.setTextColor(Color.rgb(135, 145, 160));
        exInfo.setTextSize(13f);
        exInfo.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams exInfoLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        exInfoLp.topMargin = dp(6);
        root.addView(exInfo, exInfoLp);

        usageButton = new Button(this);
        usageButton.setText("Nadaj dostęp do użycia aplikacji");
        usageButton.setOnClickListener(v -> openUsageAccess());
        LinearLayout.LayoutParams usageLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        usageLp.topMargin = dp(16);
        root.addView(usageButton, usageLp);

        status = new TextView(this);
        status.setTextSize(14f);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        statusLp.topMargin = dp(18);
        root.addView(status, statusLp);

        setContentView(root);

        mainListener = (buttonView, checked) -> {
            Prefs.setEnabled(this, checked);
            if (checked) {
                if (!Settings.canDrawOverlays(this)) {
                    Prefs.setEnabled(this, false);
                    setSwitchWithoutCallback(mainSwitch, false, mainListener);
                    openOverlayPermission();
                    return;
                }
                if (Prefs.isXtreamPriority(this) && !hasUsageAccess()) {
                    openUsageAccess();
                    updateUi();
                    return;
                }
                startMonitorAndGoHome();
            } else {
                stopService(new Intent(this, OverlayService.class));
                updateUi();
            }
        };

        xtreamListener = (buttonView, checked) -> {
            Prefs.setXtreamPriority(this, checked);
            if (checked && !hasUsageAccess()) {
                openUsageAccess();
            }
            refreshService();
            updateUi();
        };

        mainSwitch.setOnCheckedChangeListener(mainListener);
        xtreamSwitch.setOnCheckedChangeListener(xtreamListener);
    }

    @Override
    protected void onResume() {
        super.onResume();
        openingSettings = false;
        // Podczas ustawień aplikacji logo nie zasłania własnego ekranu.
        Intent i = new Intent(this, OverlayService.class).setAction(OverlayService.ACTION_UI_OPEN);
        startService(i);
        updateUi();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (!openingSettings && Prefs.isEnabled(this)) {
            Intent i = new Intent(this, OverlayService.class).setAction(OverlayService.ACTION_UI_CLOSED);
            startService(i);
        }
    }

    private void updateUi() {
        setSwitchWithoutCallback(mainSwitch, Prefs.isEnabled(this), mainListener);
        setSwitchWithoutCallback(xtreamSwitch, Prefs.isXtreamPriority(this), xtreamListener);

        boolean usageNeeded = Prefs.isXtreamPriority(this) && !hasUsageAccess();
        usageButton.setVisibility(usageNeeded ? View.VISIBLE : View.GONE);

        if (!Settings.canDrawOverlays(this)) {
            status.setTextColor(Color.rgb(255, 170, 80));
            status.setText("Potrzebne uprawnienie: Wyświetlanie nad innymi aplikacjami");
        } else if (usageNeeded) {
            status.setTextColor(Color.rgb(255, 190, 90));
            status.setText("Nadaj Dostęp do użycia, aby TvMad-Xtream miał pierwszeństwo.");
        } else if (Prefs.isEnabled(this)) {
            status.setTextColor(Color.rgb(95, 210, 255));
            status.setText("ON • ustawienie zapamiętane");
        } else {
            status.setTextColor(Color.rgb(145, 150, 160));
            status.setText("OFF • normalny mirroring");
        }
    }

    private void setSwitchWithoutCallback(Switch sw, boolean checked,
                                          CompoundButton.OnCheckedChangeListener listener) {
        sw.setOnCheckedChangeListener(null);
        sw.setChecked(checked);
        sw.setOnCheckedChangeListener(listener);
    }

    private void openOverlayPermission() {
        openingSettings = true;
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
        startActivityForResult(intent, REQ_OVERLAY);
    }

    private void openUsageAccess() {
        openingSettings = true;
        try {
            Intent intent = new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Throwable t) {
            startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS));
        }
    }

    private boolean hasUsageAccess() {
        try {
            AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
            if (appOps == null) return false;
            int mode = appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(), getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Throwable t) {
            return false;
        }
    }

    private void refreshService() {
        if (Prefs.isEnabled(this) && Settings.canDrawOverlays(this)) {
            Intent i = new Intent(this, OverlayService.class).setAction(OverlayService.ACTION_REFRESH);
            startService(i);
        }
    }

    private void startMonitorAndGoHome() {
        Intent i = new Intent(this, OverlayService.class).setAction(OverlayService.ACTION_UI_CLOSED);
        startService(i);
        updateUi();
        moveTaskToBack(true);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OVERLAY && Settings.canDrawOverlays(this)) {
            Prefs.setEnabled(this, true);
            if (Prefs.isXtreamPriority(this) && !hasUsageAccess()) {
                openUsageAccess();
            } else {
                startMonitorAndGoHome();
            }
        }
        updateUi();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
