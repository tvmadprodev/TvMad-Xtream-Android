package com.tvmad.connect;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int REQ_OVERLAY = 1001;
    private Switch toggle;
    private TextView status;
    private boolean pendingEnable;
    private CompoundButton.OnCheckedChangeListener switchListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        int pad = dp(24);
        root.setPadding(pad, pad, pad, pad);
        root.setBackgroundColor(Color.BLACK);

        ImageView icon = new ImageView(this);
        icon.setImageResource(R.drawable.app_icon);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(120), dp(120));
        iconLp.bottomMargin = dp(16);
        root.addView(icon, iconLp);

        TextView title = new TextView(this);
        title.setText("TvMad Connect");
        title.setTextColor(Color.WHITE);
        title.setTextSize(26f);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView subtitle = new TextView(this);
        subtitle.setText("Po włączeniu pokaże AMOLED logo tylko na telefonie, gdy wykryje HDMI. TV zostaje na normalnym pulpicie.");
        subtitle.setTextColor(Color.rgb(180, 180, 180));
        subtitle.setTextSize(15f);
        subtitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        subLp.topMargin = dp(12);
        root.addView(subtitle, subLp);

        toggle = new Switch(this);
        toggle.setText("Włącz logo przy HDMI");
        toggle.setTextColor(Color.WHITE);
        toggle.setTextSize(20f);
        LinearLayout.LayoutParams toggleLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        toggleLp.topMargin = dp(28);
        root.addView(toggle, toggleLp);

        status = new TextView(this);
        status.setTextColor(Color.rgb(120, 210, 255));
        status.setTextSize(14f);
        status.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        statusLp.topMargin = dp(20);
        root.addView(status, statusLp);

        TextView hint = new TextView(this);
        hint.setText("Uwaga: przy pierwszym włączeniu trzeba zaakceptować uprawnienie do nakładki.");
        hint.setTextColor(Color.GRAY);
        hint.setTextSize(13f);
        hint.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams hintLp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hintLp.topMargin = dp(16);
        root.addView(hint, hintLp);

        setContentView(root);

        switchListener = (buttonView, isChecked) -> {
            if (isChecked) {
                enableFeature();
            } else {
                pendingEnable = false;
                Prefs.setEnabled(this, false);
                stopService(new Intent(this, OverlayService.class));
                updateStatus();
            }
        };
        toggle.setOnCheckedChangeListener(switchListener);
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean enabled = Prefs.isEnabled(this);
        toggle.setOnCheckedChangeListener(null);
        toggle.setChecked(enabled);
        toggle.setOnCheckedChangeListener(switchListener);

        if (pendingEnable && Settings.canDrawOverlays(this)) {
            pendingEnable = false;
            Prefs.setEnabled(this, true);
            startService(new Intent(this, OverlayService.class).setAction(OverlayService.ACTION_REFRESH));
            moveTaskToBack(true);
        }
        updateStatus();
    }

    private void enableFeature() {
        if (!Settings.canDrawOverlays(this)) {
            pendingEnable = true;
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivityForResult(intent, REQ_OVERLAY);
            updateStatus();
            return;
        }
        Prefs.setEnabled(this, true);
        startService(new Intent(this, OverlayService.class).setAction(OverlayService.ACTION_REFRESH));
        updateStatus();
        moveTaskToBack(true);
    }

    private void updateStatus() {
        if (!Settings.canDrawOverlays(this)) {
            status.setText("Status: potrzebne uprawnienie do nakładki.");
        } else if (Prefs.isEnabled(this)) {
            status.setText("Status: monitor HDMI włączony.");
        } else {
            status.setText("Status: monitor HDMI wyłączony.");
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_OVERLAY) {
            if (Settings.canDrawOverlays(this)) {
                Prefs.setEnabled(this, true);
                toggle.setOnCheckedChangeListener(null);
                toggle.setChecked(true);
                toggle.setOnCheckedChangeListener(switchListener);
                startService(new Intent(this, OverlayService.class).setAction(OverlayService.ACTION_REFRESH));
                moveTaskToBack(true);
            } else {
                pendingEnable = false;
                Prefs.setEnabled(this, false);
                toggle.setOnCheckedChangeListener(null);
                toggle.setChecked(false);
                toggle.setOnCheckedChangeListener(switchListener);
            }
            updateStatus();
        }
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
