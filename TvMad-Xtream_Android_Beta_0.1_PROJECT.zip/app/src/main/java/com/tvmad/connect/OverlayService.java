package com.tvmad.connect;

import android.app.AppOpsManager;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Process;
import android.provider.Settings;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;

import java.lang.reflect.Method;

public class OverlayService extends Service {
    public static final String ACTION_REFRESH = "com.tvmad.connect.action.REFRESH";
    public static final String ACTION_UI_OPEN = "com.tvmad.connect.action.UI_OPEN";
    public static final String ACTION_UI_CLOSED = "com.tvmad.connect.action.UI_CLOSED";

    private static final String TAG = "TvMadConnect";
    private static final String XTREAM_PACKAGE = "pl.tvmad.xtream.tv";

    private WindowManager windowManager;
    private View overlayView;
    private DisplayManager displayManager;
    private UsageStatsManager usageStatsManager;
    private Handler handler;
    private boolean uiOpen = false;

    private final DisplayManager.DisplayListener displayListener = new DisplayManager.DisplayListener() {
        @Override public void onDisplayAdded(int displayId) { scheduleRefresh(150); }
        @Override public void onDisplayRemoved(int displayId) { scheduleRefresh(150); }
        @Override public void onDisplayChanged(int displayId) { scheduleRefresh(150); }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        displayManager = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
        usageStatsManager = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
        if (displayManager != null) {
            displayManager.registerDisplayListener(displayListener, handler);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        if (ACTION_UI_OPEN.equals(action)) {
            uiOpen = true;
            removeOverlay();
        } else if (ACTION_UI_CLOSED.equals(action)) {
            uiOpen = false;
        }
        scheduleRefresh(60);
        return START_STICKY;
    }

    private void scheduleRefresh(long delayMs) {
        if (handler == null) return;
        handler.removeCallbacks(refreshRunnable);
        handler.postDelayed(refreshRunnable, delayMs);
    }

    private final Runnable refreshRunnable = new Runnable() {
        @Override
        public void run() {
            refreshState();
            if (Prefs.isEnabled(OverlayService.this)) {
                long next = isExternalDisplayConnected() ? 350L : 1200L;
                handler.postDelayed(this, next);
            }
        }
    };

    private void refreshState() {
        boolean enabled = Prefs.isEnabled(this);
        if (!enabled || !Settings.canDrawOverlays(this)) {
            removeOverlay();
            if (!enabled) stopSelf();
            return;
        }

        boolean hdmi = isExternalDisplayConnected();
        boolean xtreamOwnsPhone = Prefs.isXtreamPriority(this)
                && hasUsageAccess()
                && XTREAM_PACKAGE.equals(getForegroundPackage());

        boolean shouldShow = hdmi && !uiOpen && !xtreamOwnsPhone;
        if (shouldShow) {
            if (overlayView == null) showOverlay();
        } else {
            removeOverlay();
        }
    }

    private boolean isExternalDisplayConnected() {
        if (displayManager == null) return false;
        Display[] displays = displayManager.getDisplays();
        if (displays == null) return false;
        for (Display display : displays) {
            if (display == null) continue;
            if (display.getDisplayId() == Display.DEFAULT_DISPLAY) continue;
            if (display.getState() == Display.STATE_OFF) continue;
            return true;
        }
        return false;
    }

    private boolean hasUsageAccess() {
        try {
            AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
            if (appOps == null) return false;
            int mode = appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(), getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Throwable t) {
            return false;
        }
    }

    private String getForegroundPackage() {
        if (usageStatsManager == null) return null;
        try {
            long end = System.currentTimeMillis();
            UsageEvents events = usageStatsManager.queryEvents(end - 8000L, end);
            if (events == null) return null;
            UsageEvents.Event event = new UsageEvents.Event();
            String pkg = null;
            long newest = 0L;
            while (events.hasNextEvent()) {
                events.getNextEvent(event);
                int type = event.getEventType();
                if (type == UsageEvents.Event.ACTIVITY_RESUMED
                        || type == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                    if (event.getTimeStamp() >= newest) {
                        newest = event.getTimeStamp();
                        pkg = event.getPackageName();
                    }
                }
            }
            return pkg;
        } catch (Throwable t) {
            Log.w(TAG, "UsageStats foreground check failed", t);
            return null;
        }
    }

    private void showOverlay() {
        try {
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (windowManager == null) return;

            FrameLayout root = new FrameLayout(this);
            // ABSOLUTNIE CZARNE tło AMOLED. Bez alpha na całym oknie.
            root.setBackgroundColor(Color.BLACK);

            ImageView logo = new ImageView(this);
            logo.setImageResource(R.drawable.overlay_logo);
            logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
            // Lekko przyciemnione samo logo, nie tło.
            logo.setAlpha(0.74f);

            int pad = Math.round(18 * getResources().getDisplayMetrics().density);
            root.setPadding(pad, pad, pad, pad);
            root.addView(logo, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    Gravity.CENTER));

            int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                    | WindowManager.LayoutParams.FLAG_FULLSCREEN;

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    flags,
                    PixelFormat.OPAQUE);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.setTitle("TvMadConnectOverlay");

            // Dodatkowo chowamy paski systemowe, jeżeli ROM pozwoli overlayowi to zrobić.
            root.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

            overlayView = root;
            windowManager.addView(overlayView, lp);
            handler.postDelayed(this::applySkipScreenshot, 350L);
        } catch (Throwable t) {
            Log.e(TAG, "showOverlay failed", t);
        }
    }

    private void applySkipScreenshot() {
        if (overlayView == null) return;
        try {
            Method getViewRootImpl = View.class.getDeclaredMethod("getViewRootImpl");
            getViewRootImpl.setAccessible(true);
            Object viewRoot = getViewRootImpl.invoke(overlayView);
            if (viewRoot == null) throw new IllegalStateException("ViewRootImpl == null");

            Method getSurfaceControl = viewRoot.getClass().getDeclaredMethod("getSurfaceControl");
            getSurfaceControl.setAccessible(true);
            Object surfaceControl = getSurfaceControl.invoke(viewRoot);
            if (surfaceControl == null) throw new IllegalStateException("SurfaceControl == null");

            Class<?> scClass = Class.forName("android.view.SurfaceControl");
            Class<?> txClass = Class.forName("android.view.SurfaceControl$Transaction");
            Object tx = txClass.getDeclaredConstructor().newInstance();

            Method setSkip = txClass.getDeclaredMethod("setSkipScreenshot", scClass, boolean.class);
            setSkip.setAccessible(true);
            setSkip.invoke(tx, surfaceControl, true);

            Method apply = txClass.getDeclaredMethod("apply");
            apply.setAccessible(true);
            apply.invoke(tx);
            Log.i(TAG, "SUCCESS: SKIP_SCREENSHOT applied");
        } catch (Throwable t) {
            Log.e(TAG, "FAILED to apply SKIP_SCREENSHOT", t);
        }
    }

    private void removeOverlay() {
        if (windowManager != null && overlayView != null) {
            try { windowManager.removeView(overlayView); } catch (Throwable ignored) {}
        }
        overlayView = null;
    }

    @Override
    public void onDestroy() {
        if (displayManager != null) {
            try { displayManager.unregisterDisplayListener(displayListener); } catch (Throwable ignored) {}
        }
        if (handler != null) handler.removeCallbacksAndMessages(null);
        removeOverlay();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
