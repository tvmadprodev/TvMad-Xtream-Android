package com.tvmad.connect;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;

import java.lang.reflect.Method;

public class OverlayService extends Service {
    public static final String ACTION_REFRESH = "com.tvmad.connect.action.REFRESH";
    private static final String TAG = "TvMadConnect";

    private WindowManager windowManager;
    private View overlayView;
    private DisplayManager displayManager;
    private Handler handler;

    private final DisplayManager.DisplayListener displayListener = new DisplayManager.DisplayListener() {
        @Override public void onDisplayAdded(int displayId) { scheduleRefresh(); }
        @Override public void onDisplayRemoved(int displayId) { scheduleRefresh(); }
        @Override public void onDisplayChanged(int displayId) { scheduleRefresh(); }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        displayManager = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
        if (displayManager != null) {
            displayManager.registerDisplayListener(displayListener, handler);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        scheduleRefresh();
        return START_STICKY;
    }

    private void scheduleRefresh() {
        if (handler == null) return;
        handler.removeCallbacks(refreshRunnable);
        handler.postDelayed(refreshRunnable, 250);
    }

    private final Runnable refreshRunnable = this::refreshState;

    private void refreshState() {
        boolean enabled = Prefs.isEnabled(this);
        boolean canOverlay = Settings.canDrawOverlays(this);
        boolean hdmi = isExternalDisplayConnected();
        boolean shouldShow = enabled && canOverlay && hdmi;

        if (shouldShow) {
            if (overlayView == null) {
                showOverlay();
            }
        } else {
            removeOverlay();
            if (!enabled) stopSelf();
        }
    }

    private boolean isExternalDisplayConnected() {
        if (displayManager == null) return false;
        Display[] displays = displayManager.getDisplays();
        if (displays == null) return false;
        for (Display display : displays) {
            if (display == null) continue;
            if (display.getDisplayId() == Display.DEFAULT_DISPLAY) continue;
            if (display.getState() == Display.STATE_OFF) continue;
            return true;
        }
        return false;
    }

    private void showOverlay() {
        try {
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (windowManager == null) return;

            FrameLayout root = new FrameLayout(this);
            root.setBackgroundColor(Color.BLACK);
            root.setAlpha(0.96f);

            ImageView imageView = new ImageView(this);
            imageView.setImageResource(R.drawable.overlay_logo);
            imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
            imageView.setAdjustViewBounds(true);
            imageView.setAlpha(0.95f);

            int pad = Math.round(32 * getResources().getDisplayMetrics().density);
            root.setPadding(pad, pad, pad, pad);
            root.addView(imageView, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    Gravity.CENTER));

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.OPAQUE);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.setTitle("TvMadConnectOverlay");

            overlayView = root;
            windowManager.addView(overlayView, lp);

            handler.postDelayed(this::applySkipScreenshot, 450);
        } catch (Throwable t) {
            Log.e(TAG, "showOverlay failed", t);
        }
    }

    private void applySkipScreenshot() {
        if (overlayView == null) return;
        try {
            Method getViewRootImpl = View.class.getDeclaredMethod("getViewRootImpl");
            getViewRootImpl.setAccessible(true);
            Object viewRoot = getViewRootImpl.invoke(overlayView);
            if (viewRoot == null) throw new IllegalStateException("ViewRootImpl == null");

            Method getSurfaceControl = viewRoot.getClass().getDeclaredMethod("getSurfaceControl");
            getSurfaceControl.setAccessible(true);
            Object surfaceControl = getSurfaceControl.invoke(viewRoot);
            if (surfaceControl == null) throw new IllegalStateException("SurfaceControl == null");

            Class<?> scClass = Class.forName("android.view.SurfaceControl");
            Class<?> txClass = Class.forName("android.view.SurfaceControl$Transaction");
            Object tx = txClass.getDeclaredConstructor().newInstance();

            Method setSkip = txClass.getDeclaredMethod("setSkipScreenshot", scClass, boolean.class);
            setSkip.setAccessible(true);
            setSkip.invoke(tx, surfaceControl, true);

            Method apply = txClass.getDeclaredMethod("apply");
            apply.setAccessible(true);
            apply.invoke(tx);

            Log.i(TAG, "SUCCESS: SKIP_SCREENSHOT applied");
        } catch (Throwable t) {
            Log.e(TAG, "FAILED to apply SKIP_SCREENSHOT", t);
        }
    }

    private void removeOverlay() {
        if (windowManager != null && overlayView != null) {
            try {
                windowManager.removeView(overlayView);
            } catch (Throwable ignored) {
            }
        }
        overlayView = null;
    }

    @Override
    public void onDestroy() {
        if (displayManager != null) {
            try {
                displayManager.unregisterDisplayListener(displayListener);
            } catch (Throwable ignored) {}
        }
        if (handler != null) {
            handler.removeCallbacksAndMessages(null);
        }
        removeOverlay();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
