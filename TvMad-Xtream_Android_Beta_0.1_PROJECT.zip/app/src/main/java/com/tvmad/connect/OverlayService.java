package com.tvmad.connect;

import android.app.AppOpsManager;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.PorterDuff;
import android.hardware.display.DisplayManager;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.PointerIcon;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;

import java.lang.reflect.Method;

public class OverlayService extends Service {
    public static final String ACTION_REFRESH = "com.tvmad.connect.action.REFRESH";
    public static final String ACTION_UI_OPEN = "com.tvmad.connect.action.UI_OPEN";
    public static final String ACTION_UI_CLOSED = "com.tvmad.connect.action.UI_CLOSED";

    private static final String TAG = "TvMadConnect";
    private static final String XTREAM_PACKAGE = "pl.tvmad.xtream.tv";
    private static final String XTREAM_SPLASH_CLASS = "pl.tvmad.xtream.PhoneSplashActivity";

    private WindowManager windowManager;
    private View overlayView;
    private DisplayManager displayManager;
    private UsageStatsManager usageStatsManager;
    private Handler handler;
    private boolean uiOpen = false;

    private boolean xtreamPhoneSplashActive = false;
    private long usageCursorMs = 0L;

    private final DisplayManager.DisplayListener displayListener = new DisplayManager.DisplayListener() {
        @Override public void onDisplayAdded(int displayId) { scheduleRefresh(80); }
        @Override public void onDisplayRemoved(int displayId) { scheduleRefresh(80); }
        @Override public void onDisplayChanged(int displayId) { scheduleRefresh(80); }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        displayManager = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
        usageStatsManager = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
        if (displayManager != null) {
            displayManager.registerDisplayListener(displayListener, handler);
        }
        rebuildXtreamStateSinceBoot();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        if (ACTION_UI_OPEN.equals(action)) {
            uiOpen = true;
            removeOverlay();
        } else if (ACTION_UI_CLOSED.equals(action)) {
            uiOpen = false;
        }
        scheduleRefresh(30);
        return START_STICKY;
    }

    private void scheduleRefresh(long delayMs) {
        if (handler == null) return;
        handler.removeCallbacks(refreshRunnable);
        handler.postDelayed(refreshRunnable, delayMs);
    }

    private final Runnable refreshRunnable = new Runnable() {
        @Override
        public void run() {
            refreshState();
            if (Prefs.isEnabled(OverlayService.this)) {
                handler.postDelayed(this, isExternalDisplayConnected() ? 220L : 900L);
            }
        }
    };

    private void refreshState() {
        boolean enabled = Prefs.isEnabled(this);
        if (!enabled || !Settings.canDrawOverlays(this)) {
            removeOverlay();
            if (!enabled) stopSelf();
            return;
        }

        updateXtreamStateIncremental();

        boolean hdmi = isExternalDisplayConnected();
        boolean xtreamOwnsPhone = Prefs.isXtreamPriority(this)
                && hasUsageAccess()
                && xtreamPhoneSplashActive;

        boolean shouldShow = hdmi && !uiOpen && !xtreamOwnsPhone;
        if (shouldShow) {
            if (overlayView == null) showOverlay();
        } else {
            removeOverlay();
        }
    }

    private boolean isExternalDisplayConnected() {
        if (displayManager == null) return false;
        Display[] displays = displayManager.getDisplays();
        if (displays == null) return false;
        for (Display display : displays) {
            if (display == null) continue;
            if (display.getDisplayId() == Display.DEFAULT_DISPLAY) continue;
            if (!display.isValid()) continue;
            if (display.getState() == Display.STATE_OFF) continue;
            return true;
        }
        return false;
    }

    private boolean hasUsageAccess() {
        try {
            AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
            if (appOps == null) return false;
            int mode = appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(), getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * TvMad-Xtream ma na AMOLED własną PhoneSplashActivity. Nie sprawdzamy już
     * "ostatniej aplikacji na pierwszym planie", bo ruch air-mouse / Nova może zmienić
     * kolejność globalnych UsageEvents. Śledzimy WYŁĄCZNIE stan tej konkretnej Activity.
     */
    private void rebuildXtreamStateSinceBoot() {
        if (!hasUsageAccess() || usageStatsManager == null) {
            usageCursorMs = System.currentTimeMillis();
            xtreamPhoneSplashActive = false;
            return;
        }
        long now = System.currentTimeMillis();
        long bootWall = now - SystemClock.elapsedRealtime() - 5000L;
        xtreamPhoneSplashActive = false;
        scanXtreamEvents(Math.max(0L, bootWall), now);
        usageCursorMs = now;
    }

    private void updateXtreamStateIncremental() {
        if (!hasUsageAccess() || usageStatsManager == null) {
            xtreamPhoneSplashActive = false;
            usageCursorMs = System.currentTimeMillis();
            return;
        }
        long now = System.currentTimeMillis();
        if (usageCursorMs <= 0L || usageCursorMs > now) {
            rebuildXtreamStateSinceBoot();
            return;
        }
        scanXtreamEvents(Math.max(0L, usageCursorMs - 1000L), now);
        usageCursorMs = now;
    }

    private void scanXtreamEvents(long begin, long end) {
        try {
            UsageEvents events = usageStatsManager.queryEvents(begin, end);
            if (events == null) return;
            UsageEvents.Event event = new UsageEvents.Event();
            while (events.hasNextEvent()) {
                events.getNextEvent(event);
                if (!XTREAM_PACKAGE.equals(event.getPackageName())) continue;
                String cls = event.getClassName();
                if (cls == null || !XTREAM_SPLASH_CLASS.equals(cls)) continue;

                int type = event.getEventType();
                if (type == UsageEvents.Event.ACTIVITY_RESUMED
                        || type == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                    xtreamPhoneSplashActive = true;
                } else if (type == UsageEvents.Event.ACTIVITY_STOPPED) {
                    // PhoneSplashActivity może być chwilowo PAUSED/BACKGROUND, gdy fokus
                    // przechodzi między ekranem telefonu, HDMI albo systemowym oknem.
                    // To NIE oznacza wyjścia z TvMad-Xtream. Za koniec sesji uznajemy
                    // dopiero rzeczywiste zatrzymanie PhoneSplashActivity.
                    xtreamPhoneSplashActive = false;
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "UsageEvents scan failed", t);
        }
    }

    private void showOverlay() {
        try {
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (windowManager == null) return;

            FrameLayout root = new FrameLayout(this) {
                @Override
                protected void dispatchDraw(Canvas canvas) {
                    // Wyczyść CAŁY bufor okna do nieprzezroczystej czerni przed
                    // narysowaniem dzieci. PorterDuff.SRC gwarantuje alpha=255.
                    canvas.drawColor(Color.BLACK, PorterDuff.Mode.SRC);
                    super.dispatchDraw(canvas);
                }

                @Override
                public boolean isOpaque() {
                    return true;
                }
            };
            root.setBackgroundColor(Color.BLACK);
            root.setAlpha(1.0f);

            // Osobna, pełnoekranowa warstwa #000000. Alpha dotyczy wyłącznie logo.
            View black = new View(this);
            black.setBackgroundColor(Color.BLACK);
            black.setAlpha(1.0f);
            root.addView(black, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT));

            ImageView logo = new ImageView(this);
            logo.setImageResource(R.drawable.overlay_logo_transparent);
            logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
            logo.setAlpha(0.78f);
            int pad = Math.round(18f * getResources().getDisplayMetrics().density);
            FrameLayout.LayoutParams logoLp = new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    Gravity.CENTER);
            logo.setPadding(pad, pad, pad, pad);
            root.addView(logo, logoLp);

            try {
                PointerIcon none = PointerIcon.getSystemIcon(this, PointerIcon.TYPE_NULL);
                root.setPointerIcon(none);
                black.setPointerIcon(none);
                logo.setPointerIcon(none);
            } catch (Throwable ignored) {}

            int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                    | WindowManager.LayoutParams.FLAG_FULLSCREEN;

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    flags,
                    PixelFormat.OPAQUE);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.alpha = 1.0f;
            lp.dimAmount = 0f;
            lp.setTitle("TvMadConnectOverlay");

            root.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);

            overlayView = root;
            windowManager.addView(overlayView, lp);

            hideSystemPointerBestEffort();
            handler.postDelayed(this::applySkipScreenshot, 180L);
        } catch (Throwable t) {
            Log.e(TAG, "showOverlay failed", t);
            removeOverlay();
        }
    }

    private void applySkipScreenshot() {
        if (overlayView == null) return;
        try {
            Method getViewRootImpl = View.class.getDeclaredMethod("getViewRootImpl");
            getViewRootImpl.setAccessible(true);
            Object viewRoot = getViewRootImpl.invoke(overlayView);
            if (viewRoot == null) throw new IllegalStateException("ViewRootImpl == null");

            Method getSurfaceControl = viewRoot.getClass().getDeclaredMethod("getSurfaceControl");
            getSurfaceControl.setAccessible(true);
            Object surfaceControl = getSurfaceControl.invoke(viewRoot);
            if (surfaceControl == null) throw new IllegalStateException("SurfaceControl == null");

            Class<?> scClass = Class.forName("android.view.SurfaceControl");
            Class<?> txClass = Class.forName("android.view.SurfaceControl$Transaction");
            Object tx = txClass.getDeclaredConstructor().newInstance();

            Method setSkip = txClass.getDeclaredMethod("setSkipScreenshot", scClass, boolean.class);
            setSkip.setAccessible(true);
            setSkip.invoke(tx, surfaceControl, true);

            Method apply = txClass.getDeclaredMethod("apply");
            apply.setAccessible(true);
            apply.invoke(tx);

            Log.i(TAG, "SUCCESS: SKIP_SCREENSHOT applied");
        } catch (Throwable t) {
            Log.e(TAG, "FAILED to apply SKIP_SCREENSHOT", t);
        }
    }

    /**
     * Na FloydROM hidden API jest odblokowane przez wcześniejsze hidden_api_policy=1.
     * Gdy ROM udostępnia tę metodę, chowamy systemowy kursor bez blokowania zdarzeń
     * myszy, dzięki czemu sterowanie pulpitem na TV nadal przechodzi pod nakładkę.
     */
    private void hideSystemPointerBestEffort() {
        try {
            Class<?> cls = Class.forName("android.hardware.input.InputManager");
            Method getInstance = cls.getDeclaredMethod("getInstance");
            getInstance.setAccessible(true);
            Object im = getInstance.invoke(null);
            Method setPointerIconType = cls.getDeclaredMethod("setPointerIconType", int.class);
            setPointerIconType.setAccessible(true);
            setPointerIconType.invoke(im, PointerIcon.TYPE_NULL);
        } catch (Throwable t) {
            Log.w(TAG, "Global pointer hide unavailable", t);
        }
    }

    private void restoreSystemPointerBestEffort() {
        try {
            Class<?> cls = Class.forName("android.hardware.input.InputManager");
            Method getInstance = cls.getDeclaredMethod("getInstance");
            getInstance.setAccessible(true);
            Object im = getInstance.invoke(null);
            Method setPointerIconType = cls.getDeclaredMethod("setPointerIconType", int.class);
            setPointerIconType.setAccessible(true);
            setPointerIconType.invoke(im, PointerIcon.TYPE_DEFAULT);
        } catch (Throwable ignored) {}
    }

    private void removeOverlay() {
        if (windowManager != null && overlayView != null) {
            try { windowManager.removeView(overlayView); } catch (Throwable ignored) {}
        }
        overlayView = null;
        restoreSystemPointerBestEffort();
    }

    @Override
    public void onDestroy() {
        if (displayManager != null) {
            try { displayManager.unregisterDisplayListener(displayListener); } catch (Throwable ignored) {}
        }
        if (handler != null) handler.removeCallbacksAndMessages(null);
        removeOverlay();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
