package com.tvmad.connect;

import android.app.AppOpsManager;
import android.app.Service;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.provider.Settings;
import android.util.Log;
import android.view.Display;
import android.view.Gravity;
import android.view.PointerIcon;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;

import java.lang.reflect.Method;

public class OverlayService extends Service {
    public static final String ACTION_REFRESH = "com.tvmad.connect.action.REFRESH";
    public static final String ACTION_UI_OPEN = "com.tvmad.connect.action.UI_OPEN";
    public static final String ACTION_UI_CLOSED = "com.tvmad.connect.action.UI_CLOSED";

    private static final String TAG = "TvMadConnect";
    private static final String XTREAM_PACKAGE = "pl.tvmad.xtream.tv";
    private static final String XTREAM_SPLASH_CLASS = "pl.tvmad.xtream.PhoneSplashActivity";

    private WindowManager windowManager;
    private View overlayView;
    private DisplayManager displayManager;
    private UsageStatsManager usageStatsManager;
    private Handler handler;
    private boolean uiOpen = false;

    private boolean xtreamPhoneSplashActive = false;
    private long usageCursorMs = 0L;

    private final DisplayManager.DisplayListener displayListener = new DisplayManager.DisplayListener() {
        @Override public void onDisplayAdded(int displayId) { scheduleRefresh(80); }
        @Override public void onDisplayRemoved(int displayId) { scheduleRefresh(80); }
        @Override public void onDisplayChanged(int displayId) { scheduleRefresh(80); }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        handler = new Handler(Looper.getMainLooper());
        displayManager = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
        usageStatsManager = (UsageStatsManager) getSystemService(Context.USAGE_STATS_SERVICE);
        if (displayManager != null) {
            displayManager.registerDisplayListener(displayListener, handler);
        }
        rebuildXtreamStateSinceBoot();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        if (ACTION_UI_OPEN.equals(action)) {
            uiOpen = true;
            removeOverlay();
        } else if (ACTION_UI_CLOSED.equals(action)) {
            uiOpen = false;
        }
        scheduleRefresh(30);
        return START_STICKY;
    }

    private void scheduleRefresh(long delayMs) {
        if (handler == null) return;
        handler.removeCallbacks(refreshRunnable);
        handler.postDelayed(refreshRunnable, delayMs);
    }

    private final Runnable refreshRunnable = new Runnable() {
        @Override
        public void run() {
            refreshState();
            if (Prefs.isEnabled(OverlayService.this)) {
                handler.postDelayed(this, isExternalDisplayConnected() ? 220L : 900L);
            }
        }
    };

    private void refreshState() {
        boolean enabled = Prefs.isEnabled(this);
        if (!enabled || !Settings.canDrawOverlays(this)) {
            removeOverlay();
            if (!enabled) stopSelf();
            return;
        }

        updateXtreamStateIncremental();

        boolean hdmi = isExternalDisplayConnected();
        boolean xtreamOwnsPhone = Prefs.isXtreamPriority(this)
                && hasUsageAccess()
                && xtreamPhoneSplashActive;

        boolean shouldShow = hdmi && !uiOpen && !xtreamOwnsPhone;
        if (shouldShow) {
            if (overlayView == null) {
                showOverlay();
            } else {
                // Android 12/13 may restore the WindowState alpha after a WM traversal.
                // Keep the compositor surface itself fully opaque while leaving
                // FLAG_NOT_TOUCHABLE untouched so the TV/Nova input behaviour stays the same.
                applyOpaqueSkipScreenshotSurface();
            }
        } else {
            removeOverlay();
        }
    }

    private boolean isExternalDisplayConnected() {
        if (displayManager == null) return false;
        Display[] displays = displayManager.getDisplays();
        if (displays == null) return false;
        for (Display display : displays) {
            if (display == null) continue;
            if (display.getDisplayId() == Display.DEFAULT_DISPLAY) continue;
            if (!display.isValid()) continue;
            if (display.getState() == Display.STATE_OFF) continue;
            return true;
        }
        return false;
    }

    private boolean hasUsageAccess() {
        try {
            AppOpsManager appOps = (AppOpsManager) getSystemService(Context.APP_OPS_SERVICE);
            if (appOps == null) return false;
            int mode = appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(), getPackageName());
            return mode == AppOpsManager.MODE_ALLOWED;
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * TvMad-Xtream ma na AMOLED własną PhoneSplashActivity. Nie sprawdzamy już
     * "ostatniej aplikacji na pierwszym planie", bo ruch air-mouse / Nova może zmienić
     * kolejność globalnych UsageEvents. Śledzimy WYŁĄCZNIE stan tej konkretnej Activity.
     */
    private void rebuildXtreamStateSinceBoot() {
        if (!hasUsageAccess() || usageStatsManager == null) {
            usageCursorMs = System.currentTimeMillis();
            xtreamPhoneSplashActive = false;
            return;
        }
        long now = System.currentTimeMillis();
        long bootWall = now - SystemClock.elapsedRealtime() - 5000L;
        xtreamPhoneSplashActive = false;
        scanXtreamEvents(Math.max(0L, bootWall), now);
        usageCursorMs = now;
    }

    private void updateXtreamStateIncremental() {
        if (!hasUsageAccess() || usageStatsManager == null) {
            xtreamPhoneSplashActive = false;
            usageCursorMs = System.currentTimeMillis();
            return;
        }
        long now = System.currentTimeMillis();
        if (usageCursorMs <= 0L || usageCursorMs > now) {
            rebuildXtreamStateSinceBoot();
            return;
        }
        scanXtreamEvents(Math.max(0L, usageCursorMs - 1000L), now);
        usageCursorMs = now;
    }

    private void scanXtreamEvents(long begin, long end) {
        try {
            UsageEvents events = usageStatsManager.queryEvents(begin, end);
            if (events == null) return;
            UsageEvents.Event event = new UsageEvents.Event();
            while (events.hasNextEvent()) {
                events.getNextEvent(event);
                if (!XTREAM_PACKAGE.equals(event.getPackageName())) continue;
                String cls = event.getClassName();
                if (cls == null || !XTREAM_SPLASH_CLASS.equals(cls)) continue;

                int type = event.getEventType();
                if (type == UsageEvents.Event.ACTIVITY_RESUMED
                        || type == UsageEvents.Event.MOVE_TO_FOREGROUND) {
                    xtreamPhoneSplashActive = true;
                } else if (type == UsageEvents.Event.ACTIVITY_STOPPED) {
                    // PhoneSplashActivity może być chwilowo PAUSED/BACKGROUND, gdy fokus
                    // przechodzi między ekranem telefonu, HDMI albo systemowym oknem.
                    // To NIE oznacza wyjścia z TvMad-Xtream. Za koniec sesji uznajemy
                    // dopiero rzeczywiste zatrzymanie PhoneSplashActivity.
                    xtreamPhoneSplashActive = false;
                }
            }
        } catch (Throwable t) {
            Log.w(TAG, "UsageEvents scan failed", t);
        }
    }

    private void showOverlay() {
        try {
            windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
            if (windowManager == null) return;

            // Match the proven TvMad-Xtream AMOLED splash construction: the window root
            // is real #000000 and the full-screen image itself is an opaque RGB bitmap
            // with #000000 baked into its background. No view-level transparency is used.
            FrameLayout root = new FrameLayout(this);
            root.setBackgroundColor(Color.BLACK);
            root.setAlpha(1.0f);

            ImageView logo = new ImageView(this);
            logo.setImageResource(R.drawable.overlay_logo_transparent);
            // The approved replacement logo is a full AMOLED splash image with true
            // #000000 already baked into the bitmap. Render it edge-to-edge so the
            // phone shows the new crisp splash exactly as designed.
            logo.setScaleType(ImageView.ScaleType.FIT_XY);
            logo.setBackgroundColor(Color.BLACK);
            logo.setAlpha(1.0f);
            root.addView(logo, new FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    Gravity.CENTER));

            try {
                PointerIcon none = PointerIcon.getSystemIcon(this, PointerIcon.TYPE_NULL);
                root.setPointerIcon(none);
                logo.setPointerIcon(none);
            } catch (Throwable ignored) {}

            int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                    | WindowManager.LayoutParams.FLAG_FULLSCREEN;

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    flags,
                    PixelFormat.OPAQUE);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.alpha = 1.0f;
            lp.dimAmount = 0f;
            lp.setTitle("TvMadConnectOverlay");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            }

            applyImmersiveUi(root);
            root.setOnSystemUiVisibilityChangeListener(visibility -> applyImmersiveUi(root));

            overlayView = root;
            windowManager.addView(overlayView, lp);

            applyImmersiveUi(overlayView);
            overlayView.post(() -> applyImmersiveUi(overlayView));
            handler.postDelayed(() -> applyImmersiveUi(overlayView), 60L);
            handler.postDelayed(() -> applyImmersiveUi(overlayView), 180L);
            handler.postDelayed(() -> applyImmersiveUi(overlayView), 500L);
            handler.postDelayed(() -> applyImmersiveUi(overlayView), 1200L);

            hideSystemPointerBestEffort();

            // Android 12/13 caps a NOT_TOUCHABLE SAW to the maximum obscuring opacity
            // inside WindowManager. We must keep NOT_TOUCHABLE for the already-working
            // Nova/TV input path, so after WindowManager attaches the layer we restore
            // the compositor plane alpha directly on SurfaceControl. SKIP_SCREENSHOT is
            // applied in the same transaction, exactly to keep the overlay off HDMI.
            overlayView.post(this::applyOpaqueSkipScreenshotSurface);
            handler.postDelayed(this::applyOpaqueSkipScreenshotSurface, 60L);
            handler.postDelayed(this::applyOpaqueSkipScreenshotSurface, 180L);
            handler.postDelayed(this::applyOpaqueSkipScreenshotSurface, 500L);
            handler.postDelayed(this::applyOpaqueSkipScreenshotSurface, 1200L);
        } catch (Throwable t) {
            Log.e(TAG, "showOverlay failed", t);
            removeOverlay();
        }
    }

    private void applyImmersiveUi(View view) {
        if (view == null) return;
        try {
            view.setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        } catch (Throwable ignored) {}

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                WindowInsetsController controller = view.getWindowInsetsController();
                if (controller != null) {
                    controller.setSystemBarsBehavior(
                            WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                    controller.hide(WindowInsets.Type.statusBars()
                            | WindowInsets.Type.navigationBars()
                            | WindowInsets.Type.systemBars());
                }
            } catch (Throwable t) {
                Log.w(TAG, "Immersive hide failed", t);
            }
        }
    }

    private void applyOpaqueSkipScreenshotSurface() {
        if (overlayView == null) return;
        applyImmersiveUi(overlayView);
        try {
            Method getViewRootImpl = View.class.getDeclaredMethod("getViewRootImpl");
            getViewRootImpl.setAccessible(true);
            Object viewRoot = getViewRootImpl.invoke(overlayView);
            if (viewRoot == null) return;

            Method getSurfaceControl = viewRoot.getClass().getDeclaredMethod("getSurfaceControl");
            getSurfaceControl.setAccessible(true);
            Object surfaceControl = getSurfaceControl.invoke(viewRoot);
            if (surfaceControl == null) return;

            Class<?> scClass = Class.forName("android.view.SurfaceControl");
            Class<?> txClass = Class.forName("android.view.SurfaceControl$Transaction");
            Object tx = txClass.getDeclaredConstructor().newInstance();

            // WMS may have rewritten LayoutParams alpha to 0.8 because the overlay is
            // FLAG_NOT_TOUCHABLE. SurfaceControl plane alpha is the final compositor
            // value, so restore it to 1.0 after the WMS compatibility adjustment.
            Method setAlpha = txClass.getDeclaredMethod("setAlpha", scClass, float.class);
            setAlpha.setAccessible(true);
            setAlpha.invoke(tx, surfaceControl, 1.0f);

            Method setOpaque = txClass.getDeclaredMethod("setOpaque", scClass, boolean.class);
            setOpaque.setAccessible(true);
            setOpaque.invoke(tx, surfaceControl, true);

            Method setSkip = txClass.getDeclaredMethod("setSkipScreenshot", scClass, boolean.class);
            setSkip.setAccessible(true);
            setSkip.invoke(tx, surfaceControl, true);

            Method apply = txClass.getDeclaredMethod("apply");
            apply.setAccessible(true);
            apply.invoke(tx);
        } catch (Throwable t) {
            Log.e(TAG, "FAILED to enforce opaque SKIP_SCREENSHOT surface", t);
        }
    }

    /**
     * Na FloydROM hidden API jest odblokowane przez wcześniejsze hidden_api_policy=1.
     * Gdy ROM udostępnia tę metodę, chowamy systemowy kursor bez blokowania zdarzeń
     * myszy, dzięki czemu sterowanie pulpitem na TV nadal przechodzi pod nakładkę.
     */
    private void hideSystemPointerBestEffort() {
        try {
            Class<?> cls = Class.forName("android.hardware.input.InputManager");
            Method getInstance = cls.getDeclaredMethod("getInstance");
            getInstance.setAccessible(true);
            Object im = getInstance.invoke(null);
            Method setPointerIconType = cls.getDeclaredMethod("setPointerIconType", int.class);
            setPointerIconType.setAccessible(true);
            setPointerIconType.invoke(im, PointerIcon.TYPE_NULL);
        } catch (Throwable t) {
            Log.w(TAG, "Global pointer hide unavailable", t);
        }
    }

    private void restoreSystemPointerBestEffort() {
        try {
            Class<?> cls = Class.forName("android.hardware.input.InputManager");
            Method getInstance = cls.getDeclaredMethod("getInstance");
            getInstance.setAccessible(true);
            Object im = getInstance.invoke(null);
            Method setPointerIconType = cls.getDeclaredMethod("setPointerIconType", int.class);
            setPointerIconType.setAccessible(true);
            setPointerIconType.invoke(im, PointerIcon.TYPE_DEFAULT);
        } catch (Throwable ignored) {}
    }

    private void removeOverlay() {
        if (windowManager != null && overlayView != null) {
            try { windowManager.removeView(overlayView); } catch (Throwable ignored) {}
        }
        overlayView = null;
        restoreSystemPointerBestEffort();
    }

    @Override
    public void onDestroy() {
        if (displayManager != null) {
            try { displayManager.unregisterDisplayListener(displayListener); } catch (Throwable ignored) {}
        }
        if (handler != null) handler.removeCallbacksAndMessages(null);
        removeOverlay();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
