package com.tvmad.connect;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

/** Device-specific software HDMI/DisplayPort control for the rooted Galaxy S9+ / Exynos9810. */
public final class HdmiControl {
    private static final String DP_LINK = "/sys/class/dp_sec/link";
    private static final String DP_TEST = "/sys/class/dp_sec/dp_test";

    private HdmiControl() {}

    /**
     * Toggle the Samsung DP link itself.
     *
     * On the Exynos9810 Samsung DP driver the link node is the cleanest control:
     *   0 = HPD/link low (disconnect external display)
     *   9 = HPD/link high (reconnect external display)
     *
     * Unlike framebuffer blanking this is reversible and does not leave the Android
     * display registered while only the scanout is black.  Most importantly, this
     * method is called ONLY from an explicit widget press.  OverlayService never
     * re-applies it from display callbacks or polling, preventing HPD/reboot loops.
     */
    public static Result setEnabled(boolean enabled) {
        StringBuilder command = new StringBuilder();

        command.append("LINK='").append(DP_LINK).append("'; ");
        command.append("if [ -e \"$LINK\" ]; then ");
        if (enabled) {
            command.append("if echo 9 > \"$LINK\" 2>/dev/null; then echo OK_LINK_ON; exit 0; fi; ");
        } else {
            command.append("if echo 0 > \"$LINK\" 2>/dev/null; then echo OK_LINK_OFF; exit 0; fi; ");
        }
        command.append("fi; ");

        // Compatibility fallback for kernels exposing only Samsung's dp_test hook.
        // This is deliberately ONE-SHOT: never call it from DisplayListener/polling.
        command.append("DP='").append(DP_TEST).append("'; ");
        command.append("if [ -e \"$DP\" ]; then ");
        if (enabled) {
            command.append("if echo 0 > \"$DP\" 2>/dev/null; then echo OK_DP_ON; exit 0; fi; ");
        } else {
            command.append("if echo 6 > \"$DP\" 2>/dev/null; then echo OK_DP_OFF; exit 0; fi; ");
        }
        command.append("fi; echo NO_DP_CONTROL; exit 44");

        return runRoot(command.toString());
    }

    private static Result runRoot(String command) {
        java.lang.Process process = null;
        StringBuilder output = new StringBuilder();
        try {
            process = new ProcessBuilder("su", "-c", command)
                    .redirectErrorStream(true)
                    .start();

            final java.lang.Process p = process;
            Thread readerThread = new Thread(() -> {
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(p.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        synchronized (output) {
                            if (output.length() > 0) output.append('\n');
                            output.append(line);
                        }
                    }
                } catch (Throwable ignored) {}
            }, "TvMad-HdmiRootReader");
            readerThread.setDaemon(true);
            readerThread.start();

            if (!process.waitFor(5, TimeUnit.SECONDS)) {
                process.destroyForcibly();
                return new Result(-2, "TIMEOUT");
            }
            try { readerThread.join(250L); } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            synchronized (output) {
                return new Result(process.exitValue(), output.toString());
            }
        } catch (Throwable t) {
            return new Result(-1, t.toString());
        } finally {
            if (process != null) {
                try { process.destroy(); } catch (Throwable ignored) {}
            }
        }
    }

    public static final class Result {
        public final int exitCode;
        public final String output;

        Result(int exitCode, String output) {
            this.exitCode = exitCode;
            this.output = output;
        }

        public boolean isSuccess() {
            return exitCode == 0;
        }
    }
}
