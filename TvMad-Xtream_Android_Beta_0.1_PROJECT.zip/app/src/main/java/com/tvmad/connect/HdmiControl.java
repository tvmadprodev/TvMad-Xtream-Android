package com.tvmad.connect;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

/** Device-specific software HDMI/DisplayPort control for the rooted Galaxy S9+ / Apollo kernel. */
public final class HdmiControl {
    private static final String DP_TEST = "/sys/class/dp_sec/dp_test";

    private HdmiControl() {}

    public static Result setEnabled(boolean enabled) {
        /*
         * Samsung's Exynos9810 DisplayPort driver exposes dp_test on this device.
         * Its own help reports:
         *   0: HPD test
         *   6: unplug work test
         *
         * OFF therefore asks the driver to run its real unplug path. ON runs the
         * driver's HPD test, which re-evaluates the still physically connected
         * adapter and rebuilds the DisplayPort link. A framebuffer blank/unblank
         * path is kept only as a conservative fallback for ROM/kernel variants.
         */
        StringBuilder command = new StringBuilder();
        command.append("DP='").append(DP_TEST).append("'; ");
        command.append("if [ -e \"$DP\" ]; then ");
        if (enabled) {
            command.append("if echo 0 > \"$DP\" 2>/dev/null; then ")
                    .append("sleep 0.20; echo OK_DP_HPD; exit 0; fi; ");
        } else {
            command.append("if echo 6 > \"$DP\" 2>/dev/null; then ")
                    .append("sleep 0.20; echo OK_DP_UNPLUG; exit 0; fi; ");
        }
        command.append("fi; ");

        // Fallback: power down/up only non-primary framebuffer(s). Never touch fb0.
        command.append("FOUND=0; ");
        command.append("for B in /sys/class/graphics/fb1/blank /sys/class/graphics/fb2/blank /sys/class/graphics/fb3/blank; do ")
                .append("[ -e \"$B\" ] || continue; FOUND=1; ");
        if (enabled) {
            command.append("echo 0 > \"$B\" 2>/dev/null || true; ");
        } else {
            command.append("echo 4 > \"$B\" 2>/dev/null || true; ");
        }
        command.append("done; ")
                .append("if [ \"$FOUND\" = 1 ]; then echo OK_FB; exit 0; fi; ")
                .append("echo NO_DP_CONTROL; exit 44");

        return runRoot(command.toString());
    }

    private static Result runRoot(String command) {
        java.lang.Process process = null;
        StringBuilder output = new StringBuilder();
        try {
            process = new ProcessBuilder("su", "-c", command)
                    .redirectErrorStream(true)
                    .start();

            final java.lang.Process p = process;
            Thread readerThread = new Thread(() -> {
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(p.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        synchronized (output) {
                            if (output.length() > 0) output.append('\n');
                            output.append(line);
                        }
                    }
                } catch (Throwable ignored) {}
            }, "TvMad-HdmiRootReader");
            readerThread.setDaemon(true);
            readerThread.start();

            if (!process.waitFor(5, TimeUnit.SECONDS)) {
                process.destroyForcibly();
                return new Result(-2, "TIMEOUT");
            }
            try { readerThread.join(250L); } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            synchronized (output) {
                return new Result(process.exitValue(), output.toString());
            }
        } catch (Throwable t) {
            return new Result(-1, t.toString());
        } finally {
            if (process != null) {
                try { process.destroy(); } catch (Throwable ignored) {}
            }
        }
    }

    public static final class Result {
        public final int exitCode;
        public final String output;

        Result(int exitCode, String output) {
            this.exitCode = exitCode;
            this.output = output;
        }

        public boolean isSuccess() {
            return exitCode == 0;
        }
    }
}
