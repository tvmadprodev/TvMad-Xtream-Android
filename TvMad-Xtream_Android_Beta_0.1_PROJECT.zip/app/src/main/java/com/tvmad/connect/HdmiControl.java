package com.tvmad.connect;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;

/** Device-specific software HPD control for the rooted Galaxy S9+ / Apollo kernel. */
public final class HdmiControl {
    private static final String DP_LINK = "/sys/class/dp_sec/link";

    private HdmiControl() {}

    public static Result setEnabled(boolean enabled) {
        String value = enabled ? "9" : "0";
        String command = "if [ -e " + DP_LINK + " ]; then "
                + "if echo " + value + " > " + DP_LINK + "; then echo OK; exit 0; "
                + "else echo WRITE_FAIL; exit 45; fi; "
                + "else echo MISSING; exit 44; fi";
        return runRoot(command);
    }

    private static Result runRoot(String command) {
        java.lang.Process process = null;
        StringBuilder output = new StringBuilder();
        try {
            process = new ProcessBuilder("su", "-c", command)
                    .redirectErrorStream(true)
                    .start();

            final java.lang.Process p = process;
            Thread readerThread = new Thread(() -> {
                try (BufferedReader reader = new BufferedReader(
                        new InputStreamReader(p.getInputStream()))) {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        synchronized (output) {
                            if (output.length() > 0) output.append('\n');
                            output.append(line);
                        }
                    }
                } catch (Throwable ignored) {}
            }, "TvMad-HdmiRootReader");
            readerThread.setDaemon(true);
            readerThread.start();

            if (!process.waitFor(5, TimeUnit.SECONDS)) {
                process.destroyForcibly();
                return new Result(-2, "TIMEOUT");
            }
            try { readerThread.join(250L); } catch (InterruptedException ignored) {
                Thread.currentThread().interrupt();
            }
            synchronized (output) {
                return new Result(process.exitValue(), output.toString());
            }
        } catch (Throwable t) {
            return new Result(-1, t.toString());
        } finally {
            if (process != null) {
                try { process.destroy(); } catch (Throwable ignored) {}
            }
        }
    }

    public static final class Result {
        public final int exitCode;
        public final String output;

        Result(int exitCode, String output) {
            this.exitCode = exitCode;
            this.output = output;
        }

        public boolean isSuccess() {
            return exitCode == 0;
        }
    }
}
