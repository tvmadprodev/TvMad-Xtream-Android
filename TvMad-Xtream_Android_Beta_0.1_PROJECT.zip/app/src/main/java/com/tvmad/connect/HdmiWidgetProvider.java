package com.tvmad.connect;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.RemoteViews;
import android.widget.Toast;

public class HdmiWidgetProvider extends AppWidgetProvider {
    private static final String TAG = "TvMadConnect";
    private static final String ACTION_TOGGLE_HDMI = "com.tvmad.connect.action.TOGGLE_HDMI";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            updateWidget(context, appWidgetManager, appWidgetId,
                    Prefs.isHdmiSoftwareEnabled(context), null);
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (intent == null || !ACTION_TOGGLE_HDMI.equals(intent.getAction())) return;

        final Context appContext = context.getApplicationContext();
        final BroadcastReceiver.PendingResult pendingResult = goAsync();
        final boolean targetEnabled = !Prefs.isHdmiSoftwareEnabled(appContext);

        Thread worker = new Thread(() -> {
            boolean previousEnabled = Prefs.isHdmiSoftwareEnabled(appContext);
            try {
                // Save the requested state before the kernel write. This prevents the
                // OverlayService display listener from seeing the old OFF value during an
                // HDMI-ON hotplug event and immediately switching HPD low again.
                Prefs.setHdmiSoftwareEnabled(appContext, targetEnabled);
                HdmiControl.Result result = HdmiControl.setEnabled(targetEnabled);
                if (result.isSuccess()) {
                    updateAllWidgets(appContext, targetEnabled, null);

                    // The external display add/remove normally triggers OverlayService's
                    // DisplayListener. This refresh is only a best-effort fast path when the
                    // service is already alive; failure here must never affect the HDMI toggle.
                    try {
                        appContext.startService(new Intent(appContext, OverlayService.class)
                                .setAction(OverlayService.ACTION_REFRESH));
                    } catch (Throwable ignored) {}
                } else {
                    Prefs.setHdmiSoftwareEnabled(appContext, previousEnabled);
                    Log.e(TAG, "HDMI widget command failed: "
                            + result.exitCode + " " + result.output);
                    updateAllWidgets(appContext, previousEnabled, "ERR");
                    new Handler(Looper.getMainLooper()).post(() -> Toast.makeText(
                            appContext,
                            "TvMad Connect: nie udało się przełączyć HDMI (sprawdź uprawnienia root).",
                            Toast.LENGTH_SHORT).show());
                }
            } catch (Throwable t) {
                Prefs.setHdmiSoftwareEnabled(appContext, previousEnabled);
                Log.e(TAG, "HDMI widget unexpected failure", t);
                updateAllWidgets(appContext, previousEnabled, "ERR");
            } finally {
                pendingResult.finish();
            }
        }, "TvMad-HdmiWidget");
        worker.setDaemon(true);
        worker.start();
    }

    private static void updateAllWidgets(Context context, boolean enabled, String overrideText) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(
                new ComponentName(context, HdmiWidgetProvider.class));
        for (int id : ids) {
            updateWidget(context, manager, id, enabled, overrideText);
        }
    }

    private static void updateWidget(Context context, AppWidgetManager manager,
                                     int appWidgetId, boolean enabled, String overrideText) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_hdmi);
        String stateText = overrideText != null ? overrideText : (enabled ? "● ON" : "○ OFF");
        views.setTextViewText(R.id.widget_toggle, stateText);
        views.setTextColor(R.id.widget_toggle,
                overrideText != null
                        ? Color.rgb(255, 150, 100)
                        : (enabled ? Color.rgb(80, 220, 255) : Color.rgb(170, 175, 185)));
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            views.setCompoundButtonChecked(R.id.widget_toggle, enabled);
        }

        Intent toggleIntent = new Intent(context, HdmiWidgetProvider.class)
                .setAction(ACTION_TOGGLE_HDMI)
                .putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, appWidgetId);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                context,
                appWidgetId,
                toggleIntent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, pendingIntent);
        views.setOnClickPendingIntent(R.id.widget_toggle, pendingIntent);
        manager.updateAppWidget(appWidgetId, views);
    }
}
