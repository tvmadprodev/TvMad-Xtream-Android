package com.tvmad.connect;

import android.content.Context;

public final class Prefs {
    private static final String PREFS = "tvmad_connect_prefs";
    private static final String KEY_ENABLED = "enabled";
    private static final String KEY_XTREAM_PRIORITY = "xtream_priority";

    private Prefs() {}

    public static boolean isEnabled(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(KEY_ENABLED, false);
    }

    public static void setEnabled(Context context, boolean value) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_ENABLED, value).apply();
    }

    public static boolean isXtreamPriority(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getBoolean(KEY_XTREAM_PRIORITY, true);
    }

    public static void setXtreamPriority(Context context, boolean value) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putBoolean(KEY_XTREAM_PRIORITY, value).apply();
    }
}
