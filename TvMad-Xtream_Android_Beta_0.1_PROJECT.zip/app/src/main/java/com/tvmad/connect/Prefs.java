package com.tvmad.connect;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    private static final String PREFS = "tvmad_connect_prefs";
    private static final String KEY_ENABLED = "enabled";

    private Prefs() {}

    public static boolean isEnabled(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_ENABLED, false);
    }

    public static void setEnabled(Context context, boolean value) {
        SharedPreferences.Editor e = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit();
        e.putBoolean(KEY_ENABLED, value);
        e.apply();
    }
}
