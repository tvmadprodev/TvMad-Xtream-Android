package pl.tvmad.galaxy
import android.content.Context
import android.graphics.*
import android.view.View
import kotlin.math.*

class GalaxyBackdropView(c:Context):View(c){
    private val p=Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(c:Canvas){
        val w=width.toFloat(); val h=height.toFloat()
        p.shader=LinearGradient(0f,0f,0f,h,intArrayOf(Color.rgb(3,8,25),Color.rgb(7,18,52),Color.rgb(14,5,42)),null,Shader.TileMode.CLAMP);c.drawRect(0f,0f,w,h,p);p.shader=null
        p.color=Color.argb(170,35,95,255); c.drawCircle(w*.82f,h*.14f,h*.20f,p); p.color=Color.argb(120,130,45,245); c.drawCircle(w*.76f,h*.27f,h*.28f,p)
        p.color=Color.argb(170,255,255,255); val r=java.util.Random(42); repeat(90){val x=r.nextFloat()*w;val y=r.nextFloat()*h*.55f;val s=if(it%13==0)2.2f else 1.1f;c.drawCircle(x,y,s,p)}
        val path=Path();path.moveTo(0f,h*.50f);var x=0f;while(x<=w){val y=h*.48f-(sin(x/w*18f)+sin(x/w*7f)*.7f)*h*.065f;path.lineTo(x,y);x+=w/28f};path.lineTo(w,h);path.lineTo(0f,h);path.close();p.color=Color.rgb(4,10,25);c.drawPath(path,p)
        p.shader=LinearGradient(0f,h*.55f,0f,h,Color.argb(90,60,30,180),Color.BLACK,Shader.TileMode.CLAMP);c.drawRect(0f,h*.52f,w,h,p);p.shader=null
    }
}
