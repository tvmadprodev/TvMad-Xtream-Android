package pl.tvmad.galaxy
import java.lang.ref.WeakReference
object PhoneCommandBridge {
    private var phone=WeakReference<PhoneStandbyActivity>(null)
    fun attach(a:PhoneStandbyActivity){phone=WeakReference(a)}
    fun detach(a:PhoneStandbyActivity){if(phone.get()===a)phone=WeakReference<PhoneStandbyActivity>(null)}
    fun openPackage(pkg:String):Boolean { val a=phone.get()?:return false; a.runOnUiThread{a.openPackageFromLauncher(pkg)}; return true }
    fun openSettings():Boolean { val a=phone.get()?:return false; a.runOnUiThread{a.openSettingsFromLauncher()}; return true }
}
