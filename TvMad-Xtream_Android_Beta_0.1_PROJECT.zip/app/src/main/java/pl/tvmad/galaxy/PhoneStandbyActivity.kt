package pl.tvmad.galaxy

import android.app.Activity
import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Display
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.PointerIcon
import android.view.View
import android.view.WindowManager
import android.graphics.*
import android.widget.FrameLayout
import android.widget.Toast
import java.lang.ref.WeakReference

/**
 * Host kept on the Galaxy S9+ AMOLED while the real launcher runs on HDMI.
 * The HDMI display on Samsung can be destroyed/recreated during mode changes, so display
 * removal is deliberately debounced instead of immediately closing the app.
 */
class PhoneStandbyActivity : Activity(), DisplayManager.DisplayListener {
    companion object {
        private const val TAG = "TvMadGalaxyDisplay"
        private const val START_DELAY_MS = 900L
        private const val DISPLAY_STABLE_MS = 1600L
        private var active = WeakReference<PhoneStandbyActivity>(null)

        fun isHostActive(): Boolean {
            val a = active.get() ?: return false
            return !a.isFinishing && !a.isDestroyed
        }
    }

    private lateinit var dm: DisplayManager
    private val h = Handler(Looper.getMainLooper())
    private var routed = false
    private var routedDisplayId = -1
    private var externalApp = false
    private var noHdmiToastShown = false

    private val initialRoute = Runnable { routeToBestDisplay() }
    private val verifyAfterDisplayChange = Runnable {
        if (isFinishing || isDestroyed || externalApp) return@Runnable
        val d = findExternalDisplay()
        if (d == null) {
            Log.i(TAG, "HDMI really gone after debounce")
            sendBroadcast(Intent("pl.tvmad.galaxy.CLOSE_EXTERNAL").setPackage(packageName))
            finishAndRemoveTask()
        } else if (!routed || routedDisplayId != d.displayId) {
            Log.i(TAG, "HDMI stable/recreated id=${d.displayId}; routing again")
            routed = false
            routedDisplayId = -1
            launchExternal(d)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        active = WeakReference(this)
        PhoneCommandBridge.attach(this)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.apply { screenBrightness = 0.05f }
        immersive()
        buildUi()

        dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        dm.registerDisplayListener(this, h)
        logDisplays("onCreate")

        // Keep the monitor alive for future HDMI hot-plug events. It no longer relaunches
        // this Activity while it is already active, so it cannot create the old start loop.
        runCatching { startService(Intent(this, HdmiMonitorService::class.java)) }

        h.postDelayed(initialRoute, START_DELAY_MS)
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(LogoView(this), FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        try { window.decorView.pointerIcon = PointerIcon.getSystemIcon(this, PointerIcon.TYPE_NULL) } catch (_: Throwable) {}
    }

    private fun immersive() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    private fun findExternalDisplay(): Display? {
        dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION).firstOrNull {
            it.displayId != Display.DEFAULT_DISPLAY && it.isValid && it.state != Display.STATE_OFF
        }?.let { return it }
        return dm.displays.firstOrNull {
            it.displayId != Display.DEFAULT_DISPLAY && it.isValid && it.state != Display.STATE_OFF
        }
    }

    private fun routeToBestDisplay() {
        if (isFinishing || isDestroyed || externalApp) return
        val d = findExternalDisplay()
        if (d == null) {
            if (!intent.getBooleanExtra("auto_hdmi", false) && !noHdmiToastShown) {
                noHdmiToastShown = true
                Toast.makeText(this, "Podłącz HDMI", Toast.LENGTH_SHORT).show()
                h.postDelayed({ if (findExternalDisplay() == null && !isFinishing) finish() }, 900L)
            }
            return
        }
        noHdmiToastShown = false
        if (routed && routedDisplayId == d.displayId) return
        launchExternal(d)
    }

    private fun launchExternal(display: Display) {
        if (isFinishing || isDestroyed || externalApp) return
        val i = Intent(this, TvLauncherActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("tvmad_galaxy_external", true)
            .putExtra("tvmad_galaxy_display_id", display.displayId)
        try {
            val o = ActivityOptions.makeBasic()
            o.setLaunchDisplayId(display.displayId)
            startActivity(i, o.toBundle())
            routed = true
            routedDisplayId = display.displayId
            Log.i(TAG, "TvLauncherActivity requested on display ${display.displayId} ${display.name}")
        } catch (t: Throwable) {
            // IMPORTANT: do not call su/waitFor on the UI thread. The previous beta could ANR here.
            routed = false
            routedDisplayId = -1
            Log.e(TAG, "External launcher start failed", t)
            Toast.makeText(this, "Nie udało się uruchomić launchera na HDMI", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDisplayAdded(displayId: Int) {
        Log.i(TAG, "onDisplayAdded id=$displayId")
        h.removeCallbacks(verifyAfterDisplayChange)
        h.postDelayed(verifyAfterDisplayChange, 450L)
    }

    override fun onDisplayChanged(displayId: Int) {
        Log.i(TAG, "onDisplayChanged id=$displayId")
        if (!externalApp) {
            h.removeCallbacks(verifyAfterDisplayChange)
            h.postDelayed(verifyAfterDisplayChange, 450L)
        }
    }

    override fun onDisplayRemoved(displayId: Int) {
        Log.i(TAG, "onDisplayRemoved id=$displayId routed=$routedDisplayId")
        if (displayId == routedDisplayId) {
            routed = false
            routedDisplayId = -1
        }
        // Samsung may recreate the HDMI Display during a mode/layer-stack change. Never close
        // immediately; wait until the HDMI state is stable.
        h.removeCallbacks(verifyAfterDisplayChange)
        h.postDelayed(verifyAfterDisplayChange, DISPLAY_STABLE_MS)
    }

    override fun onResume() {
        super.onResume()
        immersive()
        if (externalApp) {
            externalApp = false
            routed = false
            routedDisplayId = -1
            h.postDelayed({ routeToBestDisplay() }, 800L)
        }
    }

    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (routed && ExternalInputBridge.hasTarget()) {
            if (e.keyCode in listOf(KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_VOLUME_DOWN, KeyEvent.KEYCODE_VOLUME_MUTE)) {
                return super.dispatchKeyEvent(e)
            }
            ExternalInputBridge.dispatchKey(e)
            return true
        }
        if (!routed && e.action == KeyEvent.ACTION_DOWN &&
            (e.keyCode == KeyEvent.KEYCODE_DPAD_CENTER || e.keyCode == KeyEvent.KEYCODE_ENTER)) {
            routeToBestDisplay()
            return true
        }
        return super.dispatchKeyEvent(e)
    }

    override fun dispatchGenericMotionEvent(e: MotionEvent): Boolean {
        if (routed && ExternalInputBridge.hasTarget() && ExternalInputBridge.isMouse(e)) {
            ExternalInputBridge.dispatchMouse(e, window.decorView.width, window.decorView.height, false)
            return true
        }
        return super.dispatchGenericMotionEvent(e)
    }

    override fun dispatchTouchEvent(e: MotionEvent): Boolean {
        if (routed && ExternalInputBridge.hasTarget() && ExternalInputBridge.isMouse(e)) {
            ExternalInputBridge.dispatchMouse(e, window.decorView.width, window.decorView.height, true)
            return true
        }
        return super.dispatchTouchEvent(e)
    }

    fun openPackageFromLauncher(pkg: String) {
        val launch = packageManager.getLaunchIntentForPackage(pkg) ?: run {
            Toast.makeText(this, "Nie można uruchomić aplikacji", Toast.LENGTH_SHORT).show()
            return
        }
        externalApp = true
        routed = false
        routedDisplayId = -1
        sendBroadcast(Intent("pl.tvmad.galaxy.CLOSE_EXTERNAL").setPackage(packageName))
        h.postDelayed({
            try { startActivity(launch) }
            catch (_: Throwable) { externalApp = false; routeToBestDisplay() }
        }, 300L)
    }

    fun openSettingsFromLauncher() {
        externalApp = true
        routed = false
        routedDisplayId = -1
        sendBroadcast(Intent("pl.tvmad.galaxy.CLOSE_EXTERNAL").setPackage(packageName))
        h.postDelayed({
            try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
            catch (_: Throwable) { externalApp = false; routeToBestDisplay() }
        }, 300L)
    }

    private fun logDisplays(where: String) {
        runCatching {
            dm.displays.forEach { d ->
                Log.i(TAG, "$where display id=${d.displayId} name=${d.name} state=${d.state} flags=0x${Integer.toHexString(d.flags)}")
            }
        }
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        PhoneCommandBridge.detach(this)
        try { dm.unregisterDisplayListener(this) } catch (_: Throwable) {}
        if (active.get() === this) active = WeakReference<PhoneStandbyActivity>(null)
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) immersive()
    }
}

private class LogoView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        super.onDraw(cv)
        val w = width.toFloat(); val h = height.toFloat()
        cv.drawColor(Color.BLACK)
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f
        p.shader = LinearGradient(w*.34f,h*.32f,w*.67f,h*.68f,Color.rgb(40,190,255),Color.rgb(160,70,255),Shader.TileMode.CLAMP)
        cv.drawOval(RectF(w*.32f,h*.25f,w*.68f,h*.75f),p)
        p.shader = null; p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create(Typeface.DEFAULT,Typeface.BOLD); p.textSize = h*.16f; p.color = Color.WHITE
        cv.drawText("TvMad",w*.45f,h*.54f,p)
        p.color = Color.rgb(77,215,255); cv.drawText("Galaxy",w*.62f,h*.54f,p)
        p.typeface = Typeface.DEFAULT; p.textSize = h*.055f; p.color = Color.rgb(120,160,190)
        cv.drawText("HDMI connected",w*.5f,h*.64f,p)
    }
}
