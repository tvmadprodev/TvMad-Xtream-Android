package pl.tvmad.galaxy

import android.app.Activity
import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.*
import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.widget.FrameLayout
import android.widget.TextView

class PhoneStandbyActivity : Activity(), DisplayManager.DisplayListener {
    private lateinit var dm: DisplayManager
    private val h=Handler(Looper.getMainLooper())
    private var routed=false
    private var externalApp=false
    override fun onCreate(b: Bundle?) { super.onCreate(b); PhoneCommandBridge.attach(this); startService(Intent(this,HdmiMonitorService::class.java)); window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); window.attributes=window.attributes.apply{screenBrightness=.05f}; immersive(); buildUi(); dm=getSystemService(Context.DISPLAY_SERVICE) as DisplayManager; dm.registerDisplayListener(this,h); h.postDelayed({route()},400) }
    private fun buildUi(){ val root=FrameLayout(this); root.setBackgroundColor(Color.BLACK); root.addView(LogoView(this),FrameLayout.LayoutParams(-1,-1)); setContentView(root); try{window.decorView.pointerIcon=PointerIcon.getSystemIcon(this,PointerIcon.TYPE_NULL)}catch(_:Throwable){} }
    private fun immersive(){ @Suppress("DEPRECATION") window.decorView.systemUiVisibility=5894 or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY }
    private fun ext(): Display? = dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION).firstOrNull{it.displayId!=Display.DEFAULT_DISPLAY&&it.isValid&&it.state!=Display.STATE_OFF} ?: dm.displays.firstOrNull{it.displayId!=Display.DEFAULT_DISPLAY&&it.isValid&&it.state!=Display.STATE_OFF}
    private fun route(){ if(externalApp)return; val d=ext(); if(d==null){ if(!intent.getBooleanExtra("auto_hdmi",false)){ android.widget.Toast.makeText(this,"Podłącz HDMI",android.widget.Toast.LENGTH_SHORT).show(); h.postDelayed({finish()},700)}; return }; if(routed)return; val i=Intent(this,TvLauncherActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP); try{ val o=ActivityOptions.makeBasic(); o.setLaunchDisplayId(d.displayId); startActivity(i,o.toBundle()); routed=true }catch(_:Throwable){ RootLaunch.launchActivity(this,"pl.tvmad.galaxy/.TvLauncherActivity",d.displayId); routed=true } }
    override fun dispatchKeyEvent(e: KeyEvent):Boolean { if(routed&&ExternalInputBridge.hasTarget()){ if(e.keyCode in listOf(KeyEvent.KEYCODE_VOLUME_UP,KeyEvent.KEYCODE_VOLUME_DOWN,KeyEvent.KEYCODE_VOLUME_MUTE)) return super.dispatchKeyEvent(e); ExternalInputBridge.dispatchKey(e); return true }; return super.dispatchKeyEvent(e) }
    override fun dispatchGenericMotionEvent(e:MotionEvent):Boolean { if(routed&&ExternalInputBridge.hasTarget()&&ExternalInputBridge.isMouse(e)){ExternalInputBridge.dispatchMouse(e,window.decorView.width,window.decorView.height,false);return true};return super.dispatchGenericMotionEvent(e)}
    override fun dispatchTouchEvent(e:MotionEvent):Boolean { if(routed&&ExternalInputBridge.hasTarget()&&ExternalInputBridge.isMouse(e)){ExternalInputBridge.dispatchMouse(e,window.decorView.width,window.decorView.height,true);return true};return super.dispatchTouchEvent(e)}
    override fun onDisplayAdded(id:Int){h.postDelayed({route()},250)}; override fun onDisplayChanged(id:Int){if(!routed)h.postDelayed({route()},200)}; override fun onDisplayRemoved(id:Int){ if(ext()==null) finishAndRemoveTask() }
    override fun onResume(){ super.onResume(); immersive(); if(externalApp){ externalApp=false; routed=false; h.postDelayed({route()},450) } }
    fun openPackageFromLauncher(pkg:String){
        val launch=packageManager.getLaunchIntentForPackage(pkg) ?: run { android.widget.Toast.makeText(this,"Nie można uruchomić aplikacji",android.widget.Toast.LENGTH_SHORT).show(); return }
        externalApp=true; routed=false
        sendBroadcast(Intent("pl.tvmad.galaxy.CLOSE_EXTERNAL").setPackage(packageName))
        h.postDelayed({ try { startActivity(launch) } catch(t:Throwable){ externalApp=false; route() } },220)
    }
    fun openSettingsFromLauncher(){
        externalApp=true; routed=false
        sendBroadcast(Intent("pl.tvmad.galaxy.CLOSE_EXTERNAL").setPackage(packageName))
        h.postDelayed({ try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) } catch(t:Throwable){ externalApp=false; route() } },220)
    }
    override fun onDestroy(){PhoneCommandBridge.detach(this);try{dm.unregisterDisplayListener(this)}catch(_:Throwable){}; super.onDestroy()}
    override fun onWindowFocusChanged(f:Boolean){super.onWindowFocusChanged(f);if(f)immersive()}
}

private class LogoView(c:Context):View(c){ private val p=Paint(Paint.ANTI_ALIAS_FLAG); override fun onDraw(cv:Canvas){super.onDraw(cv); val w=width.toFloat(); val h=height.toFloat(); cv.drawColor(Color.BLACK); p.style=Paint.Style.STROKE;p.strokeWidth=3f;p.shader=LinearGradient(w*.34f,h*.32f,w*.67f,h*.68f,Color.rgb(40,190,255),Color.rgb(160,70,255),Shader.TileMode.CLAMP);cv.drawOval(RectF(w*.32f,h*.25f,w*.68f,h*.75f),p);p.shader=null;p.style=Paint.Style.FILL;p.textAlign=Paint.Align.CENTER;p.typeface=Typeface.create(Typeface.DEFAULT,Typeface.BOLD);p.textSize=h*.16f;p.color=Color.WHITE;cv.drawText("TvMad",w*.45f,h*.54f,p);p.color=Color.rgb(77,215,255);cv.drawText("Galaxy",w*.62f,h*.54f,p);p.typeface=Typeface.DEFAULT;p.textSize=h*.055f;p.color=Color.rgb(120,160,190);cv.drawText("HDMI connected",w*.5f,h*.64f,p)} }
