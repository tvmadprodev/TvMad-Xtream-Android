package pl.tvmad.galaxy

import android.app.Activity
import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Display
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.PointerIcon
import android.view.View
import android.view.WindowManager
import android.graphics.*
import android.widget.FrameLayout
import android.widget.Toast
import java.lang.ref.WeakReference

/**
 * Phone-side host for the Galaxy S9+ HDMI build.
 *
 * IMPORTANT: the HDMI routing path is intentionally kept as close as possible to the proven
 * PhoneSplashActivity from TvMad-Xtream 1.24.  The phone Activity stays alive on display 0,
 * while TvLauncherActivity is started on the external display with ActivityOptions.
 */
class PhoneStandbyActivity : Activity(), DisplayManager.DisplayListener {
    companion object {
        private const val TAG = "TvMadGalaxyDisplay"
        private const val START_DELAY_MS = 850L
        private var activeInstance: WeakReference<PhoneStandbyActivity>? = null

        fun isHostActive(): Boolean {
            val a = activeInstance?.get() ?: return false
            return !a.isFinishing && !a.isDestroyed
        }

        fun closePhoneHost() {
            val a = activeInstance?.get() ?: return
            a.runOnUiThread {
                if (!a.isFinishing && !a.isDestroyed) a.finishAndRemoveTask()
            }
            activeInstance = null
        }
    }

    private lateinit var displayManager: DisplayManager
    private val handler = Handler(Looper.getMainLooper())
    private var routed = false
    private var noHdmiToastShown = false
    private val initialRoute = Runnable { routeToBestDisplay() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activeInstance = WeakReference(this)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.apply { screenBrightness = 0.05f }
        setContentView(buildPhoneUi())
        immersive()
        hidePhoneMouseCursor()

        displayManager = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        displayManager.displays.forEach { d ->
            Log.i(TAG, "visible display id=${d.displayId} name=${d.name} state=${d.state} flags=0x${Integer.toHexString(d.flags)}")
        }
        displayManager.registerDisplayListener(this, handler)
        handler.postDelayed(initialRoute, START_DELAY_MS)
    }

    private fun buildPhoneUi(): View = FrameLayout(this).apply {
        setBackgroundColor(Color.BLACK)
        addView(LogoView(this@PhoneStandbyActivity), FrameLayout.LayoutParams(-1, -1))
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { displayManager.unregisterDisplayListener(this) } catch (_: Throwable) {}
        if (activeInstance?.get() === this) activeInstance = null
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            immersive()
            hidePhoneMouseCursor()
        }
    }

    private fun hidePhoneMouseCursor() {
        try { window.decorView.pointerIcon = PointerIcon.getSystemIcon(this, PointerIcon.TYPE_NULL) }
        catch (_: Throwable) {}
    }

    private fun immersive() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    private fun findExternalDisplay(): Display? {
        val presentation = displayManager.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION)
        presentation.firstOrNull {
            it.displayId != Display.DEFAULT_DISPLAY && it.isValid && it.state != Display.STATE_OFF
        }?.let { return it }

        return displayManager.displays.firstOrNull {
            it.displayId != Display.DEFAULT_DISPLAY && it.isValid && it.state != Display.STATE_OFF
        }
    }

    private fun routeToBestDisplay() {
        if (routed || isFinishing || isDestroyed) return
        val external = findExternalDisplay()
        if (external != null) {
            launchExternal(external)
        } else {
            if (!noHdmiToastShown) {
                noHdmiToastShown = true
                Toast.makeText(this, "Podłącz HDMI", Toast.LENGTH_SHORT).show()
            }
            // Keep the app simple and deterministic when HDMI is absent.  The monitor service is
            // started only now (no external display), so it cannot interfere with a manual HDMI start.
            startMonitorSafely()
            handler.postDelayed({
                if (!routed && findExternalDisplay() == null && !isFinishing && !isDestroyed) finish()
            }, 1000L)
        }
    }

    private fun launchExternal(display: Display) {
        val intent = Intent(this, TvLauncherActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("tvmad_galaxy_external", true)
            .putExtra("tvmad_galaxy_display_id", display.displayId)

        try {
            val options = ActivityOptions.makeBasic()
            options.setLaunchDisplayId(display.displayId)
            startActivity(intent, options.toBundle())
            routed = true
            noHdmiToastShown = false
            Log.i(TAG, "TvLauncherActivity requested on external display id=${display.displayId} name=${display.name}")

            // Do not start the monitor while the external Activity is being created.  The previous
            // betas started extra HDMI logic during this exact window.  Start it much later, after
            // the proven two-Activity route has had time to settle.
            handler.postDelayed({ if (!isFinishing && !isDestroyed) startMonitorSafely() }, 5000L)
        } catch (t: Throwable) {
            Log.e(TAG, "External display launch failed", t)
            routed = false
            Toast.makeText(this, "Nie udało się uruchomić launchera na HDMI", Toast.LENGTH_LONG).show()
        }
    }

    private fun startMonitorSafely() {
        runCatching {
            val i = Intent(this, HdmiMonitorService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        }.onFailure { Log.w(TAG, "HDMI monitor start skipped", it) }
    }

    override fun onDisplayAdded(displayId: Int) {
        if (!routed) {
            handler.removeCallbacks(initialRoute)
            handler.postDelayed({ routeToBestDisplay() }, 350L)
        }
    }

    override fun onDisplayChanged(displayId: Int) {
        if (!routed) {
            handler.removeCallbacks(initialRoute)
            handler.postDelayed({ routeToBestDisplay() }, 250L)
        }
    }

    override fun onDisplayRemoved(displayId: Int) {
        // Intentionally do nothing here.  This is exactly the stable behaviour used by TvMad-Xtream.
        // Samsung/FloydROM can recreate the HDMI Display while assigning its layer stack.
        Log.i(TAG, "onDisplayRemoved id=$displayId (ignored)")
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (routed && ExternalInputBridge.hasExternalTarget()) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_VOLUME_UP,
                KeyEvent.KEYCODE_VOLUME_DOWN,
                KeyEvent.KEYCODE_VOLUME_MUTE -> return super.dispatchKeyEvent(event)
            }
            ExternalInputBridge.dispatchKey(event)
            return true
        }

        if (!routed && event.action == KeyEvent.ACTION_DOWN &&
            (event.keyCode == KeyEvent.KEYCODE_DPAD_CENTER || event.keyCode == KeyEvent.KEYCODE_ENTER)) {
            handler.removeCallbacks(initialRoute)
            routeToBestDisplay()
            return true
        }
        if (routed && event.keyCode == KeyEvent.KEYCODE_BACK) return true
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        if (routed && ExternalInputBridge.hasExternalTarget() && ExternalInputBridge.isMouse(event)) {
            ExternalInputBridge.dispatchMouse(event, window.decorView.width, window.decorView.height, false)
            return true
        }
        return super.dispatchGenericMotionEvent(event)
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        if (routed && ExternalInputBridge.hasExternalTarget() && ExternalInputBridge.isMouse(event)) {
            ExternalInputBridge.dispatchMouse(event, window.decorView.width, window.decorView.height, true)
            return true
        }
        return super.dispatchTouchEvent(event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (routed && ExternalInputBridge.hasExternalTarget()) {
            val now = android.os.SystemClock.uptimeMillis()
            ExternalInputBridge.dispatchKey(KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_BACK, 0))
            ExternalInputBridge.dispatchKey(KeyEvent(now, now, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_BACK, 0))
            return
        }
        if (routed) return
        super.onBackPressed()
    }
}

private class LogoView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        super.onDraw(cv)
        val w = width.toFloat(); val h = height.toFloat()
        cv.drawColor(Color.BLACK)
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f
        p.shader = LinearGradient(w*.34f,h*.32f,w*.67f,h*.68f,Color.rgb(40,190,255),Color.rgb(160,70,255),Shader.TileMode.CLAMP)
        cv.drawOval(RectF(w*.32f,h*.25f,w*.68f,h*.75f),p)
        p.shader = null; p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create(Typeface.DEFAULT,Typeface.BOLD); p.textSize = h*.16f; p.color = Color.WHITE
        cv.drawText("TvMad",w*.45f,h*.54f,p)
        p.color = Color.rgb(77,215,255); cv.drawText("Galaxy",w*.62f,h*.54f,p)
        p.typeface = Typeface.DEFAULT; p.textSize = h*.055f; p.color = Color.rgb(120,160,190)
        cv.drawText("HDMI connected",w*.5f,h*.64f,p)
    }
}
