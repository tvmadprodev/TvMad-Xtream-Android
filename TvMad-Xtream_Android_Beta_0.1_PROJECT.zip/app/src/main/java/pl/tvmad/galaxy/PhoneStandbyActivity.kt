package pl.tvmad.galaxy

import android.app.Activity
import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Display
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.PointerIcon
import android.view.View
import android.view.WindowManager
import android.graphics.*
import android.widget.FrameLayout
import android.widget.Toast
import java.lang.ref.WeakReference

/**
 * Host kept on the Galaxy S9+ AMOLED while TvMad Galaxy runs on HDMI.
 *
 * IMPORTANT: the HDMI routing intentionally mirrors the proven PhoneSplashActivity pattern
 * from TvMad-Xtream. In particular, HDMI display removal/recreation is NOT used to close the
 * phone host. Samsung can recreate the external Display while changing layer stacks; closing
 * the host on that transient event caused the previous TvMad Galaxy betas to disappear.
 */
class PhoneStandbyActivity : Activity(), DisplayManager.DisplayListener {
    companion object {
        private const val TAG = "TvMadGalaxyDisplay"
        private const val START_DELAY_MS = 850L
        private var activeInstance = WeakReference<PhoneStandbyActivity>(null)

        fun isHostActive(): Boolean {
            val a = activeInstance.get() ?: return false
            return !a.isFinishing && !a.isDestroyed
        }
    }

    private lateinit var displayManager: DisplayManager
    private val handler = Handler(Looper.getMainLooper())
    private var routed = false
    private var routedDisplayId = -1
    private var externalApp = false
    private var noHdmiToastShown = false

    private val initialRoute = Runnable { routeToBestDisplay() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activeInstance = WeakReference(this)
        PhoneCommandBridge.attach(this)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.apply { screenBrightness = 0.05f }
        setContentView(buildPhoneUi())
        immersive()

        displayManager = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        displayManager.displays.forEach { d ->
            Log.i(TAG, "visible display id=${d.displayId} name=${d.name} state=${d.state} flags=0x${Integer.toHexString(d.flags)}")
        }
        displayManager.registerDisplayListener(this, handler)

        // Start the hot-plug monitor only after this host is registered as active, so the
        // service cannot relaunch the host and create a task/start loop.
        runCatching {
            val service = Intent(this, HdmiMonitorService::class.java)
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
        }

        handler.postDelayed(initialRoute, START_DELAY_MS)
    }

    private fun buildPhoneUi(): View {
        return FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(LogoView(this@PhoneStandbyActivity), FrameLayout.LayoutParams(-1, -1))
            try { pointerIcon = PointerIcon.getSystemIcon(this@PhoneStandbyActivity, PointerIcon.TYPE_NULL) } catch (_: Throwable) {}
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        PhoneCommandBridge.detach(this)
        try { displayManager.unregisterDisplayListener(this) } catch (_: Throwable) {}
        if (activeInstance.get() === this) activeInstance = WeakReference<PhoneStandbyActivity>(null)
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) immersive()
    }

    private fun immersive() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    private fun findExternalDisplay(): Display? {
        val presentation = displayManager.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION)
        presentation.firstOrNull {
            it.displayId != Display.DEFAULT_DISPLAY && it.isValid && it.state != Display.STATE_OFF
        }?.let { return it }

        return displayManager.displays.firstOrNull {
            it.displayId != Display.DEFAULT_DISPLAY && it.isValid && it.state != Display.STATE_OFF
        }
    }

    private fun routeToBestDisplay() {
        if (routed || externalApp || isFinishing || isDestroyed) return
        val external = findExternalDisplay()
        if (external != null) {
            launchExternal(external)
        } else if (!noHdmiToastShown) {
            noHdmiToastShown = true
            Toast.makeText(this, "Podłącz HDMI", Toast.LENGTH_SHORT).show()
            handler.postDelayed({
                if (!routed && findExternalDisplay() == null && !isFinishing && !isDestroyed) finish()
            }, 1100L)
        }
    }

    private fun launchExternal(display: Display) {
        val intent = Intent(this, TvLauncherActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("tvmad_galaxy_external", true)
            .putExtra("tvmad_galaxy_display_id", display.displayId)

        try {
            val options = ActivityOptions.makeBasic()
            options.setLaunchDisplayId(display.displayId)
            startActivity(intent, options.toBundle())
            routed = true
            routedDisplayId = display.displayId
            noHdmiToastShown = false
            Log.i(TAG, "TvLauncherActivity requested on external display id=${display.displayId} name=${display.name}")
            // Deliberately keep this Activity alive on AMOLED, exactly like TvMad-Xtream.
        } catch (t: Throwable) {
            routed = false
            routedDisplayId = -1
            Log.e(TAG, "External display launch failed", t)
            Toast.makeText(this, "Nie udało się uruchomić launchera na HDMI", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDisplayAdded(displayId: Int) {
        Log.i(TAG, "onDisplayAdded id=$displayId")
        if (!routed && !externalApp) {
            handler.removeCallbacks(initialRoute)
            handler.postDelayed({ routeToBestDisplay() }, 350L)
        }
    }

    override fun onDisplayChanged(displayId: Int) {
        Log.i(TAG, "onDisplayChanged id=$displayId")
        if (!routed && !externalApp) {
            handler.removeCallbacks(initialRoute)
            handler.postDelayed({ routeToBestDisplay() }, 250L)
        }
    }

    override fun onDisplayRemoved(displayId: Int) {
        // DO NOT close PhoneStandbyActivity here. Samsung/FloydROM may transiently destroy
        // and recreate the external Display while assigning the HDMI layer stack. TvMad-Xtream
        // already proved that ignoring this callback is the stable approach on this S9+.
        Log.i(TAG, "onDisplayRemoved id=$displayId (ignored; host remains alive)")
        if (displayId == routedDisplayId) {
            routed = false
            routedDisplayId = -1
        }
    }

    override fun onResume() {
        super.onResume()
        immersive()
        if (externalApp) {
            externalApp = false
            routed = false
            routedDisplayId = -1
            handler.postDelayed({ routeToBestDisplay() }, 700L)
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (routed && ExternalInputBridge.hasTarget()) {
            if (event.keyCode in listOf(KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_VOLUME_DOWN, KeyEvent.KEYCODE_VOLUME_MUTE)) {
                return super.dispatchKeyEvent(event)
            }
            ExternalInputBridge.dispatchKey(event)
            return true
        }
        if (!routed && event.action == KeyEvent.ACTION_DOWN &&
            (event.keyCode == KeyEvent.KEYCODE_DPAD_CENTER || event.keyCode == KeyEvent.KEYCODE_ENTER)) {
            handler.removeCallbacks(initialRoute)
            routeToBestDisplay()
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        if (routed && ExternalInputBridge.hasTarget() && ExternalInputBridge.isMouse(event)) {
            ExternalInputBridge.dispatchMouse(event, window.decorView.width, window.decorView.height, false)
            return true
        }
        return super.dispatchGenericMotionEvent(event)
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        if (routed && ExternalInputBridge.hasTarget() && ExternalInputBridge.isMouse(event)) {
            ExternalInputBridge.dispatchMouse(event, window.decorView.width, window.decorView.height, true)
            return true
        }
        return super.dispatchTouchEvent(event)
    }

    fun openPackageFromLauncher(pkg: String) {
        val launch = packageManager.getLaunchIntentForPackage(pkg) ?: run {
            Toast.makeText(this, "Nie można uruchomić aplikacji", Toast.LENGTH_SHORT).show()
            return
        }
        externalApp = true
        routed = false
        routedDisplayId = -1
        sendBroadcast(Intent("pl.tvmad.galaxy.CLOSE_EXTERNAL").setPackage(packageName))
        handler.postDelayed({
            try { startActivity(launch) }
            catch (_: Throwable) {
                externalApp = false
                handler.postDelayed({ routeToBestDisplay() }, 300L)
            }
        }, 250L)
    }

    fun openSettingsFromLauncher() {
        externalApp = true
        routed = false
        routedDisplayId = -1
        sendBroadcast(Intent("pl.tvmad.galaxy.CLOSE_EXTERNAL").setPackage(packageName))
        handler.postDelayed({
            try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
            catch (_: Throwable) {
                externalApp = false
                handler.postDelayed({ routeToBestDisplay() }, 300L)
            }
        }, 250L)
    }
}

private class LogoView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(cv: Canvas) {
        super.onDraw(cv)
        val w = width.toFloat(); val h = height.toFloat()
        cv.drawColor(Color.BLACK)
        p.style = Paint.Style.STROKE; p.strokeWidth = 3f
        p.shader = LinearGradient(w*.34f,h*.32f,w*.67f,h*.68f,Color.rgb(40,190,255),Color.rgb(160,70,255),Shader.TileMode.CLAMP)
        cv.drawOval(RectF(w*.32f,h*.25f,w*.68f,h*.75f),p)
        p.shader = null; p.style = Paint.Style.FILL; p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create(Typeface.DEFAULT,Typeface.BOLD); p.textSize = h*.16f; p.color = Color.WHITE
        cv.drawText("TvMad",w*.45f,h*.54f,p)
        p.color = Color.rgb(77,215,255); cv.drawText("Galaxy",w*.62f,h*.54f,p)
        p.typeface = Typeface.DEFAULT; p.textSize = h*.055f; p.color = Color.rgb(120,160,190)
        cv.drawText("HDMI connected",w*.5f,h*.64f,p)
    }
}
