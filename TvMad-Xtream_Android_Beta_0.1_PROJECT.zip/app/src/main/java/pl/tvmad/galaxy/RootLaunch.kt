package pl.tvmad.galaxy
import android.content.Context
object RootLaunch { fun launchActivity(c:Context, component:String, displayId:Int):Boolean = try { val p=Runtime.getRuntime().exec(arrayOf("su","-c","am start --display $displayId -n $component")); p.waitFor()==0 } catch(_:Throwable){false} }
