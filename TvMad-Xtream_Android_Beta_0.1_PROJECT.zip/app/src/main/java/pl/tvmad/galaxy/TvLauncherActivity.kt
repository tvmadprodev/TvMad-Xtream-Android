package pl.tvmad.galaxy

import android.app.Activity
import android.app.ActivityOptions
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicReference

class TvLauncherActivity : Activity() {
    companion object { private const val TAG = "TvMadGalaxyLauncher" }

    private val handler = Handler(Looper.getMainLooper())
    private val statsExecutor = Executors.newSingleThreadExecutor { r -> Thread(r, "TvMadGalaxyStats") }
    private val statsSnapshot = AtomicReference("CPU --°C     CPU --%     RAM wolne -- / -- GB")

    private lateinit var root: FrameLayout
    private lateinit var clock: TextView
    private lateinit var date: TextView
    private lateinit var stats: TextView
    private lateinit var tiles: LinearLayout
    private var picker: View? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i(TAG, "onCreate actualDisplay=${display?.displayId} requested=${intent.getIntExtra("tvmad_galaxy_display_id", -1)}")
        immersive()
        buildUi()
        handler.post(clockTick)
        handler.post(statsTick)
    }

    override fun onResume() {
        super.onResume()
        ExternalInputBridge.attach(this)
        immersive()
    }

    override fun onPause() {
        ExternalInputBridge.detach(this)
        super.onPause()
    }

    override fun onDestroy() {
        ExternalInputBridge.detach(this)
        handler.removeCallbacksAndMessages(null)
        statsExecutor.shutdownNow()
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) immersive()
    }

    private fun immersive() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    private val clockTick = object : Runnable {
        override fun run() {
            if (isFinishing || isDestroyed) return
            val now = Date()
            clock.text = SimpleDateFormat("HH:mm", Locale.getDefault()).format(now)
            val pl = Locale("pl", "PL")
            val raw = SimpleDateFormat("EEEE, d MMMM yyyy", pl).format(now)
            date.text = raw.replaceFirstChar { if (it.isLowerCase()) it.titlecase(pl) else it.toString() }
            stats.text = statsSnapshot.get()
            handler.postDelayed(this, 1000L)
        }
    }

    private val statsTick = object : Runnable {
        override fun run() {
            if (isFinishing || isDestroyed) return
            statsExecutor.execute {
                val cpu = SystemStats.cpuPercent()
                val temp = SystemStats.temperatureC()
                val (free, total) = SystemStats.freeRamGb(applicationContext)
                val text = "CPU ${if (temp > 0) "${temp}°C" else "--"}     CPU ${cpu}%     RAM wolne %.1f / %.1f GB".format(Locale.US, free, total)
                statsSnapshot.set(text)
            }
            handler.postDelayed(this, 2500L)
        }
    }

    private fun buildUi() {
        root = FrameLayout(this)
        root.addView(GalaxyBackdropView(this), FrameLayout.LayoutParams(-1, -1))

        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(48), dp(28), dp(48), dp(24))
        }
        root.addView(content, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        clock = TextView(this).apply { setTextColor(Color.WHITE); textSize = 50f; typeface = Typeface.DEFAULT_BOLD; text = "--:--" }
        date = TextView(this).apply { setTextColor(Color.rgb(230,235,248)); textSize = 19f; text = "" }
        left.addView(clock); left.addView(date)
        top.addView(left, LinearLayout.LayoutParams(0, -2, 1f))

        stats = TextView(this).apply {
            setTextColor(Color.WHITE); textSize = 17f; gravity = Gravity.CENTER
            setPadding(dp(20), dp(13), dp(20), dp(13)); background = panelBg(); text = statsSnapshot.get()
        }
        top.addView(stats, LinearLayout.LayoutParams(-2, -2))
        content.addView(top)

        content.addView(TextView(this).apply {
            text = "TvMad Galaxy"; textSize = 20f; setTextColor(Color.rgb(77,215,255)); typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(12), 0, dp(6))
        })

        val scroll = ScrollView(this).apply { isFillViewport = true; overScrollMode = View.OVER_SCROLL_NEVER }
        tiles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(tiles, FrameLayout.LayoutParams(-1, -2))
        content.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        rebuildTiles()
    }

    private data class TileDef(val label: String, val icon: android.graphics.drawable.Drawable?, val action: () -> Unit, val removePkg: String? = null)

    private fun rebuildTiles() {
        tiles.removeAllViews()
        val defs = mutableListOf<TileDef>()
        LauncherPrefs.get(this).toList().forEach { pkg ->
            val info = runCatching { packageManager.getApplicationInfo(pkg, 0) }.getOrNull() ?: return@forEach
            val icon = runCatching { packageManager.getApplicationIcon(info) }.getOrNull()
            defs += TileDef(packageManager.getApplicationLabel(info).toString(), icon, { openPackage(pkg) }, pkg)
        }
        defs += TileDef("Ustawienia", runCatching { getDrawable(android.R.drawable.ic_menu_preferences) }.getOrNull(), { openSettings() })
        defs += TileDef("Wszystkie aplikacje", runCatching { getDrawable(android.R.drawable.ic_menu_view) }.getOrNull(), { showPicker(false) })
        defs += TileDef("+ Dodaj aplikację", runCatching { getDrawable(android.R.drawable.ic_input_add) }.getOrNull(), { showPicker(true) })

        defs.chunked(4).forEach { chunk ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            chunk.forEach { d ->
                val v = createTile(d.label, d.icon, d.action)
                d.removePkg?.let { pkg ->
                    v.setOnLongClickListener {
                        val list = LauncherPrefs.get(this@TvLauncherActivity)
                        list.remove(pkg); LauncherPrefs.save(this@TvLauncherActivity, list); rebuildTiles(); true
                    }
                }
                row.addView(v, LinearLayout.LayoutParams(0, dp(142), 1f).apply { setMargins(dp(7),dp(7),dp(7),dp(7)) })
            }
            repeat(4 - chunk.size) { row.addView(Space(this), LinearLayout.LayoutParams(0, dp(142), 1f).apply { setMargins(dp(7),dp(7),dp(7),dp(7)) }) }
            tiles.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        if (tiles.childCount > 0) ((tiles.getChildAt(0) as? LinearLayout)?.getChildAt(0))?.requestFocus()
    }

    private fun createTile(label: String, icon: android.graphics.drawable.Drawable?, action: () -> Unit): View =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; isFocusable = true; isClickable = true
            setPadding(dp(10),dp(12),dp(10),dp(12)); background = tileBg(false); setOnClickListener { action() }
            setOnFocusChangeListener { v, f -> v.background = tileBg(f); v.scaleX = if (f) 1.025f else 1f; v.scaleY = if (f) 1.025f else 1f }
            addView(ImageView(this@TvLauncherActivity).apply { setImageDrawable(icon); scaleType = ImageView.ScaleType.CENTER_INSIDE }, LinearLayout.LayoutParams(dp(62),dp(62)))
            addView(TextView(this@TvLauncherActivity).apply {
                text = label; setTextColor(Color.WHITE); textSize = 17f; gravity = Gravity.CENTER; maxLines = 2; typeface = Typeface.DEFAULT_BOLD
            }, LinearLayout.LayoutParams(-1,-2).apply { topMargin = dp(7) })
        }

    private fun openPackage(pkg: String) {
        val launch = packageManager.getLaunchIntentForPackage(pkg) ?: run {
            Toast.makeText(this, "Nie można uruchomić aplikacji", Toast.LENGTH_SHORT).show(); return
        }
        try {
            // Keep apps on the same HDMI display when Android allows it.  This also avoids moving
            // the phone-side TvMad Galaxy logo activity between displays.
            val displayId = display?.displayId ?: Display.DEFAULT_DISPLAY
            if (displayId != Display.DEFAULT_DISPLAY) {
                val options = ActivityOptions.makeBasic().setLaunchDisplayId(displayId)
                startActivity(launch, options.toBundle())
            } else startActivity(launch)
        } catch (t: Throwable) {
            Log.w(TAG, "launch on HDMI failed for $pkg; trying normal launch", t)
            runCatching { startActivity(launch) }
                .onFailure { Toast.makeText(this, "Nie można uruchomić aplikacji", Toast.LENGTH_SHORT).show() }
        }
    }

    private fun openSettings() {
        val i = Intent(Settings.ACTION_SETTINGS)
        try {
            val displayId = display?.displayId ?: Display.DEFAULT_DISPLAY
            if (displayId != Display.DEFAULT_DISPLAY) startActivity(i, ActivityOptions.makeBasic().setLaunchDisplayId(displayId).toBundle())
            else startActivity(i)
        } catch (_: Throwable) { runCatching { startActivity(i) } }
    }

    private fun showPicker(addMode: Boolean) {
        if (picker != null) return
        val shade = FrameLayout(this).apply { setBackgroundColor(Color.argb(220,0,0,0)); isFocusable = true; isClickable = true }
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24),dp(20),dp(24),dp(20)); background = panelBg() }
        shade.addView(panel, FrameLayout.LayoutParams((resources.displayMetrics.widthPixels*.84f).toInt(), (resources.displayMetrics.heightPixels*.80f).toInt(), Gravity.CENTER))
        val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        head.addView(TextView(this).apply { text = if (addMode) "Dodaj aplikację" else "Wszystkie aplikacje"; textSize = 25f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD }, LinearLayout.LayoutParams(0,-2,1f))
        val close = Button(this).apply { text = "Zamknij"; isFocusable = true; setOnClickListener { hidePicker() } }
        head.addView(close); panel.addView(head)
        val sc = ScrollView(this); val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }; sc.addView(list); panel.addView(sc, LinearLayout.LayoutParams(-1,0,1f))
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val resolved = packageManager.queryIntentActivities(query,0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(packageManager).toString().lowercase() }
        val pinned = LauncherPrefs.get(this)
        resolved.chunked(4).forEach { chunk ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            chunk.forEach { ri ->
                val pkg = ri.activityInfo.packageName
                val tile = createTile(ri.loadLabel(packageManager).toString(), runCatching { ri.loadIcon(packageManager) }.getOrNull()) {
                    if (addMode) {
                        if (!pinned.contains(pkg)) { pinned.add(pkg); LauncherPrefs.save(this, pinned) }
                        hidePicker(); rebuildTiles()
                    } else { hidePicker(); openPackage(pkg) }
                }
                row.addView(tile, LinearLayout.LayoutParams(0,dp(108),1f).apply { setMargins(dp(4),dp(4),dp(4),dp(4)) })
            }
            repeat(4 - chunk.size) { row.addView(Space(this), LinearLayout.LayoutParams(0,dp(108),1f)) }
            list.addView(row, LinearLayout.LayoutParams(-1,-2))
        }
        root.addView(shade, FrameLayout.LayoutParams(-1,-1)); picker = shade
        ((list.getChildAt(0) as? LinearLayout)?.getChildAt(0) ?: close).requestFocus()
    }

    private fun hidePicker() {
        picker?.let { root.removeView(it) }; picker = null
        ((tiles.getChildAt(0) as? LinearLayout)?.getChildAt(0))?.requestFocus()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (picker != null) { hidePicker(); return }
        super.onBackPressed()
    }

    private fun panelBg() = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE; cornerRadius = dp(18).toFloat(); setColor(Color.argb(185,6,13,30)); setStroke(dp(1),Color.argb(170,100,120,210))
    }
    private fun tileBg(f: Boolean) = GradientDrawable().apply {
        shape = GradientDrawable.RECTANGLE; cornerRadius = dp(18).toFloat(); setColor(if(f)Color.argb(238,9,30,65) else Color.argb(210,7,15,34)); setStroke(dp(if(f)3 else 1), if(f)Color.rgb(60,205,255) else Color.argb(155,90,80,180))
    }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt().coerceAtLeast(v)
}
