package pl.tvmad.galaxy

import android.app.Activity
import android.content.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.*
import android.provider.Settings
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class TvLauncherActivity:Activity(){
    private val h=Handler(Looper.getMainLooper())
    private lateinit var root:FrameLayout
    private lateinit var clock:TextView; private lateinit var date:TextView; private lateinit var stats:TextView
    private lateinit var grid:GridLayout
    private var picker:View?=null
    private val closeReceiver=object:BroadcastReceiver(){override fun onReceive(c:Context?,i:Intent?){finishAndRemoveTask()}}

    override fun onCreate(b:Bundle?){super.onCreate(b);immersive();buildUi();registerClose();h.post(tick)}
    override fun onResume(){super.onResume();ExternalInputBridge.attach(this);immersive()}
    override fun onDestroy(){ExternalInputBridge.detach(this);h.removeCallbacksAndMessages(null);try{unregisterReceiver(closeReceiver)}catch(_:Throwable){};super.onDestroy()}
    private fun registerClose(){
        val f=IntentFilter("pl.tvmad.galaxy.CLOSE_EXTERNAL")
        if(Build.VERSION.SDK_INT>=33) registerReceiver(closeReceiver,f,Context.RECEIVER_NOT_EXPORTED)
        else { @Suppress("DEPRECATION") registerReceiver(closeReceiver,f) }
    }
    private fun immersive(){@Suppress("DEPRECATION") window.decorView.systemUiVisibility=5894 or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY}
    override fun onWindowFocusChanged(f:Boolean){super.onWindowFocusChanged(f);if(f)immersive()}

    private val tick=object:Runnable{override fun run(){val now=Date();clock.text=SimpleDateFormat("HH:mm",Locale.getDefault()).format(now);val loc=Locale("pl","PL");date.text=SimpleDateFormat("EEEE, d MMMM yyyy",loc).format(now).replaceFirstChar{if(it.isLowerCase())it.titlecase(loc)else it.toString()}; val cpu=SystemStats.cpuPercent();val t=SystemStats.temperatureC();val(rf,rt)=SystemStats.freeRamGb(this@TvLauncherActivity);stats.text="CPU ${if(t>0)"${t}°C" else "--"}     CPU ${cpu}%     RAM wolne %.1f / %.1f GB".format(rf,rt);h.postDelayed(this,1500)}}

    private fun buildUi(){
        root=FrameLayout(this);root.addView(GalaxyBackdropView(this),FrameLayout.LayoutParams(-1,-1))
        val content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(54),dp(34),dp(54),dp(28))}
        root.addView(content,FrameLayout.LayoutParams(-1,-1));setContentView(root)
        val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val left=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        clock=TextView(this).apply{setTextColor(Color.WHITE);textSize=52f;typeface=Typeface.DEFAULT_BOLD}
        date=TextView(this).apply{setTextColor(Color.rgb(230,235,248));textSize=20f}
        left.addView(clock);left.addView(date);top.addView(left,LinearLayout.LayoutParams(0,-2,1f))
        stats=TextView(this).apply{setTextColor(Color.WHITE);textSize=18f;gravity=Gravity.CENTER;setPadding(dp(24),dp(15),dp(24),dp(15));background=panelBg()}
        top.addView(stats,LinearLayout.LayoutParams(-2,-2));content.addView(top)
        val title=TextView(this).apply{text="TvMad Galaxy";textSize=20f;setTextColor(Color.rgb(77,215,255));typeface=Typeface.DEFAULT_BOLD;setPadding(0,dp(14),0,dp(8))};content.addView(title)
        val scroll=ScrollView(this).apply{isFillViewport=true;overScrollMode=View.OVER_SCROLL_NEVER}
        grid=GridLayout(this).apply{columnCount=4;alignmentMode=GridLayout.ALIGN_BOUNDS;useDefaultMargins=false}
        scroll.addView(grid,ScrollView.LayoutParams(-1,-2));content.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));rebuildGrid()
    }

    private fun rebuildGrid(){grid.removeAllViews();val apps=LauncherPrefs.get(this);apps.forEach{pkg->val info=runCatching{packageManager.getApplicationInfo(pkg,0)}.getOrNull()?:return@forEach; val label=packageManager.getApplicationLabel(info).toString(); addTile(label,packageManager.getApplicationIcon(info)){openPackage(pkg)}.setOnLongClickListener{apps.remove(pkg);LauncherPrefs.save(this,apps);rebuildGrid();true}}
        addTile("Ustawienia",getDrawable(android.R.drawable.ic_menu_preferences)){openSettings()}
        addTile("Wszystkie aplikacje",getDrawable(android.R.drawable.ic_menu_view)){showPicker(false)}
        addTile("+ Dodaj aplikację",getDrawable(android.R.drawable.ic_input_add)){showPicker(true)}
        if(grid.childCount>0)grid.getChildAt(0).requestFocus()
    }
    private fun addTile(label:String,icon:android.graphics.drawable.Drawable?,action:()->Unit):View{
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;isFocusable=true;isClickable=true;setPadding(dp(12),dp(16),dp(12),dp(14));background=tileBg(false);setOnClickListener{action()};setOnFocusChangeListener{v,f->v.background=tileBg(f);v.scaleX=if(f)1.035f else 1f;v.scaleY=if(f)1.035f else 1f}}
        val iv=ImageView(this).apply{setImageDrawable(icon);scaleType=ImageView.ScaleType.CENTER_INSIDE};box.addView(iv,LinearLayout.LayoutParams(dp(68),dp(68)))
        val tv=TextView(this).apply{text=label;setTextColor(Color.WHITE);textSize=18f;gravity=Gravity.CENTER;maxLines=2;typeface=Typeface.DEFAULT_BOLD};box.addView(tv,LinearLayout.LayoutParams(-1,-2).apply{topMargin=dp(8)})
        val lp=GridLayout.LayoutParams().apply{width=0;height=dp(150);columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);setMargins(dp(8),dp(8),dp(8),dp(8))};grid.addView(box,lp);return box
    }
    private fun openPackage(pkg:String){if(PhoneCommandBridge.openPackage(pkg)){finishAndRemoveTask();return}; val li=packageManager.getLaunchIntentForPackage(pkg)?:return;startActivity(li)}
    private fun openSettings(){if(PhoneCommandBridge.openSettings()){finishAndRemoveTask();return};startActivity(Intent(Settings.ACTION_SETTINGS))}

    private fun showPicker(addMode:Boolean){if(picker!=null)return;val shade=FrameLayout(this).apply{setBackgroundColor(Color.argb(210,0,0,0));isFocusable=true;isClickable=true};val panel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(26),dp(22),dp(26),dp(22));background=panelBg()};val flp=FrameLayout.LayoutParams((resources.displayMetrics.widthPixels*.82f).toInt(),(resources.displayMetrics.heightPixels*.78f).toInt(),Gravity.CENTER);shade.addView(panel,flp)
        val head=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL};head.addView(TextView(this).apply{text=if(addMode)"Dodaj aplikację" else "Wszystkie aplikacje";textSize=26f;setTextColor(Color.WHITE);typeface=Typeface.DEFAULT_BOLD},LinearLayout.LayoutParams(0,-2,1f));val close=Button(this).apply{text="Zamknij";isFocusable=true;setOnClickListener{hidePicker()}};head.addView(close);panel.addView(head)
        val sc=ScrollView(this);val g=GridLayout(this).apply{columnCount=4};sc.addView(g);panel.addView(sc,LinearLayout.LayoutParams(-1,0,1f))
        val intent=Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);val list=packageManager.queryIntentActivities(intent,0).filter{it.activityInfo.packageName!=packageName}.distinctBy{it.activityInfo.packageName}.sortedBy{it.loadLabel(packageManager).toString().lowercase()}
        val pinned=LauncherPrefs.get(this)
        list.forEach{ri->val pkg=ri.activityInfo.packageName;val tile=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;isFocusable=true;isClickable=true;setPadding(dp(8),dp(10),dp(8),dp(10));background=tileBg(false);setOnFocusChangeListener{v,f->v.background=tileBg(f)};setOnClickListener{if(addMode){if(!pinned.contains(pkg)){pinned.add(pkg);LauncherPrefs.save(this@TvLauncherActivity,pinned)};hidePicker();rebuildGrid()}else{hidePicker();openPackage(pkg)}}};tile.addView(ImageView(this).apply{setImageDrawable(ri.loadIcon(packageManager));scaleType=ImageView.ScaleType.CENTER_INSIDE},LinearLayout.LayoutParams(dp(52),dp(52)));tile.addView(TextView(this).apply{text=ri.loadLabel(packageManager);setTextColor(Color.WHITE);textSize=14f;gravity=Gravity.CENTER;maxLines=2},LinearLayout.LayoutParams(-1,-2));g.addView(tile,GridLayout.LayoutParams().apply{width=0;height=dp(112);columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);setMargins(dp(5),dp(5),dp(5),dp(5))})}
        root.addView(shade,FrameLayout.LayoutParams(-1,-1));picker=shade; if(g.childCount>0)g.getChildAt(0).requestFocus() else close.requestFocus()
    }
    private fun hidePicker(){picker?.let{root.removeView(it)};picker=null;if(grid.childCount>0)grid.getChildAt(0).requestFocus()}
    override fun onBackPressed(){if(picker!=null){hidePicker();return};super.onBackPressed()}
    private fun panelBg()=GradientDrawable().apply{shape=GradientDrawable.RECTANGLE;cornerRadius=dp(18).toFloat();setColor(Color.argb(175,6,13,30));setStroke(dp(1),Color.argb(160,100,120,210))}
    private fun tileBg(f:Boolean)=GradientDrawable().apply{shape=GradientDrawable.RECTANGLE;cornerRadius=dp(18).toFloat();setColor(if(f)Color.argb(235,9,30,65) else Color.argb(205,7,15,34));setStroke(dp(if(f)3 else 1),if(f)Color.rgb(60,205,255) else Color.argb(150,90,80,180))}
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
}
