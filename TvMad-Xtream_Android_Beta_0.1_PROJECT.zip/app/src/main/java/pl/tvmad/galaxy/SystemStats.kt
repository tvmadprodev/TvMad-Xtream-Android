package pl.tvmad.galaxy

import android.app.ActivityManager
import android.content.Context
import java.io.File

object SystemStats {
    private var lastTotal=0L; private var lastIdle=0L
    fun cpuPercent():Int {
        return try {
            val parts=File("/proc/stat").useLines{it.first()}.trim().split(Regex("\\s+"))
            val nums=parts.drop(1).mapNotNull{it.toLongOrNull()}
            val idle=(nums.getOrNull(3)?:0L)+(nums.getOrNull(4)?:0L)
            val total=nums.sum(); val dt=total-lastTotal; val di=idle-lastIdle; lastTotal=total; lastIdle=idle
            if(dt<=0)0 else (((dt-di)*100/dt).toInt()).coerceIn(0,100)
        }catch(_:Throwable){0}
    }
    fun freeRamGb(c:Context):Pair<Double,Double>{ val mi=ActivityManager.MemoryInfo(); (c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi); return Pair(mi.availMem/1073741824.0,mi.totalMem/1073741824.0) }
    fun temperatureC():Int {
        return try {
            val root=File("/sys/class/thermal")
            val vals=root.listFiles()?.filter{it.name.startsWith("thermal_zone")}.mapNotNull{z->
                val type=runCatching{File(z,"type").readText().trim().lowercase()}.getOrDefault("")
                if(!(type.contains("cpu")||type.contains("soc")||type.contains("ap")||type.contains("big")||type.contains("little"))) return@mapNotNull null
                val raw=runCatching{File(z,"temp").readText().trim().toDouble()}.getOrNull()?:return@mapNotNull null
                val v=if(raw>1000)raw/1000.0 else raw
                v.takeIf{it in 15.0..110.0}
            } ?: emptyList()
            (vals.maxOrNull() ?: 0.0).toInt()
        }catch(_:Throwable){0}
    }
}
