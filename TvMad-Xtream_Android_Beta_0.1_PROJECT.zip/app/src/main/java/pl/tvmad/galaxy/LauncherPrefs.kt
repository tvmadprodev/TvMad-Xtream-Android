package pl.tvmad.galaxy
import android.content.Context
object LauncherPrefs {
    private const val N="launcher"; private const val K="apps"
    fun get(c:Context):MutableList<String>{ val raw=c.getSharedPreferences(N,0).getString(K,null); if(raw!=null)return raw.split('|').filter{it.isNotBlank()}.toMutableList(); val d=listOf("pl.tvmad.xtream.tv","com.google.android.youtube","org.videolan.vlc"); return d.filter{c.packageManager.getLaunchIntentForPackage(it)!=null}.toMutableList() }
    fun save(c:Context,l:List<String>){c.getSharedPreferences(N,0).edit().putString(K,l.distinct().joinToString("|")).apply()}
}
