package pl.tvmad.galaxy

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import java.lang.ref.WeakReference

object ExternalInputBridge {
    private val handler = Handler(Looper.getMainLooper())
    @Volatile private var target = WeakReference<Activity>(null)
    private var cursorOwner = WeakReference<ViewGroup>(null)
    private var cursor: ImageView? = null
    private val hide = Runnable { cursor?.visibility = View.GONE }

    fun attach(a: Activity) { if ((a.display?.displayId ?: Display.DEFAULT_DISPLAY) != Display.DEFAULT_DISPLAY) target = WeakReference(a) }
    fun detach(a: Activity) { if (target.get() === a) target = WeakReference<Activity>(null); removeCursor() }
    fun hasTarget() = targetActivity() != null
    fun dispatchKey(e: KeyEvent): Boolean = try { targetActivity()?.dispatchKeyEvent(KeyEvent(e)) ?: false } catch (_: Throwable) { false }
    fun isMouse(e: MotionEvent) = e.isFromSource(InputDevice.SOURCE_MOUSE) || e.isFromSource(InputDevice.SOURCE_MOUSE_RELATIVE)
    fun dispatchMouse(e: MotionEvent, sw: Int, sh: Int, touch: Boolean): Boolean {
        val a = targetActivity() ?: return false
        val decor = a.window.decorView as? ViewGroup ?: return false
        if (sw <= 0 || sh <= 0 || decor.width <= 0 || decor.height <= 0) return false
        val x = (e.x / sw.toFloat() * decor.width).coerceIn(0f, (decor.width - 1).coerceAtLeast(0).toFloat())
        val y = (e.y / sh.toFloat() * decor.height).coerceIn(0f, (decor.height - 1).coerceAtLeast(0).toFloat())
        showCursor(a, decor, x, y)
        val c = MotionEvent.obtain(e)
        return try { c.setLocation(x,y); if (touch) a.dispatchTouchEvent(c) else a.dispatchGenericMotionEvent(c) } finally { c.recycle() }
    }
    private fun targetActivity(): Activity? { val a=target.get() ?: return null; if (a.isFinishing || a.isDestroyed) { target=WeakReference<Activity>(null); return null }; return a }
    private fun showCursor(a: Activity, p: ViewGroup, x: Float, y: Float) {
        var c = cursor
        if (c == null || cursorOwner.get() !== p || c.parent !== p) {
            removeCursor(); val d=a.resources.displayMetrics.density
            c = ImageView(a).apply { setImageResource(pl.tvmad.galaxy.R.drawable.remote_cursor); isFocusable=false; isClickable=false; elevation=1000f; visibility=View.GONE }
            p.addView(c, ViewGroup.LayoutParams((28*d).toInt().coerceAtLeast(20),(36*d).toInt().coerceAtLeast(26)))
            cursor=c; cursorOwner=WeakReference(p)
        }
        c.x=x; c.y=y; c.visibility=View.VISIBLE; c.bringToFront(); handler.removeCallbacks(hide); handler.postDelayed(hide,2200)
    }
    private fun removeCursor(){ handler.removeCallbacks(hide); try{(cursor?.parent as? ViewGroup)?.removeView(cursor)}catch(_:Throwable){}; cursor=null; cursorOwner=WeakReference<ViewGroup>(null)}
}
