package pl.tvmad.galaxy

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import java.lang.ref.WeakReference

/** Direct port of the input bridge already proven in TvMad-Xtream on this Galaxy S9+. */
object ExternalInputBridge {
    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var activeExternal = WeakReference<Activity>(null)
    private var cursorOwner = WeakReference<ViewGroup>(null)
    private var cursorView: ImageView? = null
    private val hideCursor = Runnable { cursorView?.visibility = View.GONE }

    fun attach(activity: Activity) {
        val displayId = activity.display?.displayId ?: activity.windowManager.defaultDisplay.displayId
        if (displayId != Display.DEFAULT_DISPLAY) activeExternal = WeakReference(activity)
    }

    fun detach(activity: Activity) {
        if (activeExternal.get() === activity) activeExternal = WeakReference<Activity>(null)
        val parent = cursorOwner.get()
        if (parent != null && parent.rootView === activity.window.decorView.rootView) removeCursor()
    }

    fun hasExternalTarget(): Boolean = targetActivity() != null

    fun dispatchKey(event: KeyEvent): Boolean {
        val activity = targetActivity() ?: return false
        return try { activity.dispatchKeyEvent(KeyEvent(event)) } catch (_: Throwable) { false }
    }

    fun dispatchMouse(event: MotionEvent, sourceWidth: Int, sourceHeight: Int, touchEvent: Boolean): Boolean {
        val activity = targetActivity() ?: return false
        val decor = activity.window.decorView as? ViewGroup ?: return false
        if (sourceWidth <= 0 || sourceHeight <= 0 || decor.width <= 0 || decor.height <= 0) return false
        val x = (event.x / sourceWidth.toFloat() * decor.width.toFloat())
            .coerceIn(0f, (decor.width - 1).coerceAtLeast(0).toFloat())
        val y = (event.y / sourceHeight.toFloat() * decor.height.toFloat())
            .coerceIn(0f, (decor.height - 1).coerceAtLeast(0).toFloat())
        showCursor(activity, decor, x, y)
        val copy = MotionEvent.obtain(event)
        return try {
            copy.setLocation(x, y)
            if (touchEvent) activity.dispatchTouchEvent(copy) else activity.dispatchGenericMotionEvent(copy)
        } catch (_: Throwable) { false }
        finally { copy.recycle() }
    }

    private fun targetActivity(): Activity? {
        val a = activeExternal.get() ?: return null
        if (a.isFinishing || a.isDestroyed) {
            activeExternal = WeakReference<Activity>(null)
            return null
        }
        return a
    }

    private fun showCursor(activity: Activity, parent: ViewGroup, x: Float, y: Float) {
        val cursor = ensureCursor(activity, parent) ?: return
        val width = cursor.layoutParams?.width?.coerceAtLeast(1) ?: 1
        val height = cursor.layoutParams?.height?.coerceAtLeast(1) ?: 1
        cursor.x = x.coerceIn(0f, (parent.width - width).coerceAtLeast(0).toFloat())
        cursor.y = y.coerceIn(0f, (parent.height - height).coerceAtLeast(0).toFloat())
        cursor.visibility = View.VISIBLE
        cursor.bringToFront()
        mainHandler.removeCallbacks(hideCursor)
        mainHandler.postDelayed(hideCursor, 2200L)
    }

    private fun ensureCursor(activity: Activity, parent: ViewGroup): ImageView? {
        val current = cursorView
        if (current != null && cursorOwner.get() === parent && current.parent === parent) return current
        removeCursor()
        val d = activity.resources.displayMetrics.density
        val w = (28f*d).toInt().coerceAtLeast(20)
        val h = (36f*d).toInt().coerceAtLeast(26)
        return ImageView(activity).apply {
            setImageResource(R.drawable.remote_cursor)
            isClickable = false; isFocusable = false
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            elevation = 1000f; visibility = View.GONE
            parent.addView(this, ViewGroup.LayoutParams(w,h))
            cursorView = this; cursorOwner = WeakReference(parent)
        }
    }

    private fun removeCursor() {
        mainHandler.removeCallbacks(hideCursor)
        try { (cursorView?.parent as? ViewGroup)?.removeView(cursorView) } catch (_: Throwable) {}
        cursorView = null
        cursorOwner = WeakReference<ViewGroup>(null)
    }

    fun isMouse(event: MotionEvent): Boolean =
        event.isFromSource(InputDevice.SOURCE_MOUSE) || event.isFromSource(InputDevice.SOURCE_MOUSE_RELATIVE)
}
