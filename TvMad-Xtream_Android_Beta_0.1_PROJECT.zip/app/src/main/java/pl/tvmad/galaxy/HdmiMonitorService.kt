package pl.tvmad.galaxy

import android.app.*
import android.content.*
import android.hardware.display.DisplayManager
import android.os.*
import android.util.Log
import android.view.Display
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Minimal HDMI hot-plug monitor.
 *
 * It NEVER closes, reroutes or restarts an already-running PhoneStandbyActivity. Its only job
 * is to start the phone host when HDMI appears and no host is active. This keeps the proven
 * TvMad-Xtream two-Activity routing path untouched.
 */
class HdmiMonitorService : Service(), DisplayManager.DisplayListener {
    companion object { private const val TAG = "TvMadGalaxyHDMI" }

    private lateinit var dm: DisplayManager
    private val handler = Handler(Looper.getMainLooper())
    private val launchRunning = AtomicBoolean(false)
    private val checkRunnable = Runnable { checkForHdmi() }

    override fun onCreate() {
        super.onCreate()
        val channelId = "tvmad_galaxy_hdmi"
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(NotificationChannel(channelId,"TvMad Galaxy HDMI",NotificationManager.IMPORTANCE_MIN))
        }
        val notification = Notification.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("TvMad Galaxy")
            .setContentText("Monitor HDMI aktywny")
            .build()
        startForeground(17, notification)

        dm = getSystemService(DISPLAY_SERVICE) as DisplayManager
        dm.registerDisplayListener(this, handler)
        scheduleCheck(500L)
    }

    private fun externalDisplay(): Display? {
        dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION).firstOrNull {
            it.displayId != Display.DEFAULT_DISPLAY && it.isValid && it.state != Display.STATE_OFF
        }?.let { return it }
        return dm.displays.firstOrNull {
            it.displayId != Display.DEFAULT_DISPLAY && it.isValid && it.state != Display.STATE_OFF
        }
    }

    private fun scheduleCheck(delay: Long = 600L) {
        handler.removeCallbacks(checkRunnable)
        handler.postDelayed(checkRunnable, delay)
    }

    private fun checkForHdmi() {
        val ext = externalDisplay() ?: return
        if (PhoneStandbyActivity.isHostActive()) return
        Log.i(TAG, "HDMI detected id=${ext.displayId}; host inactive -> auto start")
        startHostSafely()
    }

    private fun startHostSafely() {
        if (!launchRunning.compareAndSet(false, true)) return

        // Try normal start first. If Android 13 blocks background activity launch, root fallback
        // runs later on a worker thread. No waitFor() ever runs on the main/UI thread.
        runCatching {
            startActivity(
                Intent(this, PhoneStandbyActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    .putExtra("auto_hdmi", true)
            )
        }.onFailure { Log.w(TAG, "normal auto-start failed", it) }

        Thread {
            try {
                Thread.sleep(1200L)
                if (PhoneStandbyActivity.isHostActive() || externalDisplay() == null) return@Thread
                val cmd = "am start -n pl.tvmad.galaxy/.PhoneStandbyActivity --ez auto_hdmi true"
                val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
                val done = if (Build.VERSION.SDK_INT >= 26) {
                    p.waitFor(8, java.util.concurrent.TimeUnit.SECONDS)
                } else {
                    p.waitFor(); true
                }
                Log.i(TAG, "root auto-start done=$done exit=${if (done) p.exitValue() else -1}")
                if (!done) p.destroy()
            } catch (t: Throwable) {
                Log.w(TAG, "root auto-start unavailable", t)
            } finally {
                launchRunning.set(false)
            }
        }.start()
    }

    override fun onDisplayAdded(displayId: Int) { Log.i(TAG,"added $displayId"); scheduleCheck(450L) }
    override fun onDisplayChanged(displayId: Int) { scheduleCheck(450L) }
    override fun onDisplayRemoved(displayId: Int) { Log.i(TAG,"removed $displayId") }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int { scheduleCheck(350L); return START_STICKY }
    override fun onBind(intent: Intent?) = null
    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { dm.unregisterDisplayListener(this) } catch (_: Throwable) {}
        super.onDestroy()
    }
}
