package pl.tvmad.galaxy

import android.app.*
import android.content.*
import android.hardware.display.DisplayManager
import android.os.*
import android.view.Display

class HdmiMonitorService: Service(), DisplayManager.DisplayListener {
    private lateinit var dm:DisplayManager; private var had=false
    override fun onCreate(){super.onCreate(); val ch="tvmad_galaxy_hdmi"; if(Build.VERSION.SDK_INT>=26)(getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel(ch,"TvMad Galaxy HDMI",NotificationManager.IMPORTANCE_MIN)); val n=Notification.Builder(this,ch).setSmallIcon(R.drawable.ic_launcher).setContentTitle("TvMad Galaxy").setContentText("Monitor HDMI aktywny").build(); startForeground(17,n); dm=getSystemService(DISPLAY_SERVICE) as DisplayManager;dm.registerDisplayListener(this,Handler(Looper.getMainLooper())); check()}
    private fun hasExt()=dm.displays.any{it.displayId!=Display.DEFAULT_DISPLAY&&it.isValid&&it.state!=Display.STATE_OFF}
    private fun check(){val now=hasExt();if(now&&!had){val i=Intent(this,PhoneStandbyActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("auto_hdmi",true);try{startActivity(i)}catch(_:Throwable){RootLaunch.launchActivity(this,"pl.tvmad.galaxy/.PhoneStandbyActivity",Display.DEFAULT_DISPLAY)}};if(!now&&had)sendBroadcast(Intent("pl.tvmad.galaxy.HDMI_GONE").setPackage(packageName));had=now}
    override fun onDisplayAdded(id:Int)=check(); override fun onDisplayRemoved(id:Int)=check(); override fun onDisplayChanged(id:Int)=check(); override fun onStartCommand(i:Intent?,f:Int,id:Int):Int{check();return START_STICKY};override fun onBind(i:Intent?)=null;override fun onDestroy(){try{dm.unregisterDisplayListener(this)}catch(_:Throwable){};super.onDestroy()}
}
