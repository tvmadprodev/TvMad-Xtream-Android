package pl.tvmad.galaxy

import android.app.*
import android.content.*
import android.hardware.display.DisplayManager
import android.os.*
import android.util.Log
import android.view.Display
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Background HDMI monitor used only for future plug-in auto start.
 * It never reroutes or closes an already-running host and all root work stays off the UI thread.
 */
class HdmiMonitorService : Service(), DisplayManager.DisplayListener {
    companion object { private const val TAG = "TvMadGalaxyHDMI" }
    private lateinit var dm: DisplayManager
    private val handler = Handler(Looper.getMainLooper())
    private val launchRunning = AtomicBoolean(false)
    private var hadExternal = false
    private val check = Runnable { checkForHdmi() }

    override fun onCreate() {
        super.onCreate()
        val ch = "tvmad_galaxy_hdmi"
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(NotificationChannel(ch, "TvMad Galaxy HDMI", NotificationManager.IMPORTANCE_MIN))
        }
        startForeground(17, Notification.Builder(this, ch)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("TvMad Galaxy")
            .setContentText("Monitor HDMI aktywny")
            .build())
        dm = getSystemService(DISPLAY_SERVICE) as DisplayManager
        dm.registerDisplayListener(this, handler)
        hadExternal = externalDisplay() != null
    }

    private fun externalDisplay(): Display? {
        dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION).firstOrNull {
            it.displayId != Display.DEFAULT_DISPLAY && it.isValid && it.state != Display.STATE_OFF
        }?.let { return it }
        return dm.displays.firstOrNull {
            it.displayId != Display.DEFAULT_DISPLAY && it.isValid && it.state != Display.STATE_OFF
        }
    }

    private fun schedule() { handler.removeCallbacks(check); handler.postDelayed(check, 700L) }

    private fun checkForHdmi() {
        val now = externalDisplay() != null
        if (now && !hadExternal && !PhoneStandbyActivity.isHostActive()) autoStartHost()
        hadExternal = now
    }

    private fun autoStartHost() {
        if (!launchRunning.compareAndSet(false, true)) return
        Thread {
            try {
                // On this rooted S9+ use the same explicit launcher Activity component.
                val p = Runtime.getRuntime().exec(arrayOf("su","-c","am start -n pl.tvmad.galaxy/.PhoneStandbyActivity --ez auto_hdmi true"))
                val done = if (Build.VERSION.SDK_INT >= 26) p.waitFor(8, java.util.concurrent.TimeUnit.SECONDS) else { p.waitFor(); true }
                Log.i(TAG, "root auto-start done=$done exit=${if(done) p.exitValue() else -1}")
                if (!done) p.destroy()
            } catch (t: Throwable) { Log.w(TAG, "auto-start unavailable", t) }
            finally { launchRunning.set(false) }
        }.start()
    }

    override fun onDisplayAdded(displayId: Int) { schedule() }
    override fun onDisplayChanged(displayId: Int) { schedule() }
    override fun onDisplayRemoved(displayId: Int) { schedule() }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int { schedule(); return START_STICKY }
    override fun onBind(intent: Intent?) = null
    override fun onDestroy() { handler.removeCallbacksAndMessages(null); try { dm.unregisterDisplayListener(this) } catch (_: Throwable) {}; super.onDestroy() }
}
