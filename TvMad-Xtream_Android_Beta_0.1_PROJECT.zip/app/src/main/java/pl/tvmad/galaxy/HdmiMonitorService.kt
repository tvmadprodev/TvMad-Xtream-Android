package pl.tvmad.galaxy

import android.app.*
import android.content.*
import android.hardware.display.DisplayManager
import android.os.*
import android.util.Log
import android.view.Display
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Foreground hot-plug monitor. Android 13 can block a background Activity start, therefore
 * auto-start has a root-assisted fallback on this dedicated rooted Galaxy S9+. Root work is
 * always done off the main thread, so it cannot freeze the UI or cause an ANR.
 */
class HdmiMonitorService : Service(), DisplayManager.DisplayListener {
    companion object { private const val TAG = "TvMadGalaxyHDMI" }

    private lateinit var dm: DisplayManager
    private val h = Handler(Looper.getMainLooper())
    private var hadExternal = false
    private val rootStartRunning = AtomicBoolean(false)
    private val stableCheck = Runnable { checkStable() }

    override fun onCreate() {
        super.onCreate()
        val ch = "tvmad_galaxy_hdmi"
        if (Build.VERSION.SDK_INT >= 26) {
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(NotificationChannel(ch,"TvMad Galaxy HDMI",NotificationManager.IMPORTANCE_MIN))
        }
        val n = Notification.Builder(this,ch)
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("TvMad Galaxy")
            .setContentText("Monitor HDMI aktywny")
            .build()
        startForeground(17,n)
        dm = getSystemService(DISPLAY_SERVICE) as DisplayManager
        dm.registerDisplayListener(this,h)
        hadExternal = hasExternal()
        Log.i(TAG,"service created external=$hadExternal")
    }

    private fun hasExternal(): Boolean = dm.displays.any {
        it.displayId != Display.DEFAULT_DISPLAY && it.isValid && it.state != Display.STATE_OFF
    }

    private fun scheduleCheck() {
        h.removeCallbacks(stableCheck)
        h.postDelayed(stableCheck, 700L)
    }

    private fun checkStable() {
        val now = hasExternal()
        Log.i(TAG,"check stable now=$now had=$hadExternal host=${PhoneStandbyActivity.isHostActive()}")
        if (now && !hadExternal && !PhoneStandbyActivity.isHostActive()) {
            autoStartHost()
        }
        hadExternal = now
    }

    private fun autoStartHost() {
        // First try the normal path. It works on some Android/Samsung builds while this
        // foreground service is alive.
        try {
            startActivity(
                Intent(this,PhoneStandbyActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    .putExtra("auto_hdmi",true)
            )
        } catch (t: Throwable) {
            Log.w(TAG,"normal background launch threw",t)
        }

        // Android may silently block that call. On this rooted S9+ use KernelSU as a fallback,
        // asynchronously. No waitFor() is ever executed on the main thread.
        if (!rootStartRunning.compareAndSet(false,true)) return
        Thread {
            try {
                Thread.sleep(900L)
                if (!hasExternal() || PhoneStandbyActivity.isHostActive()) return@Thread
                val cmd = "am start -n pl.tvmad.galaxy/.PhoneStandbyActivity --ez auto_hdmi true"
                val p = Runtime.getRuntime().exec(arrayOf("su","-c",cmd))
                val done = if (Build.VERSION.SDK_INT >= 26) p.waitFor(8,java.util.concurrent.TimeUnit.SECONDS) else { p.waitFor(); true }
                Log.i(TAG,"root auto-start done=$done exit=${if(done) p.exitValue() else -1}")
                if (!done) p.destroy()
            } catch (t: Throwable) {
                Log.w(TAG,"root auto-start unavailable",t)
            } finally {
                rootStartRunning.set(false)
            }
        }.start()
    }

    override fun onDisplayAdded(displayId:Int){Log.i(TAG,"added $displayId");scheduleCheck()}
    override fun onDisplayRemoved(displayId:Int){Log.i(TAG,"removed $displayId");scheduleCheck()}
    override fun onDisplayChanged(displayId:Int){scheduleCheck()}
    override fun onStartCommand(i:Intent?,f:Int,id:Int):Int{scheduleCheck();return START_STICKY}
    override fun onBind(i:Intent?)=null
    override fun onDestroy(){h.removeCallbacksAndMessages(null);try{dm.unregisterDisplayListener(this)}catch(_:Throwable){};super.onDestroy()}
}
