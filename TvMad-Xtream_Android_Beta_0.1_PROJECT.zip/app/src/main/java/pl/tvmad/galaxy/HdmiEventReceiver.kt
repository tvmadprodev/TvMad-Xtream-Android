package pl.tvmad.galaxy
import android.content.*
import android.os.Build
class HdmiEventReceiver:BroadcastReceiver(){override fun onReceive(c:Context,i:Intent){val s=Intent(c,HdmiMonitorService::class.java);if(Build.VERSION.SDK_INT>=26)c.startForegroundService(s) else c.startService(s)}}
