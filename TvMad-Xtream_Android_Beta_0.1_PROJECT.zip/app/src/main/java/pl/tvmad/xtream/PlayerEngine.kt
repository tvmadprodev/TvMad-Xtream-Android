package pl.tvmad.xtream

import android.content.Context
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.RenderersFactory
import androidx.media3.exoplayer.mediacodec.MediaCodecInfo
import androidx.media3.exoplayer.mediacodec.MediaCodecSelector
import androidx.media3.exoplayer.mediacodec.MediaCodecUtil

/**
 * Wspólna konfiguracja odtwarzania dla LIVE i VOD.
 *
 * Cała logika doboru dekoderów, bufora i warstwy sieciowej jest tutaj, żeby LIVE i VOD nie
 * rozjeżdżały się przypadkiem i żeby dało się je stroić w jednym miejscu.
 */
@UnstableApi
object PlayerEngine {

    /** User-Agent używany dotąd przez LIVE. Nie zmieniamy go — serwery IPTV bywają na niego wyczulone. */
    private const val LIVE_USER_AGENT = "TvMad-Xtream Android"

    /** User-Agent używany dotąd przez VOD. */
    private const val VOD_USER_AGENT = "TvMad-Xtream/AndroidTV"

    /**
     * Selektor dekoderów, który dla WIDEO stawia sprzętowy MediaCodec przed programowym.
     *
     * `MediaCodecSelector.DEFAULT` zwraca listę w kolejności podanej przez platformę, a tania
     * przystawka TV potrafi wystawić `c2.android.avc.decoder` (software) przed dekoderem
     * sprzętowym. Software H.264/HEVC w 1080p50 to natychmiast 90%+ CPU i gubione klatki.
     * Dekodery programowe zostają na końcu listy jako realny fallback — nie są usuwane.
     */
    private val hardwareFirstSelector = MediaCodecSelector { mimeType, requiresSecure, requiresTunneling ->
        val infos = MediaCodecUtil.getDecoderInfos(mimeType, requiresSecure, requiresTunneling)
        if (!MimeTypes.isVideo(mimeType) || infos.size < 2) infos
        else infos.sortedByDescending { rank(it) }
    }

    private fun rank(info: MediaCodecInfo): Int = when {
        info.hardwareAccelerated -> 2
        !info.softwareOnly -> 1
        else -> 0
    }

    /**
     * LIVE: sprzętowy MediaCodec ma priorytet dla wideo, FFmpeg zostaje wyłącznie jako
     * fallback audio (rozszerzenie media3-ffmpeg nie zawiera renderera wideo, więc obraz
     * nigdy nie trafia do FFmpeg). `EXTENSION_RENDERER_MODE_ON` ustawia FFmpeg ZA
     * MediaCodekiem, czyli sprzęt jest wybierany zawsze, gdy obsługuje format.
     */
    fun liveRenderers(context: Context): RenderersFactory =
        DefaultRenderersFactory(context.applicationContext)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
            .setEnableDecoderFallback(true)
            .setMediaCodecSelector(hardwareFirstSelector)

    /**
     * VOD: identyczna ścieżka wideo (sprzęt pierwszy), ale audio zostaje na dotychczasowym
     * `EXTENSION_RENDERER_MODE_PREFER`. Pliki VOD mają AC3/EAC3/DTS/TrueHD, których część
     * przystawek nie dekoduje poprawnie sprzętowo, a ta konfiguracja działa u użytkownika
     * od dawna. Zmiana kolejności rendererów audio w VOD nie ma uzasadnienia wydajnościowego
     * (24/25 fps, dużo zapasu CPU), a mogłaby zabrać dźwięk w egzotycznych formatach.
     */
    fun vodRenderers(context: Context): RenderersFactory =
        DefaultRenderersFactory(context.applicationContext)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
            .setEnableDecoderFallback(true)
            .setMediaCodecSelector(hardwareFirstSelector)

    /**
     * Bufor LIVE.
     *
     * Kluczowa wartość to ostatni parametr — ile materiału player musi uzbierać po rebufferze,
     * zanim wznowi odtwarzanie. Strumień LIVE przychodzi w tempie rzeczywistym, więc 5 s
     * oznaczało dosłownie ~5 s czarnego ekranu po każdej czkawce i wpychało odtwarzanie
     * w pętlę start-stop-start. 2 s wystarczają, żeby wyjść z dołka i nie zamrażać obrazu.
     *
     * Górny limit zszedł z 40 s do 20 s: bufor media3 to tablice bajtów na stercie aplikacji,
     * a 40 s strumienia 8-10 Mb/s to kilkadziesiąt MB, które na przystawce z małym heapem
     * generują GC w trakcie dekodowania 50 fps. Dodatkowy twardy limit bajtowy pilnuje tego
     * niezależnie od bitrate'u kanału.
     */
    fun liveLoadControl(): DefaultLoadControl = DefaultLoadControl.Builder()
        .setBufferDurationsMs(
            /* minBufferMs = */ 5_000,
            /* maxBufferMs = */ 20_000,
            /* bufferForPlaybackMs = */ 1_000,
            /* bufferForPlaybackAfterRebufferMs = */ 2_000
        )
        // Domyślny limit media3 to ~130 MB na ścieżkę, czyli w praktyce brak limitu.
        // 16 MB to ~16 s kanału 8 Mb/s i ~6 s kanału 20 Mb/s — poniżej minBufferMs player
        // i tak ładuje bez ograniczeń, więc ten limit nigdy nie zagłodzi startu.
        .setTargetBufferBytes(16 * 1024 * 1024)
        .setPrioritizeTimeOverSizeThresholds(true)
        .setBackBuffer(0, false)
        .build()

    /** VOD: bez zmian względem wersji, która działa — plik da się dociągnąć szybciej niż realtime. */
    fun vodLoadControl(): DefaultLoadControl = DefaultLoadControl.Builder()
        .setBufferDurationsMs(2_500, 30_000, 750, 1_500)
        .setPrioritizeTimeOverSizeThresholds(true)
        .build()

    /**
     * Warstwa HTTP dla LIVE.
     *
     * Timeouty zeszły z 20 s/60 s do 8 s/20 s. Przy zappingu martwe połączenie trzymało
     * odtwarzacz w "Buforowanie" nawet minutę, zanim w ogóle doszło do ponowienia. Dla
     * strumienia czasu rzeczywistego brak danych przez 20 s to i tak koniec transmisji.
     */
    fun liveHttpFactory(authHeader: String): DefaultHttpDataSource.Factory {
        val headers = HashMap<String, String>(4)
        headers["Accept"] = "*/*"
        headers["Accept-Encoding"] = "identity"
        headers["Connection"] = "keep-alive"
        if (authHeader.isNotBlank()) headers["Authorization"] = authHeader
        return DefaultHttpDataSource.Factory()
            .setUserAgent(LIVE_USER_AGENT)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(8_000)
            .setReadTimeoutMs(20_000)
            .setDefaultRequestProperties(headers)
    }

    /**
     * Warstwa danych dla VOD. `DefaultDataSource` opakowuje stos HTTP i dokłada obsługę
     * `file://` / `content://`, dzięki czemu lokalne nagrania otwierają się tą samą ścieżką
     * co filmy z serwera (wcześniej trafiały do fabryki wyłącznie HTTP).
     */
    fun vodDataSourceFactory(context: Context): DataSource.Factory {
        val http = DefaultHttpDataSource.Factory()
            .setUserAgent(VOD_USER_AGENT)
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(30_000)
            .setReadTimeoutMs(120_000)
            .setDefaultRequestProperties(
                mapOf(
                    "Accept" to "*/*",
                    "Accept-Encoding" to "identity",
                    "Connection" to "keep-alive"
                )
            )
        return DefaultDataSource.Factory(context.applicationContext, http)
    }
}
