package pl.tvmad.xtream

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject
import java.io.File


data class TvRecording(
    val id:String,
    val title:String,
    val channel:String,
    val description:String,
    val url:String,
    val authHeader:String="",
    val startEpoch:Long,
    val endEpoch:Long,
    val filePath:String="",
    val active:Boolean=false
)

object RecordingStore {
    private const val PREF="tvmad_recordings"
    private const val KEY="items"

    @Synchronized fun list(c:Context):MutableList<TvRecording>{
        val raw=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(KEY,"[]")?:"[]"
        return try{
            val a=JSONArray(raw);MutableList(a.length()){i->val o=a.getJSONObject(i);TvRecording(
                o.optString("id"),o.optString("title"),o.optString("channel"),o.optString("description"),o.optString("url"),o.optString("authHeader"),
                o.optLong("startEpoch"),o.optLong("endEpoch"),o.optString("filePath"),o.optBoolean("active",false)
            )}
        }catch(_:Exception){mutableListOf()}
    }

    @Synchronized private fun save(c:Context,items:List<TvRecording>){
        val a=JSONArray();items.forEach{r->a.put(JSONObject().apply{
            put("id",r.id);put("title",r.title);put("channel",r.channel);put("description",r.description);put("url",r.url);put("authHeader",r.authHeader)
            put("startEpoch",r.startEpoch);put("endEpoch",r.endEpoch);put("filePath",r.filePath);put("active",r.active)
        })}
        c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString(KEY,a.toString()).apply()
    }

    @Synchronized fun upsert(c:Context,r:TvRecording){val x=list(c);val i=x.indexOfFirst{it.id==r.id};if(i>=0)x[i]=r else x.add(0,r);save(c,x)}
    @Synchronized fun markFinished(c:Context,id:String,path:String){val x=list(c);val i=x.indexOfFirst{it.id==id};if(i>=0)x[i]=x[i].copy(filePath=path,active=false);save(c,x)}
    @Synchronized fun markStopped(c:Context,id:String){val x=list(c);val i=x.indexOfFirst{it.id==id};if(i>=0)x[i]=x[i].copy(active=false);save(c,x)}
    @Synchronized fun remove(c:Context,id:String){val x=list(c);val r=x.firstOrNull{it.id==id};r?.filePath?.takeIf{it.isNotBlank()}?.let{runCatching{File(it).delete()}};save(c,x.filterNot{it.id==id})}
    fun completed(c:Context)=list(c).filter{!it.active&&it.filePath.isNotBlank()&&File(it.filePath).exists()}.sortedByDescending{it.startEpoch}
    fun isActiveForUrl(c:Context,url:String)=list(c).any{it.active&&it.url==url}
    fun activeForUrl(c:Context,url:String)=list(c).firstOrNull{it.active&&it.url==url}

    fun recordingDir(c:Context):File?{
        val chosen=AppOptionsStore.storagePath(c).takeIf{it.isNotBlank()}?.let{File(it)}
        val base=chosen?.takeIf{it.exists()&&it.canWrite()} ?: c.getExternalFilesDirs(null).firstOrNull{it!=null&&it.exists()&&it.canWrite()}
        return base?.let{File(it,"Recordings").apply{mkdirs()}}?.takeIf{it.isDirectory&&it.canWrite()}
    }

    fun schedule(c:Context,r:TvRecording):Boolean{
        upsert(c,r.copy(active=false))
        val now=System.currentTimeMillis()
        if(r.startEpoch<=now+1500L){startNow(c,r);return true}
        val am=c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi=PendingIntent.getBroadcast(c,r.id.hashCode(),Intent(c,RecordingAlarmReceiver::class.java).apply{putExtra("recordingId",r.id)},PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return try{
            if(Build.VERSION.SDK_INT>=31&&am.canScheduleExactAlarms())am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,r.startEpoch,pi)
            else if(Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,r.startEpoch,pi)
            else am.setExact(AlarmManager.RTC_WAKEUP,r.startEpoch,pi)
            true
        }catch(_:Exception){false}
    }

    fun startNow(c:Context,r:TvRecording){
        upsert(c,r.copy(active=true))
        val i=Intent(c,RecordingService::class.java).apply{action=RecordingService.ACTION_START;putExtra("recordingId",r.id)}
        if(Build.VERSION.SDK_INT>=26)c.startForegroundService(i) else c.startService(i)
    }

    fun stop(c:Context,id:String){
        val i=Intent(c,RecordingService::class.java).apply{action=RecordingService.ACTION_STOP;putExtra("recordingId",id)}
        c.startService(i)
    }

    fun fileUri(r:TvRecording):Uri=Uri.fromFile(File(r.filePath))
}
