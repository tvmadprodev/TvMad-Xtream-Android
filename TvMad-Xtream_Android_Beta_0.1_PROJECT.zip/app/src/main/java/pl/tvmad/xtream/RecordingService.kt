package pl.tvmad.xtream

import android.app.*
import android.content.Intent
import android.os.IBinder
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

class RecordingService:Service(){
    companion object{const val ACTION_START="pl.tvmad.xtream.RECORD_START";const val ACTION_STOP="pl.tvmad.xtream.RECORD_STOP";private const val CH="tvmad_recording";private val activeUrls=ConcurrentHashMap.newKeySet<String>();fun isActiveUrl(url:String)=activeUrls.contains(url)}
    private val stopFlags=ConcurrentHashMap<String,Boolean>()
    override fun onBind(intent:Intent?):IBinder?=null
    override fun onCreate(){super.onCreate();if(android.os.Build.VERSION.SDK_INT>=26){val nm=getSystemService(NOTIFICATION_SERVICE) as NotificationManager;nm.createNotificationChannel(NotificationChannel(CH,"Nagrywanie TvMad",NotificationManager.IMPORTANCE_LOW))}}
    override fun onStartCommand(intent:Intent?,flags:Int,startId:Int):Int{
        val id=intent?.getStringExtra("recordingId").orEmpty();if(id.isBlank())return START_NOT_STICKY
        if(intent?.action==ACTION_STOP){stopFlags[id]=true;return START_NOT_STICKY}
        val r=RecordingStore.list(this).firstOrNull{it.id==id}?:return START_NOT_STICKY
        stopFlags[id]=false;activeUrls.add(r.url);startForeground(id.hashCode().and(0x7fffffff).coerceAtLeast(1),notification("Nagrywanie: ${r.title}"))
        thread(name="TvMad-Recorder-$id",isDaemon=true){try{record(r)}finally{activeUrls.remove(r.url);if(activeUrls.isEmpty()){stopForeground(STOP_FOREGROUND_REMOVE);stopSelf()}}}
        return START_NOT_STICKY
    }
    private fun notification(text:String):Notification{
        val b=if(android.os.Build.VERSION.SDK_INT>=26)Notification.Builder(this,CH) else Notification.Builder(this)
        return b.setContentTitle("TvMad-Xtream").setContentText(text).setSmallIcon(android.R.drawable.presence_video_online).setOngoing(true).build()
    }
    private fun shouldStop(r:TvRecording)=stopFlags[r.id]==true || (r.endEpoch>0L&&System.currentTimeMillis()>=r.endEpoch)
    private fun safeName(s:String)=s.replace(Regex("[\\/:*?\"<>|\\p{Cntrl}]"),"_").trim().take(90).ifBlank{"nagranie"}
    private fun record(r:TvRecording){
        val dir=RecordingStore.recordingDir(this);if(dir==null){RecordingStore.markStopped(this,r.id);return}
        val stamp=java.text.SimpleDateFormat("yyyyMMdd_HHmm",java.util.Locale.getDefault()).format(java.util.Date(if(r.startEpoch>0)r.startEpoch else System.currentTimeMillis()))
        val file=File(dir,"${stamp}_${safeName(r.title)}.ts")
        var ok=false
        try{BufferedOutputStream(FileOutputStream(file),128*1024).use{out->ok=if(r.url.contains(".m3u8",true))recordHls(r,r.url,out) else recordDirect(r,r.url,out)}}catch(_:Exception){}
        if(file.exists()&&file.length()>0L)RecordingStore.markFinished(this,r.id,file.absolutePath) else{runCatching{file.delete()};RecordingStore.markStopped(this,r.id)}
    }
    private fun open(raw:String,auth:String=""):HttpURLConnection=(URL(raw).openConnection() as HttpURLConnection).apply{connectTimeout=15000;readTimeout=20000;instanceFollowRedirects=true;setRequestProperty("User-Agent","TvMad-Xtream Android");setRequestProperty("Connection","keep-alive");if(auth.isNotBlank())setRequestProperty("Authorization",auth)}
    private fun recordDirect(r:TvRecording,url:String,out:OutputStream):Boolean{
        val c=open(url,r.authHeader);try{
            val ct=c.contentType.orEmpty().lowercase();if(ct.contains("mpegurl")||ct.contains("m3u8"))return recordHls(r,url,out)
            val buf=ByteArray(64*1024);c.inputStream.use{input->while(!shouldStop(r)){val n=try{input.read(buf)}catch(_:java.net.SocketTimeoutException){continue};if(n<0)break;if(n>0)out.write(buf,0,n)}};out.flush();return true
        }finally{c.disconnect()}
    }
    private fun readText(url:String,auth:String):String{val c=open(url,auth);return try{c.inputStream.bufferedReader().use{it.readText()}}finally{c.disconnect()}}
    private fun abs(base:String,part:String)=URL(URL(base),part).toString()
    private fun recordHls(r:TvRecording,start:String,out:OutputStream):Boolean{
        var playlist=start;val seen=LinkedHashSet<String>();var initialized=false
        while(!shouldStop(r)){
            val text=try{readText(playlist,r.authHeader)}catch(_:Exception){Thread.sleep(900);continue}
            val lines=text.lineSequence().map{it.trim()}.filter{it.isNotEmpty()}.toList()
            val variant=lines.indices.firstOrNull{i->lines[i].startsWith("#EXT-X-STREAM-INF",true)&&i+1<lines.size&&!lines[i+1].startsWith("#")}
            if(variant!=null){playlist=abs(playlist,lines[variant+1]);continue}
            val segs=lines.filter{!it.startsWith("#")}.map{abs(playlist,it)}
            if(!initialized&&segs.size>3)segs.take((segs.size-2).coerceAtLeast(0)).forEach{seen.add(it)}
            initialized=true
            for(seg in segs){if(shouldStop(r))break;if(!seen.add(seg))continue;try{val c=open(seg,r.authHeader);try{c.inputStream.use{it.copyTo(out,64*1024)}}finally{c.disconnect()}}catch(_:Exception){seen.remove(seg)}}
            out.flush();if(lines.any{it.equals("#EXT-X-ENDLIST",true)})break;Thread.sleep(900)
        };return true
    }
}
