package pl.tvmad.xtream

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object SourceStore {
    private const val PREFS = "tvmad_sources"
    private const val KEY = "sources"

    fun load(context: Context): MutableList<Source> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        return try {
            val a = JSONArray(raw)
            MutableList(a.length()) { i ->
                val o = a.getJSONObject(i)
                Source(
                    type = o.optString("type"), name = o.optString("name"), host = o.optString("host"),
                    user = o.optString("user"), pass = o.optString("pass"), url = o.optString("url")
                )
            }
        } catch (_: Exception) { mutableListOf() }
    }

    fun save(context: Context, sources: List<Source>) {
        val a = JSONArray()
        sources.forEach { s ->
            a.put(JSONObject().apply {
                put("type", s.type); put("name", s.name); put("host", s.host)
                put("user", s.user); put("pass", s.pass); put("url", s.url)
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply()
    }
}
