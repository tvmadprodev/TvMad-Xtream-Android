package pl.tvmad.xtream

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class RecordingAlarmReceiver:BroadcastReceiver(){
    override fun onReceive(context:Context,intent:Intent){
        val id=intent.getStringExtra("recordingId").orEmpty();if(id.isBlank())return
        val r=RecordingStore.list(context).firstOrNull{it.id==id}?:return
        if(r.endEpoch>0L&&System.currentTimeMillis()>=r.endEpoch){RecordingStore.markStopped(context,id);return}
        RecordingStore.startNow(context,r)
    }
}
