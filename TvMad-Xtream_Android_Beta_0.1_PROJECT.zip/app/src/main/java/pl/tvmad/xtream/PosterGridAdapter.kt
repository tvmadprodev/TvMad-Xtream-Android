package pl.tvmad.xtream

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.util.concurrent.Executors

/**
 * Lekki adapter okładek przeznaczony dla Android TV.
 * Nie wymaga zewnętrznej biblioteki obrazów: ma cache RAM + cache dyskowy,
 * a pobieranie okładek odbywa się poza wątkiem UI.
 */
class PosterGridAdapter(
    private val context: Context,
    private val titles: List<String>,
    private val posters: List<String>,
    private val series: Boolean
) : BaseAdapter() {

    private val density = context.resources.displayMetrics.density
    private var selectedPosition = 0

    private data class Holder(val poster: ImageView, val title: TextView)

    override fun getCount() = titles.size
    override fun getItem(position: Int) = titles[position]
    override fun getItemId(position: Int) = position.toLong()

    fun setSelectedPosition(position: Int) {
        selectedPosition = position.coerceIn(0, (count - 1).coerceAtLeast(0))
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val root: LinearLayout
        val holder: Holder
        if (convertView is LinearLayout && convertView.tag is Holder) {
            root = convertView
            holder = convertView.tag as Holder
        } else {
            root = LinearLayout(context).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                isFocusable = false
                isClickable = false
                setPadding(dp(6), dp(6), dp(6), dp(6))
                background = context.getDrawable(if (series) R.drawable.poster_card_series else R.drawable.poster_card_vod)
                layoutParams = android.widget.AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(214))
            }
            val poster = ImageView(context).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                adjustViewBounds = false
                setImageResource(if (series) R.drawable.ic_reel_large else R.drawable.ic_clapper_large)
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(168))
            }
            val title = TextView(context).apply {
                setTextColor(0xFFFFFFFF.toInt())
                textSize = 12f
                gravity = Gravity.CENTER
                isSingleLine = true
                ellipsize = android.text.TextUtils.TruncateAt.MARQUEE
                marqueeRepeatLimit = -1
                setHorizontallyScrolling(true)
                isFocusable = false
                isFocusableInTouchMode = false
                setPadding(dp(3), dp(7), dp(3), 0)
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(38))
            }
            root.addView(poster)
            root.addView(title)
            holder = Holder(poster, title)
            root.tag = holder
        }

        root.isSelected = position == selectedPosition
        holder.title.text = titles[position]
        // MARQUEE działa wyłącznie dla aktualnie zaznaczonej okładki.
        holder.title.isSelected = position == selectedPosition

        val posterUrl = posters.getOrNull(position).orEmpty()
        holder.poster.tag = posterUrl
        holder.poster.setImageResource(if (series) R.drawable.ic_reel_large else R.drawable.ic_clapper_large)
        if (posterUrl.isNotBlank()) PosterImageLoader.load(context, posterUrl, holder.poster)
        return root
    }

    private fun dp(v: Int) = (v * density + 0.5f).toInt()
}

private object PosterImageLoader {
    private val main = Handler(Looper.getMainLooper())
    private val workers = Executors.newFixedThreadPool(4)
    private val memory = object : LruCache<String, Bitmap>(24 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    fun load(context: Context, url: String, image: ImageView) {
        memory.get(url)?.let {
            if (image.tag == url) image.setImageBitmap(it)
            return
        }
        val dir = File(context.cacheDir, "poster_grid").apply { mkdirs() }
        val disk = File(dir, sha1(url) + ".img")
        workers.execute {
            var bitmap: Bitmap? = null
            try {
                if (disk.isFile && disk.length() > 0L) {
                    bitmap = decodeSized(disk.readBytes())
                }
                if (bitmap == null) {
                    val c = (URL(url).openConnection() as HttpURLConnection).apply {
                        connectTimeout = 12000
                        readTimeout = 18000
                        instanceFollowRedirects = true
                        setRequestProperty("User-Agent", "Mozilla/5.0 TvMad-Xtream")
                    }
                    val bytes = try {
                        c.inputStream.use { it.readBytes() }
                    } finally {
                        c.disconnect()
                    }
                    if (bytes.isNotEmpty()) {
                        try { disk.writeBytes(bytes) } catch (_: Exception) {}
                        bitmap = decodeSized(bytes)
                    }
                }
            } catch (_: Exception) {}
            bitmap?.let { b ->
                memory.put(url, b)
                main.post { if (image.tag == url) image.setImageBitmap(b) }
            }
        }
    }

    private fun decodeSized(bytes: ByteArray): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
        var sample = 1
        while (bounds.outWidth / sample > 420 || bounds.outHeight / sample > 630) sample *= 2
        return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = sample })
    }

    private fun sha1(s: String): String = MessageDigest.getInstance("SHA-1")
        .digest(s.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
}
