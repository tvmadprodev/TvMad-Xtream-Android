package pl.tvmad.xtream

import android.content.Context

object LastLiveStore {
    private const val PREFS = "tvmad_last_live"

    data class Saved(val source:Source,val channel:Channel)

    fun save(context:Context, source:Source, channel:Channel){
        context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit()
            .putString("sourceType",source.type).putString("sourceName",source.name)
            .putString("sourceHost",source.host).putString("sourceUser",source.user).putString("sourceUrl",source.url)
            .putString("name",channel.name).putString("url",channel.url).putString("group",channel.group)
            .putString("logo",channel.logo).putString("epgId",channel.epgId).putString("streamId",channel.streamId).putString("groupId",channel.groupId)
            .apply()
    }

    fun load(context:Context):Saved?{
        val p=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE)
        val url=p.getString("url","").orEmpty()
        if(url.isBlank())return null
        val source=Source(
            p.getString("sourceType","").orEmpty(),p.getString("sourceName","").orEmpty(),
            p.getString("sourceHost","").orEmpty(),p.getString("sourceUser","").orEmpty(),"",
            p.getString("sourceUrl","").orEmpty()
        )
        val channel=Channel(
            NameCleaner.cleanLive(p.getString("name","").orEmpty()),url,p.getString("group","").orEmpty(),
            p.getString("logo","").orEmpty(),p.getString("epgId","").orEmpty(),p.getString("streamId","").orEmpty(),p.getString("groupId","").orEmpty()
        )
        return Saved(source,channel)
    }

    fun sourceMatches(saved:Source, actual:Source):Boolean = when(saved.type){
        "xtream" -> actual.type=="xtream" && actual.host==saved.host && actual.user==saved.user
        "m3u" -> actual.type=="m3u" && actual.url==saved.url
        else -> false
    }
}
