package pl.tvmad.xtream

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

/**
 * Persistent, per-source snapshot for VOD/series catalogues.
 * UI always reads a stable snapshot. Background refreshes only replace files,
 * never the lists currently shown on screen.
 */
object CatalogCacheStore {
    private fun key(src: Source): String {
        val raw = if (src.type == "xtream") "${src.type}|${src.host}|${src.user}" else "${src.type}|${src.url}"
        return MessageDigest.getInstance("SHA-256").digest(raw.toByteArray()).take(10).joinToString("") { "%02x".format(it) }
    }

    private fun safePart(raw: String): String = MessageDigest.getInstance("SHA-256")
        .digest(raw.toByteArray()).take(8).joinToString("") { "%02x".format(it) }

    private fun file(context: Context, src: Source, name: String) = File(context.filesDir, "catalog_${key(src)}_$name.json")

    private fun writeAtomic(target: File, text: String) {
        try {
            val tmp = File(target.parentFile, target.name + ".tmp")
            tmp.writeText(text)
            if (target.exists()) target.delete()
            if (!tmp.renameTo(target)) {
                target.writeText(text)
                tmp.delete()
            }
        } catch (_: Exception) {}
    }

    fun saveVodCategories(context: Context, src: Source, items: List<MediaCategory>) {
        val a = JSONArray()
        items.forEach { a.put(JSONObject().apply { put("id", it.id); put("name", it.name) }) }
        writeAtomic(file(context, src, "vod_categories"), a.toString())
    }

    fun loadVodCategories(context: Context, src: Source): List<MediaCategory> {
        return try {
        val f = file(context, src, "vod_categories"); if (!f.exists()) return emptyList()
        val a = JSONArray(f.readText()); val out = ArrayList<MediaCategory>(a.length())
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val id = o.optString("id"); if (id.isBlank()) continue
            out += MediaCategory(id, o.optString("name"))
        }
        out
        } catch (_: Exception) { emptyList() }
    }

    fun saveVodItems(context: Context, src: Source, categoryId: String, items: List<MediaItem>) {
        val a = JSONArray()
        items.forEach { x -> a.put(JSONObject().apply {
            put("id", x.id); put("name", x.name); put("categoryId", x.categoryId); put("icon", x.icon); put("ext", x.ext); put("url", x.url)
        }) }
        writeAtomic(file(context, src, "vod_${safePart(categoryId)}"), a.toString())
    }

    fun loadVodItems(context: Context, src: Source, categoryId: String): List<MediaItem> {
        return try {
        val f = file(context, src, "vod_${safePart(categoryId)}"); if (!f.exists()) return emptyList()
        val a = JSONArray(f.readText()); val out = ArrayList<MediaItem>(a.length())
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val id = o.optString("id"); if (id.isBlank()) continue
            out += MediaItem(id, o.optString("name"), o.optString("categoryId"), o.optString("icon"), o.optString("ext").ifBlank { "mp4" }, o.optString("url"))
        }
        out
        } catch (_: Exception) { emptyList() }
    }

    fun saveSeriesCategories(context: Context, src: Source, items: List<MediaCategory>) {
        val a = JSONArray()
        items.forEach { a.put(JSONObject().apply { put("id", it.id); put("name", it.name) }) }
        writeAtomic(file(context, src, "series_categories"), a.toString())
    }

    fun loadSeriesCategories(context: Context, src: Source): List<MediaCategory> {
        return try {
        val f = file(context, src, "series_categories"); if (!f.exists()) return emptyList()
        val a = JSONArray(f.readText()); val out = ArrayList<MediaCategory>(a.length())
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val id = o.optString("id"); if (id.isBlank()) continue
            out += MediaCategory(id, o.optString("name"))
        }
        out
        } catch (_: Exception) { emptyList() }
    }

    fun saveSeriesItems(context: Context, src: Source, categoryId: String, items: List<SeriesItem>) {
        val a = JSONArray()
        items.forEach { x -> a.put(JSONObject().apply { put("id", x.id); put("name", x.name); put("categoryId", x.categoryId); put("cover", x.cover) }) }
        writeAtomic(file(context, src, "series_${safePart(categoryId)}"), a.toString())
    }

    fun loadSeriesItems(context: Context, src: Source, categoryId: String): List<SeriesItem> {
        return try {
        val f = file(context, src, "series_${safePart(categoryId)}"); if (!f.exists()) return emptyList()
        val a = JSONArray(f.readText()); val out = ArrayList<SeriesItem>(a.length())
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            val id = o.optString("id"); if (id.isBlank()) continue
            out += SeriesItem(id, o.optString("name"), o.optString("categoryId"), o.optString("cover"))
        }
        out
        } catch (_: Exception) { emptyList() }
    }

    fun saveVodAll(context: Context, src: Source, items: List<MediaItem>) {
        val a = JSONArray()
        items.forEach { x -> a.put(JSONObject().apply {
            put("id", x.id); put("name", x.name); put("categoryId", x.categoryId); put("icon", x.icon); put("ext", x.ext); put("url", x.url)
        }) }
        writeAtomic(file(context, src, "vod_all"), a.toString())
    }

    fun loadVodAll(context: Context, src: Source): List<MediaItem> {
        return try {
            val f = file(context, src, "vod_all"); if (!f.exists()) return emptyList()
            val a = JSONArray(f.readText()); val out = ArrayList<MediaItem>(a.length())
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                val id = o.optString("id"); if (id.isBlank()) continue
                out += MediaItem(id, o.optString("name"), o.optString("categoryId"), o.optString("icon"), o.optString("ext").ifBlank { "mp4" }, o.optString("url"))
            }
            out
        } catch (_: Exception) { emptyList() }
    }

    fun saveSeriesAll(context: Context, src: Source, items: List<SeriesItem>) {
        val a = JSONArray()
        items.forEach { x -> a.put(JSONObject().apply { put("id", x.id); put("name", x.name); put("categoryId", x.categoryId); put("cover", x.cover) }) }
        writeAtomic(file(context, src, "series_all"), a.toString())
    }

    fun loadSeriesAll(context: Context, src: Source): List<SeriesItem> {
        return try {
            val f = file(context, src, "series_all"); if (!f.exists()) return emptyList()
            val a = JSONArray(f.readText()); val out = ArrayList<SeriesItem>(a.length())
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                val id = o.optString("id"); if (id.isBlank()) continue
                out += SeriesItem(id, o.optString("name"), o.optString("categoryId"), o.optString("cover"))
            }
            out
        } catch (_: Exception) { emptyList() }
    }
}
