package pl.tvmad.xtream

import org.json.JSONObject
import java.io.BufferedInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Tmdb {
    private const val KEY = "23c6d4a22a29bc1f9ab89c0355a6272a"
    data class Meta(val title:String,val overview:String,val rating:String,val year:String,val genres:String,val poster:String,val runtime:String="")

    private fun get(url:String):String {
        val c=(URL(url).openConnection() as HttpURLConnection).apply{
            connectTimeout=12000;readTimeout=15000;requestMethod="GET";setRequestProperty("User-Agent","TvMad-Xtream Android")
        }
        c.inputStream.use{return BufferedInputStream(it).bufferedReader().readText()}
    }
    private fun enc(s:String)=URLEncoder.encode(s,"UTF-8")
    private fun cleanTitle(raw:String):String = raw
        .replace('★',' ').replace('•',' ')
        .replace(Regex("(?i)\\b(PL|EN|UK|US|VIP|VOD|MULTI|LEKTOR|NAPISY|4K|UHD|FHD|HD|SD|1080P|720P|2160P)\\b")," ")
        .replace(Regex("\\b(19|20)\\d{2}\\b")," ")
        .replace(Regex("\\s+")," ").trim(' ','-','|',':')
    private fun yearFrom(raw:String)=Regex("\\b((?:19|20)\\d{2})\\b").find(raw)?.groupValues?.get(1).orEmpty()

    fun fetch(kind:String, rawTitle:String):Meta? {
        return try {
            val k=if(kind=="tv")"tv" else "movie";val title=cleanTitle(rawTitle);if(title.isBlank())return null
            val year=yearFrom(rawTitle)
            val yearArg=if(year.isNotBlank()) "&${if(k=="movie")"primary_release_year" else "first_air_date_year"}=$year" else ""
            val search=JSONObject(get("https://api.themoviedb.org/3/search/$k?api_key=$KEY&language=pl-PL&query=${enc(title)}$yearArg"))
            val arr=search.optJSONArray("results")?:return null;if(arr.length()==0)return null
            val hit=arr.getJSONObject(0);val id=hit.optString("id");if(id.isBlank())return null
            var d=JSONObject(get("https://api.themoviedb.org/3/$k/$id?api_key=$KEY&language=pl-PL"))
            var overview=d.optString("overview")
            if(overview.isBlank()){
                val en=JSONObject(get("https://api.themoviedb.org/3/$k/$id?api_key=$KEY&language=en-US"));overview=en.optString("overview")
            }
            val genres=d.optJSONArray("genres");val gl=ArrayList<String>();if(genres!=null)for(i in 0 until genres.length())gl+=genres.getJSONObject(i).optString("name")
            val dt=if(k=="movie")d.optString("release_date") else d.optString("first_air_date")
            val runtime=if(k=="movie")d.optInt("runtime",0).takeIf{it>0}?.let{"$it min"}.orEmpty() else ""
            Meta(
                d.optString(if(k=="movie")"title" else "name").ifBlank{rawTitle},
                overview.ifBlank{"Brak opisu w TMDB."},
                String.format("%.1f/10",d.optDouble("vote_average",0.0)),
                dt.take(4),gl.joinToString(" • "),
                d.optString("poster_path").takeIf{it.isNotBlank()}?.let{"https://image.tmdb.org/t/p/w500$it"}.orEmpty(),runtime
            )
        }catch(_:Exception){null}
    }

    fun loadImage(url:String):ByteArray?=try{URL(url).openStream().use{it.readBytes()}}catch(_:Exception){null}
}
