package pl.tvmad.xtream

import android.os.SystemClock
import android.util.Log
import androidx.media3.common.Format
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DecoderCounters
import androidx.media3.exoplayer.DecoderReuseEvaluation
import androidx.media3.exoplayer.analytics.AnalyticsListener

const val PLAYER_DIAG_TAG = "TvMadPlayer"

/**
 * Lekka diagnostyka odtwarzania.
 *
 * Nie odpytuje niczego cyklicznie i nie trzyma żadnego Handlera — reaguje wyłącznie na
 * zdarzenia, które media3 i tak generuje. Jedyne zdarzenie o wysokiej częstotliwości
 * (gubione klatki) jest agregowane i wypisywane najwyżej raz na [DROP_LOG_INTERVAL_MS].
 */
@UnstableApi
class PlaybackDiagnostics(private val label: String) : AnalyticsListener {

    private var videoDecoder = ""
    private var videoMime = ""
    private var videoSize = ""
    private var videoFps = ""
    private var droppedTotal = 0
    private var droppedSinceLog = 0
    private var lastDropLog = 0L
    private var rebuffers = 0
    private var everReady = false

    fun rebufferCount(): Int = rebuffers

    fun droppedFrames(): Int = droppedTotal

    /** Wywoływane przy zmianie kanału/pozycji, żeby liczniki dotyczyły bieżącego materiału. */
    fun resetCounters() {
        droppedTotal = 0
        droppedSinceLog = 0
        rebuffers = 0
        everReady = false
    }

    override fun onVideoDecoderInitialized(
        eventTime: AnalyticsListener.EventTime,
        decoderName: String,
        initializedTimestampMs: Long,
        initializationDurationMs: Long
    ) {
        videoDecoder = decoderName
        Log.i(
            PLAYER_DIAG_TAG,
            "$label video decoder init name=$decoderName mode=${if (isSoftwareCodec(decoderName)) "SOFTWARE" else "HARDWARE"} took=${initializationDurationMs}ms"
        )
        if (isSoftwareCodec(decoderName)) {
            Log.w(
                PLAYER_DIAG_TAG,
                "$label UWAGA: obraz dekodowany programowo ($decoderName) — to główne źródło wysokiego CPU"
            )
        }
    }

    override fun onVideoDecoderReleased(eventTime: AnalyticsListener.EventTime, decoderName: String) {
        Log.i(PLAYER_DIAG_TAG, "$label video decoder release name=$decoderName")
    }

    override fun onAudioDecoderInitialized(
        eventTime: AnalyticsListener.EventTime,
        decoderName: String,
        initializedTimestampMs: Long,
        initializationDurationMs: Long
    ) {
        Log.i(PLAYER_DIAG_TAG, "$label audio decoder init name=$decoderName")
    }

    override fun onVideoInputFormatChanged(
        eventTime: AnalyticsListener.EventTime,
        format: Format,
        decoderReuseEvaluation: DecoderReuseEvaluation?
    ) {
        videoMime = format.sampleMimeType ?: "?"
        if (format.width > 0 && format.height > 0) videoSize = "${format.width}x${format.height}"
        if (format.frameRate > 0f) videoFps = String.format("%.2f", format.frameRate)
        val reuse = decoderReuseEvaluation?.result
        Log.i(
            PLAYER_DIAG_TAG,
            "$label video format mime=$videoMime size=$videoSize fps=$videoFps codecs=${format.codecs ?: "-"} decoderReuse=${reuseName(reuse)}"
        )
    }

    override fun onVideoSizeChanged(eventTime: AnalyticsListener.EventTime, size: VideoSize) {
        videoSize = "${size.width}x${size.height}"
    }

    override fun onDroppedVideoFrames(
        eventTime: AnalyticsListener.EventTime,
        droppedFrames: Int,
        elapsedMs: Long
    ) {
        droppedTotal += droppedFrames
        droppedSinceLog += droppedFrames
        val now = SystemClock.uptimeMillis()
        if (now - lastDropLog < DROP_LOG_INTERVAL_MS) return
        lastDropLog = now
        Log.w(
            PLAYER_DIAG_TAG,
            "$label dropped=$droppedSinceLog (total=$droppedTotal) decoder=$videoDecoder $videoSize@$videoFps"
        )
        droppedSinceLog = 0
    }

    override fun onPlaybackStateChanged(eventTime: AnalyticsListener.EventTime, state: Int) {
        when (state) {
            Player.STATE_READY -> everReady = true
            Player.STATE_BUFFERING -> if (everReady) {
                rebuffers++
                Log.w(PLAYER_DIAG_TAG, "$label rebuffer #$rebuffers decoder=$videoDecoder dropped=$droppedTotal")
            }
        }
    }

    override fun onVideoDisabled(eventTime: AnalyticsListener.EventTime, counters: DecoderCounters) {
        counters.ensureUpdated()
        Log.i(
            PLAYER_DIAG_TAG,
            "$label video summary rendered=${counters.renderedOutputBufferCount} dropped=${counters.droppedBufferCount}" +
                " skipped=${counters.skippedOutputBufferCount} maxConsecutiveDropped=${counters.maxConsecutiveDroppedBufferCount}" +
                " rebuffers=$rebuffers"
        )
    }

    private fun reuseName(result: Int?): String = when (result) {
        null -> "none"
        DecoderReuseEvaluation.REUSE_RESULT_NO -> "no"
        DecoderReuseEvaluation.REUSE_RESULT_YES_WITHOUT_RECONFIGURATION -> "yes"
        DecoderReuseEvaluation.REUSE_RESULT_YES_WITH_RECONFIGURATION -> "yes-reconfig"
        DecoderReuseEvaluation.REUSE_RESULT_YES_WITH_FLUSH -> "yes-flush"
        else -> result.toString()
    }

    companion object {
        private const val DROP_LOG_INTERVAL_MS = 5_000L

        /** Ta sama heurystyka nazw, której media3 używa poniżej API 29 do wykrycia dekodera programowego. */
        fun isSoftwareCodec(name: String): Boolean =
            name.startsWith("OMX.google.") ||
                name.startsWith("OMX.ffmpeg.") ||
                name.startsWith("c2.android.") ||
                name.startsWith("c2.google.") ||
                (name.startsWith("OMX.SEC.") && name.endsWith(".sw.dec")) ||
                name == "OMX.qcom.video.decoder.hevcswvdec"
    }
}
