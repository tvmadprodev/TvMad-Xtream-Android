package pl.tvmad.xtream

import android.content.Context
import android.graphics.*
import android.os.SystemClock
import android.view.KeyEvent
import android.view.View
import kotlin.math.max
import kotlin.math.min

class MultiEpgGridView(context: Context) : View(context) {
    interface Listener {
        fun onSelectionChanged(channelIndex: Int, event: EpgEvent?)
        fun onNeedData(channelIndex: Int)
        fun onExitRequested()
    }

    var listener: Listener? = null
    private var channels: List<Channel> = emptyList()
    private val schedules = HashMap<String, List<EpgEvent>>()
    private val picons = HashMap<String, Bitmap>()
    private var selectedChannel = 0
    private var selectedEvent = 0
    private var anchorTime = System.currentTimeMillis()
    private var windowStart = floorHalfHour(System.currentTimeMillis()) - 15L * 60L * 1000L
    private var selectionChangedAt = SystemClock.uptimeMillis()

    private val density = resources.displayMetrics.density
    private fun dp(v: Float) = v * density
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL) }
    private val boldPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }

    private val headerH get() = dp(42f)
    private val rowH get() = dp(58f)
    private val channelW get() = dp(245f)
    private val piconW get() = dp(58f)
    private val piconH get() = dp(38f)
    private val timeSpan = 4L * 60L * 60L * 1000L

    init {
        isFocusable = true
        isFocusableInTouchMode = true
        setBackgroundColor(Color.rgb(3, 7, 11))
    }

    fun setData(newChannels: List<Channel>, startChannel: Int) {
        channels = newChannels
        selectedChannel = startChannel.coerceIn(0, max(0, channels.lastIndex))
        selectedEvent = eventIndexForTime(selectedChannel, anchorTime)
        selectionChangedAt = SystemClock.uptimeMillis()
        notifySelection()
        invalidate()
    }

    fun setSchedule(channelUrl: String, events: List<EpgEvent>) {
        schedules[channelUrl] = events.filter { it.startEpoch > 0L && it.endEpoch > it.startEpoch }.sortedBy { it.startEpoch }
        if (channels.getOrNull(selectedChannel)?.url == channelUrl) {
            selectedEvent = eventIndexForTime(selectedChannel, anchorTime)
            notifySelection()
        }
        invalidate()
    }

    fun setSchedules(all: Map<String, List<EpgEvent>>) {
        for ((k, v) in all) setSchedule(k, v)
    }

    fun setPicon(channelUrl: String, bitmap: Bitmap?) {
        if (bitmap != null) picons[channelUrl] = bitmap
        invalidate()
    }

    fun currentChannelIndex(): Int = selectedChannel

    private fun eventsFor(index: Int): List<EpgEvent> = channels.getOrNull(index)?.let { schedules[it.url] }.orEmpty()

    private fun eventIndexForTime(channelIndex: Int, t: Long): Int {
        val ev = eventsFor(channelIndex)
        if (ev.isEmpty()) return 0
        val current = ev.indexOfFirst { t >= it.startEpoch && t < it.endEpoch }
        if (current >= 0) return current
        val next = ev.indexOfFirst { it.startEpoch > t }
        return if (next >= 0) next else ev.lastIndex
    }

    private fun selectedEvent(): EpgEvent? = eventsFor(selectedChannel).getOrNull(selectedEvent)

    private fun notifySelection() {
        val ev = selectedEvent()
        if (ev != null) anchorTime = (ev.startEpoch + ev.endEpoch) / 2L
        keepSelectedEventVisible(ev)
        listener?.onSelectionChanged(selectedChannel, ev)
        listener?.onNeedData(selectedChannel)
    }

    private fun keepSelectedEventVisible(ev: EpgEvent?) {
        ev ?: return
        val right = windowStart + timeSpan
        if (ev.startEpoch < windowStart) windowStart = floorHalfHour(ev.startEpoch) - 15L * 60L * 1000L
        else if (ev.endEpoch > right) windowStart = floorHalfHour(ev.startEpoch) - 30L * 60L * 1000L
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (channels.isEmpty()) return super.onKeyDown(keyCode, event)
        when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> {
                selectedChannel = (selectedChannel - 1).coerceAtLeast(0)
                selectedEvent = eventIndexForTime(selectedChannel, anchorTime)
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                selectedChannel = (selectedChannel + 1).coerceAtMost(channels.lastIndex)
                selectedEvent = eventIndexForTime(selectedChannel, anchorTime)
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                val ev = eventsFor(selectedChannel)
                if (ev.isNotEmpty()) selectedEvent = (selectedEvent - 1).coerceAtLeast(0)
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                val ev = eventsFor(selectedChannel)
                if (ev.isNotEmpty()) selectedEvent = (selectedEvent + 1).coerceAtMost(ev.lastIndex)
            }
            KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE -> {
                listener?.onExitRequested(); return true
            }
            else -> return super.onKeyDown(keyCode, event)
        }
        selectionChangedAt = SystemClock.uptimeMillis()
        notifySelection()
        invalidate()
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (channels.isEmpty()) {
            textPaint.color = Color.LTGRAY; textPaint.textSize = dp(18f)
            canvas.drawText("Brak kanałów", dp(24f), dp(42f), textPaint)
            return
        }
        val timelineW = width - channelW
        if (timelineW <= 0f) return
        val pxPerMs = timelineW / timeSpan.toFloat()

        paint.color = Color.rgb(5, 10, 15)
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), paint)
        paint.color = Color.rgb(10, 19, 28)
        canvas.drawRect(0f, 0f, channelW, height.toFloat(), paint)

        drawHeader(canvas, pxPerMs)

        val visibleRows = max(1, ((height - headerH) / rowH).toInt())
        var firstRow = selectedChannel - visibleRows / 2
        firstRow = firstRow.coerceIn(0, max(0, channels.size - visibleRows))
        val lastRow = min(channels.lastIndex, firstRow + visibleRows - 1)

        for (rowIndex in firstRow..lastRow) {
            val yTop = headerH + (rowIndex - firstRow) * rowH
            drawRow(canvas, rowIndex, yTop, pxPerMs)
        }

        val now = System.currentTimeMillis()
        if (now in windowStart..(windowStart + timeSpan)) {
            val x = channelW + (now - windowStart) * pxPerMs
            paint.color = Color.rgb(220, 62, 50); paint.strokeWidth = dp(2f)
            canvas.drawLine(x, headerH - dp(3f), x, height.toFloat(), paint)
            val path = Path().apply { moveTo(x, headerH - dp(2f)); lineTo(x - dp(6f), headerH - dp(13f)); lineTo(x + dp(6f), headerH - dp(13f)); close() }
            canvas.drawPath(path, paint)
        }
    }

    private fun drawHeader(canvas: Canvas, pxPerMs: Float) {
        paint.color = Color.rgb(11, 19, 27); canvas.drawRect(0f, 0f, width.toFloat(), headerH, paint)
        boldPaint.color = Color.rgb(245, 166, 35); boldPaint.textSize = dp(15f)
        canvas.drawText("Dzisiaj", dp(10f), dp(27f), boldPaint)
        val half = 30L * 60L * 1000L
        var t = floorHalfHour(windowStart)
        val end = windowStart + timeSpan + half
        textPaint.color = Color.rgb(215, 224, 233); textPaint.textSize = dp(14f)
        val fmt = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault())
        while (t <= end) {
            val x = channelW + (t - windowStart) * pxPerMs
            if (x >= channelW - dp(20f) && x <= width + dp(20f)) {
                canvas.drawText(fmt.format(java.util.Date(t)), x + dp(4f), dp(27f), textPaint)
                paint.color = Color.rgb(53, 67, 79); paint.strokeWidth = dp(1f)
                canvas.drawLine(x, headerH, x, height.toFloat(), paint)
            }
            t += half
        }
        paint.color = Color.rgb(83, 101, 116); paint.strokeWidth = dp(1f)
        canvas.drawLine(0f, headerH - 1f, width.toFloat(), headerH - 1f, paint)
        canvas.drawLine(channelW, 0f, channelW, height.toFloat(), paint)
    }

    private fun drawRow(canvas: Canvas, index: Int, yTop: Float, pxPerMs: Float) {
        val c = channels[index]
        val selectedRow = index == selectedChannel
        paint.color = if (selectedRow) Color.rgb(17, 58, 91) else if (index % 2 == 0) Color.rgb(5, 12, 18) else Color.rgb(7, 15, 22)
        canvas.drawRect(0f, yTop, channelW, yTop + rowH, paint)
        paint.color = Color.rgb(58, 74, 88); paint.strokeWidth = dp(1f)
        canvas.drawLine(0f, yTop + rowH - 1f, width.toFloat(), yTop + rowH - 1f, paint)

        val bm = picons[c.url]
        if (bm != null) {
            val dst = RectF(dp(8f), yTop + (rowH - piconH) / 2f, dp(8f) + piconW, yTop + (rowH - piconH) / 2f + piconH)
            canvas.drawBitmap(bm, null, dst, paint)
        }
        boldPaint.color = if (selectedRow) Color.rgb(245, 166, 35) else Color.WHITE
        boldPaint.textSize = dp(15f)
        val label = c.name
        canvas.save(); canvas.clipRect(dp(72f), yTop, channelW - dp(6f), yTop + rowH)
        canvas.drawText(label, dp(75f), yTop + rowH / 2f + dp(5f), boldPaint); canvas.restore()

        val events = schedules[c.url].orEmpty()
        if (events.isEmpty()) {
            textPaint.color = Color.rgb(130, 143, 154); textPaint.textSize = dp(13f)
            canvas.drawText("EPG…", channelW + dp(10f), yTop + rowH / 2f + dp(5f), textPaint)
            return
        }
        val viewportEnd = windowStart + timeSpan
        for ((ei, ev) in events.withIndex()) {
            if (ev.endEpoch <= windowStart || ev.startEpoch >= viewportEnd) continue
            val x1 = channelW + ((max(ev.startEpoch, windowStart) - windowStart) * pxPerMs)
            val x2 = channelW + ((min(ev.endEpoch, viewportEnd) - windowStart) * pxPerMs)
            if (x2 - x1 < dp(4f)) continue
            val selected = selectedRow && ei == selectedEvent
            val isNow = System.currentTimeMillis() in ev.startEpoch until ev.endEpoch
            paint.color = when {
                selected -> Color.rgb(32, 118, 190)
                isNow -> Color.rgb(32, 105, 49)
                else -> Color.rgb(11, 16, 21)
            }
            canvas.drawRect(x1 + dp(1f), yTop + dp(2f), x2 - dp(1f), yTop + rowH - dp(2f), paint)
            paint.style = Paint.Style.STROKE; paint.color = Color.rgb(138, 151, 163); paint.strokeWidth = dp(if (selected) 1.6f else 0.8f)
            canvas.drawRect(x1 + dp(1f), yTop + dp(2f), x2 - dp(1f), yTop + rowH - dp(2f), paint); paint.style = Paint.Style.FILL

            val clipL = x1 + dp(6f); val clipR = x2 - dp(5f)
            if (clipR > clipL) {
                canvas.save(); canvas.clipRect(clipL, yTop + dp(2f), clipR, yTop + rowH - dp(2f))
                textPaint.color = Color.rgb(234, 239, 244); textPaint.textSize = dp(13.5f)
                val baseY = yTop + rowH / 2f + dp(5f)
                var tx = clipL
                if (selected) {
                    val textW = textPaint.measureText(ev.title)
                    val avail = clipR - clipL
                    if (textW > avail && SystemClock.uptimeMillis() - selectionChangedAt > 3000L) {
                        val overflow = textW - avail + dp(28f)
                        val elapsed = SystemClock.uptimeMillis() - selectionChangedAt - 3000L
                        val cycle = max(1L, (overflow * 35L / density).toLong() + 1700L)
                        val phase = elapsed % cycle
                        val moveTime = cycle - 1700L
                        val off = if (phase < moveTime) overflow * (phase.toFloat() / moveTime.toFloat()) else overflow
                        tx -= off
                        postInvalidateDelayed(40L)
                    } else if (textW > avail) postInvalidateDelayed(250L)
                }
                canvas.drawText(ev.title, tx, baseY, textPaint)
                canvas.restore()
            }
        }
    }

    companion object {
        private fun floorHalfHour(ms: Long): Long {
            val half = 30L * 60L * 1000L
            return (ms / half) * half
        }
    }
}
