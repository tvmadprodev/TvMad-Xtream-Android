package pl.tvmad.xtream

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** External-display-safe confirmation dialogs with explicit focusable buttons. */
object TvMadDialogs {
    fun showConfirm(
        activity: Activity,
        title: String,
        message: String,
        positiveText: String = "Tak",
        negativeText: String = "Nie",
        onPositive: () -> Unit,
        onNegative: () -> Unit = {},
        onCancel: () -> Unit = {}
    ): Dialog {
        val density = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * density + 0.5f).toInt()

        val dialog = Dialog(activity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(true)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setOwnerActivity(activity)

        val panel = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(34), dp(28), dp(34), dp(24))
            background = GradientDrawable().apply {
                setColor(Color.rgb(10, 22, 36))
                setStroke(dp(2), Color.rgb(66, 128, 176))
                cornerRadius = dp(12).toFloat()
            }
        }
        val titleView = TextView(activity).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 23f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val messageView = TextView(activity).apply {
            text = message
            setTextColor(Color.rgb(220, 232, 242))
            textSize = 18f
            setPadding(0, dp(12), 0, dp(22))
        }
        val buttons = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
        }
        val no = Button(activity).apply {
            text = negativeText
            isAllCaps = false
            isFocusable = true
            isFocusableInTouchMode = true
            minWidth = dp(132)
            minHeight = dp(54)
            textSize = 17f
            setTextColor(Color.WHITE)
            setBackgroundResource(R.drawable.button_dark)
            setOnClickListener { dialog.dismiss(); onNegative() }
        }
        val yes = Button(activity).apply {
            text = positiveText
            isAllCaps = false
            isFocusable = true
            isFocusableInTouchMode = true
            minWidth = dp(132)
            minHeight = dp(54)
            textSize = 17f
            setTextColor(Color.WHITE)
            setBackgroundResource(R.drawable.button_dark)
            setOnClickListener { dialog.dismiss(); onPositive() }
        }
        buttons.addView(no, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(54)).apply { marginEnd = dp(16) })
        buttons.addView(yes, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(54)))
        panel.addView(titleView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        panel.addView(messageView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        panel.addView(buttons, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        dialog.setContentView(panel)
        dialog.setOnCancelListener { onCancel() }
        dialog.setOnDismissListener { ExternalInputBridge.detachModal(dialog) }
        dialog.show()

        dialog.window?.let { w ->
            w.setBackgroundDrawableResource(android.R.color.transparent)
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            val attrs = w.attributes
            attrs.dimAmount = 0.48f
            w.attributes = attrs

            // Use the actual HDMI Activity window as the sizing reference. displayMetrics on the
            // S9+ can temporarily report Samsung's logical density and make dialogs tiny.
            val decorW = activity.window.decorView.width.takeIf { it > 0 } ?: activity.resources.displayMetrics.widthPixels
            val wanted = (decorW * 0.58f).toInt()
            val minW = (decorW * 0.46f).toInt()
            val maxW = (decorW * 0.78f).toInt()
            w.setLayout(wanted.coerceIn(minW.coerceAtLeast(1), maxW.coerceAtLeast(minW.coerceAtLeast(1))), WindowManager.LayoutParams.WRAP_CONTENT)
        }

        ExternalInputBridge.attachModal(dialog)
        no.requestFocus()
        return dialog
    }
}
