package pl.tvmad.xtream

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Small, external-display-safe confirmation dialog with an explicit button row. */
object TvMadDialogs {
    fun showConfirm(
        activity: Activity,
        title: String,
        message: String,
        positiveText: String = "Tak",
        negativeText: String = "Nie",
        onPositive: () -> Unit,
        onNegative: () -> Unit = {},
        onCancel: () -> Unit = {}
    ): Dialog {
        val density = activity.resources.displayMetrics.density
        fun dp(v: Int) = (v * density + 0.5f).toInt()

        val dialog = Dialog(activity)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.setCancelable(true)

        val panel = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(28), dp(22), dp(28), dp(20))
            background = GradientDrawable().apply {
                setColor(Color.rgb(10, 22, 36))
                setStroke(dp(1), Color.rgb(52, 98, 134))
                cornerRadius = dp(10).toFloat()
            }
        }
        val titleView = TextView(activity).apply {
            text = title
            setTextColor(Color.WHITE)
            textSize = 20f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val messageView = TextView(activity).apply {
            text = message
            setTextColor(Color.rgb(213, 225, 236))
            textSize = 16f
            setPadding(0, dp(10), 0, dp(18))
        }
        val buttons = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
        }
        val no = Button(activity).apply {
            text = negativeText
            isAllCaps = false
            isFocusable = true
            minWidth = dp(112)
            minHeight = dp(46)
            setTextColor(Color.WHITE)
            setBackgroundResource(R.drawable.button_dark)
            setOnClickListener { dialog.dismiss(); onNegative() }
        }
        val yes = Button(activity).apply {
            text = positiveText
            isAllCaps = false
            isFocusable = true
            minWidth = dp(112)
            minHeight = dp(46)
            setTextColor(Color.WHITE)
            setBackgroundResource(R.drawable.button_dark)
            setOnClickListener { dialog.dismiss(); onPositive() }
        }
        buttons.addView(no, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)).apply { marginEnd = dp(12) })
        buttons.addView(yes, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(46)))
        panel.addView(titleView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        panel.addView(messageView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        panel.addView(buttons, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        dialog.setContentView(panel)
        dialog.setOnCancelListener { onCancel() }
        dialog.show()

        dialog.window?.let { w ->
            w.setBackgroundDrawableResource(android.R.color.transparent)
            w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND)
            val attrs = w.attributes
            attrs.dimAmount = 0.55f
            w.attributes = attrs
            val dm = activity.resources.displayMetrics
            val maxByDp = dp(820)
            val width = (dm.widthPixels * 0.68f).toInt().coerceAtMost(maxByDp).coerceAtLeast(dp(520))
            w.setLayout(width.coerceAtMost((dm.widthPixels * 0.90f).toInt()), WindowManager.LayoutParams.WRAP_CONTENT)
        }
        no.requestFocus()
        return dialog
    }
}
