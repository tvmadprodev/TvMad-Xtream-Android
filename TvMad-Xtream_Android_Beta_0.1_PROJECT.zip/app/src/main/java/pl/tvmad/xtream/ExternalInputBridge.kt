package pl.tvmad.xtream

import android.app.Activity
import android.app.Dialog
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import java.lang.ref.WeakReference

/**
 * Input bridge used only by the Galaxy S9+ external-display build.
 *
 * Samsung keeps the physical mouse/remote attached to the default (phone) display even when
 * MainActivity is launched directly on HDMI. PhoneSplashActivity therefore receives the input.
 * This bridge forwards those events to whichever TvMad Activity is currently resumed on the
 * external display. Mouse coordinates are normalized from the AMOLED window to the HDMI window.
 *
 * IMPORTANT: dialogs on the HDMI display are separate Android windows. While one of our dialogs
 * is visible, all forwarded remote/mouse input is routed to that dialog window first and never to
 * the Activity behind it. This prevents the air-mouse cursor or DPAD focus from slipping through
 * a confirmation dialog onto the VOD infobar.
 */
object ExternalInputBridge {
    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var activeExternal = WeakReference<Activity>(null)
    @Volatile private var activeModal = WeakReference<Dialog>(null)

    private var cursorOwner = WeakReference<ViewGroup>(null)
    private var cursorView: ImageView? = null
    private val hideCursor = Runnable { cursorView?.visibility = View.GONE }

    fun attach(activity: Activity) {
        val displayId = activity.display?.displayId ?: activity.windowManager.defaultDisplay.displayId
        if (displayId != Display.DEFAULT_DISPLAY) {
            activeExternal = WeakReference(activity)
        }
    }

    fun detach(activity: Activity) {
        if (activeExternal.get() === activity) activeExternal = WeakReference<Activity>(null)
        val modal = activeModal.get()
        if (modal?.ownerActivity === activity) detachModal(modal)
        val parent = cursorOwner.get()
        if (parent != null && parent.rootView === activity.window.decorView.rootView) removeCursor()
    }

    fun attachModal(dialog: Dialog) {
        activeModal = WeakReference(dialog)
        removeCursor()
    }

    fun detachModal(dialog: Dialog) {
        if (activeModal.get() === dialog) activeModal = WeakReference<Dialog>(null)
        removeCursor()
    }

    fun hasExternalTarget(): Boolean = targetActivity() != null

    fun dispatchKey(event: KeyEvent): Boolean {
        val dialog = targetModal()
        if (dialog != null) {
            return try { dialog.dispatchKeyEvent(KeyEvent(event)) } catch (_: Throwable) { true }
        }
        val activity = targetActivity() ?: return false
        return try {
            activity.dispatchKeyEvent(KeyEvent(event))
        } catch (_: Throwable) {
            false
        }
    }

    fun dispatchMouse(event: MotionEvent, sourceWidth: Int, sourceHeight: Int, touchEvent: Boolean): Boolean {
        val activity = targetActivity() ?: return false
        val activityDecor = activity.window.decorView
        val targetWidth = activityDecor.width
        val targetHeight = activityDecor.height
        if (sourceWidth <= 0 || sourceHeight <= 0 || targetWidth <= 0 || targetHeight <= 0) return false

        val externalX = (event.x / sourceWidth.toFloat() * targetWidth.toFloat())
            .coerceIn(0f, (targetWidth - 1).coerceAtLeast(0).toFloat())
        val externalY = (event.y / sourceHeight.toFloat() * targetHeight.toFloat())
            .coerceIn(0f, (targetHeight - 1).coerceAtLeast(0).toFloat())

        val dialog = targetModal()
        if (dialog != null) {
            val decor = dialog.window?.decorView as? ViewGroup ?: return true
            if (decor.width <= 0 || decor.height <= 0) return true
            val activityLoc = IntArray(2)
            val dialogLoc = IntArray(2)
            activityDecor.getLocationOnScreen(activityLoc)
            decor.getLocationOnScreen(dialogLoc)
            val screenX = activityLoc[0] + externalX
            val screenY = activityLoc[1] + externalY
            val localX = screenX - dialogLoc[0]
            val localY = screenY - dialogLoc[1]
            val inside = localX >= 0f && localY >= 0f && localX < decor.width && localY < decor.height
            if (!inside) {
                // Modal really means modal: consume outside movement/clicks so the Activity beneath
                // can never be operated through the confirmation window.
                removeCursor()
                return true
            }
            showCursor(activity, decor, localX, localY)
            val copy = MotionEvent.obtain(event)
            return try {
                copy.setLocation(localX, localY)
                if (touchEvent) dialog.dispatchTouchEvent(copy)
                else dialog.dispatchGenericMotionEvent(copy)
            } catch (_: Throwable) {
                true
            } finally {
                copy.recycle()
            }
        }

        showCursor(activity, activityDecor as? ViewGroup ?: return false, externalX, externalY)
        val copy = MotionEvent.obtain(event)
        return try {
            copy.setLocation(externalX, externalY)
            if (touchEvent) activity.dispatchTouchEvent(copy)
            else activity.dispatchGenericMotionEvent(copy)
        } catch (_: Throwable) {
            false
        } finally {
            copy.recycle()
        }
    }

    private fun targetActivity(): Activity? {
        val activity = activeExternal.get() ?: return null
        if (activity.isFinishing || activity.isDestroyed) {
            activeExternal = WeakReference<Activity>(null)
            return null
        }
        return activity
    }

    private fun targetModal(): Dialog? {
        val dialog = activeModal.get() ?: return null
        if (!dialog.isShowing) {
            activeModal = WeakReference<Dialog>(null)
            return null
        }
        return dialog
    }

    private fun showCursor(activity: Activity, parent: ViewGroup, x: Float, y: Float) {
        val cursor = ensureCursor(activity, parent) ?: return
        val width = cursor.layoutParams?.width?.coerceAtLeast(1) ?: 1
        val height = cursor.layoutParams?.height?.coerceAtLeast(1) ?: 1
        cursor.x = x.coerceIn(0f, (parent.width - width).coerceAtLeast(0).toFloat())
        cursor.y = y.coerceIn(0f, (parent.height - height).coerceAtLeast(0).toFloat())
        cursor.visibility = View.VISIBLE
        cursor.bringToFront()
        mainHandler.removeCallbacks(hideCursor)
        mainHandler.postDelayed(hideCursor, 2200L)
    }

    private fun ensureCursor(activity: Activity, parent: ViewGroup): ImageView? {
        val current = cursorView
        if (current != null && cursorOwner.get() === parent && current.parent === parent) return current
        removeCursor()

        val density = activity.resources.displayMetrics.density
        val w = (28f * density).toInt().coerceAtLeast(20)
        val h = (36f * density).toInt().coerceAtLeast(26)
        return ImageView(activity).apply {
            setImageResource(R.drawable.remote_cursor)
            isClickable = false
            isFocusable = false
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            elevation = 1000f
            visibility = View.GONE
            parent.addView(this, ViewGroup.LayoutParams(w, h))
            cursorView = this
            cursorOwner = WeakReference(parent)
        }
    }

    private fun removeCursor() {
        mainHandler.removeCallbacks(hideCursor)
        val cursor = cursorView
        try { (cursor?.parent as? ViewGroup)?.removeView(cursor) } catch (_: Throwable) {}
        cursorView = null
        cursorOwner = WeakReference<ViewGroup>(null)
    }

    fun isMouse(event: MotionEvent): Boolean =
        event.isFromSource(InputDevice.SOURCE_MOUSE) ||
        event.isFromSource(InputDevice.SOURCE_MOUSE_RELATIVE)
}
