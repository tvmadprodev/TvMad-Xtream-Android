package pl.tvmad.xtream

import android.app.Activity
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import java.lang.ref.WeakReference

/**
 * Input bridge used only by the Galaxy S9+ external-display build.
 *
 * Samsung keeps the physical mouse/remote attached to the default (phone) display even when
 * MainActivity is launched directly on HDMI. PhoneSplashActivity therefore receives the input.
 * This bridge forwards those events to whichever TvMad Activity is currently resumed on the
 * external display. Mouse coordinates are normalized from the AMOLED window to the HDMI window
 * and a tiny software cursor is drawn on HDMI, while the real system cursor is hidden on phone.
 */
object ExternalInputBridge {
    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var activeExternal = WeakReference<Activity>(null)
    private var cursorOwner = WeakReference<Activity>(null)
    private var cursorView: ImageView? = null
    private val hideCursor = Runnable { cursorView?.visibility = View.GONE }

    fun attach(activity: Activity) {
        val displayId = activity.display?.displayId ?: activity.windowManager.defaultDisplay.displayId
        if (displayId != Display.DEFAULT_DISPLAY) {
            activeExternal = WeakReference(activity)
        }
    }

    fun detach(activity: Activity) {
        if (activeExternal.get() === activity) activeExternal = WeakReference<Activity>(null)
        if (cursorOwner.get() === activity) removeCursor()
    }

    fun hasExternalTarget(): Boolean = target() != null

    fun dispatchKey(event: KeyEvent): Boolean {
        val activity = target() ?: return false
        return try {
            activity.dispatchKeyEvent(KeyEvent(event))
        } catch (_: Throwable) {
            false
        }
    }

    fun dispatchMouse(event: MotionEvent, sourceWidth: Int, sourceHeight: Int, touchEvent: Boolean): Boolean {
        val activity = target() ?: return false
        val decor = activity.window.decorView
        val targetWidth = decor.width
        val targetHeight = decor.height
        if (sourceWidth <= 0 || sourceHeight <= 0 || targetWidth <= 0 || targetHeight <= 0) return false

        val x = (event.x / sourceWidth.toFloat() * targetWidth.toFloat()).coerceIn(0f, (targetWidth - 1).coerceAtLeast(0).toFloat())
        val y = (event.y / sourceHeight.toFloat() * targetHeight.toFloat()).coerceIn(0f, (targetHeight - 1).coerceAtLeast(0).toFloat())
        showCursor(activity, x, y)

        val copy = MotionEvent.obtain(event)
        return try {
            copy.setLocation(x, y)
            if (touchEvent) activity.dispatchTouchEvent(copy)
            else activity.dispatchGenericMotionEvent(copy)
        } catch (_: Throwable) {
            false
        } finally {
            copy.recycle()
        }
    }

    private fun target(): Activity? {
        val activity = activeExternal.get() ?: return null
        if (activity.isFinishing || activity.isDestroyed) {
            activeExternal = WeakReference<Activity>(null)
            return null
        }
        return activity
    }

    private fun showCursor(activity: Activity, x: Float, y: Float) {
        val cursor = ensureCursor(activity) ?: return
        val width = cursor.layoutParams?.width?.coerceAtLeast(1) ?: 1
        val height = cursor.layoutParams?.height?.coerceAtLeast(1) ?: 1
        val decor = activity.window.decorView
        cursor.x = x.coerceIn(0f, (decor.width - width).coerceAtLeast(0).toFloat())
        cursor.y = y.coerceIn(0f, (decor.height - height).coerceAtLeast(0).toFloat())
        cursor.visibility = View.VISIBLE
        cursor.bringToFront()
        mainHandler.removeCallbacks(hideCursor)
        mainHandler.postDelayed(hideCursor, 2200L)
    }

    private fun ensureCursor(activity: Activity): ImageView? {
        val current = cursorView
        if (current != null && cursorOwner.get() === activity && current.parent != null) return current
        removeCursor()

        val decor = activity.window.decorView as? ViewGroup ?: return null
        val density = activity.resources.displayMetrics.density
        val w = (28f * density).toInt().coerceAtLeast(20)
        val h = (36f * density).toInt().coerceAtLeast(26)
        return ImageView(activity).apply {
            setImageResource(R.drawable.remote_cursor)
            isClickable = false
            isFocusable = false
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            elevation = 1000f
            visibility = View.GONE
            decor.addView(this, ViewGroup.LayoutParams(w, h))
            cursorView = this
            cursorOwner = WeakReference(activity)
        }
    }

    private fun removeCursor() {
        mainHandler.removeCallbacks(hideCursor)
        val cursor = cursorView
        try { (cursor?.parent as? ViewGroup)?.removeView(cursor) } catch (_: Throwable) {}
        cursorView = null
        cursorOwner = WeakReference<Activity>(null)
    }

    fun isMouse(event: MotionEvent): Boolean =
        event.isFromSource(InputDevice.SOURCE_MOUSE) ||
        event.isFromSource(InputDevice.SOURCE_MOUSE_RELATIVE)
}
