package pl.tvmad.xtream

import android.content.Context
import android.util.Xml
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.BufferedInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.concurrent.ConcurrentHashMap
import java.util.zip.GZIPInputStream

/**
 * Opcjonalny XMLTV per serwer. EPG dostawcy zawsze ma pierwszeństwo; ten cache jest fallbackiem.
 * Aktualizacja odbywa się tylko po przekroczeniu 24 h od ostatniego UDANEGO skanu.
 */
object ExternalEpgStore {
    private const val REFRESH_MS = 24L * 60L * 60L * 1000L
    private const val KEEP_BACK_MS = 3L * 60L * 60L * 1000L
    private const val KEEP_FORWARD_MS = 30L * 60L * 60L * 1000L
    private const val PREFS = "external_xmltv_v1"

    private data class XmlChannel(val id:String,val names:Set<String>,val events:List<EpgEvent>)
    private data class Cache(val stamp:Long,val channels:List<XmlChannel>)
    private val memory=ConcurrentHashMap<String,Cache>()

    private fun hash(raw:String)=MessageDigest.getInstance("SHA-256").digest(raw.toByteArray()).take(12).joinToString(""){"%02x".format(it)}
    private fun sourceKey(src:Source)=hash(if(src.type=="xtream")"x|${src.host}|${src.user}|${src.epgUrl}" else "m|${src.url}|${src.epgUrl}")
    private fun file(context:Context,src:Source)=File(context.filesDir,"external_xmltv_${sourceKey(src)}.json")
    private fun prefKey(src:Source)="ok_${sourceKey(src)}"

    fun isConfigured(src:Source)=src.epgUrl.trim().startsWith("http://",true)||src.epgUrl.trim().startsWith("https://",true)

    fun refreshIfDue(context:Context,src:Source):Boolean {
        if(!isConfigured(src))return false
        val prefs=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE)
        val last=prefs.getLong(prefKey(src),0L)
        val f=file(context,src)
        val now=System.currentTimeMillis()
        if(f.exists() && last>0L && now-last<REFRESH_MS)return false
        val channels=sourceChannels(context,src)
        if(channels.isEmpty())return false
        val parsed=parseRemote(src.epgUrl.trim(),channels,now)
        save(context,src,parsed)
        prefs.edit().putLong(prefKey(src),System.currentTimeMillis()).apply()
        return true
    }

    private fun sourceChannels(context:Context,src:Source):List<Channel>{
        val groups=LiveCacheStore.loadGroups(context,src)
        val out=ArrayList<Channel>()
        for(g in groups)out.addAll(LiveCacheStore.loadGroupChannels(context,src,g))
        if(out.isEmpty())out.addAll(LiveCacheStore.loadChannels(context,src))
        return out.distinctBy{it.url}
    }

    private fun normId(s:String)=s.trim().lowercase(Locale.ROOT)

    private fun parseRemote(url:String,channels:List<Channel>,now:Long):List<XmlChannel>{
        val wantedIds=channels.mapNotNull{it.epgId.trim().takeIf{v->v.isNotBlank()}?.let(::normId)}.toHashSet()
        val wantedNames=channels.flatMap{NameCleaner.epgKeys(it.name)}.toHashSet()
        val conn=(URL(url).openConnection() as HttpURLConnection).apply{
            connectTimeout=15000;readTimeout=60000;instanceFollowRedirects=true
            setRequestProperty("User-Agent","TvMad-Xtream Android TV")
            setRequestProperty("Accept-Encoding","identity")
        }
        conn.connect()
        if(conn.responseCode !in 200..299)throw java.io.IOException("XMLTV HTTP ${conn.responseCode}")
        val raw=BufferedInputStream(conn.inputStream,64*1024)
        raw.mark(4);val b1=raw.read();val b2=raw.read();raw.reset()
        val compressed=url.lowercase(Locale.ROOT).endsWith(".gz") || (b1==0x1f && b2==0x8b)
        val input=if(compressed)GZIPInputStream(raw,64*1024) else raw
        val matchedIds=HashSet<String>()
        val namesById=HashMap<String,MutableSet<String>>()
        val eventsById=HashMap<String,MutableList<EpgEvent>>()
        try{
            val parser=Xml.newPullParser().apply{setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES,false);setInput(input,null)}
            var event=parser.eventType
            var channelId="";var inChannel=false
            while(event!=XmlPullParser.END_DOCUMENT){
                if(event==XmlPullParser.START_TAG){
                    when(parser.name){
                        "channel"->{channelId=parser.getAttributeValue(null,"id").orEmpty().trim();inChannel=true}
                        "display-name"->if(inChannel&&channelId.isNotBlank()){
                            val n=parser.nextText().trim();if(n.isNotBlank())namesById.getOrPut(channelId){linkedSetOf()}.add(n)
                        }
                        "programme"->{
                            val id=parser.getAttributeValue(null,"channel").orEmpty().trim()
                            val sid=normId(id)
                            val direct=sid in wantedIds
                            if(direct)matchedIds.add(id)
                            if(id in matchedIds){
                                val start=parseXmltvTime(parser.getAttributeValue(null,"start").orEmpty())
                                val stop=parseXmltvTime(parser.getAttributeValue(null,"stop").orEmpty())
                                if(stop>=now-KEEP_BACK_MS && start<=now+KEEP_FORWARD_MS){
                                    val ev=parseProgramme(parser,start,stop)
                                    if(ev.title.isNotBlank())eventsById.getOrPut(id){ArrayList()}.add(ev)
                                    event=parser.eventType
                                    continue
                                }
                            }
                        }
                    }
                }else if(event==XmlPullParser.END_TAG && parser.name=="channel"){
                    if(channelId.isNotBlank()){
                        val sid=normId(channelId)
                        val direct=sid in wantedIds
                        val nameMatch=namesById[channelId].orEmpty().any{n->NameCleaner.epgKeys(n).any{it in wantedNames}}
                        if(direct||nameMatch)matchedIds.add(channelId)
                    }
                    inChannel=false;channelId=""
                }
                event=parser.next()
            }
        }finally{try{input.close()}catch(_:Exception){};conn.disconnect()}
        val ids=(matchedIds+eventsById.keys).toList()
        return ids.mapNotNull{id->
            val ev=eventsById[id].orEmpty().sortedBy{it.startEpoch}
            if(ev.isEmpty())null else XmlChannel(id,namesById[id].orEmpty().toSet(),ev)
        }
    }

    private fun parseProgramme(parser:XmlPullParser,start:Long,stop:Long):EpgEvent{
        var title="";var desc="";var depth=parser.depth
        var event=parser.next()
        while(!(event==XmlPullParser.END_TAG && parser.depth==depth && parser.name=="programme") && event!=XmlPullParser.END_DOCUMENT){
            if(event==XmlPullParser.START_TAG){
                when(parser.name){
                    "title"->if(title.isBlank())title=parser.nextText().trim()
                    "desc"->if(desc.isBlank())desc=parser.nextText().trim()
                }
            }
            event=parser.next()
        }
        return EpgEvent(title,fmt(start),fmt(stop),start,stop,desc)
    }

    private fun parseXmltvTime(raw:String):Long{
        val s=raw.trim();if(s.isBlank())return 0L
        val candidates=listOf("yyyyMMddHHmmss Z","yyyyMMddHHmm Z","yyyyMMddHHmmss","yyyyMMddHHmm")
        for(pattern in candidates){
            try{
                val df=SimpleDateFormat(pattern,Locale.US).apply{isLenient=false;if(!pattern.contains("Z"))timeZone=TimeZone.getDefault()}
                val normalized=if(pattern.contains(" Z") && s.length>=5 && s[s.length-5] != ' ') s.dropLast(5)+" "+s.takeLast(5) else s
                val d=df.parse(normalized)?:continue
                return d.time
            }catch(_:Exception){}
        }
        return 0L
    }

    private fun fmt(ms:Long)=if(ms>0L)SimpleDateFormat("HH:mm",Locale.getDefault()).format(Date(ms)) else ""

    private fun save(context:Context,src:Source,channels:List<XmlChannel>){
        val a=JSONArray()
        channels.forEach{ch->
            a.put(JSONObject().apply{
                put("id",ch.id);put("names",JSONArray(ch.names.toList()))
                put("events",JSONArray().apply{ch.events.forEach{e->put(JSONObject().apply{
                    put("title",e.title);put("startEpoch",e.startEpoch);put("endEpoch",e.endEpoch);put("description",e.description)
                })}})
            })
        }
        val target=file(context,src);val tmp=File(target.parentFile,target.name+".tmp")
        tmp.writeText(JSONObject().apply{put("channels",a)}.toString())
        if(target.exists())target.delete();if(!tmp.renameTo(target)){target.writeText(tmp.readText());tmp.delete()}
        memory.remove(sourceKey(src))
    }

    private fun load(context:Context,src:Source):List<XmlChannel>{
        val f=file(context,src);if(!f.exists())return emptyList()
        val key=sourceKey(src);memory[key]?.takeIf{it.stamp==f.lastModified()}?.let{return it.channels}
        return try{
            val a=JSONObject(f.readText()).optJSONArray("channels")?:JSONArray();val out=ArrayList<XmlChannel>()
            for(i in 0 until a.length()){
                val o=a.optJSONObject(i)?:continue;val id=o.optString("id");val ns=o.optJSONArray("names")?:JSONArray();val names=linkedSetOf<String>()
                for(j in 0 until ns.length())names.add(ns.optString(j))
                val es=o.optJSONArray("events")?:JSONArray();val events=ArrayList<EpgEvent>()
                for(j in 0 until es.length()){
                    val e=es.optJSONObject(j)?:continue;val se=e.optLong("startEpoch");val ee=e.optLong("endEpoch")
                    events+=EpgEvent(e.optString("title"),fmt(se),fmt(ee),se,ee,e.optString("description"))
                }
                out+=XmlChannel(id,names,events)
            }
            memory[key]=Cache(f.lastModified(),out);out
        }catch(_:Exception){emptyList()}
    }

    fun schedule(context:Context,src:Source,ch:Channel):List<EpgEvent>{
        if(!isConfigured(src))return emptyList()
        val rows=load(context,src);if(rows.isEmpty())return emptyList()
        val eid=normId(ch.epgId);val keys=NameCleaner.epgKeys(ch.name)
        val row=rows.firstOrNull{eid.isNotBlank()&&normId(it.id)==eid}
            ?:rows.firstOrNull{r->r.names.any{n->NameCleaner.epgKeys(n).any{it in keys}}}
            ?:return emptyList()
        val now=System.currentTimeMillis()
        return row.events.filter{it.startEpoch>0&&it.endEpoch>it.startEpoch&&it.endEpoch>=now-6L*60L*60L*1000L}.sortedBy{it.startEpoch}
    }

    fun nowNext(context:Context,src:Source,ch:Channel):List<EpgEvent>{
        if(!isConfigured(src))return emptyList()
        val rows=load(context,src);if(rows.isEmpty())return emptyList()
        val eid=normId(ch.epgId);val keys=NameCleaner.epgKeys(ch.name)
        val row=rows.firstOrNull{eid.isNotBlank()&&normId(it.id)==eid}
            ?:rows.firstOrNull{r->r.names.any{n->NameCleaner.epgKeys(n).any{it in keys}}}
            ?:return emptyList()
        val now=System.currentTimeMillis();val timed=row.events.filter{it.startEpoch>0&&it.endEpoch>it.startEpoch}.sortedBy{it.startEpoch}
        val cur=timed.indexOfFirst{now>=it.startEpoch&&now<it.endEpoch}
        if(cur>=0)return timed.drop(cur).take(2)
        val next=timed.indexOfFirst{it.startEpoch>now}
        return if(next>=0)timed.drop(next).take(2) else emptyList()
    }
}
