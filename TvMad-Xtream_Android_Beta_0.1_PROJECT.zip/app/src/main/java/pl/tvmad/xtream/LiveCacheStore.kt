package pl.tvmad.xtream

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest

object LiveCacheStore {
    private fun key(src: Source): String {
        val raw = if (src.type == "xtream") "${src.type}|${src.host}|${src.user}" else "${src.type}|${src.url}"
        return MessageDigest.getInstance("SHA-256").digest(raw.toByteArray()).take(10).joinToString("") { "%02x".format(it) }
    }
    private fun channelsFile(context: Context, src: Source) = File(context.filesDir, "live_channels_v3_${key(src)}.json")
    private fun groupsFile(context: Context, src: Source) = File(context.filesDir, "live_groups_v3_${key(src)}.json")
    private fun groupChannelsFile(context: Context, src: Source, groupId:String):File {
        val g=MessageDigest.getInstance("SHA-256").digest(groupId.toByteArray()).take(8).joinToString(""){"%02x".format(it)}
        return File(context.filesDir,"live_group_v3_${key(src)}_${g}.json")
    }
    private fun epgFile(context: Context, src: Source) = File(context.filesDir, "live_last_epg_${key(src)}.json")

    fun saveChannels(context: Context, src: Source, channels: List<Channel>) {
        try {
            val a = JSONArray()
            channels.forEach { c -> a.put(JSONObject().apply {
                put("name", c.name); put("url", c.url); put("group", c.group); put("logo", c.logo); put("epgId", c.epgId); put("streamId", c.streamId); put("groupId", c.groupId)
            }) }
            val target = channelsFile(context, src)
            val tmp = File(target.parentFile, target.name + ".tmp." + Thread.currentThread().id)
            tmp.writeText(a.toString())
            if (target.exists()) target.delete()
            if (!tmp.renameTo(target)) { target.writeText(a.toString()); tmp.delete() }
        } catch (_: Exception) {}
    }

    fun loadChannels(context: Context, src: Source): List<Channel> {
        return try {
            val f = channelsFile(context, src); if (!f.exists()) return emptyList()
            val a = JSONArray(f.readText()); val out = ArrayList<Channel>(a.length())
            for (i in 0 until a.length()) {
                val o = a.optJSONObject(i) ?: continue
                val url = o.optString("url"); if (url.isBlank()) continue
                out += Channel(o.optString("name"), url, o.optString("group"), o.optString("logo"), o.optString("epgId"), o.optString("streamId"), o.optString("groupId"))
            }
            out
        } catch (_: Exception) { emptyList() }
    }


    fun saveGroupChannels(context:Context, src:Source, group:LiveGroup, channels:List<Channel>) {
        try {
            val a=JSONArray()
            channels.forEach { c -> a.put(JSONObject().apply {
                put("name",c.name);put("url",c.url);put("group",group.name);put("logo",c.logo);put("epgId",c.epgId);put("streamId",c.streamId);put("groupId",group.id)
            }) }
            val target=groupChannelsFile(context,src,group.id);val tmp=File(target.parentFile,target.name+".tmp."+Thread.currentThread().id)
            tmp.writeText(a.toString());if(target.exists())target.delete();if(!tmp.renameTo(target)){target.writeText(a.toString());tmp.delete()}
        } catch (_:Exception) {}
    }

    fun loadGroupChannels(context:Context, src:Source, group:LiveGroup):List<Channel> {
        return try {
            val f=groupChannelsFile(context,src,group.id);if(!f.exists())return emptyList()
            val a=JSONArray(f.readText());val out=ArrayList<Channel>(a.length())
            for(i in 0 until a.length()){
                val o=a.optJSONObject(i)?:continue;val url=o.optString("url");if(url.isBlank())continue
                out+=Channel(o.optString("name"),url,group.name,o.optString("logo"),o.optString("epgId"),o.optString("streamId"),group.id)
            }
            out
        } catch (_:Exception){emptyList()}
    }


    fun saveGroups(context: Context, src: Source, groups: List<LiveGroup>) {
        try {
            val a=JSONArray(); groups.forEach{g->a.put(JSONObject().apply{put("id",g.id);put("name",g.name)})}
            val target=groupsFile(context,src); val tmp=File(target.parentFile,target.name+".tmp."+Thread.currentThread().id)
            tmp.writeText(a.toString()); if(target.exists())target.delete(); if(!tmp.renameTo(target)){target.writeText(a.toString());tmp.delete()}
        } catch (_:Exception) {}
    }

    fun groupsAgeMs(context:Context,src:Source):Long {
        val f=groupsFile(context,src);if(!f.exists())return Long.MAX_VALUE
        return (System.currentTimeMillis()-f.lastModified()).coerceAtLeast(0L)
    }

    fun loadGroups(context: Context, src: Source): List<LiveGroup> {
        return try {
            val f=groupsFile(context,src); if(!f.exists())return emptyList()
            val a=JSONArray(f.readText()); val out=ArrayList<LiveGroup>()
            for(i in 0 until a.length()){val o=a.optJSONObject(i)?:continue;val id=o.optString("id").trim();val name=o.optString("name").trim();if(id.isNotBlank()&&name.isNotBlank())out+=LiveGroup(id,name)}
            out
        } catch (_:Exception){emptyList()}
    }

    fun saveCatalog(context: Context, src: Source, catalog: Api.LiveCatalog) {
        saveGroups(context,src,catalog.groups); saveChannels(context,src,catalog.channels)
    }
    fun saveLastEpg(context: Context, src: Source, channel: Channel, events: List<EpgEvent>) {
        try {
            val a = JSONArray(); events.take(4).forEach { e -> a.put(JSONObject().apply {
                put("title",e.title); put("start",e.start); put("end",e.end); put("startEpoch",e.startEpoch); put("endEpoch",e.endEpoch); put("description",e.description)
            }) }
            epgFile(context, src).writeText(JSONObject().apply { put("url",channel.url); put("events",a) }.toString())
        } catch (_: Exception) {}
    }

    fun loadLastEpg(context: Context, src: Source, channel: Channel): List<EpgEvent> {
        return try {
            val f=epgFile(context,src); if(!f.exists()) return emptyList()
            val o=JSONObject(f.readText()); if(o.optString("url")!=channel.url) return emptyList()
            val a=o.optJSONArray("events")?:return emptyList(); val out=ArrayList<EpgEvent>()
            for(i in 0 until a.length()) { val e=a.optJSONObject(i)?:continue; out+=EpgEvent(e.optString("title"),e.optString("start"),e.optString("end"),e.optLong("startEpoch"),e.optLong("endEpoch"),e.optString("description")) }
            val now=System.currentTimeMillis(); val useful=out.filter{it.endEpoch<=0L || it.endEpoch>=now-60_000L}
            if(useful.isNotEmpty()) useful else emptyList()
        } catch (_: Exception) { emptyList() }
    }
}
