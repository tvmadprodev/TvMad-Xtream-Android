package pl.tvmad.xtream

import android.content.Context
import java.io.*
import java.net.*
import java.util.concurrent.Executors
import java.util.zip.ZipInputStream

class WebConfigServer(
    private val context: Context,
    private val port: Int = 5557,
    private val onChanged: () -> Unit = {}
) {
    @Volatile private var running = false
    private var server: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()

    fun start() {
        if (running) return
        running = true
        pool.execute {
            try {
                server = ServerSocket(port, 20, InetAddress.getByName("0.0.0.0"))
                while (running) {
                    val s = server?.accept() ?: break
                    pool.execute { handle(s) }
                }
            } catch (_: Exception) { }
        }
    }

    fun stop() {
        running = false
        try { server?.close() } catch (_: Exception) {}
        pool.shutdownNow()
    }

    fun address(): String {
        var fallback = "127.0.0.1"
        var best = ""
        try {
            val all = NetworkInterface.getNetworkInterfaces()
            while (all.hasMoreElements()) {
                val ni = all.nextElement(); val n=ni.name.lowercase()
                if (!ni.isUp || ni.isLoopback || n.startsWith("tun") || n.startsWith("tap") || n.contains("vpn")) continue
                val addrs = ni.inetAddresses
                while (addrs.hasMoreElements()) {
                    val a = addrs.nextElement()
                    if (a !is Inet4Address || a.isLoopbackAddress) continue
                    val ip=a.hostAddress?:continue; fallback=ip
                    if(n.startsWith("wlan")||n.startsWith("eth")||n.startsWith("en")||ip.startsWith("192.168.")){best=ip;break}
                }
                if(best.isNotBlank())break
            }
        } catch (_: Exception) {}
        return "http://${best.ifBlank{fallback}}:$port"
    }

    private fun esc(s:String)=s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;")
    private fun js(s:String)=s.replace("\\","\\\\").replace("\'","\\\'").replace("\r"," ").replace("\n"," ")
    private fun decode(s:String)=URLDecoder.decode(s,"UTF-8")
    private fun form(body:String):Map<String,String> = body.split('&').mapNotNull { p ->
        val z=p.split('=',limit=2); if(z.size==2) decode(z[0]) to decode(z[1]) else null
    }.toMap()

    private fun html(): String {
        val src = SourceStore.load(context)
        val picons = PiconRepository.dir(context).listFiles()?.filter{it.isFile && it.extension.lowercase() in setOf("png","jpg","jpeg","webp") }?.sortedBy{it.name.lowercase()} ?: emptyList()
        val rows = src.mapIndexed { i,s ->
            val info = when(s.type){"xtream"->"${esc(s.host)} / ${esc(s.user)}";"e2"->"${esc(s.host)}:${s.webPort} · stream ${s.streamPort} · ${if(s.e2ZapOnBox)"ZAP dekodera" else "druga głowica / bez ZAP"} · picony ${if(s.e2PiconSource.equals("local",true))"lokalne" else "OpenWebIF"}";else->esc(s.url)}
            val epgInfo = if(s.epgUrl.isBlank()) "" else " · EPG XMLTV"
            val expInfo = if(s.expiry.isBlank()) "" else " · ważny do ${esc(s.expiry)}"
            val edit = when(s.type){"xtream"->"<button type='button' onclick=\"editX('${js(s.name)}','${js(s.host)}','${js(s.user)}','${js(s.pass)}','${js(s.epgUrl)}')\">Edytuj</button>";"e2"->"<button type='button' onclick=\"editE('${js(s.name)}','${js(s.host)}','${s.webPort}','${s.streamPort}','${js(s.user)}','${js(s.pass)}')\">Edytuj</button>";else->"<button type='button' onclick=\"editM('${js(s.name)}','${js(s.url)}','${js(s.epgUrl)}')\">Edytuj</button>"}
            "<div class='server'><div class='serverIcon'>▣</div><div class='serverMain'><b>${esc(s.name)}</b><small>${esc(s.type.uppercase())} · $info$epgInfo$expInfo</small></div>$edit<form method='post' action='/source/delete'><input type='hidden' name='i' value='$i'><button class='danger'>Usuń</button></form></div>"
        }.joinToString("")
        val piconGrid = if(picons.isEmpty()) "<div class='empty'>Brak własnych piconów</div>" else picons.take(36).joinToString("") { f ->
            "<div class='picon'><img src='/picon/${URLEncoder.encode(f.name,"UTF-8")}'><span>${esc(f.nameWithoutExtension)}</span></div>"
        }
        return """<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
        <title>TvMad-Xtream TV</title><style>
        :root{--bg:#070b12;--panel:#0e1620e8;--line:#263849;--blue:#1976e9;--cyan:#29a8ff;--violet:#8b5cff;--gold:#f59e0b;--text:#eef5fc;--muted:#8fa2b5}
        *{box-sizing:border-box}body{margin:0;font-family:system-ui,-apple-system,Segoe UI,sans-serif;background:radial-gradient(circle at 14% 8%,#0c3c78 0,transparent 27%),radial-gradient(circle at 80% 0,#361850 0,transparent 25%),linear-gradient(135deg,#050810,#0c1420 58%,#111b2b);color:var(--text);min-height:100vh}
        .shell{display:grid;grid-template-columns:220px 1fr;min-height:100vh}.side{background:#07101ae8;border-right:1px solid #24374a;padding:22px 14px;position:sticky;top:0;height:100vh}.brand{font-size:22px;font-weight:850;color:var(--cyan);margin:4px 8px 4px}.sub{font-size:11px;color:#71859a;margin:0 8px 24px}.nav{display:flex;flex-direction:column;gap:6px}.nav a{color:#c8d4df;text-decoration:none;padding:11px 12px;border-radius:9px}.nav a.active,.nav a:hover{background:linear-gradient(90deg,#0854c9,#147de7);color:white}.main{padding:24px 28px;max-width:1300px}.top{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px}.top h1{font-size:24px;margin:0}.pill{padding:8px 12px;border:1px solid #31516d;border-radius:10px;background:#0d1824;color:#9bd5ff;font-size:12px}
        .grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.box{background:linear-gradient(160deg,#111b27e8,#0a111aed);padding:18px;border:1px solid var(--line);border-radius:15px;box-shadow:0 14px 40px #0007}.widebox{grid-column:1/-1}.blue{border-color:#235f9e}.violet{border-color:#68439b}.gold{border-color:#95601d}h2{font-size:17px;margin:0 0 14px}small{display:block;color:var(--muted);line-height:1.45}
        input,button{padding:10px 11px;margin:4px 2px;border-radius:9px;border:1px solid #40566f;background:#0b121b;color:#fff;outline:none}input{min-width:180px}input.wide{width:calc(100% - 6px)}input:focus{border-color:#2e9bff;box-shadow:0 0 0 2px #2e9bff33}button{background:linear-gradient(135deg,#1257bc,#2583eb);border-color:#499cf0;font-weight:700;cursor:pointer}.danger{background:#351a23;border-color:#7f3545;color:#ffb9c4}.server{display:flex;align-items:center;gap:12px;padding:10px;border-bottom:1px solid #203143}.server:last-child{border:0}.serverIcon{width:36px;height:36px;display:grid;place-items:center;border-radius:9px;background:#0d58c4;color:#fff}.serverMain{flex:1}.serverMain b{display:block}.serverMain small{margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
        .upload{border:1px dashed #526b82;border-radius:12px;padding:12px;background:#08111a}.picons{display:grid;grid-template-columns:repeat(auto-fill,minmax(92px,1fr));gap:10px;margin-top:12px}.picon{background:#09111a;border:1px solid #24384b;border-radius:10px;padding:8px;text-align:center}.picon img{width:100%;height:54px;object-fit:contain}.picon span{font-size:10px;color:#8fa2b5;display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:5px}.empty{color:#71869b;padding:16px;text-align:center}.foot{margin-top:18px;color:#61768b;font-size:11px;text-align:right}
        @media(max-width:850px){.shell{grid-template-columns:1fr}.side{height:auto;position:static;border-right:0;border-bottom:1px solid #24374a}.nav{flex-direction:row;overflow:auto}.main{padding:16px}.grid{grid-template-columns:1fr}.widebox{grid-column:auto}}
        </style></head><body><div class='shell'>
        <aside class='side'><div class='brand'>TvMad-Xtream TV</div><div class='sub'>Web Interface · Android TV</div><nav class='nav'><a class='active' href='#servers'>▣ Serwery</a><a href='#xtream'>＋ Xtream</a><a href='#m3u'>▶ M3U</a><a href='#e2'>▣ Enigma2</a><a href='#picons'>▧ Picony</a></nav></aside>
        <main class='main'><div class='top'><h1>Konfiguracja TvMad-Xtream TV</h1><div class='pill'>Lokalna sieć · port $port</div></div><div class='grid'>
        <section id='servers' class='box blue widebox'><h2>Serwery</h2>${rows.ifBlank{"<div class='empty'>Nie dodano jeszcze serwera</div>"}}</section>
        <section id='xtream' class='box blue'><h2>＋ Xtream Codes</h2><form method='post' action='/source/add'><input type='hidden' name='type' value='xtream'><input id='xname' class='wide' name='name' placeholder='Nazwa serwera'><input id='xhost' class='wide' name='host' placeholder='http://host:port'><input id='xuser' name='user' placeholder='Użytkownik'><input id='xpass' name='pass' placeholder='Hasło'><input id='xepg' class='wide' name='epg' placeholder='Dodatkowe EPG XMLTV URL (.xml lub .gz)'><button>Zapisz / aktualizuj</button></form><small>Ten sam host + użytkownik aktualizuje istniejący wpis.</small></section>
        <section id='m3u' class='box violet'><h2>▶ Lista M3U</h2><form method='post' action='/source/add'><input type='hidden' name='type' value='m3u'><input id='mname' class='wide' name='name' placeholder='Nazwa listy'><input id='murl' class='wide' name='url' placeholder='Pełny URL M3U'><input id='mepg' class='wide' name='epg' placeholder='Dodatkowe EPG XMLTV URL (.xml lub .gz)'><button>Zapisz / aktualizuj</button></form><small>Konfigurujesz wygodnie z telefonu zamiast pilotem.</small></section>
        <section id='e2' class='box blue'><h2>▣ Enigma2 / OpenWebIF</h2><form id='e2form' method='post' action='/source/add'><input type='hidden' name='type' value='e2'><input id='ename' class='wide' name='name' placeholder='Nazwa dekodera, np. SF8008'><input id='ehost' class='wide' name='host' placeholder='IP / host, np. 192.168.8.115'><input id='eweb' name='webPort' placeholder='OpenWebIF port' value='80'><input id='estream' name='streamPort' placeholder='Stream port' value='8001'><input id='euser' name='user' placeholder='Użytkownik, np. root'><input id='epass' name='pass' placeholder='Hasło'><label><input id='ezap' type='checkbox' name='zap' value='1'> Przełączaj kanał także na dekoderze (ZAP)</label><select id='epicons' name='picons'><option value='web'>Picony z WebInterface Enigma2</option><option value='local'>Picony lokalne TvMad</option></select><button type='button' onclick='testE2()'>Test połączenia</button><button>Zapisz / aktualizuj</button></form><small>Bez ZAP TvMad otwiera service reference bezpośrednio przez streamproxy; przy dwóch głowicach Enigma2 może przydzielić wolną głowicę bez zmiany kanału na ekranie dekodera.</small></section>
        <section id='picons' class='box gold widebox'><h2>▧ Własne picony</h2><div class='upload'><form method='post' action='/upload' enctype='multipart/form-data'><input type='file' name='file' accept='.png,.jpg,.jpeg,.webp,.zip'><button>Wgraj picony</button></form><small>PNG/JPG/WEBP lub paczka ZIP. Dopasowanie wykorzystuje oczyszczone nazwy kanałów.</small></div><div class='picons'>$piconGrid</div></section>
        </div><div class='foot'>TvMad-Xtream TV · panel dostępny wyłącznie w Twojej sieci lokalnej</div></main></div><script>function editX(n,h,u,p,e){xname.value=n;xhost.value=h;xuser.value=u;xpass.value=p;xepg.value=e||'';location.hash='xtream';xname.focus()}function editM(n,u,e){mname.value=n;murl.value=u;mepg.value=e||'';location.hash='m3u';mname.focus()}function editE(n,h,w,s,u,p,z,pi){ename.value=n;ehost.value=h;eweb.value=w;estream.value=s;euser.value=u;epass.value=p;ezap.checked=(z==='true');epicons.value=pi||'web';location.hash='e2';ename.focus()}async function testE2(){try{const r=await fetch('/e2/test',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(new FormData(document.getElementById('e2form')))});alert(await r.text())}catch(e){alert('Błąd testu: '+e)}}</script></body></html>"""
    }

    private fun send(out:OutputStream, code:Int, type:String, data:ByteArray) {
        val head="HTTP/1.1 $code OK\r\nContent-Type: $type; charset=utf-8\r\nContent-Length: ${data.size}\r\nConnection: close\r\nCache-Control: no-store\r\n\r\n"
        out.write(head.toByteArray()); out.write(data); out.flush()
    }
    private fun redirect(out:OutputStream) {
        val h="HTTP/1.1 303 See Other\r\nLocation: /\r\nConnection: close\r\nContent-Length: 0\r\n\r\n";out.write(h.toByteArray());out.flush()
    }

    private fun handle(sock:Socket) {
        sock.soTimeout=5000
        try { sock.use { s ->
            val input=BufferedInputStream(s.getInputStream()); val out=s.getOutputStream()
            val header=ByteArrayOutputStream(); var state=0
            while(header.size()<65536){ val b=input.read(); if(b<0)break; header.write(b); state=when{state==0&&b==13->1;state==1&&b==10->2;state==2&&b==13->3;state==3&&b==10->4;else->0}; if(state==4)break }
            val hs=header.toString("ISO-8859-1"); val lines=hs.split("\r\n"); val req=lines.firstOrNull()?.split(' ')?:return
            if(req.size<2)return; val method=req[0]; val path=req[1]
            val len=lines.firstOrNull{it.startsWith("Content-Length:",true)}?.substringAfter(':')?.trim()?.toIntOrNull()?:0
            val ct=lines.firstOrNull{it.startsWith("Content-Type:",true)}?.substringAfter(':')?.trim().orEmpty()
            val body=ByteArray(len); var off=0; while(off<len){val n=input.read(body,off,len-off);if(n<=0)break;off+=n}
            when {
                method=="GET" && path=="/" -> send(out,200,"text/html",html().toByteArray())
                method=="POST" && path=="/source/add" -> { val f=form(String(body,Charsets.UTF_8)); val type=f["type"].orEmpty(); val list=SourceStore.load(context); val src=when(type){"m3u"->Source("m3u",f["name"].orEmpty().ifBlank{"M3U"},url=f["url"].orEmpty(),epgUrl=f["epg"].orEmpty().trim());"e2"->Source("e2",f["name"].orEmpty().ifBlank{f["host"].orEmpty()},host=f["host"].orEmpty(),user=f["user"].orEmpty(),pass=f["pass"].orEmpty(),webPort=f["webPort"]?.toIntOrNull()?:80,streamPort=f["streamPort"]?.toIntOrNull()?:8001,e2ZapOnBox=f["zap"]=="1",e2PiconSource=f["picons"].orEmpty().ifBlank{"web"});else->Source("xtream",f["name"].orEmpty().ifBlank{f["host"].orEmpty()},host=f["host"].orEmpty(),user=f["user"].orEmpty(),pass=f["pass"].orEmpty(),epgUrl=f["epg"].orEmpty().trim())}; val same=list.indexOfFirst{it.type==src.type&&when(src.type){"xtream"->it.host==src.host&&it.user==src.user;"e2"->it.host==src.host&&it.webPort==src.webPort;else->it.url==src.url}}; if(same>=0)list[same]=src.copy(expiry=list[same].expiry) else list.add(src);SourceStore.save(context,list);onChanged();redirect(out) }
                method=="POST" && path=="/e2/test" -> { val f=form(String(body,Charsets.UTF_8)); val src=Source("e2",f["name"].orEmpty().ifBlank{f["host"].orEmpty()},host=f["host"].orEmpty(),user=f["user"].orEmpty(),pass=f["pass"].orEmpty(),webPort=f["webPort"]?.toIntOrNull()?:80,streamPort=f["streamPort"]?.toIntOrNull()?:8001,e2ZapOnBox=f["zap"]=="1",e2PiconSource=f["picons"].orEmpty().ifBlank{"web"}); try{val r=Api.e2Test(src);send(out,200,"text/plain",("OK: "+r.message).toByteArray())}catch(e:Exception){send(out,400,"text/plain",("BŁĄD: "+(e.message?:"brak połączenia")).toByteArray())} }
                method=="POST" && path=="/source/delete" -> { val f=form(String(body,Charsets.UTF_8));val list=SourceStore.load(context);val i=f["i"]?.toIntOrNull()?:-1;if(i in list.indices){list.removeAt(i);SourceStore.save(context,list);onChanged()};redirect(out) }
                method=="POST" && path=="/upload" -> { uploadMultipart(body,ct);onChanged();redirect(out) }
                method=="GET" && path.startsWith("/picon/") -> { val fn=decode(path.substringAfter("/picon/")); val f=File(PiconRepository.dir(context),File(fn).name); if(f.exists()&&f.isFile){val type=when(f.extension.lowercase()){"png"->"image/png";"webp"->"image/webp";else->"image/jpeg"};send(out,200,type,f.readBytes())}else send(out,404,"text/plain","Not found".toByteArray()) }
                else -> send(out,404,"text/plain","Not found".toByteArray())
            }
        }} catch (_:Exception) { try{sock.close()}catch(_:Exception){} }
    }

    private fun uploadMultipart(body:ByteArray, ct:String) {
        val boundary=ct.substringAfter("boundary=","").trim().trim('"'); if(boundary.isBlank())return
        val marker=("--$boundary").toByteArray(Charsets.ISO_8859_1)
        fun indexOf(data:ByteArray, pat:ByteArray, from:Int):Int { outer@ for(i in from..data.size-pat.size){for(j in pat.indices)if(data[i+j]!=pat[j])continue@outer;return i};return -1 }
        var pos=indexOf(body,marker,0)
        while(pos>=0){ val next=indexOf(body,marker,pos+marker.size); if(next<0)break; val part=body.copyOfRange(pos+marker.size,next); val sep=indexOf(part,"\r\n\r\n".toByteArray(),0); if(sep>0){ val h=String(part,0,sep,Charsets.ISO_8859_1); val fn=Regex("filename=\"([^\"]+)\"").find(h)?.groupValues?.getOrNull(1)?.substringAfterLast('/')?.substringAfterLast('\\'); if(!fn.isNullOrBlank()){ var data=part.copyOfRange(sep+4,part.size); if(data.size>=2&&data[data.size-2]==13.toByte()&&data[data.size-1]==10.toByte())data=data.copyOfRange(0,data.size-2); saveUpload(fn,data) } }; pos=next }
    }

    private fun saveUpload(name:String,data:ByteArray) {
        val d=PiconRepository.dir(context)
        if(name.endsWith(".zip",true)) {
            ZipInputStream(ByteArrayInputStream(data)).use { z ->
                while(true){val e=z.nextEntry?:break;if(e.isDirectory)continue;val base=File(e.name).name;if(!base.matches(Regex("(?i).+\\.(png|jpg|jpeg|webp)$")))continue;val key=PiconRepository.key(base.substringBeforeLast('.'));if(key.isBlank())continue;val ext=base.substringAfterLast('.').lowercase();File(d,"$key.$ext").outputStream().use{z.copyTo(it)}}
            }
        } else if(name.matches(Regex("(?i).+\\.(png|jpg|jpeg|webp)$"))) {
            val key=PiconRepository.key(name.substringBeforeLast('.')); if(key.isNotBlank())File(d,"$key.${name.substringAfterLast('.').lowercase()}").writeBytes(data)
        }
    }
}
