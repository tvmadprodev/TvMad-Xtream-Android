package pl.tvmad.xtream

import android.content.Context
import java.io.*
import java.net.*
import java.util.concurrent.Executors
import java.util.zip.ZipInputStream

class WebConfigServer(
    private val context: Context,
    private val port: Int = 5557,
    private val onChanged: () -> Unit = {}
) {
    @Volatile private var running = false
    private var server: ServerSocket? = null
    private val pool = Executors.newCachedThreadPool()

    fun start() {
        if (running) return
        running = true
        pool.execute {
            try {
                server = ServerSocket(port, 20, InetAddress.getByName("0.0.0.0"))
                while (running) {
                    val s = server?.accept() ?: break
                    pool.execute { handle(s) }
                }
            } catch (_: Exception) { }
        }
    }

    fun stop() {
        running = false
        try { server?.close() } catch (_: Exception) {}
        pool.shutdownNow()
    }

    fun address(): String {
        var ip = "127.0.0.1"
        try {
            val all = NetworkInterface.getNetworkInterfaces()
            while (all.hasMoreElements()) {
                val ni = all.nextElement()
                if (!ni.isUp || ni.isLoopback) continue
                val addrs = ni.inetAddresses
                while (addrs.hasMoreElements()) {
                    val a = addrs.nextElement()
                    if (a is Inet4Address && !a.isLoopbackAddress) { ip = a.hostAddress ?: ip; break }
                }
                if (ip != "127.0.0.1") break
            }
        } catch (_: Exception) {}
        return "http://$ip:$port"
    }

    private fun esc(s:String)=s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;")
    private fun decode(s:String)=URLDecoder.decode(s,"UTF-8")
    private fun form(body:String):Map<String,String> = body.split('&').mapNotNull { p ->
        val z=p.split('=',limit=2); if(z.size==2) decode(z[0]) to decode(z[1]) else null
    }.toMap()

    private fun html(): String {
        val src = SourceStore.load(context)
        val rows = src.mapIndexed { i,s ->
            val info = if(s.type=="xtream") "${esc(s.host)} / ${esc(s.user)}" else esc(s.url)
            "<tr><td>${esc(s.name)}</td><td>${esc(s.type.uppercase())}</td><td>$info</td><td><form method='post' action='/source/delete'><input type='hidden' name='i' value='$i'><button>Usuń</button></form></td></tr>"
        }.joinToString("")
        return """<!doctype html><html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'>
        <title>TvMad-Xtream TV</title><style>
        :root{--bg:#070b12;--panel:#111a26;--line:#2d4157;--blue:#2583eb;--violet:#8b5cff;--gold:#f59e0b;--text:#eef5fc;--muted:#8fa2b5}
        *{box-sizing:border-box}body{font-family:system-ui,-apple-system,Segoe UI,sans-serif;background:radial-gradient(circle at 10% 0,#10284c 0,transparent 32%),radial-gradient(circle at 90% 0,#39164f 0,transparent 28%),linear-gradient(135deg,#050810,#0c1420 58%,#111b2b);color:var(--text);max-width:1100px;margin:auto;padding:24px}
        .head{display:flex;justify-content:space-between;align-items:center;margin-bottom:18px}.brand{font-size:31px;font-weight:800;color:#36a9ff}.tag{color:var(--muted);font-size:13px}.pill{padding:9px 13px;border:1px solid var(--line);border-radius:10px;background:#111a26;color:#9bd5ff}
        .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(310px,1fr));gap:16px}.box{background:linear-gradient(160deg,#121c29dd,#0d141fef);padding:18px;border:1px solid var(--line);border-radius:16px;box-shadow:0 14px 40px #0008}.box.blue{border-color:#245f9e}.box.violet{border-color:#63459e}.box.gold{border-color:#8f5b13}
        h2{margin:0 0 14px;color:#fff;font-size:19px}table{width:100%;border-collapse:collapse}td,th{padding:10px 8px;border-bottom:1px solid #263649;text-align:left}th{color:#7fbdf2;font-size:12px;text-transform:uppercase}
        input,select,button{padding:11px 12px;margin:5px 3px;border-radius:9px;border:1px solid #40566f;background:#0b121b;color:#fff;outline:none}input:focus{border-color:#2e9bff;box-shadow:0 0 0 2px #2e9bff33}button{background:linear-gradient(135deg,#1358bc,#2583eb);border-color:#499cf0;font-weight:700;cursor:pointer}.danger{background:#6d2430;border-color:#a64a58}
        .wide{width:calc(100% - 8px)}small{color:var(--muted);line-height:1.5}.upload{border:1px dashed #5c7088;border-radius:12px;padding:12px;background:#0a111a}.foot{margin-top:20px;color:#64788d;text-align:center;font-size:12px}
        @media(max-width:650px){body{padding:14px}.head{display:block}.pill{margin-top:10px;display:inline-block}.grid{grid-template-columns:1fr}}
        </style></head><body>
        <div class='head'><div><div class='brand'>TvMad-Xtream TV</div><div class='tag'>Android TV • ExoPlayer + FFmpeg • lokalny panel konfiguracji</div></div><div class='pill'>Web Interface • port $port</div></div>
        <div class='box blue'><h2>Serwery</h2><table><tr><th>Nazwa</th><th>Typ</th><th>Dane</th><th></th></tr>$rows</table></div>
        <div class='grid'>
         <div class='box blue'><h2>＋ Xtream Codes</h2><form method='post' action='/source/add'><input type='hidden' name='type' value='xtream'><input class='wide' name='name' placeholder='Nazwa serwera'><input class='wide' name='host' placeholder='http://host:port'><input name='user' placeholder='Użytkownik'><input name='pass' placeholder='Hasło'><button>Zapisz serwer</button></form><small>Jeśli host + użytkownik już istnieją, wpis zostanie zaktualizowany.</small></div>
         <div class='box violet'><h2>＋ Lista M3U</h2><form method='post' action='/source/add'><input type='hidden' name='type' value='m3u'><input class='wide' name='name' placeholder='Nazwa listy'><input class='wide' name='url' placeholder='Pełny URL M3U'><button>Zapisz listę</button></form><small>Lista pojawi się w aplikacji bez wpisywania danych pilotem.</small></div>
         <div class='box gold'><h2>◉ Własne picony</h2><div class='upload'><form method='post' action='/upload' enctype='multipart/form-data'><input class='wide' type='file' name='file' accept='.png,.jpg,.jpeg,.webp,.zip'><button>Wgraj picony</button></form></div><small>Obsługiwany jest pojedynczy PNG/JPG/WEBP albo cała paczka ZIP. Nazwy są dopasowywane po oczyszczeniu nazwy kanału.</small></div>
        </div><div class='foot'>TvMad-Xtream TV • konfiguracja dostępna tylko w Twojej sieci lokalnej</div>
        </body></html>"""
    }

    private fun send(out:OutputStream, code:Int, type:String, data:ByteArray) {
        val head="HTTP/1.1 $code OK\r\nContent-Type: $type; charset=utf-8\r\nContent-Length: ${data.size}\r\nConnection: close\r\nCache-Control: no-store\r\n\r\n"
        out.write(head.toByteArray()); out.write(data); out.flush()
    }
    private fun redirect(out:OutputStream) {
        val h="HTTP/1.1 303 See Other\r\nLocation: /\r\nConnection: close\r\nContent-Length: 0\r\n\r\n";out.write(h.toByteArray());out.flush()
    }

    private fun handle(sock:Socket) {
        sock.soTimeout=5000
        try { sock.use { s ->
            val input=BufferedInputStream(s.getInputStream()); val out=s.getOutputStream()
            val header=ByteArrayOutputStream(); var state=0
            while(header.size()<65536){ val b=input.read(); if(b<0)break; header.write(b); state=when{state==0&&b==13->1;state==1&&b==10->2;state==2&&b==13->3;state==3&&b==10->4;else->0}; if(state==4)break }
            val hs=header.toString("ISO-8859-1"); val lines=hs.split("\r\n"); val req=lines.firstOrNull()?.split(' ')?:return
            if(req.size<2)return; val method=req[0]; val path=req[1]
            val len=lines.firstOrNull{it.startsWith("Content-Length:",true)}?.substringAfter(':')?.trim()?.toIntOrNull()?:0
            val ct=lines.firstOrNull{it.startsWith("Content-Type:",true)}?.substringAfter(':')?.trim().orEmpty()
            val body=ByteArray(len); var off=0; while(off<len){val n=input.read(body,off,len-off);if(n<=0)break;off+=n}
            when {
                method=="GET" && path=="/" -> send(out,200,"text/html",html().toByteArray())
                method=="POST" && path=="/source/add" -> { val f=form(String(body,Charsets.UTF_8)); val type=f["type"].orEmpty(); val list=SourceStore.load(context); val src=if(type=="m3u") Source("m3u",f["name"].orEmpty().ifBlank{"M3U"},url=f["url"].orEmpty()) else Source("xtream",f["name"].orEmpty().ifBlank{f["host"].orEmpty()},host=f["host"].orEmpty(),user=f["user"].orEmpty(),pass=f["pass"].orEmpty()); val same=list.indexOfFirst{it.type==src.type&&((src.type=="xtream"&&it.host==src.host&&it.user==src.user)||(src.type=="m3u"&&it.url==src.url))}; if(same>=0)list[same]=src else list.add(src);SourceStore.save(context,list);onChanged();redirect(out) }
                method=="POST" && path=="/source/delete" -> { val f=form(String(body,Charsets.UTF_8));val list=SourceStore.load(context);val i=f["i"]?.toIntOrNull()?:-1;if(i in list.indices){list.removeAt(i);SourceStore.save(context,list);onChanged()};redirect(out) }
                method=="POST" && path=="/upload" -> { uploadMultipart(body,ct);onChanged();redirect(out) }
                else -> send(out,404,"text/plain","Not found".toByteArray())
            }
        }} catch (_:Exception) { try{sock.close()}catch(_:Exception){} }
    }

    private fun uploadMultipart(body:ByteArray, ct:String) {
        val boundary=ct.substringAfter("boundary=","").trim().trim('"'); if(boundary.isBlank())return
        val marker=("--$boundary").toByteArray(Charsets.ISO_8859_1)
        fun indexOf(data:ByteArray, pat:ByteArray, from:Int):Int { outer@ for(i in from..data.size-pat.size){for(j in pat.indices)if(data[i+j]!=pat[j])continue@outer;return i};return -1 }
        var pos=indexOf(body,marker,0)
        while(pos>=0){ val next=indexOf(body,marker,pos+marker.size); if(next<0)break; val part=body.copyOfRange(pos+marker.size,next); val sep=indexOf(part,"\r\n\r\n".toByteArray(),0); if(sep>0){ val h=String(part,0,sep,Charsets.ISO_8859_1); val fn=Regex("filename=\"([^\"]+)\"").find(h)?.groupValues?.getOrNull(1)?.substringAfterLast('/')?.substringAfterLast('\\'); if(!fn.isNullOrBlank()){ var data=part.copyOfRange(sep+4,part.size); if(data.size>=2&&data[data.size-2]==13.toByte()&&data[data.size-1]==10.toByte())data=data.copyOfRange(0,data.size-2); saveUpload(fn,data) } }; pos=next }
    }

    private fun saveUpload(name:String,data:ByteArray) {
        val d=PiconRepository.dir(context)
        if(name.endsWith(".zip",true)) {
            ZipInputStream(ByteArrayInputStream(data)).use { z ->
                while(true){val e=z.nextEntry?:break;if(e.isDirectory)continue;val base=File(e.name).name;if(!base.matches(Regex("(?i).+\\.(png|jpg|jpeg|webp)$")))continue;val key=PiconRepository.key(base.substringBeforeLast('.'));if(key.isBlank())continue;val ext=base.substringAfterLast('.').lowercase();File(d,"$key.$ext").outputStream().use{z.copyTo(it)}}
            }
        } else if(name.matches(Regex("(?i).+\\.(png|jpg|jpeg|webp)$"))) {
            val key=PiconRepository.key(name.substringBeforeLast('.')); if(key.isNotBlank())File(d,"$key.${name.substringAfterLast('.').lowercase()}").writeBytes(data)
        }
    }
}
