package pl.tvmad.xtream

import android.os.Build
import android.util.Log
import android.view.Display
import android.view.Surface
import android.view.SurfaceView
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.common.util.UnstableApi

/**
 * Galaxy S9+ / physical HDMI frame-pacing helper.
 *
 * The external TvMad Activity already lives directly on the HDMI display, so we can give the
 * compositor a content-aware frame-rate hint on the actual video Surface instead of letting the
 * 60 Hz phone display be the timing source.  For European TV, 25 fps is deliberately advertised
 * as 50 Hz so each decoded frame can live for exactly two output refreshes; 50 fps maps 1:1.
 * 30/60 fps uses 60 Hz.  No root/sysfs writes are used here.
 */
@UnstableApi
object S9VideoOutputTuner {
    private const val TAG = "TvMadFrameRate"

    /** Stop Media3 from replacing our explicit Surface.setFrameRate request. */
    fun configurePlayer(player: ExoPlayer) {
        try {
            player.setVideoChangeFrameRateStrategy(C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_OFF)
        } catch (t: Throwable) {
            Log.w(TAG, "Cannot disable Media3 frame-rate strategy: ${t.javaClass.simpleName}:${t.message}")
        }
    }

    /** Apply the best output cadence once the stream format is known. Safe to call repeatedly. */
    fun applyFromPlayer(player: ExoPlayer, playerView: PlayerView, reason: String) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        val display = playerView.display ?: return
        if (display.displayId == Display.DEFAULT_DISPLAY) return

        val contentFps = player.videoFormat?.frameRate ?: -1f
        if (!contentFps.isFinite() || contentFps <= 1f) return
        val targetHz = targetOutputHz(contentFps)

        // Ask the HDMI Activity window for the same 50/60 Hz family. This is a normal Android
        // preference (not a root/sysfs force), so unsupported modes are simply ignored.
        try {
            (playerView.context as? android.app.Activity)?.window?.let { window ->
                val attrs = window.attributes
                attrs.preferredRefreshRate = targetHz
                window.attributes = attrs
            }
        } catch (_: Throwable) {
        }

        // The SurfaceView may be created a few frames after PlayerView is attached. Try now and
        // once more shortly afterwards.
        if (!applyToSurface(playerView, contentFps, targetHz, reason)) {
            playerView.postDelayed({ applyToSurface(playerView, contentFps, targetHz, "$reason-retry") }, 250L)
        }
    }

    fun clear(playerView: PlayerView) {
        try {
            (playerView.context as? android.app.Activity)?.window?.let { window ->
                val attrs = window.attributes
                attrs.preferredRefreshRate = 0f
                window.attributes = attrs
            }
        } catch (_: Throwable) {
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return
        val sv = playerView.videoSurfaceView as? SurfaceView ?: return
        val surface = sv.holder.surface
        if (!surface.isValid) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                surface.setFrameRate(0f, Surface.FRAME_RATE_COMPATIBILITY_DEFAULT, Surface.CHANGE_FRAME_RATE_ALWAYS)
            } else {
                surface.setFrameRate(0f, Surface.FRAME_RATE_COMPATIBILITY_DEFAULT)
            }
        } catch (_: Throwable) {
        }
    }

    private fun applyToSurface(playerView: PlayerView, contentFps: Float, targetHz: Float, reason: String): Boolean {
        val sv = playerView.videoSurfaceView as? SurfaceView ?: return false
        val surface = sv.holder.surface
        if (!surface.isValid) return false
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                surface.setFrameRate(
                    targetHz,
                    Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE,
                    Surface.CHANGE_FRAME_RATE_ALWAYS
                )
            } else {
                surface.setFrameRate(targetHz, Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE)
            }
            Log.i(
                TAG,
                "HDMI content=${"%.3f".format(contentFps)}fps -> request=${"%.3f".format(targetHz)}Hz " +
                    "display=${playerView.display?.displayId} reason=$reason"
            )
            true
        } catch (t: Throwable) {
            Log.w(TAG, "Surface.setFrameRate failed: ${t.javaClass.simpleName}:${t.message}")
            false
        }
    }

    private fun targetOutputHz(fps: Float): Float = when {
        // Cinema material: keep native cadence where the sink offers 24p.
        fps in 23.0f..24.49f -> 24f
        // PAL / European broadcast: 25 -> 50 (2:2), 50 -> 50 (1:1).
        fps in 24.49f..26.0f -> 50f
        fps in 49.0f..51.0f -> 50f
        // NTSC-ish / 30/60 material: keep the HDMI path at 60 Hz.
        fps in 28.5f..31.0f -> 60f
        fps in 58.0f..61.0f -> 60f
        // Conservative fallback for unusual broadcast rates.
        fps < 28.5f -> 50f
        else -> 60f
    }
}
