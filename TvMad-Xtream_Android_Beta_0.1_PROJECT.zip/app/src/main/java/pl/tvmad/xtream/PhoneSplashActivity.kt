package pl.tvmad.xtream

import android.app.Activity
import android.app.ActivityOptions
import android.content.Context
import android.content.Intent
import android.hardware.display.DisplayManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Display
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.PointerIcon
import android.view.View
import android.view.WindowManager
import java.lang.ref.WeakReference

/**
 * Galaxy S9+ / HDMI launcher.
 *
 * This tiny activity stays on the internal AMOLED and shows only the dark TvMad logo.
 * When a physical/presentation display is present, the real TvMad MainActivity is launched
 * directly on that display. This keeps the existing TV UI/player code unchanged, but makes
 * its PlayerView/SurfaceView belong to the HDMI display instead of to the mirrored phone UI.
 *
 * If Android/Samsung refuses a secondary-display launch, or HDMI is not connected, we fall
 * back to the original behaviour and open MainActivity on the phone.
 */
class PhoneSplashActivity : Activity(), DisplayManager.DisplayListener {
    companion object {
        private const val TAG = "TvMadDisplay"
        private const val START_DELAY_MS = 850L
        private var activeInstance: WeakReference<PhoneSplashActivity>? = null

        /** Close the AMOLED splash when the user exits TvMad from the HDMI activity. */
        fun closePhoneSplash() {
            val activity = activeInstance?.get() ?: return
            activity.runOnUiThread {
                if (!activity.isFinishing && !activity.isDestroyed) {
                    activity.finishAndRemoveTask()
                }
            }
            activeInstance = null
        }
    }

    private lateinit var displayManager: DisplayManager
    private val handler = Handler(Looper.getMainLooper())
    private var routed = false

    private val initialRoute = Runnable { routeToBestDisplay() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activeInstance = WeakReference(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.attributes = window.attributes.apply { screenBrightness = 0.07f }
        setContentView(R.layout.activity_phone_splash)
        immersive()
        hidePhoneMouseCursor()

        displayManager = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        displayManager.displays.forEach { d ->
            Log.i(TAG, "visible display id=${d.displayId} name=${d.name} state=${d.state} flags=0x${Integer.toHexString(d.flags)}")
        }
        displayManager.registerDisplayListener(this, handler)
        handler.postDelayed(initialRoute, START_DELAY_MS)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        try { displayManager.unregisterDisplayListener(this) } catch (_: Exception) {}
        if (activeInstance?.get() === this) activeInstance = null
        super.onDestroy()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            immersive()
            hidePhoneMouseCursor()
        }
    }

    private fun hidePhoneMouseCursor() {
        try {
            val hidden = PointerIcon.getSystemIcon(this, PointerIcon.TYPE_NULL)
            window.decorView.pointerIcon = hidden
            findViewById<View?>(R.id.phoneSplashLogo)?.pointerIcon = hidden
        } catch (_: Throwable) {}
    }

    private fun immersive() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
    }

    private fun findExternalDisplay(): Display? {
        val presentation = displayManager.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION)
        presentation.firstOrNull {
            it.displayId != Display.DEFAULT_DISPLAY && it.isValid && it.state != Display.STATE_OFF
        }?.let { return it }

        return displayManager.displays.firstOrNull {
            it.displayId != Display.DEFAULT_DISPLAY && it.isValid && it.state != Display.STATE_OFF
        }
    }

    private fun routeToBestDisplay() {
        if (routed || isFinishing || isDestroyed) return
        val external = findExternalDisplay()
        if (external != null) {
            launchExternal(external)
        } else {
            launchInternalFallback("no external display")
        }
    }

    private fun launchExternal(display: Display) {
        val intent = Intent(this, MainActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            .putExtra("tvmad_external_display", true)
            .putExtra("tvmad_external_display_id", display.displayId)

        try {
            val options = ActivityOptions.makeBasic()
            options.setLaunchDisplayId(display.displayId)
            startActivity(intent, options.toBundle())
            routed = true
            Log.i(TAG, "MainActivity requested on external display id=${display.displayId} name=${display.name}")
            // Keep this activity alive on the AMOLED. It is intentionally NOT finished.
        } catch (t: Throwable) {
            Log.e(TAG, "External display launch failed; falling back to phone", t)
            launchInternalFallback("external launch failed")
        }
    }

    private fun launchInternalFallback(reason: String) {
        if (routed || isFinishing || isDestroyed) return
        routed = true
        Log.i(TAG, "MainActivity fallback on phone: $reason")
        startActivity(Intent(this, MainActivity::class.java).putExtra("tvmad_external_display", false))
        finish()
    }

    override fun onDisplayAdded(displayId: Int) {
        if (!routed) {
            handler.removeCallbacks(initialRoute)
            handler.postDelayed({ routeToBestDisplay() }, 350L)
        }
    }

    override fun onDisplayChanged(displayId: Int) {
        if (!routed) {
            handler.removeCallbacks(initialRoute)
            handler.postDelayed({ routeToBestDisplay() }, 250L)
        }
    }

    override fun onDisplayRemoved(displayId: Int) {
        // MainActivity on the removed display will be handled by Android. The AMOLED logo
        // remains visible; reopening TvMad will re-run display discovery cleanly.
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        // Samsung keeps the remote / air-mouse focused on display 0 (the AMOLED splash).
        // When the real TvMad window is on HDMI, forward remote keys to the active external
        // Activity instead of letting BACK/EXIT close only this splash.
        if (routed && ExternalInputBridge.hasExternalTarget()) {
            when (event.keyCode) {
                KeyEvent.KEYCODE_VOLUME_UP,
                KeyEvent.KEYCODE_VOLUME_DOWN,
                KeyEvent.KEYCODE_VOLUME_MUTE -> return super.dispatchKeyEvent(event)
            }
            ExternalInputBridge.dispatchKey(event)
            return true
        }

        // While the launcher is still waiting for HDMI, OK/ENTER performs an immediate rescan.
        if (!routed && event.action == KeyEvent.ACTION_DOWN &&
            (event.keyCode == KeyEvent.KEYCODE_DPAD_CENTER || event.keyCode == KeyEvent.KEYCODE_ENTER)) {
            handler.removeCallbacks(initialRoute)
            routeToBestDisplay()
            return true
        }
        // If an external launch has already been requested, never allow BACK to orphan the HDMI
        // Activity during the short interval before it reaches onResume().
        if (routed && event.keyCode == KeyEvent.KEYCODE_BACK) return true
        return super.dispatchKeyEvent(event)
    }

    override fun dispatchGenericMotionEvent(event: MotionEvent): Boolean {
        if (routed && ExternalInputBridge.hasExternalTarget() && ExternalInputBridge.isMouse(event)) {
            ExternalInputBridge.dispatchMouse(
                event,
                window.decorView.width,
                window.decorView.height,
                touchEvent = false
            )
            return true
        }
        return super.dispatchGenericMotionEvent(event)
    }

    override fun dispatchTouchEvent(event: MotionEvent): Boolean {
        // Air-mouse clicks arrive as mouse-source touch events on the phone display. Route them
        // to HDMI using the same normalized coordinates as hover movement. Normal finger touches
        // on the AMOLED logo stay local and do not operate the TV UI.
        if (routed && ExternalInputBridge.hasExternalTarget() && ExternalInputBridge.isMouse(event)) {
            ExternalInputBridge.dispatchMouse(
                event,
                window.decorView.width,
                window.decorView.height,
                touchEvent = true
            )
            return true
        }
        return super.dispatchTouchEvent(event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (routed && ExternalInputBridge.hasExternalTarget()) {
            val now = android.os.SystemClock.uptimeMillis()
            ExternalInputBridge.dispatchKey(KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_BACK, 0))
            ExternalInputBridge.dispatchKey(KeyEvent(now, now, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_BACK, 0))
            return
        }
        if (routed) return
        super.onBackPressed()
    }
}
