package pl.tvmad.xtream

import android.app.Activity
import android.graphics.Color
import android.view.*
import android.widget.*

class TvListAdapter(
    private val activity: Activity,
    private val items: List<String>,
    private val accent: Int = 0,
    private val numbered: Boolean = false
) : BaseAdapter() {
    override fun getCount() = items.size
    override fun getItem(position: Int) = items[position]
    override fun getItemId(position: Int) = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val row = (convertView as? LinearLayout) ?: LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(14), dp(7), dp(14), dp(7))
            isFocusable = false
            isClickable = false
            background = activity.getDrawable(when(accent){1->R.drawable.row_focus_violet;2->R.drawable.row_focus_gold;else->R.drawable.row_focus_blue})
            addView(TextView(activity).apply {
                id = 2001
                textSize = 12f
                gravity = Gravity.CENTER
                setTextColor(when(accent){1->0xFFB99AFF.toInt();2->0xFFFFB84D.toInt();else->0xFF61B9FF.toInt()})
            }, LinearLayout.LayoutParams(dp(34), dp(44)))
            addView(TextView(activity).apply {
                id = 2002
                textSize = 17f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER_VERTICAL
                maxLines = 1
            }, LinearLayout.LayoutParams(0, dp(54), 1f))
            addView(TextView(activity).apply {
                id = 2003
                text = "›"
                textSize = 24f
                gravity = Gravity.CENTER
                setTextColor(0xFF6F8194.toInt())
            }, LinearLayout.LayoutParams(dp(28), dp(54)))
        }
        row.findViewById<TextView>(2001).text = if(numbered) "${position+1}" else when(accent){1->"◆";2->"●";else->"▣"}
        row.findViewById<TextView>(2002).text = items[position]
        return row
    }
    private fun dp(v:Int)=(v*activity.resources.displayMetrics.density).toInt()
}
