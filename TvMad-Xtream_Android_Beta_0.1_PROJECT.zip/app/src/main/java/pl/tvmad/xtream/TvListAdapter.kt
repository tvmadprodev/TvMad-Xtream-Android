package pl.tvmad.xtream

import android.app.Activity
import android.graphics.Color
import android.util.TypedValue
import android.view.*
import android.widget.*
import kotlin.math.min

class TvListAdapter(
    private val activity: Activity,
    private val items: List<String>,
    private val accent: Int = 0,
    private val numbered: Boolean = false
) : BaseAdapter() {
    /**
     * The S9 external display can report a different logical density after a secondary Activity
     * or an HDMI timing change. Rows created after returning from VOD would then be almost half
     * the previous size. Base the TV list geometry on the physical HDMI mode instead of the
     * transient resource density so categories keep exactly the same readable size.
     */
    private val stableScale: Float by lazy {
        val mode = activity.display?.mode
        val rw = mode?.physicalWidth ?: activity.resources.displayMetrics.widthPixels
        val rh = mode?.physicalHeight ?: activity.resources.displayMetrics.heightPixels
        val w = maxOf(rw, rh).coerceAtLeast(1).toFloat()
        val h = minOf(rw, rh).coerceAtLeast(1).toFloat()
        min(w / 1536f, h / 864f).coerceIn(0.75f, 2.5f)
    }
    private val roomy = accent == 1 || accent == 2

    override fun getCount() = items.size
    override fun getItem(position: Int) = items[position]
    override fun getItemId(position: Int) = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val row = (convertView as? LinearLayout) ?: LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            val py = if (roomy) 8 else 7
            setPadding(dp(14), dp(py), dp(14), dp(py))
            isFocusable = false
            isClickable = false
            background = activity.getDrawable(when(accent){1->R.drawable.row_focus_violet;2->R.drawable.row_focus_gold;else->R.drawable.row_focus_blue})
            addView(TextView(activity).apply {
                id = 2001
                setStableTextSize(if (roomy) 14f else 12f)
                gravity = Gravity.CENTER
                setTextColor(when(accent){1->0xFFB99AFF.toInt();2->0xFFFFB84D.toInt();else->0xFF61B9FF.toInt()})
            }, LinearLayout.LayoutParams(dp(if (roomy) 38 else 34), dp(if (roomy) 50 else 44)))
            addView(TextView(activity).apply {
                id = 2002
                setStableTextSize(if (roomy) 19f else 17f)
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER_VERTICAL
                maxLines = 1
            }, LinearLayout.LayoutParams(0, dp(if (roomy) 60 else 54), 1f))
            addView(TextView(activity).apply {
                id = 2003
                text = "›"
                setStableTextSize(if (roomy) 26f else 24f)
                gravity = Gravity.CENTER
                setTextColor(0xFF6F8194.toInt())
            }, LinearLayout.LayoutParams(dp(if (roomy) 32 else 28), dp(if (roomy) 60 else 54)))
        }
        row.findViewById<TextView>(2001).text = if(numbered) "${position+1}" else when(accent){1->"◆";2->"●";else->"▣"}
        row.findViewById<TextView>(2002).text = items[position]
        return row
    }

    private fun dp(v: Int) = (v * stableScale + 0.5f).toInt()
    private fun TextView.setStableTextSize(designSp: Float) =
        setTextSize(TypedValue.COMPLEX_UNIT_PX, designSp * stableScale)
}
