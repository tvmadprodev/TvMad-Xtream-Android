package pl.tvmad.xtream

import android.app.Activity
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.media.MediaPlayer
import android.os.*
import android.view.*
import android.widget.*

class PlayerActivity:Activity(), TextureView.SurfaceTextureListener {
 private lateinit var texture:TextureView; private lateinit var info:View; private var player:MediaPlayer?=null; private val handler=Handler(Looper.getMainLooper())
 private val hideInfo=Runnable{info.visibility=View.GONE}
 override fun onCreate(b:Bundle?){ super.onCreate(b); setContentView(R.layout.activity_player); immersive(); texture=findViewById(R.id.video); info=findViewById(R.id.info); findViewById<TextView>(R.id.channel).text=intent.getStringExtra("name")?:""; texture.surfaceTextureListener=this; findViewById<View>(R.id.playerRoot).setOnClickListener{info.visibility=if(info.visibility==View.VISIBLE)View.GONE else View.VISIBLE;if(info.visibility==View.VISIBLE){handler.removeCallbacks(hideInfo);handler.postDelayed(hideInfo,3000)}}; handler.postDelayed(hideInfo,3000) }
 private fun immersive(){ window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); if(Build.VERSION.SDK_INT>=30){window.setDecorFitsSystemWindows(false);window.insetsController?.let{it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars());it.systemBarsBehavior=WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE}}else{@Suppress("DEPRECATION") window.decorView.systemUiVisibility=View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE} }
 override fun onWindowFocusChanged(hasFocus:Boolean){super.onWindowFocusChanged(hasFocus);if(hasFocus)immersive()}
 private fun start(surface:Surface){ val url=intent.getStringExtra("url")?:return; player?.release(); player=MediaPlayer().apply{setSurface(surface);setDataSource(this@PlayerActivity,android.net.Uri.parse(url),mapOf("User-Agent" to "Mozilla/5.0 TvMadProE2"));setOnPreparedListener{mp->applyCrop(mp.videoWidth,mp.videoHeight);mp.start()};setOnVideoSizeChangedListener{_,w,h->applyCrop(w,h)};setOnErrorListener{_,_,_->Toast.makeText(this@PlayerActivity,"Nie można uruchomić strumienia",Toast.LENGTH_SHORT).show();true};prepareAsync()} }
 private fun applyCrop(vw:Int,vh:Int){if(vw<=0||vh<=0||texture.width<=0||texture.height<=0)return;val viewW=texture.width.toFloat();val viewH=texture.height.toFloat();val scale=maxOf(viewW/vw.toFloat(),viewH/vh.toFloat());val scaledW=vw*scale;val scaledH=vh*scale;val m=Matrix();m.setScale(scaledW/viewW,scaledH/viewH,viewW/2f,viewH/2f);texture.setTransform(m)}
 override fun onSurfaceTextureAvailable(st:SurfaceTexture,w:Int,h:Int){start(Surface(st))}; override fun onSurfaceTextureSizeChanged(st:SurfaceTexture,w:Int,h:Int){player?.let{applyCrop(it.videoWidth,it.videoHeight)}}; override fun onSurfaceTextureDestroyed(st:SurfaceTexture):Boolean{player?.release();player=null;return true}; override fun onSurfaceTextureUpdated(st:SurfaceTexture){}
 override fun onDestroy(){handler.removeCallbacksAndMessages(null);player?.release();player=null;super.onDestroy()}
}
