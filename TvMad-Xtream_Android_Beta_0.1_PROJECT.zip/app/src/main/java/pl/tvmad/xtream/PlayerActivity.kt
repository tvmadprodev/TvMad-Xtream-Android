package pl.tvmad.xtream

import android.app.*
import android.graphics.BitmapFactory
import android.os.*
import android.view.*
import android.widget.*
import androidx.media3.common.*
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.DefaultTimeBar
import androidx.media3.ui.PlayerView
import androidx.media3.common.util.UnstableApi
import java.net.URL

@UnstableApi
class PlayerActivity:Activity(){
 private lateinit var playerView:PlayerView;private lateinit var info:View;private lateinit var aspect:Button;private lateinit var pause:Button;private lateinit var stop:Button;private lateinit var audio:Button;private lateinit var subtitles:Button;private lateinit var channelText:TextView
 private lateinit var picon:ImageView;private lateinit var nowTitle:TextView;private lateinit var nextTitle:TextView;private lateinit var liveProgress:ProgressBar;private lateinit var vodSeek:SeekBar
 private var player:ExoPlayer?=null;private val handler=Handler(Looper.getMainLooper());private var fillMode=false;private var isVod=false;private var userSeeking=false
 private var seekHeld=false;private var seekDirection=0L
 private var liveIndex=0;private var navUrls=arrayListOf<String>();private var navNames=arrayListOf<String>();private var navLogos=arrayListOf<String>();private var navLocalLogos=arrayListOf<String>();private var navNowTitles=arrayListOf<String>();private var navNowStarts=arrayListOf<String>();private var navNowEnds=arrayListOf<String>();private var navNextTitles=arrayListOf<String>();private var navNextStarts=arrayListOf<String>();private var navNextEnds=arrayListOf<String>();private var navNowStartEpoch=LongArray(0);private var navNowEndEpoch=LongArray(0)
 private var liveStartEpoch=0L;private var liveEndEpoch=0L
 private val hideInfo=Runnable{info.visibility=View.GONE;aspect.visibility=View.GONE;if(isVod){playerView.hideController();vodSeek.visibility=View.GONE}}
 private val updateLive=object:Runnable{override fun run(){updateLiveProgress();handler.postDelayed(this,15000)}}
 private val updateVodSeek=object:Runnable{override fun run(){if(isVod&&!userSeeking){val p=player;val d=p?.duration?:0L;if(d>0L&&d!=C.TIME_UNSET)vodSeek.progress=((p!!.currentPosition.coerceIn(0,d)*1000)/d).toInt()};handler.postDelayed(this,500)}}
 private val repeatSeek=object:Runnable{override fun run(){if(seekHeld&&seekDirection!=0L){seekBy(seekDirection,false);handler.postDelayed(this,170)}}}
 override fun onCreate(b:Bundle?){
  super.onCreate(b);setContentView(R.layout.activity_player);immersive();isVod=intent.getBooleanExtra("vod",false)
  playerView=findViewById(R.id.playerView);info=findViewById(R.id.info);aspect=findViewById(R.id.aspect);pause=findViewById(R.id.pause);stop=findViewById(R.id.stop);audio=findViewById(R.id.audio);subtitles=findViewById(R.id.subtitles);vodSeek=findViewById(R.id.vodSeek)
  picon=findViewById(R.id.infoPicon);nowTitle=findViewById(R.id.nowTitle);nextTitle=findViewById(R.id.nextTitle);liveProgress=findViewById(R.id.liveProgress);channelText=findViewById(R.id.channel);channelText.text=intent.getStringExtra("name")?:""
  if(!isVod)loadLiveNavigation()
  setupInfo();playerView.useController=isVod;playerView.controllerAutoShow=false;playerView.controllerHideOnTouch=false;playerView.resizeMode=AspectRatioFrameLayout.RESIZE_MODE_FIT;playerView.subtitleView?.apply{visibility=View.VISIBLE;setApplyEmbeddedStyles(true);setApplyEmbeddedFontSizes(true)}
  aspect.setOnClickListener{fillMode=!fillMode;aspect.text=if(fillMode)"↔ WYPEŁNIJ" else "16:9";playerView.resizeMode=if(fillMode)AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT;showControls()}
  pause.setOnClickListener{player?.let{if(it.isPlaying)it.pause()else it.play()};showControls()};stop.setOnClickListener{if(isVod)player?.stop();finish()};audio.setOnClickListener{showTrackDialog(C.TRACK_TYPE_AUDIO,"Ścieżka audio")};subtitles.setOnClickListener{showTrackDialog(C.TRACK_TYPE_TEXT,"Napisy")}
  findViewById<View>(R.id.playerRoot).setOnClickListener{toggleControls()};setupVodSeek();startExo();showControls()
 }
 private fun loadLiveNavigation(){
  navUrls=intent.getStringArrayListExtra("navUrls")?:arrayListOf();navNames=intent.getStringArrayListExtra("navNames")?:arrayListOf();navLogos=intent.getStringArrayListExtra("navLogos")?:arrayListOf();navLocalLogos=intent.getStringArrayListExtra("navLocalLogos")?:arrayListOf();navNowTitles=intent.getStringArrayListExtra("navNowTitles")?:arrayListOf();navNowStarts=intent.getStringArrayListExtra("navNowStarts")?:arrayListOf();navNowEnds=intent.getStringArrayListExtra("navNowEnds")?:arrayListOf();navNextTitles=intent.getStringArrayListExtra("navNextTitles")?:arrayListOf();navNextStarts=intent.getStringArrayListExtra("navNextStarts")?:arrayListOf();navNextEnds=intent.getStringArrayListExtra("navNextEnds")?:arrayListOf();navNowStartEpoch=intent.getLongArrayExtra("navNowStartEpoch")?:LongArray(0);navNowEndEpoch=intent.getLongArrayExtra("navNowEndEpoch")?:LongArray(0);liveIndex=intent.getIntExtra("navIndex",0).coerceAtLeast(0)
 }
 private fun setupInfo(){val epg=findViewById<TextView>(R.id.epg);epg.visibility=View.GONE
  if(isVod){info.setBackgroundColor(0x70101010);nowTitle.visibility=View.GONE;nextTitle.visibility=View.GONE;liveProgress.visibility=View.GONE;picon.visibility=View.GONE;vodSeek.visibility=View.VISIBLE;audio.visibility=View.GONE;subtitles.visibility=View.GONE}
  else{info.setBackgroundColor(0xD9101010.toInt());pause.visibility=View.GONE;stop.visibility=View.GONE;audio.visibility=View.GONE;subtitles.visibility=View.GONE;nowTitle.visibility=View.VISIBLE;nextTitle.visibility=View.VISIBLE;liveProgress.visibility=View.VISIBLE;vodSeek.visibility=View.GONE;applyInitialLiveInfo();handler.post(updateLive)}
 }
 private fun applyInitialLiveInfo(){val ns=intent.getStringExtra("nowStart").orEmpty();val ne=intent.getStringExtra("nowEnd").orEmpty();val nt=intent.getStringExtra("nowTitle").orEmpty();nowTitle.text=(if(ns.isNotBlank()||ne.isNotBlank())"$ns - $ne  "else"")+nt;val xs=intent.getStringExtra("nextStart").orEmpty();val xe=intent.getStringExtra("nextEnd").orEmpty();val xt=intent.getStringExtra("nextTitle").orEmpty();nextTitle.text=if(xt.isBlank())""else"Następnie: "+(if(xs.isNotBlank()||xe.isNotBlank())"$xs - $xe  "else"")+xt;liveStartEpoch=intent.getLongExtra("nowStartEpoch",0);liveEndEpoch=intent.getLongExtra("nowEndEpoch",0);loadPicon(intent.getStringExtra("localLogo").orEmpty(),intent.getStringExtra("logo").orEmpty());updateLiveProgress()}
 private fun setupVodSeek(){if(!isVod)return;vodSeek.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onStartTrackingTouch(s:SeekBar){userSeeking=true;handler.removeCallbacks(hideInfo)};override fun onProgressChanged(s:SeekBar,progress:Int,fromUser:Boolean){if(fromUser){val p=player?:return;val d=p.duration;if(d>0&&d!=C.TIME_UNSET)p.seekTo((d*progress)/1000)}};override fun onStopTrackingTouch(s:SeekBar){userSeeking=false;showControls()}});handler.post(updateVodSeek)}
 private fun positionVodSeek(){if(!isVod)return;vodSeek.post{if(info.height>0)vodSeek.translationY=-info.height.toFloat()}}
 private fun updateLiveProgress(){if(isVod)return;if(liveStartEpoch>0&&liveEndEpoch>liveStartEpoch){val n=System.currentTimeMillis();liveProgress.progress=(((n-liveStartEpoch).coerceIn(0,liveEndEpoch-liveStartEpoch)*1000)/(liveEndEpoch-liveStartEpoch)).toInt()}else liveProgress.progress=0}
 private fun startExo(){
  val url=intent.getStringExtra("url")?:return
  val p=if(isVod){val renderers=DefaultRenderersFactory(this).setEnableDecoderFallback(true).setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER);ExoPlayer.Builder(this,renderers).build().also{it.setAudioAttributes(AudioAttributes.DEFAULT,true);it.setMediaItem(androidx.media3.common.MediaItem.Builder().setUri(url).build());it.prepare();it.playWhenReady=true}}else LivePlayerSession.attach(playerView,this,url)
  player=p;if(isVod)playerView.player=p
  p.addListener(object:Player.Listener{override fun onIsPlayingChanged(v:Boolean){pause.text=if(v)"PAUZA"else"PLAY"};override fun onTracksChanged(tracks:Tracks){updateTrackButtons(tracks)};override fun onPlayerError(error:PlaybackException){Toast.makeText(this@PlayerActivity,"Błąd odtwarzania: ${error.errorCodeName}",Toast.LENGTH_LONG).show()}})
  updateTrackButtons(p.currentTracks);playerView.post{hideBuiltInTimeBar();positionVodSeek()}
 }
 private fun updateTrackButtons(tracks:Tracks){var audioCount=0;var textCount=0;for(g in tracks.groups){if(g.type==C.TRACK_TYPE_AUDIO){for(i in 0 until g.length)if(g.isTrackSupported(i))audioCount++};if(g.type==C.TRACK_TYPE_TEXT){for(i in 0 until g.length)if(g.isTrackSupported(i))textCount++}}
  if(isVod){audio.visibility=if(audioCount>1)View.VISIBLE else View.GONE;subtitles.visibility=if(textCount>0)View.VISIBLE else View.GONE;stop.visibility=View.VISIBLE;pause.visibility=View.VISIBLE}else{stop.visibility=View.GONE;pause.visibility=View.GONE;audio.visibility=if(audioCount>1)View.VISIBLE else View.GONE;subtitles.visibility=if(textCount>0)View.VISIBLE else View.GONE}
 }
 private fun hideBuiltInTimeBar(){if(isVod)playerView.findViewById<DefaultTimeBar>(androidx.media3.ui.R.id.exo_progress)?.visibility=View.GONE}
 private data class TrackChoice(val label:String,val group:Tracks.Group?,val index:Int)
 private fun showTrackDialog(type:Int,title:String){val p=player?:return;val choices=ArrayList<TrackChoice>();if(type==C.TRACK_TYPE_TEXT)choices+=TrackChoice("Wyłącz napisy",null,-1);for(g in p.currentTracks.groups){if(g.type!=type)continue;for(i in 0 until g.length){if(!g.isTrackSupported(i))continue;val f=g.getTrackFormat(i);val lang=f.language?.uppercase()?:"";val label=f.label?.takeIf{it.isNotBlank()}?:if(type==C.TRACK_TYPE_AUDIO)"Audio ${choices.size+1}"else"Napisy ${choices.size+1}";choices+=TrackChoice(if(lang.isBlank())label else"$label  [$lang]",g,i)}};if(choices.isEmpty()||(type==C.TRACK_TYPE_TEXT&&choices.size==1)){Toast.makeText(this,"Brak dostępnych ścieżek",Toast.LENGTH_SHORT).show();return};AlertDialog.Builder(this).setTitle(title).setItems(choices.map{it.label}.toTypedArray()){_,w->val c=choices[w];val b=p.trackSelectionParameters.buildUpon().clearOverridesOfType(type);if(c.group==null)b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT,true)else{b.setTrackTypeDisabled(type,false);b.setOverrideForType(TrackSelectionOverride(c.group.mediaTrackGroup,listOf(c.index)))};p.trackSelectionParameters=b.build();showControls()}.setNegativeButton("Anuluj",null).show()}
 private fun showControls(){info.visibility=View.VISIBLE;aspect.visibility=View.VISIBLE;if(isVod){vodSeek.visibility=View.VISIBLE;playerView.showController();hideBuiltInTimeBar();positionVodSeek()};handler.removeCallbacks(hideInfo);handler.postDelayed(hideInfo,5000)}
 private fun toggleControls(){if(info.visibility==View.VISIBLE){handler.removeCallbacks(hideInfo);hideInfo.run()}else showControls()}
 override fun dispatchKeyEvent(e:KeyEvent):Boolean{
  if(e.keyCode==KeyEvent.KEYCODE_DPAD_LEFT||e.keyCode==KeyEvent.KEYCODE_DPAD_RIGHT){if(isVod){if(e.action==KeyEvent.ACTION_DOWN){if(!seekHeld){seekHeld=true;seekDirection=if(e.keyCode==KeyEvent.KEYCODE_DPAD_RIGHT)5000L else -5000L;seekBy(seekDirection,true);handler.postDelayed(repeatSeek,350)};return true}else if(e.action==KeyEvent.ACTION_UP){stopSeekHold();return true}}}
  if(e.action!=KeyEvent.ACTION_DOWN)return super.dispatchKeyEvent(e)
  when(e.keyCode){
   KeyEvent.KEYCODE_DPAD_CENTER,KeyEvent.KEYCODE_ENTER->{if(info.visibility!=View.VISIBLE){showControls();return true};if(currentFocus==null||currentFocus===playerView){when{audio.visibility==View.VISIBLE->audio.requestFocus();subtitles.visibility==View.VISIBLE->subtitles.requestFocus();else->aspect.requestFocus()};handler.removeCallbacks(hideInfo);return true}}
   KeyEvent.KEYCODE_DPAD_UP->{if(!isVod&&!isControlFocused()){switchLive(-1);return true}}
   KeyEvent.KEYCODE_DPAD_DOWN->{if(!isVod&&!isControlFocused()){switchLive(1);return true}}
   KeyEvent.KEYCODE_CHANNEL_UP->{if(!isVod){switchLive(-1);return true}}
   KeyEvent.KEYCODE_CHANNEL_DOWN->{if(!isVod){switchLive(1);return true}}
   KeyEvent.KEYCODE_BACK->{if(info.visibility==View.VISIBLE){hideInfo.run();return true}}
  }
  return super.dispatchKeyEvent(e)
 }
 private fun isControlFocused():Boolean=currentFocus===audio||currentFocus===subtitles||currentFocus===aspect||currentFocus===pause||currentFocus===stop
 private fun switchLive(delta:Int){if(navUrls.isEmpty())return;liveIndex=(liveIndex+delta+navUrls.size)%navUrls.size;val url=navUrls.getOrNull(liveIndex)?:return;player=LivePlayerSession.attach(playerView,this,url);applyNavInfo(liveIndex);player?.currentTracks?.let{updateTrackButtons(it)};showControls()}
 private fun applyNavInfo(i:Int){channelText.text=navNames.getOrNull(i).orEmpty();val ns=navNowStarts.getOrNull(i).orEmpty();val ne=navNowEnds.getOrNull(i).orEmpty();val nt=navNowTitles.getOrNull(i).orEmpty();nowTitle.text=(if(ns.isNotBlank()||ne.isNotBlank())"$ns - $ne  "else"")+nt;val xs=navNextStarts.getOrNull(i).orEmpty();val xe=navNextEnds.getOrNull(i).orEmpty();val xt=navNextTitles.getOrNull(i).orEmpty();nextTitle.text=if(xt.isBlank())""else"Następnie: "+(if(xs.isNotBlank()||xe.isNotBlank())"$xs - $xe  "else"")+xt;liveStartEpoch=navNowStartEpoch.getOrElse(i){0L};liveEndEpoch=navNowEndEpoch.getOrElse(i){0L};loadPicon(navLocalLogos.getOrNull(i).orEmpty(),navLogos.getOrNull(i).orEmpty());updateLiveProgress()}
 private fun loadPicon(localLogo:String,logo:String){picon.setImageDrawable(null);if(localLogo.isNotBlank()){val b=BitmapFactory.decodeFile(localLogo);if(b!=null){picon.visibility=View.VISIBLE;picon.setImageBitmap(b);return}};if(logo.isNotBlank()){picon.visibility=View.VISIBLE;val expected=logo;Thread{try{val b=URL(expected).openStream().use{it.readBytes()};runOnUiThread{picon.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.size))}}catch(_:Exception){runOnUiThread{picon.visibility=View.GONE}}}.start()}else picon.visibility=View.GONE}
 private fun stopSeekHold(){seekHeld=false;seekDirection=0L;handler.removeCallbacks(repeatSeek)}
 private fun seekBy(ms:Long,refresh:Boolean=true){val p=player?:return;val d=p.duration;if(d>0&&d!=C.TIME_UNSET)p.seekTo((p.currentPosition+ms).coerceIn(0,d));if(refresh)showControls()}
 private fun immersive(){window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);if(Build.VERSION.SDK_INT>=30){window.setDecorFitsSystemWindows(false);window.insetsController?.let{it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars());it.systemBarsBehavior=WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE}}else{@Suppress("DEPRECATION")window.decorView.systemUiVisibility=View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE}}
 override fun onWindowFocusChanged(f:Boolean){super.onWindowFocusChanged(f);if(f)immersive()}
 override fun dispatchTouchEvent(ev:MotionEvent):Boolean{if(ev.action==MotionEvent.ACTION_UP&&!userSeeking)showControls();return super.dispatchTouchEvent(ev)}
 override fun onStop(){super.onStop();if(isVod)player?.pause()}
 override fun onDestroy(){stopSeekHold();handler.removeCallbacksAndMessages(null);if(isVod){playerView.player=null;player?.release()}else LivePlayerSession.detach(playerView);player=null;super.onDestroy()}
}
