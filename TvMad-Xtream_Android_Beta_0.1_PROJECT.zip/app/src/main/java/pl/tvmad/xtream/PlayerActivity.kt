package pl.tvmad.xtream

import android.app.*
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.*
import android.view.*
import android.widget.*
import androidx.media3.common.*
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.DefaultTimeBar
import androidx.media3.ui.PlayerView
import androidx.media3.common.util.UnstableApi
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.util.VLCVideoLayout
import java.net.URL

@UnstableApi
class PlayerActivity:Activity(){
 private lateinit var playerView:PlayerView; private lateinit var videoBox:FrameLayout; private lateinit var info:View; private lateinit var aspect:Button
 private lateinit var pause:Button; private lateinit var stop:Button; private lateinit var audio:Button; private lateinit var subtitles:Button
 private lateinit var vodButtons:View;private lateinit var picon:ImageView;private lateinit var nowTitle:TextView;private lateinit var nextTitle:TextView;private lateinit var liveProgress:ProgressBar;private lateinit var vodSeek:SeekBar
 private var player:ExoPlayer?=null;private var libVlc:LibVLC?=null;private var vlcPlayer:org.videolan.libvlc.MediaPlayer?=null;private var vlcLayout:VLCVideoLayout?=null
 private val handler=Handler(Looper.getMainLooper()); private var fillMode=false;private var isVod=false;private var userSeeking=false
 private val hideInfo=Runnable{info.visibility=View.GONE;aspect.visibility=View.GONE;if(isVod){playerView.hideController();vodSeek.visibility=View.GONE}}
 private val updateLive=object:Runnable{override fun run(){updateLiveProgress();handler.postDelayed(this,15000)}}
 private val updateVodSeek=object:Runnable{override fun run(){if(isVod&&!userSeeking){val p=player;val d=p?.duration?:0L;if(d>0L&&d!=C.TIME_UNSET){vodSeek.progress=((p!!.currentPosition.coerceIn(0L,d)*1000L)/d).toInt()}};handler.postDelayed(this,500)}}

 override fun onCreate(b:Bundle?){
  super.onCreate(b);setContentView(R.layout.activity_player);immersive();isVod=intent.getBooleanExtra("vod",false)
  playerView=findViewById(R.id.playerView);videoBox=findViewById(R.id.videoBox);info=findViewById(R.id.info);aspect=findViewById(R.id.aspect)
  pause=findViewById(R.id.pause);stop=findViewById(R.id.stop);audio=findViewById(R.id.audio);subtitles=findViewById(R.id.subtitles);vodButtons=findViewById(R.id.vodButtons);vodSeek=findViewById(R.id.vodSeek)
  picon=findViewById(R.id.infoPicon);nowTitle=findViewById(R.id.nowTitle);nextTitle=findViewById(R.id.nextTitle);liveProgress=findViewById(R.id.liveProgress)
  findViewById<TextView>(R.id.channel).text=intent.getStringExtra("name")?:""
  setupInfo()
  playerView.useController=isVod;playerView.controllerAutoShow=false;playerView.controllerHideOnTouch=false;playerView.resizeMode=AspectRatioFrameLayout.RESIZE_MODE_FIT
  playerView.subtitleView?.apply{visibility=View.VISIBLE;setApplyEmbeddedStyles(true);setApplyEmbeddedFontSizes(true)}
  aspect.setOnClickListener{fillMode=!fillMode;aspect.text=if(fillMode)"↔ WYPEŁNIJ" else "16:9";if(isVod)playerView.resizeMode=if(fillMode)AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT else vlcPlayer?.setVideoScale(if(fillMode)org.videolan.libvlc.MediaPlayer.ScaleType.SURFACE_FILL else org.videolan.libvlc.MediaPlayer.ScaleType.SURFACE_BEST_FIT);showControls()}
  pause.setOnClickListener{player?.let{p->if(p.isPlaying){p.pause();pause.text="PLAY"}else{p.play();pause.text="PAUZA"}};showControls()}
  stop.setOnClickListener{player?.stop();finish()}
  audio.setOnClickListener{showTrackDialog(C.TRACK_TYPE_AUDIO,"Ścieżka audio")}
  subtitles.setOnClickListener{showTrackDialog(C.TRACK_TYPE_TEXT,"Napisy")}
  findViewById<View>(R.id.playerRoot).setOnClickListener{if(isVod)toggleControls() else showControls()}
  setupVodSeek();startPlayback();showControls()
 }
 private fun setupInfo(){
  val epg=findViewById<TextView>(R.id.epg)
  if(isVod){info.setBackgroundColor(0x70101010);vodButtons.visibility=View.VISIBLE;epg.visibility=View.GONE;nowTitle.visibility=View.GONE;nextTitle.visibility=View.GONE;liveProgress.visibility=View.GONE;picon.visibility=View.GONE;vodSeek.visibility=View.VISIBLE}
  else{
   info.setBackgroundColor(0xD9101010.toInt());vodButtons.visibility=View.GONE;epg.visibility=View.GONE;nowTitle.visibility=View.VISIBLE;nextTitle.visibility=View.VISIBLE;liveProgress.visibility=View.VISIBLE;vodSeek.visibility=View.GONE
   val ns=intent.getStringExtra("nowStart").orEmpty();val ne=intent.getStringExtra("nowEnd").orEmpty();val nt=intent.getStringExtra("nowTitle").orEmpty()
   nowTitle.text=(if(ns.isNotBlank()||ne.isNotBlank())"$ns - $ne  " else "")+nt
   val xs=intent.getStringExtra("nextStart").orEmpty();val xe=intent.getStringExtra("nextEnd").orEmpty();val xt=intent.getStringExtra("nextTitle").orEmpty()
   nextTitle.text=if(xt.isBlank())"" else "Następnie: "+(if(xs.isNotBlank()||xe.isNotBlank())"$xs - $xe  " else "")+xt
   val logo=intent.getStringExtra("logo").orEmpty();if(logo.isNotBlank()){picon.visibility=View.VISIBLE;Thread{try{val b=URL(logo).openStream().use{it.readBytes()};runOnUiThread{picon.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.size))}}catch(_:Exception){runOnUiThread{picon.visibility=View.GONE}}}.start()}else picon.visibility=View.GONE
   updateLiveProgress();handler.post(updateLive)
  }
 }
 private fun setupVodSeek(){
  if(!isVod)return
  vodSeek.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
   override fun onStartTrackingTouch(s:SeekBar){userSeeking=true;handler.removeCallbacks(hideInfo)}
   override fun onProgressChanged(s:SeekBar,progress:Int,fromUser:Boolean){if(fromUser){val p=player?:return;val d=p.duration;if(d>0L&&d!=C.TIME_UNSET)p.seekTo((d*progress)/1000L)}}
   override fun onStopTrackingTouch(s:SeekBar){userSeeking=false;showControls()}
  })
  handler.post(updateVodSeek)
 }
 private fun positionVodSeek(){if(!isVod)return;vodSeek.post{if(info.height>0)vodSeek.translationY=-info.height.toFloat()}}
 private fun updateLiveProgress(){if(isVod)return;val s=intent.getLongExtra("nowStartEpoch",0L);val e=intent.getLongExtra("nowEndEpoch",0L);if(s>0&&e>s){val n=System.currentTimeMillis();liveProgress.progress=(((n-s).coerceIn(0,e-s)*1000L)/(e-s)).toInt()}else liveProgress.progress=0}
 private fun startPlayback(){if(isVod)startExoVod() else startVlcLive()}
 private fun startExoVod(){
  val url=intent.getStringExtra("url")?:return
  val renderers=DefaultRenderersFactory(this).setEnableDecoderFallback(true)
  val p=ExoPlayer.Builder(this,renderers).build();player=p;playerView.player=p;playerView.visibility=View.VISIBLE
  p.setAudioAttributes(AudioAttributes.DEFAULT,true);p.setMediaItem(androidx.media3.common.MediaItem.Builder().setUri(url).build());p.prepare();p.playWhenReady=true
  p.addListener(object:Player.Listener{
   override fun onIsPlayingChanged(isPlaying:Boolean){pause.text=if(isPlaying)"PAUZA" else "PLAY"}
   override fun onTracksChanged(tracks:Tracks){hideBuiltInTimeBar()}
   override fun onPlayerError(error:PlaybackException){Toast.makeText(this@PlayerActivity,"Błąd odtwarzania: ${error.errorCodeName}",Toast.LENGTH_LONG).show()}
  })
  playerView.post{hideBuiltInTimeBar();positionVodSeek()}
 }
 private fun startVlcLive(){
  val url=intent.getStringExtra("url")?:return
  playerView.visibility=View.GONE
  try{
   val opts=arrayListOf("--network-caching=1200","--clock-jitter=0","--clock-synchro=0")
   val lib=LibVLC(this,opts);libVlc=lib
   val layout=VLCVideoLayout(this);vlcLayout=layout;videoBox.addView(layout,0,FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT,FrameLayout.LayoutParams.MATCH_PARENT))
   val mp=org.videolan.libvlc.MediaPlayer(lib);vlcPlayer=mp;mp.attachViews(layout,null,false,false);mp.setVideoScale(org.videolan.libvlc.MediaPlayer.ScaleType.SURFACE_BEST_FIT)
   val media=Media(lib,Uri.parse(url));media.setHWDecoderEnabled(true,false);media.addOption(":network-caching=1200");media.addOption(":audio-time-stretch");mp.media=media;media.release();mp.play()
  }catch(e:Exception){Toast.makeText(this,"VLC Live: ${e.message}",Toast.LENGTH_LONG).show()}
 }
 private fun hideBuiltInTimeBar(){if(!isVod)return;playerView.findViewById<DefaultTimeBar>(androidx.media3.ui.R.id.exo_progress)?.visibility=View.GONE}
 private data class TrackChoice(val label:String,val group:Tracks.Group?,val index:Int)
 private fun showTrackDialog(type:Int,title:String){
  val p=player?:return;val choices=ArrayList<TrackChoice>()
  if(type==C.TRACK_TYPE_TEXT)choices+=TrackChoice("Wyłącz napisy",null,-1)
  for(g in p.currentTracks.groups){if(g.type!=type)continue;for(i in 0 until g.length){if(!g.isTrackSupported(i))continue;val f=g.getTrackFormat(i);val lang=f.language?.uppercase()?:"";val label=f.label?.takeIf{it.isNotBlank()}?:when(type){C.TRACK_TYPE_AUDIO->"Audio ${choices.size+1}";else->"Napisy ${choices.size+1}"};choices+=TrackChoice(if(lang.isBlank())label else "$label  [$lang]",g,i)}}
  if(choices.isEmpty()||(type==C.TRACK_TYPE_TEXT&&choices.size==1)){Toast.makeText(this,"Brak dostępnych ścieżek",Toast.LENGTH_SHORT).show();return}
  AlertDialog.Builder(this).setTitle(title).setItems(choices.map{it.label}.toTypedArray()){_,which->
   val c=choices[which];val b=p.trackSelectionParameters.buildUpon().clearOverridesOfType(type)
   if(c.group==null){b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT,true)}else{b.setTrackTypeDisabled(type,false);b.setOverrideForType(TrackSelectionOverride(c.group.mediaTrackGroup,listOf(c.index)));if(type==C.TRACK_TYPE_TEXT){val lang=c.group.getTrackFormat(c.index).language;if(!lang.isNullOrBlank())b.setPreferredTextLanguage(lang)}}
   p.trackSelectionParameters=b.build();playerView.subtitleView?.visibility=View.VISIBLE;showControls()
  }.setNegativeButton("Anuluj",null).show()
 }
 private fun showControls(){info.visibility=View.VISIBLE;aspect.visibility=View.VISIBLE;if(isVod){vodSeek.visibility=View.VISIBLE;playerView.showController();hideBuiltInTimeBar();positionVodSeek()};handler.removeCallbacks(hideInfo);handler.postDelayed(hideInfo,5000)}
 private fun toggleControls(){if(info.visibility==View.VISIBLE){handler.removeCallbacks(hideInfo);hideInfo.run()}else showControls()}
 private fun immersive(){window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);if(Build.VERSION.SDK_INT>=30){window.setDecorFitsSystemWindows(false);window.insetsController?.let{it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars());it.systemBarsBehavior=WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE}}else{@Suppress("DEPRECATION") window.decorView.systemUiVisibility=View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE}}
 override fun onWindowFocusChanged(hasFocus:Boolean){super.onWindowFocusChanged(hasFocus);if(hasFocus)immersive()}
 override fun dispatchTouchEvent(ev:MotionEvent):Boolean{if(isVod&&ev.action==MotionEvent.ACTION_UP&&!userSeeking)showControls();return super.dispatchTouchEvent(ev)}
 override fun onStop(){super.onStop();if(isVod)player?.pause() else try{vlcPlayer?.pause()}catch(_:Exception){}}
 override fun onDestroy(){handler.removeCallbacksAndMessages(null);playerView.player=null;player?.release();player=null;try{vlcPlayer?.stop()}catch(_:Exception){};try{vlcPlayer?.detachViews()}catch(_:Exception){};try{vlcPlayer?.release()}catch(_:Exception){};vlcPlayer=null;try{libVlc?.release()}catch(_:Exception){};libVlc=null;super.onDestroy()}
}
