package pl.tvmad.xtream

import android.app.*
import android.graphics.BitmapFactory
import android.os.*
import android.view.*
import android.widget.*
import androidx.media3.common.*
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.DefaultTimeBar
import androidx.media3.ui.PlayerView
import androidx.media3.common.util.UnstableApi
import java.net.URL

@UnstableApi
class PlayerActivity:Activity(){
 private lateinit var playerView:PlayerView;private lateinit var info:View;private lateinit var aspect:Button;private lateinit var pause:Button;private lateinit var stop:Button;private lateinit var audio:Button;private lateinit var subtitles:Button;private lateinit var channelText:TextView
 private lateinit var picon:ImageView;private lateinit var nowTitle:TextView;private lateinit var nextTitle:TextView;private lateinit var liveProgress:ProgressBar;private lateinit var vodSeek:SeekBar;private lateinit var vodTime:TextView;private lateinit var bufferingBox:View;private lateinit var bufferingText:TextView
 private var player:ExoPlayer?=null;private val handler=Handler(Looper.getMainLooper());private var fillMode=false;private var isVod=false;private var userSeeking=false;private var vodControlsMode=false;private var exitPromptShowing=false
 private var seekHeld=false;private var seekDirection=0L;private var seekTarget=0L;private var seekWasPlaying=false;private var seekHoldStarted=0L;private var seekLastTick=0L;private var suppressRecoveryUntil=0L;private var hasPlayed=false;private var retryCount=0;private var retryScheduled=false;private var bufferingVisible=false
 private var liveIndex=0;private var navUrls=arrayListOf<String>();private var navNames=arrayListOf<String>();private var navLogos=arrayListOf<String>();private var navGroups=arrayListOf<String>();private var navEpgIds=arrayListOf<String>();private var navStreamIds=arrayListOf<String>();private var navLocalLogos=arrayListOf<String>();private var navNowTitles=arrayListOf<String>();private var navNowStarts=arrayListOf<String>();private var navNowEnds=arrayListOf<String>();private var navNextTitles=arrayListOf<String>();private var navNextStarts=arrayListOf<String>();private var navNextEnds=arrayListOf<String>();private var navNowStartEpoch=LongArray(0);private var navNowEndEpoch=LongArray(0)
 private var liveStartEpoch=0L;private var liveEndEpoch=0L
 private val hideInfo=Runnable{hideInfoAnimated()}
 private val updateLive=object:Runnable{override fun run(){updateLiveProgress();handler.postDelayed(this,15000)}}
 private val updateVodSeek=object:Runnable{override fun run(){if(isVod&&!userSeeking&&!seekHeld){val p=player;val d=p?.duration?:0L;if(d>0L&&d!=C.TIME_UNSET){val pos=p!!.currentPosition.coerceIn(0,d);vodSeek.progress=((pos*100000L)/d).toInt();vodTime.text="${fmtTime(pos)} / ${fmtTime(d)}"}};handler.postDelayed(this,250)}}
 private val repeatSeek=object:Runnable{override fun run(){if(seekHeld&&seekDirection!=0L){val now=SystemClock.uptimeMillis();val dt=(now-seekLastTick).coerceIn(8L,40L);seekLastTick=now;val held=(now-seekHoldStarted).coerceAtLeast(0L);val speed=(28.0+(held/1400.0).coerceAtMost(1.0)*92.0);advanceSeekPreview((seekDirection*dt*speed).toLong());showControlsKeepVisible();handler.postDelayed(this,16)}}}
 private val bufferingTick=object:Runnable{override fun run(){if(bufferingVisible){val pct=(player?.bufferedPercentage?:0).coerceIn(0,100);bufferingText.text="Buforowanie $pct%";handler.postDelayed(this,250)}}}
 private val retryPlayback=Runnable{retryScheduled=false;if(bufferingVisible&&retryCount<3){retryCount++;restartAfterBreak();scheduleRetry()}}
 override fun onCreate(b:Bundle?){
  super.onCreate(b);setContentView(R.layout.activity_player);immersive();isVod=intent.getBooleanExtra("vod",false)
  playerView=findViewById(R.id.playerView);playerView.isFocusable=true;playerView.isFocusableInTouchMode=true;info=findViewById(R.id.info);aspect=findViewById(R.id.aspect);pause=findViewById(R.id.pause);stop=findViewById(R.id.stop);audio=findViewById(R.id.audio);subtitles=findViewById(R.id.subtitles);vodSeek=findViewById(R.id.vodSeek)
  picon=findViewById(R.id.infoPicon);nowTitle=findViewById(R.id.nowTitle);nextTitle=findViewById(R.id.nextTitle);liveProgress=findViewById(R.id.liveProgress);vodTime=findViewById(R.id.vodTime);bufferingBox=findViewById(R.id.bufferingBox);bufferingText=findViewById(R.id.bufferingText);channelText=findViewById(R.id.channel);channelText.text=intent.getStringExtra("name")?:""
  if(!isVod)loadLiveNavigation()
  setupInfo();playerView.setKeepContentOnPlayerReset(true);playerView.useController=false;playerView.controllerAutoShow=false;playerView.controllerHideOnTouch=false;playerView.resizeMode=AspectRatioFrameLayout.RESIZE_MODE_FIT;playerView.subtitleView?.apply{visibility=View.VISIBLE;setApplyEmbeddedStyles(true);setApplyEmbeddedFontSizes(true)}
  aspect.setOnClickListener{fillMode=!fillMode;aspect.text=if(fillMode)"↔ WYPEŁNIJ" else "16:9";playerView.resizeMode=if(fillMode)AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT;showControls()}
  pause.setOnClickListener{player?.let{if(it.isPlaying)it.pause()else it.play()};showControls()};stop.setOnClickListener{if(isVod)askVodExitSave() else finish()};audio.setOnClickListener{showTrackDialog(C.TRACK_TYPE_AUDIO,"Ścieżka audio")};subtitles.setOnClickListener{showTrackDialog(C.TRACK_TYPE_TEXT,"Napisy")}
  findViewById<View>(R.id.playerRoot).setOnClickListener{toggleControls()};setupVodSeek();startExo();showControls()
 }
 private fun loadLiveNavigation(){
  navUrls=intent.getStringArrayListExtra("navUrls")?:arrayListOf();navNames=intent.getStringArrayListExtra("navNames")?:arrayListOf();navLogos=intent.getStringArrayListExtra("navLogos")?:arrayListOf();navGroups=intent.getStringArrayListExtra("navGroups")?:arrayListOf();navEpgIds=intent.getStringArrayListExtra("navEpgIds")?:arrayListOf();navStreamIds=intent.getStringArrayListExtra("navStreamIds")?:arrayListOf();navLocalLogos=intent.getStringArrayListExtra("navLocalLogos")?:arrayListOf();navNowTitles=intent.getStringArrayListExtra("navNowTitles")?:arrayListOf();navNowStarts=intent.getStringArrayListExtra("navNowStarts")?:arrayListOf();navNowEnds=intent.getStringArrayListExtra("navNowEnds")?:arrayListOf();navNextTitles=intent.getStringArrayListExtra("navNextTitles")?:arrayListOf();navNextStarts=intent.getStringArrayListExtra("navNextStarts")?:arrayListOf();navNextEnds=intent.getStringArrayListExtra("navNextEnds")?:arrayListOf();navNowStartEpoch=intent.getLongArrayExtra("navNowStartEpoch")?:LongArray(0);navNowEndEpoch=intent.getLongArrayExtra("navNowEndEpoch")?:LongArray(0);liveIndex=intent.getIntExtra("navIndex",0).coerceAtLeast(0)
 }
 private fun setupInfo(){val epg=findViewById<TextView>(R.id.epg);epg.visibility=View.GONE
  if(isVod){vodTime.visibility=View.VISIBLE;nowTitle.visibility=View.GONE;nextTitle.visibility=View.GONE;liveProgress.visibility=View.GONE;picon.visibility=View.GONE;vodSeek.visibility=View.VISIBLE;audio.visibility=View.GONE;subtitles.visibility=View.GONE}
  else{vodTime.visibility=View.GONE;pause.visibility=View.GONE;stop.visibility=View.GONE;audio.visibility=View.GONE;subtitles.visibility=View.GONE;nowTitle.visibility=View.VISIBLE;nextTitle.visibility=View.VISIBLE;liveProgress.visibility=View.VISIBLE;vodSeek.visibility=View.GONE;applyInitialLiveInfo();handler.post(updateLive)}
 }
 private fun applyInitialLiveInfo(){val ns=intent.getStringExtra("nowStart").orEmpty();val ne=intent.getStringExtra("nowEnd").orEmpty();val nt=intent.getStringExtra("nowTitle").orEmpty();nowTitle.text=(if(ns.isNotBlank()||ne.isNotBlank())"$ns - $ne  " else "")+nt;val xs=intent.getStringExtra("nextStart").orEmpty();val xe=intent.getStringExtra("nextEnd").orEmpty();val xt=intent.getStringExtra("nextTitle").orEmpty();nextTitle.text=if(xt.isBlank())"" else "Następnie: "+(if(xs.isNotBlank()||xe.isNotBlank())"$xs - $xe  " else "")+xt;liveStartEpoch=intent.getLongExtra("nowStartEpoch",0);liveEndEpoch=intent.getLongExtra("nowEndEpoch",0);loadPicon(intent.getStringExtra("localLogo").orEmpty(),intent.getStringExtra("logo").orEmpty());updateLiveProgress()}
 private fun setupVodSeek(){if(!isVod)return;vodSeek.max=100000;vodSeek.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{override fun onStartTrackingTouch(s:SeekBar){userSeeking=true;handler.removeCallbacks(hideInfo)};override fun onProgressChanged(s:SeekBar,progress:Int,fromUser:Boolean){if(fromUser){val p=player?:return;val d=p.duration;if(d>0&&d!=C.TIME_UNSET){val target=(d*progress)/100000L;vodTime.text="${fmtTime(target)} / ${fmtTime(d)}"}}};override fun onStopTrackingTouch(s:SeekBar){val p=player;val d=p?.duration?:0L;if(d>0&&d!=C.TIME_UNSET){suppressRecoveryUntil=SystemClock.uptimeMillis()+2200;p?.seekTo((d*s.progress)/100000L)};userSeeking=false;showControls()}});handler.post(updateVodSeek)}
 private fun positionVodSeek(){if(!isVod)return;vodSeek.translationY=0f}
 private fun updateLiveProgress(){if(isVod)return;if(liveStartEpoch>0&&liveEndEpoch>liveStartEpoch){val n=System.currentTimeMillis();liveProgress.progress=(((n-liveStartEpoch).coerceIn(0,liveEndEpoch-liveStartEpoch)*1000)/(liveEndEpoch-liveStartEpoch)).toInt()}else liveProgress.progress=0}
 private fun startExo(){
  val url=intent.getStringExtra("url")?:return
  val p=if(isVod){
   val renderers=DefaultRenderersFactory(this).setEnableDecoderFallback(true).setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
   val http=DefaultHttpDataSource.Factory().setUserAgent("TvMad-Xtream/AndroidTV").setConnectTimeoutMs(30000).setReadTimeoutMs(120000).setAllowCrossProtocolRedirects(true).setDefaultRequestProperties(mapOf("Accept" to "*/*","Accept-Encoding" to "identity","Connection" to "keep-alive"))
   val load=DefaultLoadControl.Builder().setBufferDurationsMs(2500,30000,750,1500).setPrioritizeTimeOverSizeThresholds(true).build()
   ExoPlayer.Builder(this,renderers).setMediaSourceFactory(DefaultMediaSourceFactory(http)).setLoadControl(load).build().also{it.setAudioAttributes(AudioAttributes.DEFAULT,true);it.setMediaItem(androidx.media3.common.MediaItem.Builder().setUri(url).build());it.prepare();val resume=intent.getLongExtra("resumeMs",0L);if(resume>0L)it.seekTo(resume);it.playWhenReady=true}
  }else LivePlayerSession.attach(playerView,this,url)
  player=p;if(isVod)playerView.player=p
  p.addListener(object:Player.Listener{
   override fun onIsPlayingChanged(v:Boolean){pause.text=if(v)"Ⅱ  PAUZA" else "▶  PLAY";if(v){hasPlayed=true;retryCount=0;hideBuffering()}}
   override fun onPlaybackStateChanged(state:Int){when(state){Player.STATE_READY->{if(p.playWhenReady&&p.playbackState==Player.STATE_READY&&!p.isPlaying)return;hideBuffering()};Player.STATE_BUFFERING->{if(hasPlayed&&SystemClock.uptimeMillis()>=suppressRecoveryUntil&&!userSeeking&&!seekHeld){showBuffering();scheduleRetry()}};Player.STATE_ENDED->{if(hasPlayed&&SystemClock.uptimeMillis()>=suppressRecoveryUntil){showBuffering();scheduleRetry()}}}}
   override fun onTracksChanged(tracks:Tracks){updateTrackButtons(tracks)}
   override fun onPlayerError(error:PlaybackException){if(hasPlayed){showBuffering();scheduleRetry(700)}else Toast.makeText(this@PlayerActivity,"Błąd odtwarzania: ${error.errorCodeName}",Toast.LENGTH_LONG).show()}
  })
  updateTrackButtons(p.currentTracks);playerView.post{hideBuiltInTimeBar();positionVodSeek()}
 }
 private fun updateTrackButtons(tracks:Tracks){var audioCount=0;var textCount=0;for(g in tracks.groups){if(g.type==C.TRACK_TYPE_AUDIO){for(i in 0 until g.length)if(g.isTrackSupported(i))audioCount++};if(g.type==C.TRACK_TYPE_TEXT){for(i in 0 until g.length)if(g.isTrackSupported(i))textCount++}}
  if(isVod){audio.visibility=if(audioCount>1)View.VISIBLE else View.GONE;subtitles.visibility=if(textCount>0)View.VISIBLE else View.GONE;stop.visibility=View.VISIBLE;pause.visibility=View.VISIBLE}else{stop.visibility=View.GONE;pause.visibility=View.GONE;audio.visibility=if(audioCount>1)View.VISIBLE else View.GONE;subtitles.visibility=if(textCount>0)View.VISIBLE else View.GONE}
 }
 private fun hideBuiltInTimeBar(){if(isVod)playerView.findViewById<DefaultTimeBar>(androidx.media3.ui.R.id.exo_progress)?.visibility=View.GONE}
 private data class TrackChoice(val label:String,val group:Tracks.Group?,val index:Int)
 private fun showTrackDialog(type:Int,title:String){val p=player?:return;val choices=ArrayList<TrackChoice>();if(type==C.TRACK_TYPE_TEXT)choices+=TrackChoice("Wyłącz napisy",null,-1);for(g in p.currentTracks.groups){if(g.type!=type)continue;for(i in 0 until g.length){if(!g.isTrackSupported(i))continue;val f=g.getTrackFormat(i);val lang=f.language?.uppercase()?:"";val label=f.label?.takeIf{it.isNotBlank()}?:if(type==C.TRACK_TYPE_AUDIO)"Audio ${choices.size+1}" else "Napisy ${choices.size+1}";choices+=TrackChoice(if(lang.isBlank())label else "$label  [$lang]",g,i)}};if(choices.isEmpty()||(type==C.TRACK_TYPE_TEXT&&choices.size==1)){Toast.makeText(this,"Brak dostępnych ścieżek",Toast.LENGTH_SHORT).show();return};AlertDialog.Builder(this).setTitle(title).setItems(choices.map{it.label}.toTypedArray()){_,w->val c=choices[w];val b=p.trackSelectionParameters.buildUpon().clearOverridesOfType(type);if(c.group==null)b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT,true)else{b.setTrackTypeDisabled(type,false);b.setOverrideForType(TrackSelectionOverride(c.group.mediaTrackGroup,listOf(c.index)))};p.trackSelectionParameters=b.build();showControls()}.setNegativeButton("Anuluj",null).show()}
 private fun showControls(delay:Long=5000){
  handler.removeCallbacks(hideInfo)
  val wasHidden=info.visibility!=View.VISIBLE
  val targetH=((resources.displayMetrics.widthPixels*372f)/1536f).toInt().coerceAtLeast(1)
  info.layoutParams=info.layoutParams.apply{height=targetH}
  info.animate().cancel();info.visibility=View.VISIBLE;aspect.visibility=View.VISIBLE
  if(isVod){vodSeek.visibility=View.VISIBLE;playerView.showController();hideBuiltInTimeBar();positionVodSeek()}
  if(wasHidden)info.post{info.translationY=info.height.toFloat();info.animate().translationY(0f).setDuration(280L).start()}
  handler.postDelayed(hideInfo,delay)
 }
 private fun hideInfoAnimated(){
  handler.removeCallbacks(hideInfo);if(isVod)exitVodControls(false);aspect.visibility=View.GONE
  if(isVod){playerView.hideController();vodSeek.visibility=View.GONE}
  info.animate().cancel()
  if(info.visibility!=View.VISIBLE){info.translationY=0f;return}
  info.animate().translationY(info.height.toFloat()).setDuration(260L).withEndAction{info.visibility=View.GONE;info.translationY=0f}.start()
 }
 private fun showControlsKeepVisible(){info.visibility=View.VISIBLE;aspect.visibility=View.VISIBLE;if(isVod){vodSeek.visibility=View.VISIBLE;playerView.showController();hideBuiltInTimeBar();positionVodSeek()};handler.removeCallbacks(hideInfo)}
 private fun toggleControls(){if(info.visibility==View.VISIBLE){handler.removeCallbacks(hideInfo);hideInfo.run()}else showControls()}
 override fun dispatchKeyEvent(e:KeyEvent):Boolean{
  if(isVod&&vodControlsMode){
   if(e.action==KeyEvent.ACTION_UP&&(e.keyCode==KeyEvent.KEYCODE_DPAD_LEFT||e.keyCode==KeyEvent.KEYCODE_DPAD_RIGHT||e.keyCode==KeyEvent.KEYCODE_DPAD_UP||e.keyCode==KeyEvent.KEYCODE_DPAD_DOWN||e.keyCode==KeyEvent.KEYCODE_DPAD_CENTER||e.keyCode==KeyEvent.KEYCODE_ENTER))return true
   if(e.action==KeyEvent.ACTION_DOWN){
    when(e.keyCode){
     KeyEvent.KEYCODE_DPAD_LEFT->{moveVodControlFocus(-1);return true}
     KeyEvent.KEYCODE_DPAD_RIGHT->{moveVodControlFocus(1);return true}
     KeyEvent.KEYCODE_DPAD_UP->{exitVodControls(true);return true}
     KeyEvent.KEYCODE_DPAD_DOWN->{return true}
     KeyEvent.KEYCODE_DPAD_CENTER,KeyEvent.KEYCODE_ENTER->{(currentFocus as? View)?.performClick();showControlsKeepVisible();return true}
     KeyEvent.KEYCODE_BACK->{exitVodControls(true);return true}
    }
   }
  }
  if(e.keyCode==KeyEvent.KEYCODE_DPAD_LEFT||e.keyCode==KeyEvent.KEYCODE_DPAD_RIGHT){if(isVod&&!vodControlsMode){if(e.action==KeyEvent.ACTION_DOWN){if(!seekHeld){val sign=if(e.keyCode==KeyEvent.KEYCODE_DPAD_RIGHT)1L else -1L;beginKeySeek(sign);handler.postDelayed(repeatSeek,220)};return true}else if(e.action==KeyEvent.ACTION_UP){commitKeySeek();return true}}}
  if(e.action!=KeyEvent.ACTION_DOWN)return super.dispatchKeyEvent(e)
  when(e.keyCode){
   KeyEvent.KEYCODE_DPAD_CENTER,KeyEvent.KEYCODE_ENTER->{if(info.visibility!=View.VISIBLE){showControls();return true};if(isVod){showControls();return true};if(currentFocus==null||currentFocus===playerView){when{audio.visibility==View.VISIBLE->audio.requestFocus();subtitles.visibility==View.VISIBLE->subtitles.requestFocus();else->aspect.requestFocus()};handler.removeCallbacks(hideInfo);return true}}
   KeyEvent.KEYCODE_DPAD_UP->{if(!isVod&&!isControlFocused()){switchLive(1);return true}}
   KeyEvent.KEYCODE_DPAD_DOWN->{if(isVod&&info.visibility==View.VISIBLE){enterVodControls();return true};if(!isVod&&!isControlFocused()){switchLive(-1);return true}}
   KeyEvent.KEYCODE_CHANNEL_UP->{if(!isVod){switchLive(1);return true}}
   KeyEvent.KEYCODE_CHANNEL_DOWN->{if(!isVod){switchLive(-1);return true}}
   KeyEvent.KEYCODE_BACK->{if(isVod){askVodExitSave();return true};if(info.visibility==View.VISIBLE){hideInfo.run();return true}}
  }
  return super.dispatchKeyEvent(e)
 }
 private fun visibleVodControls():List<View>{val all=listOf<View>(pause,stop,audio,subtitles);return all.filter{it.visibility==View.VISIBLE&&it.isEnabled}}
 private fun enterVodControls(){if(!isVod)return;stopSeekHold(false);val controls=visibleVodControls();if(controls.isEmpty())return;vodControlsMode=true;showControlsKeepVisible();controls.first().requestFocus()}
 private fun moveVodControlFocus(delta:Int){val controls=visibleVodControls();if(controls.isEmpty())return;val cur=controls.indexOf(currentFocus).let{if(it<0)0 else it};controls[(cur+delta+controls.size)%controls.size].requestFocus();showControlsKeepVisible()}
 private fun exitVodControls(keepInfo:Boolean){if(!isVod)return;vodControlsMode=false;pause.clearFocus();stop.clearFocus();audio.clearFocus();subtitles.clearFocus();playerView.requestFocus();if(keepInfo)showControls()}
 private fun isControlFocused():Boolean=currentFocus===audio||currentFocus===subtitles||currentFocus===aspect||currentFocus===pause||currentFocus===stop
 private fun switchLive(delta:Int){if(navUrls.isEmpty())return;liveIndex=(liveIndex+delta+navUrls.size)%navUrls.size;val url=navUrls.getOrNull(liveIndex)?:return;hasPlayed=false;retryCount=0;hideBuffering();player=LivePlayerSession.attach(playerView,this,url);applyNavInfo(liveIndex);saveLastLive(liveIndex);player?.currentTracks?.let{updateTrackButtons(it)};showControls()}
 private fun applyNavInfo(i:Int){channelText.text=navNames.getOrNull(i).orEmpty();val ns=navNowStarts.getOrNull(i).orEmpty();val ne=navNowEnds.getOrNull(i).orEmpty();val nt=navNowTitles.getOrNull(i).orEmpty();nowTitle.text=(if(ns.isNotBlank()||ne.isNotBlank())"$ns - $ne  " else "")+nt;val xs=navNextStarts.getOrNull(i).orEmpty();val xe=navNextEnds.getOrNull(i).orEmpty();val xt=navNextTitles.getOrNull(i).orEmpty();nextTitle.text=if(xt.isBlank())"" else "Następnie: "+(if(xs.isNotBlank()||xe.isNotBlank())"$xs - $xe  " else "")+xt;liveStartEpoch=navNowStartEpoch.getOrElse(i){0L};liveEndEpoch=navNowEndEpoch.getOrElse(i){0L};loadPicon(navLocalLogos.getOrNull(i).orEmpty(),navLogos.getOrNull(i).orEmpty());updateLiveProgress()}
 private fun loadPicon(localLogo:String,logo:String){picon.setImageDrawable(null);if(localLogo.isNotBlank()){val b=BitmapFactory.decodeFile(localLogo);if(b!=null){picon.visibility=View.VISIBLE;picon.setImageBitmap(b);return}};if(logo.isNotBlank()){picon.visibility=View.VISIBLE;val expected=logo;Thread{try{val b=URL(expected).openStream().use{it.readBytes()};runOnUiThread{picon.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.size))}}catch(_:Exception){runOnUiThread{picon.visibility=View.GONE}}}.start()}else picon.visibility=View.GONE}
 private fun beginKeySeek(sign:Long){val p=player?:return;val d=p.duration;if(d<=0||d==C.TIME_UNSET)return;seekHeld=true;seekDirection=sign;seekWasPlaying=p.isPlaying;seekTarget=(p.currentPosition+sign*5000L).coerceIn(0,d);seekHoldStarted=SystemClock.uptimeMillis();seekLastTick=seekHoldStarted;suppressRecoveryUntil=seekHoldStarted+8000;hideBuffering();p.pause();updateSeekPreview();showControlsKeepVisible()}
 private fun advanceSeekPreview(ms:Long){val p=player?:return;val d=p.duration;if(d<=0||d==C.TIME_UNSET)return;seekTarget=(seekTarget+ms).coerceIn(0,d);updateSeekPreview()}
 private fun updateSeekPreview(){val p=player?:return;val d=p.duration;if(d>0&&d!=C.TIME_UNSET){vodSeek.progress=((seekTarget*100000L)/d).toInt();vodTime.text="${fmtTime(seekTarget)} / ${fmtTime(d)}"}}
 private fun fmtTime(ms:Long):String{val total=(ms.coerceAtLeast(0L)/1000L);val h=total/3600;val m=(total%3600)/60;val s=total%60;return if(h>0)String.format("%d:%02d:%02d",h,m,s) else String.format("%02d:%02d",m,s)}
 private fun commitKeySeek(){if(!seekHeld)return;seekHeld=false;seekDirection=0L;handler.removeCallbacks(repeatSeek);val p=player?:return;suppressRecoveryUntil=SystemClock.uptimeMillis()+2200;p.seekTo(seekTarget);if(seekWasPlaying)p.play();handler.removeCallbacks(hideInfo);handler.postDelayed(hideInfo,3000)}
 private fun stopSeekHold(scheduleHide:Boolean=false){if(seekHeld)commitKeySeek() else {seekDirection=0L;handler.removeCallbacks(repeatSeek);if(scheduleHide){handler.removeCallbacks(hideInfo);handler.postDelayed(hideInfo,3000)}}}
 private fun seekBy(ms:Long,refresh:Boolean=true){val p=player?:return;val d=p.duration;if(d>0&&d!=C.TIME_UNSET){suppressRecoveryUntil=SystemClock.uptimeMillis()+1800;p.seekTo((p.currentPosition+ms).coerceIn(0,d))};if(refresh)showControls()}

 private fun askVodExitSave(){
  if(!isVod){finish();return};if(exitPromptShowing)return;stopSeekHold(false);player?.pause();exitPromptShowing=true
  AlertDialog.Builder(this).setTitle("Zapisać pozycję?").setMessage("Czy zapisać aktualną pozycję odtwarzania?").setPositiveButton("Tak"){_,_->saveVodPosition();exitPromptShowing=false;finish()}.setNegativeButton("Nie"){_,_->exitPromptShowing=false;finish()}.setOnCancelListener{exitPromptShowing=false;player?.play()}.show()
 }
 private fun saveVodPosition(){
  val p=player?:return;val pos=p.currentPosition.coerceAtLeast(0L);val duration=p.duration.takeIf{it>0L&&it!=C.TIME_UNSET}?:0L
  val type=intent.getStringExtra("sourceType").orEmpty();val host=intent.getStringExtra("sourceHost").orEmpty();val user=intent.getStringExtra("sourceUser").orEmpty();val srcUrl=intent.getStringExtra("sourceUrl").orEmpty();val sourceKey=VodHistoryStore.sourceKey(type,host,user,srcUrl)
  val key=intent.getStringExtra("recentKey").orEmpty().ifBlank{intent.getStringExtra("url").orEmpty()};val kind=intent.getStringExtra("recentKind").orEmpty().ifBlank{"movie"};val title=intent.getStringExtra("recentTitle").orEmpty().ifBlank{channelText.text.toString()};val shown=channelText.text.toString();val subtitle=if(kind=="series"&&shown!=title)shown else ""
  VodHistoryStore.save(this,VodHistoryEntry(key,kind,title,subtitle,intent.getStringExtra("recentPoster").orEmpty(),intent.getStringExtra("url").orEmpty(),pos,duration,sourceKey))
 }
 @Deprecated("Deprecated in Java") override fun onBackPressed(){if(isVod){askVodExitSave()}else super.onBackPressed()}

 private fun sourceFromIntent()=Source(intent.getStringExtra("sourceType").orEmpty(),intent.getStringExtra("sourceName").orEmpty(),intent.getStringExtra("sourceHost").orEmpty(),intent.getStringExtra("sourceUser").orEmpty(),intent.getStringExtra("sourcePass").orEmpty(),intent.getStringExtra("sourceUrl").orEmpty())
 private fun saveLastLive(i:Int){if(isVod)return;val url=navUrls.getOrNull(i)?:intent.getStringExtra("url").orEmpty();if(url.isBlank())return;val c=Channel(navNames.getOrNull(i)?:channelText.text.toString(),url,navGroups.getOrNull(i)?:intent.getStringExtra("group").orEmpty(),navLogos.getOrNull(i)?:intent.getStringExtra("logo").orEmpty(),navEpgIds.getOrNull(i)?:intent.getStringExtra("epgId").orEmpty(),navStreamIds.getOrNull(i)?:intent.getStringExtra("streamId").orEmpty());LastLiveStore.save(this,sourceFromIntent(),c)}
 private fun showBuffering(){if(!hasPlayed)return;bufferingVisible=true;bufferingBox.visibility=View.VISIBLE;handler.removeCallbacks(bufferingTick);handler.post(bufferingTick)}
 private fun hideBuffering(){bufferingVisible=false;bufferingBox.visibility=View.GONE;handler.removeCallbacks(bufferingTick);handler.removeCallbacks(retryPlayback);retryScheduled=false}
 private fun scheduleRetry(delay:Long=3500){if(!hasPlayed||retryScheduled||retryCount>=3)return;retryScheduled=true;handler.postDelayed(retryPlayback,delay)}
 private fun restartAfterBreak(){val p=player?:return;if(isVod){val pos=p.currentPosition.coerceAtLeast(0L);val uri=intent.getStringExtra("url").orEmpty();p.stop();p.clearMediaItems();p.setMediaItem(androidx.media3.common.MediaItem.fromUri(uri));p.prepare();if(pos>0)p.seekTo(pos);p.playWhenReady=true}else LivePlayerSession.restartCurrent()}

 private fun immersive(){window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);if(Build.VERSION.SDK_INT>=30){window.setDecorFitsSystemWindows(false);window.insetsController?.let{it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars());it.systemBarsBehavior=WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE}}else{@Suppress("DEPRECATION")window.decorView.systemUiVisibility=View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE}}
 override fun onWindowFocusChanged(f:Boolean){super.onWindowFocusChanged(f);if(f)immersive()}
 override fun dispatchTouchEvent(ev:MotionEvent):Boolean{if(ev.action==MotionEvent.ACTION_UP&&!userSeeking)showControls();return super.dispatchTouchEvent(ev)}
 override fun onResume(){super.onResume();AppScreenshotBridge.attach(this)}
 override fun onPause(){AppScreenshotBridge.detach(this);super.onPause()}
 override fun onStop(){super.onStop();if(isVod)player?.pause()}
 override fun onDestroy(){stopSeekHold(false);handler.removeCallbacksAndMessages(null);if(isVod){playerView.player=null;player?.release()}else LivePlayerSession.detach(playerView);player=null;super.onDestroy()}
}
