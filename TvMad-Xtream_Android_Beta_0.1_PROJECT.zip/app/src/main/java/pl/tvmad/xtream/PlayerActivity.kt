package pl.tvmad.xtream

import android.app.*
import android.os.*
import android.view.*
import android.widget.*
import androidx.media3.common.*
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import androidx.media3.common.util.UnstableApi

@UnstableApi
class PlayerActivity:Activity(){
 private lateinit var playerView:PlayerView; private lateinit var videoBox:FrameLayout; private lateinit var info:View; private lateinit var aspect:Button
 private lateinit var pause:Button; private lateinit var stop:Button; private lateinit var audio:Button; private lateinit var subtitles:Button
 private var player:ExoPlayer?=null; private val handler=Handler(Looper.getMainLooper()); private var fillMode=false
 private val hideInfo=Runnable{info.visibility=View.GONE;aspect.visibility=View.GONE;playerView.hideController()}

 override fun onCreate(b:Bundle?){
  super.onCreate(b);setContentView(R.layout.activity_player);immersive()
  playerView=findViewById(R.id.playerView);videoBox=findViewById(R.id.videoBox);info=findViewById(R.id.info);aspect=findViewById(R.id.aspect)
  pause=findViewById(R.id.pause);stop=findViewById(R.id.stop);audio=findViewById(R.id.audio);subtitles=findViewById(R.id.subtitles)
  findViewById<TextView>(R.id.channel).text=intent.getStringExtra("name")?:"";findViewById<TextView>(R.id.epg).text=intent.getStringExtra("epg")?:""
  playerView.useController=true;playerView.controllerAutoShow=false;playerView.controllerHideOnTouch=false;playerView.resizeMode=AspectRatioFrameLayout.RESIZE_MODE_FIT
  aspect.setOnClickListener{fillMode=!fillMode;aspect.text=if(fillMode)"↔ WYPEŁNIJ" else "16:9";playerView.resizeMode=if(fillMode)AspectRatioFrameLayout.RESIZE_MODE_ZOOM else AspectRatioFrameLayout.RESIZE_MODE_FIT;showControls()}
  pause.setOnClickListener{player?.let{p->if(p.isPlaying){p.pause();pause.text="PLAY"}else{p.play();pause.text="PAUZA"}};showControls()}
  stop.setOnClickListener{player?.stop();finish()}
  audio.setOnClickListener{showTrackDialog(C.TRACK_TYPE_AUDIO,"Ścieżka audio")}
  subtitles.setOnClickListener{showTrackDialog(C.TRACK_TYPE_TEXT,"Napisy")}
  findViewById<View>(R.id.playerRoot).setOnClickListener{toggleControls()}
  startPlayer();showControls()
 }
 private fun startPlayer(){
  val url=intent.getStringExtra("url")?:return
  val p=ExoPlayer.Builder(this).build();player=p;playerView.player=p
  p.setMediaItem(MediaItem.Builder().setUri(url).build());p.prepare();p.playWhenReady=true
  p.addListener(object:Player.Listener{
   override fun onIsPlayingChanged(isPlaying:Boolean){pause.text=if(isPlaying)"PAUZA" else "PLAY"}
   override fun onPlayerError(error:PlaybackException){Toast.makeText(this@PlayerActivity,"Błąd odtwarzania: ${error.errorCodeName}",Toast.LENGTH_LONG).show()}
  })
 }
 private data class TrackChoice(val label:String,val group:Tracks.Group?,val index:Int)
 private fun showTrackDialog(type:Int,title:String){
  val p=player?:return;val choices=ArrayList<TrackChoice>()
  if(type==C.TRACK_TYPE_TEXT)choices+=TrackChoice("Wyłącz napisy",null,-1)
  for(g in p.currentTracks.groups){
   if(g.type!=type)continue
   for(i in 0 until g.length){
    if(!g.isTrackSupported(i))continue
    val f=g.getTrackFormat(i);val lang=f.language?.uppercase()?:"";val label=f.label?.takeIf{it.isNotBlank()}?:when(type){C.TRACK_TYPE_AUDIO->"Audio ${choices.size+1}";else->"Napisy ${choices.size+1}"}
    choices+=TrackChoice(if(lang.isBlank())label else "$label  [$lang]",g,i)
   }
  }
  if(choices.isEmpty()){Toast.makeText(this,"Brak dostępnych ścieżek",Toast.LENGTH_SHORT).show();return}
  AlertDialog.Builder(this).setTitle(title).setItems(choices.map{it.label}.toTypedArray()){_,which->
   val c=choices[which];val b=p.trackSelectionParameters.buildUpon().clearOverridesOfType(type)
   if(c.group==null){if(type==C.TRACK_TYPE_TEXT)b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT,true)}else{
    b.setTrackTypeDisabled(type,false);b.setOverrideForType(TrackSelectionOverride(c.group.mediaTrackGroup,listOf(c.index)))
   }
   p.trackSelectionParameters=b.build();showControls()
  }.setNegativeButton("Anuluj",null).show()
 }
 private fun showControls(){info.visibility=View.VISIBLE;aspect.visibility=View.VISIBLE;playerView.showController();handler.removeCallbacks(hideInfo);handler.postDelayed(hideInfo,5000)}
 private fun toggleControls(){if(info.visibility==View.VISIBLE){handler.removeCallbacks(hideInfo);hideInfo.run()}else showControls()}
 private fun immersive(){window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);if(Build.VERSION.SDK_INT>=30){window.setDecorFitsSystemWindows(false);window.insetsController?.let{it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars());it.systemBarsBehavior=WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE}}else{@Suppress("DEPRECATION") window.decorView.systemUiVisibility=View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE}}
 override fun onWindowFocusChanged(hasFocus:Boolean){super.onWindowFocusChanged(hasFocus);if(hasFocus)immersive()}
 override fun dispatchTouchEvent(ev:android.view.MotionEvent):Boolean{if(ev.action==android.view.MotionEvent.ACTION_UP)showControls();return super.dispatchTouchEvent(ev)}
 override fun onStop(){super.onStop();player?.pause()}
 override fun onDestroy(){handler.removeCallbacksAndMessages(null);playerView.player=null;player?.release();player=null;super.onDestroy()}
}
