package pl.tvmad.xtream

import org.json.JSONArray
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Api {
    private const val UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/125 Mobile Safari/537.36 TvMad-Xtream/0.2"

    private fun safeUrl(raw: String): String = raw
        .replace(Regex("([?&]username=)[^&]*", RegexOption.IGNORE_CASE), "$1***")
        .replace(Regex("([?&]password=)[^&]*", RegexOption.IGNORE_CASE), "$1***")
        .replace(Regex("(/live/)[^/]+/[^/]+/", RegexOption.IGNORE_CASE), "$1***/***/")

    private fun get(rawUrl: String): String {
        var current = rawUrl.trim()
        if (!current.startsWith("http://", true) && !current.startsWith("https://", true)) {
            throw IOException("Adres musi zaczynać się od http:// lub https://")
        }

        repeat(6) { hop ->
            val c = (URL(current).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                requestMethod = "GET"
                connectTimeout = 15000
                readTimeout = 30000
                useCaches = false
                setRequestProperty("User-Agent", UA)
                setRequestProperty("Accept", "*/*")
                setRequestProperty("Accept-Encoding", "identity")
                setRequestProperty("Connection", "close")
            }

            try {
                val code = c.responseCode
                if (code in 300..399) {
                    val location = c.getHeaderField("Location")
                        ?: throw IOException("HTTP $code: serwer przekierował bez adresu docelowego")
                    current = URL(URL(current), location).toString()
                    if (hop == 5) throw IOException("Za dużo przekierowań HTTP")
                    return@repeat
                }

                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()

                if (code !in 200..299) {
                    val msg = body.replace(Regex("\\s+"), " ").take(180).trim()
                    val suffix = if (msg.isNotEmpty()) ": $msg" else ""
                    throw IOException("HTTP $code ${c.responseMessage ?: ""}$suffix")
                }
                if (body.isBlank()) throw IOException("Serwer odpowiedział HTTP $code, ale zwrócił pustą odpowiedź")
                return body
            } catch (e: IOException) {
                val m = e.message.orEmpty()
                if (m.startsWith("HTTP ") || m.startsWith("Adres ") || m.startsWith("Serwer ") || m.startsWith("Za dużo")) throw e
                throw IOException("Połączenie nie powiodło się (${safeUrl(current)}): ${m.ifBlank { e.javaClass.simpleName }}", e)
            } finally {
                c.disconnect()
            }
        }
        throw IOException("Nie udało się pobrać danych")
    }

    fun xtream(host: String, user: String, pass: String): List<Channel> {
        val h = host.trim().trimEnd('/')
        if (h.contains("get.php", true)) {
            throw IOException("W Xtream wpisz tylko adres serwera, np. http://serwer:port — pełny get.php dodaj przez DODAJ M3U")
        }
        val u = URLEncoder.encode(user.trim(), "UTF-8")
        val p = URLEncoder.encode(pass.trim(), "UTF-8")
        val cats = JSONArray(get("$h/player_api.php?username=$u&password=$p&action=get_live_categories"))
        val names = mutableMapOf<String, String>()
        for (i in 0 until cats.length()) {
            val o = cats.getJSONObject(i)
            names[o.optString("category_id")] = o.optString("category_name")
        }
        val a = JSONArray(get("$h/player_api.php?username=$u&password=$p&action=get_live_streams"))
        val out = ArrayList<Channel>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val id = o.optString("stream_id")
            out += Channel(
                NameCleaner.clean(o.optString("name")),
                "$h/live/${user.trim()}/${pass.trim()}/$id.ts",
                names[o.optString("category_id")] ?: "",
                o.optString("stream_icon"),
                o.optString("epg_channel_id")
            )
        }
        return out
    }

    fun m3u(url: String): List<Channel> {
        val body = get(url)
        if (body.trimStart().startsWith("<html", true) || body.trimStart().startsWith("<!doctype", true)) {
            throw IOException("Serwer zwrócił stronę HTML zamiast listy M3U")
        }
        val lines = body.lines()
        val out = ArrayList<Channel>()
        var meta = ""
        for (x in lines) {
            val l = x.trim()
            if (l.startsWith("#EXTINF", true)) {
                meta = l
            } else if (l.isNotEmpty() && !l.startsWith("#") && meta.isNotEmpty()) {
                val name = meta.substringAfterLast(',')
                val group = Regex("group-title=\\\"([^\\\"]*)\\\"").find(meta)?.groupValues?.get(1) ?: ""
                val logo = Regex("tvg-logo=\\\"([^\\\"]*)\\\"").find(meta)?.groupValues?.get(1) ?: ""
                val epg = Regex("tvg-id=\\\"([^\\\"]*)\\\"").find(meta)?.groupValues?.get(1) ?: ""
                out += Channel(NameCleaner.clean(name), l, group, logo, epg)
                meta = ""
            }
        }
        if (out.isEmpty()) {
            val start = body.replace(Regex("\\s+"), " ").take(160)
            throw IOException("Lista została pobrana, ale nie znaleziono kanałów M3U. Początek odpowiedzi: $start")
        }
        return out
    }
}
