package pl.tvmad.xtream

import org.json.JSONArray
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder

object Api {
    private const val UA = "Mozilla/5.0 TvMadProE2"

    private fun safeUrl(raw: String): String = raw
        .replace(Regex("([?&]username=)[^&]*", RegexOption.IGNORE_CASE), "$1***")
        .replace(Regex("([?&]password=)[^&]*", RegexOption.IGNORE_CASE), "$1***")
        .replace(Regex("(/live/)[^/]+/[^/]+/", RegexOption.IGNORE_CASE), "$1***/***/")

    private fun get(rawUrl: String): String {
        var current = rawUrl.trim()
        if (!current.startsWith("http://", true) && !current.startsWith("https://", true)) throw IOException("Adres musi zaczynać się od http:// lub https://")
        repeat(6) { hop ->
            val c = (URL(current).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false; requestMethod = "GET"; connectTimeout = 15000; readTimeout = 45000; useCaches = false
                setRequestProperty("User-Agent", UA); setRequestProperty("Accept", "*/*"); setRequestProperty("Accept-Encoding", "identity"); setRequestProperty("Connection", "close")
            }
            try {
                val code = c.responseCode
                if (code in 300..399) {
                    val location = c.getHeaderField("Location") ?: throw IOException("HTTP $code: przekierowanie bez adresu")
                    current = URL(URL(current), location).toString()
                    if (hop == 5) throw IOException("Za dużo przekierowań HTTP")
                    return@repeat
                }
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (code !in 200..299) {
                    val msg = body.replace(Regex("\\s+"), " ").take(160).trim()
                    throw IOException("HTTP $code${if (msg.isNotEmpty()) ": $msg" else ""}")
                }
                if (body.isBlank()) throw IOException("Serwer zwrócił pustą odpowiedź")
                return body
            } catch (e: IOException) {
                val m = e.message.orEmpty()
                if (m.startsWith("HTTP ") || m.startsWith("Serwer ") || m.startsWith("Za dużo")) throw e
                throw IOException("Połączenie nie powiodło się (${safeUrl(current)}): ${m.ifBlank { e.javaClass.simpleName }}", e)
            } finally { c.disconnect() }
        }
        throw IOException("Nie udało się pobrać danych")
    }

    private fun enc(s:String)=URLEncoder.encode(s.trim(), "UTF-8")

    fun xtream(host: String, user: String, pass: String): List<Channel> {
        val h = host.trim().trimEnd('/')
        if (h.contains("get.php", true)) throw IOException("W Xtream wpisz tylko adres serwera")
        val u = enc(user); val p = enc(pass)
        val cats = JSONArray(get("$h/player_api.php?username=$u&password=$p&action=get_live_categories"))
        val names = mutableMapOf<String, String>()
        for (i in 0 until cats.length()) { val o=cats.getJSONObject(i); names[o.optString("category_id")]=NameCleaner.clean(o.optString("category_name")) }
        val a = JSONArray(get("$h/player_api.php?username=$u&password=$p&action=get_live_streams"))
        val out=ArrayList<Channel>()
        for(i in 0 until a.length()){
            val o=a.getJSONObject(i); val id=o.optString("stream_id"); if(id.isBlank()) continue
            out += Channel(NameCleaner.clean(o.optString("name")), "$h/live/${user.trim()}/${pass.trim()}/$id.ts", names[o.optString("category_id")] ?: "Other", o.optString("stream_icon"), o.optString("epg_channel_id"))
        }
        return out
    }

    private fun attr(meta:String, key:String):String {
        val quoted = Regex("(?:^|\\s)${Regex.escape(key)}\\s*=\\s*\"([^\"]*)\"", RegexOption.IGNORE_CASE).find(meta)?.groupValues?.get(1)
        if (quoted != null) return quoted
        return Regex("(?:^|\\s)${Regex.escape(key)}\\s*=\\s*([^\\s,]+)", RegexOption.IGNORE_CASE).find(meta)?.groupValues?.get(1) ?: ""
    }

    private fun parseM3u(body:String):List<Channel> {
        if (body.trimStart().startsWith("<html", true) || body.trimStart().startsWith("<!doctype", true)) throw IOException("Serwer zwrócił HTML zamiast M3U")
        val out=ArrayList<Channel>(); var meta=""; var extGroup=""
        body.lineSequence().forEach { raw ->
            val l=raw.trim()
            when {
                l.startsWith("#EXTGRP:", true) -> extGroup=l.substringAfter(':').trim()
                l.startsWith("#EXTINF:", true) -> meta=l
                l.isNotEmpty() && !l.startsWith("#") && meta.isNotEmpty() -> {
                    var inQuotes=false; var comma=-1
                    meta.forEachIndexed { i,ch -> if(ch=='\"') inQuotes=!inQuotes else if(ch==',' && !inQuotes && comma<0) comma=i }
                    val name=if(comma>=0) meta.substring(comma+1).trim() else "Kanał ${out.size+1}"
                    val group=(attr(meta,"group-title").ifBlank{attr(meta,"tvg-group")}.ifBlank{attr(meta,"group")}.ifBlank{extGroup}).ifBlank{"Other"}
                    out += Channel(NameCleaner.clean(name), l, NameCleaner.clean(group), attr(meta,"tvg-logo"), attr(meta,"tvg-id"))
                    meta=""; extGroup=""
                }
            }
        }
        return out
    }

    private data class XcFromM3u(val host:String,val user:String,val pass:String)
    private fun xtreamFromM3uUrl(raw:String):XcFromM3u? = try {
        val u=URL(raw); if(!u.path.endsWith("get.php", true)) return null
        val q=u.query.orEmpty().split('&').mapNotNull { p -> val x=p.split('=',limit=2); if(x.size==2) x[0].lowercase() to URLDecoder.decode(x[1],"UTF-8") else null }.toMap()
        val user=q["username"].orEmpty(); val pass=q["password"].orEmpty(); if(user.isBlank()||pass.isBlank()) null else XcFromM3u("${u.protocol}://${u.authority}",user,pass)
    } catch (_:Exception){ null }

    fun m3u(url:String):List<Channel> {
        var directError:Exception?=null
        try {
            val parsed=parseM3u(get(url))
            if(parsed.isNotEmpty()) return parsed
            directError=IOException("Lista M3U nie zawiera kanałów")
        } catch(e:Exception){ directError=e }
        val xc=xtreamFromM3uUrl(url)
        if(xc!=null) {
            try { return xtream(xc.host,xc.user,xc.pass) } catch(e:Exception) {
                throw IOException("M3U: ${directError?.message}; fallback Xtream: ${e.message}")
            }
        }
        throw IOException(directError?.message ?: "Nie udało się wczytać M3U")
    }
}
