package pl.tvmad.xtream

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Api {
    private const val UA = "Mozilla/5.0 TvMadProE2"

    private fun safeUrl(raw: String): String = raw
        .replace(Regex("([?&]username=)[^&]*", RegexOption.IGNORE_CASE), "$1***")
        .replace(Regex("([?&]password=)[^&]*", RegexOption.IGNORE_CASE), "$1***")
        .replace(Regex("(/(?:live|movie|series)/)[^/]+/[^/]+/", RegexOption.IGNORE_CASE), "$1***/***/")

    private fun get(rawUrl: String): String {
        var current = rawUrl.trim()
        if (!current.startsWith("http://", true) && !current.startsWith("https://", true)) throw IOException("Adres musi zaczynać się od http:// lub https://")
        repeat(6) { hop ->
            val c = (URL(current).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false; requestMethod = "GET"; connectTimeout = 15000; readTimeout = 45000; useCaches = false
                setRequestProperty("User-Agent", UA); setRequestProperty("Accept", "*/*"); setRequestProperty("Accept-Encoding", "identity"); setRequestProperty("Connection", "close")
            }
            try {
                val code = c.responseCode
                if (code in 300..399) {
                    val location = c.getHeaderField("Location") ?: throw IOException("HTTP $code: przekierowanie bez adresu")
                    current = URL(URL(current), location).toString()
                    if (hop == 5) throw IOException("Za dużo przekierowań HTTP")
                    return@repeat
                }
                val stream = if (code in 200..299) c.inputStream else c.errorStream
                val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                if (code !in 200..299) {
                    val msg = body.replace(Regex("\\s+"), " ").take(160).trim()
                    throw IOException("HTTP $code${if (msg.isNotEmpty()) ": $msg" else ""}")
                }
                if (body.isBlank()) throw IOException("Serwer zwrócił pustą odpowiedź")
                return body
            } catch (e: IOException) {
                val m = e.message.orEmpty()
                if (m.startsWith("HTTP ") || m.startsWith("Serwer ") || m.startsWith("Za dużo")) throw e
                throw IOException("Połączenie nie powiodło się (${safeUrl(current)}): ${m.ifBlank { e.javaClass.simpleName }}", e)
            } finally { c.disconnect() }
        }
        throw IOException("Nie udało się pobrać danych")
    }

    private fun enc(s:String)=URLEncoder.encode(s.trim(), "UTF-8")
    private fun host(h:String)=h.trim().trimEnd('/')
    private fun apiUrl(x:Xc,action:String,extra:String=""):String = "${x.host}/player_api.php?username=${enc(x.user)}&password=${enc(x.pass)}&action=$action$extra"

    data class Xc(val host:String,val user:String,val pass:String)

    fun xtreamParams(src:Source):Xc? {
        if(src.type=="xtream" && src.host.isNotBlank() && src.user.isNotBlank() && src.pass.isNotBlank()) return Xc(host(src.host),src.user.trim(),src.pass.trim())
        if(src.type=="m3u") return xtreamFromM3uUrl(src.url)
        return null
    }

    fun xtream(host: String, user: String, pass: String): List<Channel> {
        val x=Xc(host(host),user.trim(),pass.trim())
        if (x.host.contains("get.php", true)) throw IOException("W Xtream wpisz tylko adres serwera")
        val cats = JSONArray(get(apiUrl(x,"get_live_categories")))
        val names = mutableMapOf<String, String>()
        for (i in 0 until cats.length()) { val o=cats.getJSONObject(i); names[o.optString("category_id")]=NameCleaner.clean(o.optString("category_name")) }
        val a = JSONArray(get(apiUrl(x,"get_live_streams")))
        val out=ArrayList<Channel>()
        for(i in 0 until a.length()){
            val o=a.getJSONObject(i); val id=o.optString("stream_id"); if(id.isBlank()) continue
            out += Channel(NameCleaner.clean(o.optString("name")), "${x.host}/live/${x.user}/${x.pass}/$id.ts", names[o.optString("category_id")] ?: "Other", o.optString("stream_icon"), o.optString("epg_channel_id"), id)
        }
        return out
    }

    private fun attr(meta:String, key:String):String {
        val quoted = Regex("(?:^|\\s)${Regex.escape(key)}\\s*=\\s*\"([^\"]*)\"", RegexOption.IGNORE_CASE).find(meta)?.groupValues?.get(1)
        if (quoted != null) return quoted
        return Regex("(?:^|\\s)${Regex.escape(key)}\\s*=\\s*([^\\s,]+)", RegexOption.IGNORE_CASE).find(meta)?.groupValues?.get(1) ?: ""
    }

    private fun streamIdFromUrl(url:String):String {
        return Regex("/(?:live/[^/]+/[^/]+/)?(\\d+)(?:\\.[A-Za-z0-9]+)?(?:\\?.*)?$",RegexOption.IGNORE_CASE).find(url)?.groupValues?.get(1).orEmpty()
    }

    private fun parseM3u(body:String):List<Channel> {
        if (body.trimStart().startsWith("<html", true) || body.trimStart().startsWith("<!doctype", true)) throw IOException("Serwer zwrócił HTML zamiast M3U")
        val out=ArrayList<Channel>(); var meta=""; var extGroup=""
        body.lineSequence().forEach { raw ->
            val l=raw.trim()
            when {
                l.startsWith("#EXTGRP:", true) -> extGroup=l.substringAfter(':').trim()
                l.startsWith("#EXTINF:", true) -> meta=l
                l.isNotEmpty() && !l.startsWith("#") && meta.isNotEmpty() -> {
                    var inQuotes=false; var comma=-1
                    meta.forEachIndexed { i,ch -> if(ch=='\"') inQuotes=!inQuotes else if(ch==',' && !inQuotes && comma<0) comma=i }
                    val name=if(comma>=0) meta.substring(comma+1).trim() else "Kanał ${out.size+1}"
                    val group=(attr(meta,"group-title").ifBlank{attr(meta,"tvg-group")}.ifBlank{attr(meta,"group")}.ifBlank{extGroup}).ifBlank{"Other"}
                    out += Channel(NameCleaner.clean(name), l, NameCleaner.clean(group), attr(meta,"tvg-logo"), attr(meta,"tvg-id"), streamIdFromUrl(l))
                    meta=""; extGroup=""
                }
            }
        }
        return out
    }

    private fun xtreamFromM3uUrl(raw:String):Xc? {
        return try {
            val u = URL(raw)
            if (!u.path.endsWith("get.php", true)) null else {
                val q = u.query.orEmpty().split('&').mapNotNull { p ->
                    val z=p.split('=',limit=2); if(z.size==2) z[0].lowercase() to URLDecoder.decode(z[1],"UTF-8") else null
                }.toMap()
                val user=q["username"].orEmpty(); val pass=q["password"].orEmpty()
                if(user.isBlank()||pass.isBlank()) null else Xc("${u.protocol}://${u.authority}",user,pass)
            }
        }catch(_:Exception){null}
    }

    fun m3u(url:String):List<Channel> {
        var directError:Exception?=null
        try {
            val parsed=parseM3u(get(url))
            if(parsed.isNotEmpty()) return parsed
            directError=IOException("Lista M3U nie zawiera kanałów")
        } catch(e:Exception){ directError=e }
        val xc=xtreamFromM3uUrl(url)
        if(xc!=null) {
            try { return xtream(xc.host,xc.user,xc.pass) } catch(e:Exception) {
                throw IOException("M3U: ${directError?.message}; fallback Xtream: ${e.message}")
            }
        }
        throw IOException(directError?.message ?: "Nie udało się wczytać M3U")
    }

    private fun maybeBase64(s:String):String {
        if(s.isBlank()) return ""
        return try{
            val d=String(Base64.decode(s,Base64.DEFAULT),Charsets.UTF_8)
            if(d.any{it.isLetterOrDigit()} && !d.contains('\u0000')) d else s
        }catch(_:Exception){s}
    }

    // Provider EPG needs the same -1 h correction as TvMad on Enigma2.
    // On Android we additionally convert the Polish EPG wall-clock to the phone timezone.
    // This keeps displayed times and progress correct in UK, Poland and when the phone timezone changes.
    private const val EPG_SHIFT_MS = -60L * 60L * 1000L

    private fun epgPhoneTime(ms:Long):Long {
        if(ms<=0L) return 0L
        val base=ms+EPG_SHIFT_MS
        val phoneOffset=java.util.TimeZone.getDefault().getOffset(base).toLong()
        val polishOffset=java.util.TimeZone.getTimeZone("Europe/Warsaw").getOffset(base).toLong()
        return base+(phoneOffset-polishOffset)
    }

    private fun epochRaw(v:Any?):Long {
        val raw=v?.toString().orEmpty().trim(); if(raw.isBlank()) return 0L
        val n=raw.toLongOrNull()
        if(n!=null){
            val ms=if(n>100000000000L)n else if(n>1000000000L)n*1000L else 0L
            if(ms>0L)return epgPhoneTime(ms)
        }
        val formats=arrayOf("yyyy-MM-dd HH:mm:ss","yyyy-MM-dd HH:mm","yyyy-MM-dd'T'HH:mm:ss")
        for(f in formats){
            try{
                val df=SimpleDateFormat(f,Locale.US).apply{isLenient=false}
                val d=df.parse(raw)?:continue
                return epgPhoneTime(d.time)
            }catch(_:Exception){}
        }
        return 0L
    }

    private fun fmtEpoch(ms:Long):String = if(ms>0L) SimpleDateFormat("HH:mm",Locale.getDefault()).format(Date(ms)) else ""

    fun epgNowNext(src:Source,ch:Channel):List<EpgEvent> {
        val x=xtreamParams(src)?:return emptyList()
        val sid=ch.streamId.ifBlank{streamIdFromUrl(ch.url)}
        if(sid.isBlank()) return emptyList()
        return try{
            val root=JSONObject(get(apiUrl(x,"get_short_epg","&stream_id=${enc(sid)}&limit=10")))
            val a=root.optJSONArray("epg_listings")?:root.optJSONArray("listings")?:JSONArray()
            val all=ArrayList<EpgEvent>()
            for(i in 0 until a.length()){
                val o=a.getJSONObject(i)
                val title=maybeBase64(o.optString("title").ifBlank{o.optString("name")})
                if(title.isBlank())continue
                val sv=o.opt("start_timestamp")?:o.opt("start")
                val ev=o.opt("stop_timestamp")?:o.opt("end")?:o.opt("stop")
                val se=epochRaw(sv);val ee=epochRaw(ev)
                all+=EpgEvent(title,fmtEpoch(se),fmtEpoch(ee),se,ee)
            }
            val timed=all.filter{it.startEpoch>0L&&it.endEpoch>it.startEpoch}.sortedBy{it.startEpoch}
            if(timed.isEmpty()) return all.take(2)
            val now=System.currentTimeMillis()
            val currentIndex=timed.indexOfFirst{now>=it.startEpoch&&now<it.endEpoch}
            when{
                currentIndex>=0 -> timed.drop(currentIndex).take(2)
                else -> {
                    val nextIndex=timed.indexOfFirst{it.startEpoch>now}
                    if(nextIndex>=0)timed.drop(nextIndex).take(2) else timed.takeLast(2)
                }
            }
        }catch(_:Exception){emptyList()}
    }

    fun epgNow(src:Source,ch:Channel):EpgEvent? = epgNowNext(src,ch).firstOrNull()

    fun vodCategories(src:Source):List<MediaCategory>{
        val x=xtreamParams(src)?:throw IOException("To źródło nie udostępnia API filmów")
        val a=JSONArray(get(apiUrl(x,"get_vod_categories")))
        return List(a.length()){i->val o=a.getJSONObject(i);MediaCategory(o.optString("category_id"),NameCleaner.clean(o.optString("category_name").ifBlank{"Filmy"}))}
    }

    fun vodItems(src:Source,categoryId:String):List<MediaItem>{
        val x=xtreamParams(src)?:throw IOException("To źródło nie udostępnia API filmów")
        val a=JSONArray(get(apiUrl(x,"get_vod_streams","&category_id=${enc(categoryId)}")))
        val out=ArrayList<MediaItem>()
        for(i in 0 until a.length()){
            val o=a.getJSONObject(i);val id=o.optString("stream_id");if(id.isBlank())continue
            val ext=o.optString("container_extension").ifBlank{"mp4"}
            out+=MediaItem(id,NameCleaner.clean(o.optString("name").ifBlank{"Film"}),o.optString("category_id"),o.optString("stream_icon"),ext,"${x.host}/movie/${x.user}/${x.pass}/$id.$ext")
        }
        return out
    }

    fun seriesCategories(src:Source):List<MediaCategory>{
        val x=xtreamParams(src)?:throw IOException("To źródło nie udostępnia API seriali")
        val a=JSONArray(get(apiUrl(x,"get_series_categories")))
        return List(a.length()){i->val o=a.getJSONObject(i);MediaCategory(o.optString("category_id"),NameCleaner.clean(o.optString("category_name").ifBlank{"Seriale"}))}
    }

    fun seriesItems(src:Source,categoryId:String):List<SeriesItem>{
        val x=xtreamParams(src)?:throw IOException("To źródło nie udostępnia API seriali")
        val a=JSONArray(get(apiUrl(x,"get_series","&category_id=${enc(categoryId)}")))
        val out=ArrayList<SeriesItem>()
        for(i in 0 until a.length()){
            val o=a.getJSONObject(i);val id=o.optString("series_id").ifBlank{o.optString("id")};if(id.isBlank())continue
            out+=SeriesItem(id,NameCleaner.clean(o.optString("name").ifBlank{"Serial"}),o.optString("category_id"),o.optString("cover"))
        }
        return out
    }

    fun seasons(src:Source,seriesId:String):Pair<List<SeasonItem>,Map<String,List<EpisodeItem>>>{
        val x=xtreamParams(src)?:throw IOException("To źródło nie udostępnia API seriali")
        val root=JSONObject(get(apiUrl(x,"get_series_info","&series_id=${enc(seriesId)}")))
        val episodes=root.optJSONObject("episodes")?:JSONObject()
        val map=linkedMapOf<String,List<EpisodeItem>>()
        val keys=episodes.keys().asSequence().toList().sortedWith(compareBy<String>{it.toIntOrNull()?:Int.MAX_VALUE}.thenBy{it})
        keys.forEach{season->
            val a=episodes.optJSONArray(season)?:JSONArray();val list=ArrayList<EpisodeItem>()
            for(i in 0 until a.length()){
                val o=a.optJSONObject(i)?:continue;val id=o.optString("id").ifBlank{o.optString("episode_id")}.ifBlank{o.optString("stream_id")};if(id.isBlank())continue
                val num=o.optString("episode_num").ifBlank{(i+1).toString()};val title=NameCleaner.clean(o.optString("title").ifBlank{o.optString("name")}.ifBlank{"Odcinek $num"})
                list+=EpisodeItem(id,"E${num.padStart(2,'0')} - $title",o.optString("container_extension").ifBlank{"mp4"},season)
            }
            map[season]=list
        }
        return keys.map{SeasonItem(it,"Sezon $it (${map[it]?.size?:0})")} to map
    }

    fun episodeUrl(src:Source,ep:EpisodeItem):String{
        val x=xtreamParams(src)?:throw IOException("Brak danych Xtream")
        return "${x.host}/series/${x.user}/${x.pass}/${ep.id}.${ep.ext.ifBlank{"mp4"}}"
    }
}
