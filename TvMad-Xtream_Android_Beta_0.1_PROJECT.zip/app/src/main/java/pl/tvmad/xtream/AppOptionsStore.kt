package pl.tvmad.xtream

import android.content.Context

object AppOptionsStore {
    private const val PREF = "tvmad_app_options"
    fun externalPlayerPackage(c:Context)=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("externalPlayerPackage","").orEmpty()
    fun setExternalPlayerPackage(c:Context,v:String)=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString("externalPlayerPackage",v).apply()
    fun storagePath(c:Context)=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("storagePath","").orEmpty()
    fun setStoragePath(c:Context,v:String)=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString("storagePath",v).apply()
    fun language(c:Context)=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("language","pl").orEmpty()
    fun background(c:Context)=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString("background","navy").orEmpty()
    fun setBackground(c:Context,v:String)=c.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString("background",v).apply()
}
