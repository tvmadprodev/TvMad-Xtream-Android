package pl.tvmad.xtream

import android.content.Context
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaItem
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

/** One live-TV ExoPlayer shared between MiniTV and fullscreen. */
object LivePlayerSession {
    private var player: ExoPlayer? = null
    private var currentUrl: String = ""
    private var currentAuth: String = ""
    private var targetView: PlayerView? = null

    private fun createPlayer(context: Context, authHeader: String): ExoPlayer {
        val renderers = DefaultRenderersFactory(context.applicationContext)
            .setEnableDecoderFallback(true)
            .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
        val loadControl = DefaultLoadControl.Builder()
            .setBufferDurationsMs(700, 5000, 120, 350)
            .setPrioritizeTimeOverSizeThresholds(true)
            .build()
        val http = DefaultHttpDataSource.Factory()
            .setAllowCrossProtocolRedirects(true)
            .setConnectTimeoutMs(20000)
            .setReadTimeoutMs(60000)
            .setUserAgent("TvMad-Xtream Android")
        if (authHeader.isNotBlank()) http.setDefaultRequestProperties(mapOf("Authorization" to authHeader))
        val mediaSources = DefaultMediaSourceFactory(http)
        return ExoPlayer.Builder(context.applicationContext, renderers)
            .setMediaSourceFactory(mediaSources)
            .setLoadControl(loadControl)
            .build().also { it.setAudioAttributes(AudioAttributes.DEFAULT, true) }
    }

    @Synchronized
    fun ensure(context: Context, url: String, authHeader: String = ""): ExoPlayer {
        var p = player
        if (p == null || currentAuth != authHeader) {
            val oldView = targetView
            try { oldView?.player = null } catch (_: Exception) {}
            try { p?.release() } catch (_: Exception) {}
            p = createPlayer(context, authHeader)
            player = p
            currentUrl = ""
            currentAuth = authHeader
            if (oldView != null) oldView.player = p
        }
        if (currentUrl != url) {
            // IPTV streams can change codec/profile/resolution between channels.
            // Stop the old item cleanly before attaching the next one so MediaCodec
            // is not asked to replace an active stream on the same surface mid-frame.
            p.stop()
            p.clearMediaItems()
            currentUrl = url
            p.setMediaItem(MediaItem.fromUri(url))
            p.prepare()
            p.playWhenReady = true
        } else if (!p.playWhenReady) {
            p.playWhenReady = true
        }
        return p
    }

    @Synchronized
    fun attach(view: PlayerView, context: Context, url: String, authHeader: String = ""): ExoPlayer {
        val p = ensure(context, url, authHeader)
        val old = targetView
        if (old !== view) {
            PlayerView.switchTargetView(p, old, view)
            targetView = view
        } else if (view.player !== p) {
            view.player = p
        }
        return p
    }

    @Synchronized
    fun detach(view: PlayerView) {
        if (targetView === view) {
            PlayerView.switchTargetView(player ?: return, view, null)
            targetView = null
        }
    }

    @Synchronized
    fun restartCurrent() {
        val p=player?:return
        val url=currentUrl
        if(url.isBlank())return
        p.stop();p.clearMediaItems();p.setMediaItem(MediaItem.fromUri(url));p.prepare();p.playWhenReady=true
    }

    fun currentUrl(): String = currentUrl

    @Synchronized
    fun release() {
        try { targetView?.player = null } catch (_: Exception) {}
        targetView = null
        try { player?.release() } catch (_: Exception) {}
        player = null
        currentUrl = ""
        currentAuth = ""
    }
}
