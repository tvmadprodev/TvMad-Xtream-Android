package pl.tvmad.xtream

import android.content.Context
import android.util.Log
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

/**
 * Jeden odtwarzacz LIVE współdzielony przez MiniTV i tryb pełnoekranowy.
 *
 * Zasady, na których stoi ta klasa:
 *  * player i jego Surface żyją przez całą sesję LIVE — MiniTV i fullscreen to tylko inne
 *    położenie tej samej powierzchni, więc przejście między nimi nie dotyka dekodera,
 *  * zmiana kanału z działającego (READY) odtwarzania NIE przechodzi przez [ExoPlayer.stop].
 *    `stop()` gasił player do stanu IDLE i wymuszał pełne zwolnienie MediaCodeca, po czym
 *    `prepare()` budował wszystko od zera. To był stały, niepotrzebny koszt przy każdym
 *    przełączeniu kanału. `setMediaItem(item, true)` + `prepare()` robi to samo o jeden pełny
 *    teardown taniej i pozwala media3 zdecydować, czy dekoder da się utrzymać,
 *  * jeżeli poprzedni kanał NIE doszedł do READY, FAST PATH zostawia player w zamaskowanym
 *    BUFFERING, a `prepare()` jest no-opem — wtedy schodzimy do IDLE, żeby nowy materiał
 *    naprawdę wystartował. Twardy reset ([restartCurrent]) i odbudowa ([rebuild]) zostają
 *    dla ścieżki odzyskiwania, gdy i to nie wystarczy.
 *
 * Czego ta ścieżka NIE gwarantuje — i dlaczego są tu metody diagnostyczne oraz [retryPrepare]:
 * `ExoPlayerImpl.prepare()` jest w media3 no-opem, gdy raportowany stan playera jest inny niż
 * `STATE_IDLE`, a `setMediaItem(..., true)` na działającym playerze od razu maskuje stan na
 * `STATE_BUFFERING`. W normalnym przebiegu to nie szkodzi, bo nowe źródło startuje wewnętrzną
 * wiadomością. Ale jeżeli wątek odtwarzania wejdzie w IDLE tuż obok zappingu (spóźniony błąd
 * porzuconego przed chwilą strumienia), albo player zostanie w zamaskowanym BUFFERING bez
 * realnego I/O, nowy MediaItem zostaje w playliście NIGDY nieprzygotowany i żaden kolejny
 * `prepare()` już się nie wykona. Dlatego:
 *  * zap z kanału, który doszedł do READY, idzie FAST PATH (bez stop),
 *  * zap z kanału, który NIE doszedł do READY, schodzi do IDLE i dopiero wtedy prepare(),
 *  * warstwa wyżej ma watchdog na wypadek, gdyby FAST PATH i tak nie wystartował.
 */
@UnstableApi
object LivePlayerSession {
    private const val TAG = "TvMadLive"

    private var player: ExoPlayer? = null
    private var currentUrl: String = ""
    private var currentAuth: String = ""
    private var targetView: PlayerView? = null
    private val diagnostics = PlaybackDiagnostics("LIVE")

    private fun createPlayer(context: Context, authHeader: String): ExoPlayer {
        val mediaSources = DefaultMediaSourceFactory(PlayerEngine.liveHttpFactory(authHeader))
        return ExoPlayer.Builder(context.applicationContext, PlayerEngine.liveRenderers(context))
            .setMediaSourceFactory(mediaSources)
            .setLoadControl(PlayerEngine.liveLoadControl())
            // Domyślne 500 ms bywa za krótkie, gdy MediaCodec na boxie TV wisi na stop().
            // Dotyczy wyłącznie release() podczas odzyskiwania — nie kosztuje nic podczas oglądania.
            .setReleaseTimeoutMs(2_000)
            .build()
            .also {
                it.setAudioAttributes(AudioAttributes.DEFAULT, true)
                it.addAnalyticsListener(diagnostics)
            }
    }

    @Synchronized
    fun ensure(context: Context, url: String, authHeader: String = ""): ExoPlayer {
        var p = player
        if (p == null || currentAuth != authHeader) {
            val oldView = targetView
            try { oldView?.player = null } catch (_: Exception) {}
            try { p?.removeAnalyticsListener(diagnostics) } catch (_: Exception) {}
            try { p?.release() } catch (_: Exception) {}
            p = createPlayer(context, authHeader)
            player = p
            currentUrl = ""
            currentAuth = authHeader
            if (oldView != null) oldView.player = p
        }
        if (currentUrl != url) {
            // FAST PATH tylko gdy poprzedni kanał realnie doszedł do READY: pipeline jest żywy,
            // setMediaItem wystarcza i prepare() może zostać no-opem (player nie jest IDLE).
            // W każdym innym przypadku (nieudany zap, IDLE, błąd, zamaskowane BUFFERING bez
            // READY) prepare() na działającym playerze NIC nie robi, a kolejny kanał dziedziczy
            // martwy stan. Wtedy schodzimy do IDLE, żeby prepare() naprawdę wystartował I/O.
            val hard = needsHardReset(p)
            diagnostics.resetCounters()
            startItem(p, url, if (hard) "zap-hard" else "zap", hard)
            currentUrl = url
        } else if (needsHardReset(p)) {
            diagnostics.resetCounters()
            startItem(p, url, "same-url-hard", hard = true)
        } else if (!p.playWhenReady) {
            p.playWhenReady = true
        }
        return p
    }

    /**
     * Twardy reset jest potrzebny, gdy `ExoPlayer.prepare()` byłby no-opem, a nowe źródło
     * i tak by nie wystartowało. media3 1.3.1: `prepare()` wraca natychmiast, gdy stan != IDLE;
     * `setMediaItem` na nie-IDLE tylko maskuje stan na BUFFERING.
     */
    private fun needsHardReset(p: ExoPlayer): Boolean {
        if (p.playerError != null) return true
        val s = p.playbackState
        if (s == Player.STATE_IDLE || s == Player.STATE_ENDED) return true
        // Poprzedni materiał nigdy nie doszedł do READY: player może tkwić w zamaskowanym
        // BUFFERING, z którego kolejny setMediaItem nic nie uruchomi.
        return currentUrl.isNotBlank() && !diagnostics.sawReady()
    }

    /** Ustawia materiał i od razu raportuje, w jakim stanie player faktycznie wylądował. */
    private fun startItem(p: ExoPlayer, url: String, reason: String, hard: Boolean) {
        if (hard) {
            Log.w(TAG, "hard reset before setMediaItem reason=$reason ${stateLabelUnlocked(p)}")
            try { p.stop() } catch (_: Exception) {}
            try { p.clearMediaItems() } catch (_: Exception) {}
        }
        val before = stateName(p.playbackState)
        p.setMediaItem(MediaItem.fromUri(url), true)
        p.playWhenReady = true
        val afterSet = p.playbackState
        p.prepare()
        var afterPrepare = p.playbackState
        // setMediaItem na IDLE zostawia IDLE — prepare() musi ruszyć. Jeżeli po prepare nadal
        // stoimy w IDLE (np. puste źródło po błędzie), jedna dodatkowa próba nic nie kosztuje.
        if (afterPrepare == Player.STATE_IDLE) {
            p.playWhenReady = true
            p.prepare()
            afterPrepare = p.playbackState
        }
        Log.i(
            TAG,
            "setMediaItem reason=$reason hard=$hard state: $before -> ${stateName(afterSet)} -> ${stateName(afterPrepare)}" +
                " prepareRan=${afterSet == Player.STATE_IDLE}"
        )
    }

    private fun stateLabelUnlocked(p: ExoPlayer): String =
        "${stateName(p.playbackState)}/pwr=${p.playWhenReady}/playing=${p.isPlaying}" +
            "/buffered=${p.totalBufferedDuration}ms/items=${p.mediaItemCount}" +
            "/err=${p.playerError?.errorCodeName ?: "-"}"

    @Synchronized
    fun attach(view: PlayerView, context: Context, url: String, authHeader: String = ""): ExoPlayer {
        val p = ensure(context, url, authHeader)
        val old = targetView
        if (old !== view) {
            PlayerView.switchTargetView(p, old, view)
            targetView = view
        } else if (view.player !== p) {
            view.player = p
        }
        return p
    }

    @Synchronized
    fun detach(view: PlayerView) {
        if (targetView === view) {
            PlayerView.switchTargetView(player ?: return, view, null)
            targetView = null
        }
    }

    /** PlayerView, na którym ma żyć obraz LIVE. Ustawiane raz, przeżywa odbudowę playera. */
    @Synchronized
    fun bindView(view: PlayerView) {
        targetView = view
    }

    // ----------------------------------------------------------------------------------------
    // Diagnostyka stanu — używana przez watchdog zappingu w MainActivity.
    // ----------------------------------------------------------------------------------------

    fun currentUrl(): String = currentUrl

    /** Jednolinijkowy zrzut stanu do logów zappingu. Wywoływany tylko przy zmianie kanału i awarii. */
    @Synchronized
    fun stateLabel(): String {
        val p = player ?: return "NO_PLAYER"
        return "${stateName(p.playbackState)}/pwr=${p.playWhenReady}/playing=${p.isPlaying}" +
            "/buffered=${p.totalBufferedDuration}ms/items=${p.mediaItemCount}" +
            "/err=${p.playerError?.errorCodeName ?: "-"}"
    }

    /** true, gdy player nie ma żadnej szansy sam ruszyć: brak playera, IDLE, ENDED albo błąd. */
    @Synchronized
    fun isStalled(): Boolean = isStalledInternal(player)

    /** Bieżący materiał realnie wystartował (READY albo isPlaying). */
    @Synchronized
    fun itemHasStarted(): Boolean {
        val p = player ?: return false
        return diagnostics.sawReady() || p.isPlaying
    }

    /** Bieżący materiał rozpoczął I/O. Zamaskowane BUFFERING po setMediaItem tego nie ustawia. */
    fun itemSawLoad(): Boolean = diagnostics.sawLoad()

    private fun isStalledInternal(p: ExoPlayer?): Boolean {
        if (p == null) return true
        if (p.playerError != null) return true
        val s = p.playbackState
        return s == Player.STATE_IDLE || s == Player.STATE_ENDED
    }

    // ----------------------------------------------------------------------------------------
    // Ścieżki odzyskiwania. Kolejno od najtańszej do najdroższej.
    // ----------------------------------------------------------------------------------------

    /**
     * Poziom 1 — najtańszy. Wyłącznie ponowne `prepare()` bieżącego materiału.
     *
     * Celuje dokładnie w przypadek opisany w dokumentacji klasy: playlista ma już właściwy
     * MediaItem, ale wewnętrzny player osiadł w IDLE i nikt go nie przygotował. Nie dotyka
     * dekodera, Surface ani połączenia, więc kosztuje tyle co nic.
     */
    @Synchronized
    fun retryPrepare(): Boolean {
        val p = player ?: return false
        val url = currentUrl
        if (url.isBlank()) return false
        Log.w(TAG, "recovery/1 retryPrepare ${stateLabel()}")
        if (p.mediaItemCount == 0 || p.playerError != null) p.setMediaItem(MediaItem.fromUri(url), true)
        p.playWhenReady = true
        p.prepare()
        return true
    }

    /**
     * Poziom 2 — kontrolowany reset odtwarzania na TYM SAMYM playerze i tej samej powierzchni.
     *
     * `stop()` gwarantuje przejście do `STATE_IDLE`, dzięki czemu następujący po nim `prepare()`
     * naprawdę się wykona (a nie zostanie po cichu pominięty). To jedyny powód, dla którego
     * `stop()` w ogóle tu jest — na normalnej ścieżce zappingu go nie ma.
     */
    @Synchronized
    fun restartCurrent(): Boolean {
        val p = player ?: return false
        val url = currentUrl
        if (url.isBlank()) return false
        Log.w(
            TAG,
            "recovery/2 restartCurrent ${stateLabel()} dropped=${diagnostics.droppedFrames()}" +
                " rebuffers=${diagnostics.rebufferCount()}"
        )
        diagnostics.resetCounters()
        p.stop()
        p.clearMediaItems()
        p.setMediaItem(MediaItem.fromUri(url), true)
        p.playWhenReady = true
        p.prepare()
        return true
    }

    /**
     * Poziom 3 — odbudowa ExoPlayera (a więc i MediaCodeca) przy zachowaniu tego samego
     * PlayerView. `PlayerView.setPlayer` przepina istniejący SurfaceView na nową instancję,
     * nie tworzy nowej powierzchni — MiniTV/fullscreen i screenshoty PixelCopy zostają nietknięte.
     *
     * Zwraca nowy player, który warstwa wyżej musi przyjąć (podpiąć listener, zaktualizować
     * własną referencję).
     */
    @Synchronized
    fun rebuild(context: Context): ExoPlayer? {
        val url = currentUrl
        if (url.isBlank()) return null
        val auth = currentAuth
        val view = targetView
        Log.w(TAG, "recovery/3 rebuild player ${stateLabel()}")
        val old = player
        try { view?.player = null } catch (_: Exception) {}
        try { old?.removeAnalyticsListener(diagnostics) } catch (_: Exception) {}
        try { old?.release() } catch (_: Exception) {}
        player = null
        val p = try { createPlayer(context, auth) } catch (e: Exception) {
            Log.e(TAG, "rebuild failed: ${e.javaClass.simpleName}:${e.message}")
            currentUrl = ""
            return null
        }
        player = p
        diagnostics.resetCounters()
        if (view != null) {
            try { view.player = p } catch (_: Exception) {}
        }
        startItem(p, url, "rebuild", hard = false)
        return p
    }

    @Synchronized
    fun release() {
        try { targetView?.player = null } catch (_: Exception) {}
        targetView = null
        try { player?.removeAnalyticsListener(diagnostics) } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
        currentUrl = ""
        currentAuth = ""
        diagnostics.resetCounters()
    }

    fun stateName(state: Int): String = when (state) {
        Player.STATE_IDLE -> "IDLE"
        Player.STATE_BUFFERING -> "BUFFERING"
        Player.STATE_READY -> "READY"
        Player.STATE_ENDED -> "ENDED"
        else -> state.toString()
    }
}
