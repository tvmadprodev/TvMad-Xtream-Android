package pl.tvmad.xtream

import android.content.Context
import android.util.Log
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.PlayerView

/**
 * Jeden odtwarzacz LIVE współdzielony przez MiniTV i tryb pełnoekranowy.
 *
 * Zasady, na których stoi ta klasa:
 *  * player i jego Surface żyją przez całą sesję LIVE — MiniTV i fullscreen to tylko inne
 *    położenie tej samej powierzchni, więc przejście między nimi nie dotyka dekodera,
 *  * zmiana kanału NIE przechodzi przez [ExoPlayer.stop]. `stop()` gasił player do stanu IDLE
 *    i wymuszał pełne zwolnienie MediaCodeca, po czym `prepare()` budował wszystko od zera.
 *    To był stały, niepotrzebny koszt przy każdym przełączeniu kanału. `setMediaItem(item, true)`
 *    + `prepare()` robi to samo o jeden pełny teardown taniej i pozwala media3 zdecydować,
 *    czy dekoder da się utrzymać (gdy kanał ma inny kodek/profil/rozdzielczość, media3 i tak
 *    przeładuje dekoder samodzielnie — nie próbujemy go trzymać na siłę),
 *  * twardy reset (stop + clearMediaItems) zostaje wyłącznie dla ścieżki odzyskiwania.
 */
@UnstableApi
object LivePlayerSession {
    private const val TAG = "TvMadLive"

    private var player: ExoPlayer? = null
    private var currentUrl: String = ""
    private var currentAuth: String = ""
    private var targetView: PlayerView? = null
    private val diagnostics = PlaybackDiagnostics("LIVE")

    private fun createPlayer(context: Context, authHeader: String): ExoPlayer {
        val mediaSources = DefaultMediaSourceFactory(PlayerEngine.liveHttpFactory(authHeader))
        return ExoPlayer.Builder(context.applicationContext, PlayerEngine.liveRenderers(context))
            .setMediaSourceFactory(mediaSources)
            .setLoadControl(PlayerEngine.liveLoadControl())
            .build()
            .also {
                it.setAudioAttributes(AudioAttributes.DEFAULT, true)
                it.addAnalyticsListener(diagnostics)
            }
    }

    @Synchronized
    fun ensure(context: Context, url: String, authHeader: String = ""): ExoPlayer {
        var p = player
        if (p == null || currentAuth != authHeader) {
            val oldView = targetView
            try { oldView?.player = null } catch (_: Exception) {}
            try { p?.release() } catch (_: Exception) {}
            p = createPlayer(context, authHeader)
            player = p
            currentUrl = ""
            currentAuth = authHeader
            if (oldView != null) oldView.player = p
        }
        if (currentUrl != url) {
            currentUrl = url
            diagnostics.resetCounters()
            // Podmiana materiału bez gaszenia playera: media3 zamyka poprzednie źródło samo,
            // a my nie płacimy za dodatkowy cykl IDLE -> prepare przy każdym zappingu.
            p.setMediaItem(MediaItem.fromUri(url), true)
            p.playWhenReady = true
            p.prepare()
        } else if (!p.playWhenReady) {
            p.playWhenReady = true
        }
        return p
    }

    @Synchronized
    fun attach(view: PlayerView, context: Context, url: String, authHeader: String = ""): ExoPlayer {
        val p = ensure(context, url, authHeader)
        val old = targetView
        if (old !== view) {
            PlayerView.switchTargetView(p, old, view)
            targetView = view
        } else if (view.player !== p) {
            view.player = p
        }
        return p
    }

    @Synchronized
    fun detach(view: PlayerView) {
        if (targetView === view) {
            PlayerView.switchTargetView(player ?: return, view, null)
            targetView = null
        }
    }

    /**
     * Twarde ponowne uruchomienie bieżącego kanału. Używane wyłącznie przez logikę
     * odzyskiwania po realnej awarii strumienia, nie przy normalnej zmianie kanału.
     */
    @Synchronized
    fun restartCurrent() {
        val p = player ?: return
        val url = currentUrl
        if (url.isBlank()) return
        Log.i(TAG, "restartCurrent dropped=${diagnostics.droppedFrames()} rebuffers=${diagnostics.rebufferCount()}")
        diagnostics.resetCounters()
        p.stop()
        p.clearMediaItems()
        p.setMediaItem(MediaItem.fromUri(url), true)
        p.playWhenReady = true
        p.prepare()
    }

    fun currentUrl(): String = currentUrl

    @Synchronized
    fun release() {
        try { targetView?.player = null } catch (_: Exception) {}
        targetView = null
        try { player?.removeAnalyticsListener(diagnostics) } catch (_: Exception) {}
        try { player?.release() } catch (_: Exception) {}
        player = null
        currentUrl = ""
        currentAuth = ""
        diagnostics.resetCounters()
    }
}
