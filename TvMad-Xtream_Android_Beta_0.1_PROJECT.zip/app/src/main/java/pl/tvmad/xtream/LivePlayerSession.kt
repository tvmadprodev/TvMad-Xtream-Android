package pl.tvmad.xtream

import android.content.Context
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

/** One live-TV ExoPlayer shared between MiniTV and fullscreen. */
object LivePlayerSession {
    private var player: ExoPlayer? = null
    private var currentUrl: String = ""
    private var targetView: PlayerView? = null

    @Synchronized
    fun ensure(context: Context, url: String): ExoPlayer {
        var p = player
        if (p == null) {
            val renderers = DefaultRenderersFactory(context.applicationContext)
                .setEnableDecoderFallback(true)
                .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
            p = ExoPlayer.Builder(context.applicationContext, renderers).build().also {
                it.setAudioAttributes(AudioAttributes.DEFAULT, true)
            }
            player = p
        }
        if (currentUrl != url) {
            currentUrl = url
            p.stop()
            p.clearMediaItems()
            p.setMediaItem(MediaItem.fromUri(url))
            p.prepare()
            p.playWhenReady = true
        } else if (!p.playWhenReady) {
            p.playWhenReady = true
        }
        return p
    }

    @Synchronized
    fun attach(view: PlayerView, context: Context, url: String): ExoPlayer {
        val p = ensure(context, url)
        val old = targetView
        if (old !== view) {
            PlayerView.switchTargetView(p, old, view)
            targetView = view
        } else if (view.player !== p) {
            view.player = p
        }
        return p
    }

    @Synchronized
    fun detach(view: PlayerView) {
        if (targetView === view) {
            PlayerView.switchTargetView(player ?: return, view, null)
            targetView = null
        }
    }

    @Synchronized
    fun restartCurrent() {
        val p=player?:return
        val url=currentUrl
        if(url.isBlank())return
        p.stop();p.clearMediaItems();p.setMediaItem(MediaItem.fromUri(url));p.prepare();p.playWhenReady=true
    }

    fun currentPlayer(): ExoPlayer? = player
    fun currentUrl(): String = currentUrl

    @Synchronized
    fun release() {
        try { targetView?.player = null } catch (_: Exception) {}
        targetView = null
        try { player?.release() } catch (_: Exception) {}
        player = null
        currentUrl = ""
    }
}
