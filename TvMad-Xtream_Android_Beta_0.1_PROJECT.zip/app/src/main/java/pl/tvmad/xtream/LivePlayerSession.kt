package pl.tvmad.xtream

import android.content.Context
import androidx.media3.common.AudioAttributes
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

/** One live-TV ExoPlayer shared between MiniTV and fullscreen so changing Activity does not restart the stream. */
object LivePlayerSession {
    private var player: ExoPlayer? = null
    private var currentUrl: String = ""

    @Synchronized
    fun ensure(context: Context, url: String): ExoPlayer {
        var p = player
        if (p == null) {
            val renderers = DefaultRenderersFactory(context.applicationContext)
                .setEnableDecoderFallback(true)
                .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_PREFER)
            p = ExoPlayer.Builder(context.applicationContext, renderers).build().also {
                it.setAudioAttributes(AudioAttributes.DEFAULT, true)
            }
            player = p
        }
        if (currentUrl != url) {
            currentUrl = url
            p.stop()
            p.clearMediaItems()
            p.setMediaItem(MediaItem.fromUri(url))
            p.prepare()
            p.playWhenReady = true
        } else if (!p.isPlaying) {
            p.playWhenReady = true
        }
        return p
    }

    fun attach(view: PlayerView, context: Context, url: String): ExoPlayer {
        val p = ensure(context, url)
        if (view.player !== p) view.player = p
        return p
    }

    fun detach(view: PlayerView) {
        if (view.player === player) view.player = null
    }

    fun currentPlayer(): ExoPlayer? = player
    fun currentUrl(): String = currentUrl

    @Synchronized
    fun release() {
        try { player?.release() } catch (_: Exception) {}
        player = null
        currentUrl = ""
    }
}
