package pl.tvmad.xtream

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object FavoriteStore {
    private const val PREFS="tvmad_favorites"
    private const val KEY="live"

    fun load(context:Context):MutableList<Channel>{
        val raw=context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).getString(KEY,"[]")?:"[]"
        return try{
            val a=JSONArray(raw)
            MutableList(a.length()){i->
                val o=a.getJSONObject(i)
                Channel(o.optString("name"),o.optString("url"),o.optString("group"),o.optString("logo"),o.optString("epgId"),o.optString("streamId"),o.optString("groupId"))
            }
        }catch(_:Exception){ mutableListOf() }
    }

    fun save(context:Context,items:List<Channel>){
        val a=JSONArray()
        items.forEach{c->a.put(JSONObject().apply{
            put("name",c.name);put("url",c.url);put("group",c.group);put("logo",c.logo);put("epgId",c.epgId);put("streamId",c.streamId);put("groupId",c.groupId)
        })}
        context.getSharedPreferences(PREFS,Context.MODE_PRIVATE).edit().putString(KEY,a.toString()).apply()
    }
}
