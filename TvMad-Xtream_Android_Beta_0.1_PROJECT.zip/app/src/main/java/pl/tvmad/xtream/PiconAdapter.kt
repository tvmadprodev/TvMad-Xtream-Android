package pl.tvmad.xtream

import android.app.Activity
import android.graphics.BitmapFactory
import android.graphics.Color
import android.view.*
import android.widget.*
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.ConcurrentHashMap

class PiconAdapter(
    private val activity:Activity,
    private val items:List<Channel>,
    private val epg:Map<String,String>,
    private val piconMode:Int=2
):BaseAdapter(){
 private val pool=Executors.newFixedThreadPool(2)
 companion object{private val cache=ConcurrentHashMap<String,ByteArray>()}
 override fun getCount()=items.size
 override fun getItem(p:Int)=items[p]
 override fun getItemId(p:Int)=p.toLong()
 override fun getView(p:Int, old:View?, parent:ViewGroup):View{
  val row=old?:LinearLayout(activity).apply{
   orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),dp(5),dp(8),dp(5));isFocusable=false;isClickable=false
   background=android.graphics.drawable.StateListDrawable().apply{
    addState(intArrayOf(android.R.attr.state_selected),android.graphics.drawable.ColorDrawable(0xFF15395B.toInt()))
    addState(intArrayOf(android.R.attr.state_activated),android.graphics.drawable.ColorDrawable(0xFF15395B.toInt()))
    addState(intArrayOf(android.R.attr.state_focused),android.graphics.drawable.ColorDrawable(0xFF0D5EA6.toInt()))
    addState(intArrayOf(),android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
   }
   addView(ImageView(activity).apply{id=1001;scaleType=ImageView.ScaleType.CENTER_INSIDE},LinearLayout.LayoutParams(dp(74),dp(50)))
   addView(LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;addView(TextView(activity).apply{id=1002;textSize=18f;setTextColor(Color.WHITE);maxLines=1});addView(TextView(activity).apply{id=1003;textSize=13f;setTextColor(0xFF64B5F6.toInt());maxLines=1})},LinearLayout.LayoutParams(0,dp(62),1f))
  }
  val c=items[p];row.findViewById<TextView>(1002).text=c.name;row.findViewById<TextView>(1003).text=epg[c.url].orEmpty();val iv=row.findViewById<ImageView>(1001);iv.tag=c.url;iv.setImageDrawable(null)
  val local=if(piconMode==0||piconMode==2)PiconRepository.find(activity,c.name) else null
  if(local!=null){try{iv.setImageBitmap(BitmapFactory.decodeFile(local.absolutePath));return row}catch(_:Exception){}}
  if((piconMode==1||piconMode==2)&&c.logo.isNotBlank()){
   cache[c.logo]?.let{iv.setImageBitmap(BitmapFactory.decodeByteArray(it,0,it.size))}?:pool.execute{try{val b=URL(c.logo).openStream().use{it.readBytes()};cache[c.logo]=b;activity.runOnUiThread{if(iv.tag==c.url)iv.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.size))}}catch(_:Exception){}}
  }
  return row
 }
 fun close(){pool.shutdownNow()}
 private fun dp(v:Int)=(v*activity.resources.displayMetrics.density).toInt()
}
