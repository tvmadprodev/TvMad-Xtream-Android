package pl.tvmad.xtream

import android.app.Activity
import android.graphics.BitmapFactory
import android.view.*
import android.widget.*
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.ConcurrentHashMap

class PiconAdapter(private val activity:Activity, private val items:List<Channel>, private val epg:Map<String,String>):BaseAdapter(){
 private val pool=Executors.newFixedThreadPool(3)
 companion object{private val cache=ConcurrentHashMap<String,ByteArray>()}
 override fun getCount()=items.size
 override fun getItem(p:Int)=items[p]
 override fun getItemId(p:Int)=p.toLong()
 override fun getView(p:Int, old:View?, parent:ViewGroup):View{
  val row=old?:LinearLayout(activity).apply{
   orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(8,6,8,6)
   addView(ImageView(activity).apply{id=1001;scaleType=ImageView.ScaleType.CENTER_INSIDE},LinearLayout.LayoutParams(dp(78),dp(52)))
   addView(LinearLayout(activity).apply{orientation=LinearLayout.VERTICAL;addView(TextView(activity).apply{id=1002;textSize=18f;setTextColor(0xFFFFFFFF.toInt())});addView(TextView(activity).apply{id=1003;textSize=14f;setTextColor(0xFFD4AF37.toInt())})},LinearLayout.LayoutParams(0,dp(68),1f))
  }
  val c=items[p];row.findViewById<TextView>(1002).text=c.name;row.findViewById<TextView>(1003).text=epg[c.url].orEmpty();val iv=row.findViewById<ImageView>(1001);iv.tag=c.logo;iv.setImageDrawable(null)
  if(c.logo.isNotBlank()){
   cache[c.logo]?.let{iv.setImageBitmap(BitmapFactory.decodeByteArray(it,0,it.size))}?:pool.execute{try{val b=URL(c.logo).openStream().use{it.readBytes()};cache[c.logo]=b;activity.runOnUiThread{if(iv.tag==c.logo)iv.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.size))}}catch(_:Exception){}}
  }
  return row
 }
 private fun dp(v:Int)=(v*activity.resources.displayMetrics.density).toInt()
}
