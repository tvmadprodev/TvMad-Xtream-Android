package pl.tvmad.xtream

import android.app.Activity
import android.graphics.BitmapFactory
import android.graphics.Color
import android.view.*
import android.widget.*
import java.net.URL
import java.util.concurrent.Executors

class PiconAdapter(
    private val activity:Activity,
    private val items:List<Channel>,
    private val epg:Map<String,String>,
    private val epgEvents:Map<String,List<EpgEvent>>,
    private val piconMode:Int=2,
    private val source:Source?=null,
    private var selectedPosition:Int=-1,
    private val fixedVisibleRows:Int=0
):BaseAdapter(){
 private val pool=Executors.newFixedThreadPool(2)
 override fun getCount()=items.size
 override fun getItem(p:Int)=items[p]
 override fun getItemId(p:Int)=p.toLong()
 override fun getView(p:Int, old:View?, parent:ViewGroup):View{
  val row=old?:LinearLayout(activity).apply{
   orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),dp(2),dp(8),dp(2));isFocusable=false;isClickable=false
   background=activity.getDrawable(R.drawable.row_channel_idle)
   addView(TextView(activity).apply{id=1000;textSize=12f;gravity=Gravity.CENTER;setTextColor(0xFFB8C7D5.toInt())},LinearLayout.LayoutParams(dp(32),dp(58)))
   addView(ImageView(activity).apply{id=1001;scaleType=ImageView.ScaleType.CENTER_INSIDE},LinearLayout.LayoutParams(dp(70),dp(50)))
   addView(LinearLayout(activity).apply{
    orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL
    addView(TextView(activity).apply{id=1002;textSize=18f;setTextColor(Color.WHITE);maxLines=1})
    addView(TextView(activity).apply{id=1003;textSize=13f;setTextColor(0xFF64B5F6.toInt());maxLines=1})
    addView(ProgressBar(activity,null,android.R.attr.progressBarStyleHorizontal).apply{id=1004;max=1000;progressTintList=android.content.res.ColorStateList.valueOf(0xFF42A5F5.toInt());progressBackgroundTintList=android.content.res.ColorStateList.valueOf(0xFF263747.toInt())},LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(4)).apply{topMargin=dp(2)})
   },LinearLayout.LayoutParams(0,dp(60),1f))
  }
  if(fixedVisibleRows>0 && parent.height>0){
   val lv=parent as? ListView
   val usable=parent.height-parent.paddingTop-parent.paddingBottom-((lv?.dividerHeight?:0)*(fixedVisibleRows-1))
   val h=(usable/fixedVisibleRows).coerceAtLeast(dp(58))
   val lp=row.layoutParams as? AbsListView.LayoutParams
   if(lp==null||lp.height!=h)row.layoutParams=AbsListView.LayoutParams(AbsListView.LayoutParams.MATCH_PARENT,h)
  }
  val selected=if(selectedPosition>=0)selectedPosition==p else (parent as? ListView)?.selectedItemPosition==p
  row.setBackgroundResource(if(selected)R.drawable.row_focus_active else R.drawable.row_channel_idle)
  val c=items[p];row.findViewById<TextView>(1000).text="${p+1}";row.findViewById<TextView>(1002).text=c.name;row.findViewById<TextView>(1003).text=epg[c.url].orEmpty()
  val bar=row.findViewById<ProgressBar>(1004);val now=epgEvents[c.url]?.firstOrNull()
  if(now!=null&&now.startEpoch>0&&now.endEpoch>now.startEpoch){val t=System.currentTimeMillis();bar.visibility=View.VISIBLE;bar.progress=(((t-now.startEpoch).coerceIn(0,now.endEpoch-now.startEpoch)*1000)/(now.endEpoch-now.startEpoch)).toInt()}else{bar.progress=0;bar.visibility=View.INVISIBLE}
  val iv=row.findViewById<ImageView>(1001);val previousTag=iv.tag as? String;iv.tag=c.url
  val local=if(piconMode==0||piconMode==2)PiconRepository.find(activity,c.name) else null
  if(local!=null){
   val key="local:${local.absolutePath}"
   val cached=PiconMemoryCache.get(key)
   if(cached!=null){iv.setImageBitmap(cached);return row}
   if(previousTag!=c.url)iv.setImageDrawable(null)
   val rowKey=c.url
   pool.execute{
    val bm=PiconRepository.decodeScaled(local,160,100)?:return@execute
    PiconMemoryCache.put(key,bm)
    activity.runOnUiThread{if(iv.tag==rowKey)iv.setImageBitmap(bm)}
   }
   return row
  }
  if((piconMode==1||piconMode==2)&&c.logo.isNotBlank()){
   val key="remote:${source?.type}:${source?.host}:${c.logo}"
   val cached=PiconMemoryCache.get(key)
   if(cached!=null){iv.setImageBitmap(cached)}else{
    if(previousTag!=c.url)iv.setImageDrawable(null)
    pool.execute{try{val b=source?.let{Api.loadRemotePicon(it,c.logo)}?:URL(c.logo).openStream().use{it.readBytes()};val bm=BitmapFactory.decodeByteArray(b,0,b.size)?:return@execute;PiconMemoryCache.put(key,bm);activity.runOnUiThread{if(iv.tag==c.url)iv.setImageBitmap(bm)}}catch(_:Exception){}}
   }
  }else if(previousTag!=c.url)iv.setImageDrawable(null)
  return row
 }
 fun setSelectedPosition(position:Int){if(selectedPosition==position)return;selectedPosition=position;notifyDataSetChanged()}
 fun close(){pool.shutdownNow()}
 private fun dp(v:Int)=(v*activity.resources.displayMetrics.density).toInt()
}
