package pl.tvmad.xtream

import android.app.Activity
import android.graphics.BitmapFactory
import android.graphics.Color
import android.view.*
import android.widget.*
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.ConcurrentHashMap

class PiconAdapter(
    private val activity:Activity,
    private val items:List<Channel>,
    private val epg:Map<String,String>,
    private val epgEvents:Map<String,List<EpgEvent>>,
    private val piconMode:Int=2,
    private val source:Source?=null
):BaseAdapter(){
 private val pool=Executors.newFixedThreadPool(2)
 companion object{private val cache=ConcurrentHashMap<String,ByteArray>()}
 override fun getCount()=items.size
 override fun getItem(p:Int)=items[p]
 override fun getItemId(p:Int)=p.toLong()
 override fun getView(p:Int, old:View?, parent:ViewGroup):View{
  val row=old?:LinearLayout(activity).apply{
   orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),dp(4),dp(8),dp(4));isFocusable=false;isClickable=false
   background=activity.getDrawable(R.drawable.row_channel_premium)
   addView(TextView(activity).apply{id=1000;textSize=12f;gravity=Gravity.CENTER;setTextColor(0xFFB8C7D5.toInt())},LinearLayout.LayoutParams(dp(32),dp(64)))
   addView(ImageView(activity).apply{id=1001;scaleType=ImageView.ScaleType.CENTER_INSIDE},LinearLayout.LayoutParams(dp(70),dp(54)))
   addView(LinearLayout(activity).apply{
    orientation=LinearLayout.VERTICAL
    addView(TextView(activity).apply{id=1002;textSize=18f;setTextColor(Color.WHITE);maxLines=1})
    addView(TextView(activity).apply{id=1003;textSize=13f;setTextColor(0xFF64B5F6.toInt());maxLines=1})
    addView(ProgressBar(activity,null,android.R.attr.progressBarStyleHorizontal).apply{id=1004;max=1000;progressTintList=android.content.res.ColorStateList.valueOf(0xFF42A5F5.toInt());progressBackgroundTintList=android.content.res.ColorStateList.valueOf(0xFF263747.toInt())},LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(4)).apply{topMargin=dp(3)})
   },LinearLayout.LayoutParams(0,dp(68),1f))
  }
  val c=items[p];row.findViewById<TextView>(1000).text="${p+1}";row.findViewById<TextView>(1002).text=c.name;row.findViewById<TextView>(1003).text=epg[c.url].orEmpty()
  val bar=row.findViewById<ProgressBar>(1004);val now=epgEvents[c.url]?.firstOrNull()
  if(now!=null&&now.startEpoch>0&&now.endEpoch>now.startEpoch){val t=System.currentTimeMillis();bar.visibility=View.VISIBLE;bar.progress=(((t-now.startEpoch).coerceIn(0,now.endEpoch-now.startEpoch)*1000)/(now.endEpoch-now.startEpoch)).toInt()}else{bar.progress=0;bar.visibility=View.INVISIBLE}
  val iv=row.findViewById<ImageView>(1001);iv.tag=c.url;iv.setImageDrawable(null)
  val local=if(piconMode==0||piconMode==2)PiconRepository.find(activity,c.name) else null
  if(local!=null){try{iv.setImageBitmap(BitmapFactory.decodeFile(local.absolutePath));return row}catch(_:Exception){}}
  if((piconMode==1||piconMode==2)&&c.logo.isNotBlank()){
   cache[c.logo]?.let{iv.setImageBitmap(BitmapFactory.decodeByteArray(it,0,it.size))}?:pool.execute{try{val b=source?.let{Api.loadRemotePicon(it,c.logo)}?:URL(c.logo).openStream().use{it.readBytes()};cache[c.logo]=b;activity.runOnUiThread{if(iv.tag==c.url)iv.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.size))}}catch(_:Exception){}}
  }
  return row
 }
 fun close(){pool.shutdownNow()}
 private fun dp(v:Int)=(v*activity.resources.displayMetrics.density).toInt()
}
