package pl.tvmad.xtream

import android.app.Activity
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.view.PixelCopy
import java.io.ByteArrayOutputStream
import java.lang.ref.WeakReference
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object AppScreenshotBridge {
    @Volatile private var active = WeakReference<Activity>(null)

    fun attach(activity: Activity) { active = WeakReference(activity) }
    fun detach(activity: Activity) { if (active.get() === activity) active = WeakReference<Activity>(null) }

    fun capturePng(): ByteArray? {
        val activity = active.get() ?: return null
        if (activity.isFinishing || activity.isDestroyed) return null
        if (Looper.myLooper() == Looper.getMainLooper()) return null
        val decor = activity.window.decorView
        val w = decor.width.coerceAtLeast(1)
        val h = decor.height.coerceAtLeast(1)
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val latch = CountDownLatch(1)
        var ok = false
        Handler(Looper.getMainLooper()).post {
            try {
                PixelCopy.request(activity.window, bitmap, { result ->
                    ok = result == PixelCopy.SUCCESS
                    latch.countDown()
                }, Handler(Looper.getMainLooper()))
            } catch (_: Exception) { latch.countDown() }
        }
        if (!latch.await(2500, TimeUnit.MILLISECONDS) || !ok) { bitmap.recycle(); return null }
        return try {
            ByteArrayOutputStream().use { out -> bitmap.compress(Bitmap.CompressFormat.PNG, 100, out); out.toByteArray() }
        } finally { bitmap.recycle() }
    }
}
