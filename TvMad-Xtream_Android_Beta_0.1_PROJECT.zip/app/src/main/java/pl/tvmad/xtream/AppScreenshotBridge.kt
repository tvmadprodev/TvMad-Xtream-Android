package pl.tvmad.xtream

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Handler
import android.os.Looper
import java.io.ByteArrayOutputStream
import java.lang.ref.WeakReference
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object AppScreenshotBridge {
    @Volatile private var active = WeakReference<Activity>(null)

    fun attach(activity: Activity) { active = WeakReference(activity) }
    fun detach(activity: Activity) { if (active.get() === activity) active = WeakReference<Activity>(null) }

    fun capturePng(): ByteArray? {
        val activity = active.get() ?: return null
        if (activity.isFinishing || activity.isDestroyed) return null
        if (Looper.myLooper() == Looper.getMainLooper()) return null

        val latch = CountDownLatch(1)
        var bytes: ByteArray? = null
        Handler(Looper.getMainLooper()).post {
            var bitmap: Bitmap? = null
            try {
                val decor = activity.window.decorView
                val w = decor.width
                val h = decor.height
                if (w > 0 && h > 0 && decor.isShown) {
                    bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    val canvas = Canvas(bitmap!!)
                    decor.draw(canvas)
                    bytes = ByteArrayOutputStream().use { out ->
                        bitmap!!.compress(Bitmap.CompressFormat.PNG, 100, out)
                        out.toByteArray()
                    }
                }
            } catch (_: Throwable) {
                bytes = null
            } finally {
                try { bitmap?.recycle() } catch (_: Throwable) {}
                latch.countDown()
            }
        }
        if (!latch.await(3000, TimeUnit.MILLISECONDS)) return null
        return bytes
    }
}
