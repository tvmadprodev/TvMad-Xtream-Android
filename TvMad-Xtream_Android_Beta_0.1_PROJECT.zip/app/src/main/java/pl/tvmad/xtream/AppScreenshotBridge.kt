package pl.tvmad.xtream

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.Looper
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import java.io.ByteArrayOutputStream
import java.lang.ref.WeakReference
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.locks.ReentrantLock

object AppScreenshotBridge {
    @Volatile private var active = WeakReference<Activity>(null)
    private const val MAX_SCREENSHOT_WIDTH = 960
    private const val JPEG_QUALITY = 78
    private val captureLock = ReentrantLock()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val blitPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val locTmp = IntArray(2)
    private var destPool: Bitmap? = null
    private var scratchPool: Bitmap? = null

    fun attach(activity: Activity) { active = WeakReference(activity) }

    fun detach(activity: Activity) {
        if (active.get() === activity) active = WeakReference<Activity>(null)
    }

    fun captureJpeg(): ByteArray? {
        if (Looper.myLooper() == Looper.getMainLooper()) return null
        if (!captureLock.tryLock(3, TimeUnit.SECONDS)) return null
        try {
            return captureLocked()
        } finally {
            captureLock.unlock()
        }
    }

    private fun captureLocked(): ByteArray? {
        val activity = active.get() ?: return null
        if (activity.isFinishing || activity.isDestroyed) return null

        val copied = runOnMain(400) {
            fillScreenshot(activity)
        }
        if (!copied) return null
        val dest = destPool?.takeIf { !it.isRecycled } ?: return null

        return try {
            ByteArrayOutputStream(96 * 1024).use { out ->
                if (!dest.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)) null
                else out.toByteArray()
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun fillScreenshot(activity: Activity): Boolean {
        if (activity.isFinishing || activity.isDestroyed) return false
        val decor = activity.window.peekDecorView() ?: return false
        val sourceW = decor.width
        val sourceH = decor.height
        if (sourceW <= 0 || sourceH <= 0 || !decor.isShown) return false

        val scale = minOf(1f, MAX_SCREENSHOT_WIDTH.toFloat() / sourceW.toFloat())
        val outW = (sourceW * scale).toInt().coerceAtLeast(1)
        val outH = (sourceH * scale).toInt().coerceAtLeast(1)
        val dest = obtainDest(outW, outH) ?: return false
        dest.eraseColor(Color.BLACK)

        val texture = findTextureView(decor)
        if (texture == null || !texture.isAvailable || texture.width <= 0 || texture.height <= 0) {
            val canvas = Canvas(dest)
            canvas.scale(scale, scale)
            drawSkippingView(decor, null, canvas)
            return true
        }

        // The LIVE PlayerView deliberately keeps a full-screen Surface and is only scaled /
        // translated into the MiniTV slot. TextureView.width/height therefore stay full-screen
        // even while the user sees a small MiniTV. Base the screenshot decision on the visual
        // bounds of the PlayerView, not on the backing Surface size.
        val videoHost = findVideoHost(texture)
        val videoBounds = visualBounds(videoHost)
        val windowArea = sourceW.toLong().coerceAtLeast(1) * sourceH.toLong().coerceAtLeast(1)
        val videoArea = videoBounds.width().toLong().coerceAtLeast(1) * videoBounds.height().toLong().coerceAtLeast(1)
        val fullscreenVideo = videoArea * 100L >= windowArea * 55L

        if (fullscreenVideo) {
            if (texture.getBitmap(dest) == null) return false
            val overlay = Canvas(dest)
            overlay.scale(scale, scale)
            drawViewsAboveVideo(decor, videoHost, overlay)
            return true
        }

        // MiniTV: first draw the complete OSD/list without the transformed PlayerView, then
        // composite the current video frame exactly into the on-screen MiniTV rectangle.
        val canvas = Canvas(dest)
        canvas.scale(scale, scale)
        drawSkippingView(decor, videoHost, canvas)
        blitTexture(texture, videoBounds, canvas, scale)
        return true
    }

    private fun blitTexture(texture: TextureView, bounds: RectF, canvas: Canvas, scale: Float) {
        if (bounds.width() <= 0f || bounds.height() <= 0f || !texture.isAvailable) return
        val sw = (bounds.width() * scale).toInt().coerceAtLeast(1)
        val sh = (bounds.height() * scale).toInt().coerceAtLeast(1)
        val scratch = obtainScratch(sw, sh) ?: return
        if (texture.getBitmap(scratch) == null) return
        canvas.drawBitmap(scratch, null, bounds, blitPaint)
    }

    private fun findVideoHost(texture: TextureView): View {
        var v: View = texture
        var p = texture.parent
        while (p is View) {
            v = p
            if (p.id == R.id.miniPlayer) return p
            p = p.parent
        }
        return v
    }

    private fun visualBounds(view: View): RectF {
        view.getLocationInWindow(locTmp)
        val w = (view.width * kotlin.math.abs(view.scaleX)).coerceAtLeast(1f)
        val h = (view.height * kotlin.math.abs(view.scaleY)).coerceAtLeast(1f)
        return RectF(locTmp[0].toFloat(), locTmp[1].toFloat(), locTmp[0] + w, locTmp[1] + h)
    }

    private fun findTextureView(view: View): TextureView? {
        if (view is TextureView && view.isShown && view.isAvailable && view.width > 0 && view.height > 0) return view
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                findTextureView(view.getChildAt(i))?.let { return it }
            }
        }
        return null
    }

    private fun drawSkippingView(view: View, skip: View?, canvas: Canvas) {
        if (!view.isShown || view === skip) return
        if (skip != null && view is ViewGroup && containsView(view, skip)) {
            view.getLocationInWindow(locTmp)
            val save = canvas.save()
            try {
                canvas.translate(locTmp[0].toFloat(), locTmp[1].toFloat())
                view.background?.let { bg ->
                    bg.setBounds(0, 0, view.width, view.height)
                    bg.draw(canvas)
                }
            } finally {
                canvas.restoreToCount(save)
            }
            for (i in 0 until view.childCount) drawSkippingView(view.getChildAt(i), skip, canvas)
            return
        }
        view.getLocationInWindow(locTmp)
        val save = canvas.save()
        try {
            canvas.translate(locTmp[0].toFloat(), locTmp[1].toFloat())
            view.draw(canvas)
        } finally {
            canvas.restoreToCount(save)
        }
    }

    private fun drawViewsAboveVideo(view: View, video: View, canvas: Canvas) {
        if (!view.isShown || view === video) return
        if (view is ViewGroup && containsView(view, video)) {
            for (i in 0 until view.childCount) drawViewsAboveVideo(view.getChildAt(i), video, canvas)
            return
        }
        if (!isDrawnAbove(view, video)) return
        view.getLocationInWindow(locTmp)
        val save = canvas.save()
        try {
            canvas.translate(locTmp[0].toFloat(), locTmp[1].toFloat())
            view.draw(canvas)
        } finally {
            canvas.restoreToCount(save)
        }
    }

    private fun containsView(group: ViewGroup, target: View): Boolean {
        var v: View? = target
        while (v != null) {
            if (v === group) return true
            v = v.parent as? View
        }
        return false
    }

    private fun isDrawnAbove(view: View, video: View): Boolean {
        if (view.elevation > video.elevation + 0.01f) return true
        val viewChain = ancestors(view)
        val videoChain = ancestors(video)
        val videoSet = videoChain.toSet()
        var common: ViewGroup? = null
        var viewChild: View = view
        for (item in viewChain) {
            if (item in videoSet && item is ViewGroup) {
                common = item
                break
            }
            viewChild = item
        }
        if (common == null) return true
        var videoChild: View = video
        for (item in videoChain) {
            if (item === common) break
            videoChild = item
        }
        return common.indexOfChild(viewChild) > common.indexOfChild(videoChild)
    }

    private fun ancestors(view: View): List<View> {
        val out = ArrayList<View>(8)
        var v: View? = view
        while (v != null) {
            out += v
            v = v.parent as? View
        }
        return out
    }

    /**
     * Runs [block] on the main thread. If the wait times out, this still waits for the
     * posted work to finish so the caller never recycles/reuses a bitmap the UI is filling.
     */
    private fun runOnMain(timeoutMs: Long, block: () -> Boolean): Boolean {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            return try { block() } catch (_: Throwable) { false }
        }
        val ok = AtomicBoolean(false)
        val latch = CountDownLatch(1)
        mainHandler.post {
            try {
                ok.set(block())
            } catch (_: Throwable) {
                ok.set(false)
            } finally {
                latch.countDown()
            }
        }
        if (!latch.await(timeoutMs, TimeUnit.MILLISECONDS)) {
            latch.await(3, TimeUnit.SECONDS)
        }
        return ok.get()
    }

    private fun obtainDest(w: Int, h: Int): Bitmap? {
        val cur = destPool
        if (cur != null && !cur.isRecycled && cur.width == w && cur.height == h) return cur
        recycleQuietly(cur)
        return try {
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { destPool = it }
        } catch (_: Throwable) {
            destPool = null
            null
        }
    }

    private fun obtainScratch(w: Int, h: Int): Bitmap? {
        val cur = scratchPool
        if (cur != null && !cur.isRecycled && cur.width == w && cur.height == h) return cur
        recycleQuietly(cur)
        return try {
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { scratchPool = it }
        } catch (_: Throwable) {
            scratchPool = null
            null
        }
    }

    private fun recycleQuietly(bitmap: Bitmap?) {
        try { if (bitmap != null && !bitmap.isRecycled) bitmap.recycle() } catch (_: Throwable) {}
    }
}
