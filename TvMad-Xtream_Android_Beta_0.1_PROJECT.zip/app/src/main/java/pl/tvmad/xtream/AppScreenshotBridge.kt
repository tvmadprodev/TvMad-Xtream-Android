package pl.tvmad.xtream

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Handler
import android.os.HandlerThread
import android.view.PixelCopy
import java.io.ByteArrayOutputStream
import java.lang.ref.WeakReference
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

object AppScreenshotBridge {
    @Volatile private var active = WeakReference<Activity>(null)
    private const val MAX_SCREENSHOT_WIDTH = 1280
    private const val JPEG_QUALITY = 88

    // PixelCopy works asynchronously against the Window surface. Unlike TextureView.getBitmap()
    // it does not synchronously read the video frame on the UI thread, so taking a WebInterface
    // screenshot must not freeze Media3 playback or force the player/activity to be recreated.
    private val copyThread = HandlerThread("TvMadScreenshot").apply { start() }
    private val copyHandler = Handler(copyThread.looper)

    fun attach(activity: Activity) { active = WeakReference(activity) }

    fun detach(activity: Activity) {
        if (active.get() === activity) active = WeakReference<Activity>(null)
    }

    fun captureJpeg(): ByteArray? {
        val activity = active.get() ?: return null
        if (activity.isFinishing || activity.isDestroyed) return null

        val decor = activity.window.peekDecorView() ?: return null
        val sourceW = decor.width
        val sourceH = decor.height
        if (sourceW <= 0 || sourceH <= 0 || !decor.isShown) return null

        val scale = minOf(1f, MAX_SCREENSHOT_WIDTH.toFloat() / sourceW.toFloat())
        val outW = (sourceW * scale).toInt().coerceAtLeast(1)
        val outH = (sourceH * scale).toInt().coerceAtLeast(1)
        val bitmap = try {
            Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        } catch (_: Throwable) {
            return null
        }

        val latch = CountDownLatch(1)
        val result = AtomicInteger(PixelCopy.ERROR_UNKNOWN)
        try {
            PixelCopy.request(
                activity.window,
                Rect(0, 0, sourceW, sourceH),
                bitmap,
                { copyResult ->
                    result.set(copyResult)
                    latch.countDown()
                },
                copyHandler
            )
        } catch (_: Throwable) {
            try { bitmap.recycle() } catch (_: Throwable) {}
            return null
        }

        if (!latch.await(1200, TimeUnit.MILLISECONDS) || result.get() != PixelCopy.SUCCESS) {
            try { bitmap.recycle() } catch (_: Throwable) {}
            return null
        }

        return try {
            ByteArrayOutputStream(256 * 1024).use { out ->
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)) return null
                out.toByteArray()
            }
        } catch (_: Throwable) {
            null
        } finally {
            try { bitmap.recycle() } catch (_: Throwable) {}
        }
    }
}
