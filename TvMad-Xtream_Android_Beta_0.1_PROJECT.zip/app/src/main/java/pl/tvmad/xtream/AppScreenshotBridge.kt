package pl.tvmad.xtream

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import androidx.media3.ui.PlayerView
import java.io.ByteArrayOutputStream
import java.lang.ref.WeakReference
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object AppScreenshotBridge {
    @Volatile private var active = WeakReference<Activity>(null)

    fun attach(activity: Activity) { active = WeakReference(activity) }
    fun detach(activity: Activity) {
        if (active.get() === activity) active = WeakReference<Activity>(null)
    }

    private fun findTexture(v: View): TextureView? {
        if (v is TextureView) return v
        if (v is ViewGroup) for (i in 0 until v.childCount) {
            findTexture(v.getChildAt(i))?.let { return it }
        }
        return null
    }

    private fun containsTexture(v: View): Boolean = findTexture(v) != null

    private fun drawAt(canvas: Canvas, decor: View, view: View) {
        if (view.visibility != View.VISIBLE || view.width <= 0 || view.height <= 0) return
        val a = IntArray(2); val d = IntArray(2)
        view.getLocationInWindow(a); decor.getLocationInWindow(d)
        canvas.save()
        canvas.translate((a[0]-d[0]).toFloat(), (a[1]-d[1]).toFloat())
        view.draw(canvas)
        canvas.restore()
    }

    private fun drawPlayerOverlays(canvas: Canvas, decor: View, playerView: PlayerView) {
        // Media3 subtitles / artwork / controller are siblings of the video surface.
        for (i in 0 until playerView.childCount) {
            val child = playerView.getChildAt(i)
            if (!containsTexture(child)) drawAt(canvas, decor, child)
        }
    }

    private fun overlayByName(activity: Activity, canvas: Canvas, decor: View, name: String) {
        val id = activity.resources.getIdentifier(name, "id", activity.packageName)
        if (id != 0) activity.findViewById<View>(id)?.let { drawAt(canvas, decor, it) }
    }

    fun capturePng(): ByteArray? {
        val activity = active.get() ?: return null
        if (activity.isFinishing || activity.isDestroyed) return null
        if (Looper.myLooper() == Looper.getMainLooper()) return null

        val latch = CountDownLatch(1)
        var bytes: ByteArray? = null

        Handler(Looper.getMainLooper()).post {
            var outBitmap: Bitmap? = null
            var frame: Bitmap? = null
            try {
                val decor = activity.window.decorView
                if (decor.width <= 0 || decor.height <= 0 || !decor.isShown) {
                    latch.countDown()
                    return@post
                }

                val playerId = activity.resources.getIdentifier(
                    if (activity is PlayerActivity) "playerView" else "miniPlayer",
                    "id", activity.packageName
                )
                val pv = if (playerId != 0) activity.findViewById<PlayerView>(playerId) else null
                val tv = pv?.let { findTexture(it) }

                outBitmap = Bitmap.createBitmap(decor.width, decor.height, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(outBitmap!!)
                canvas.drawColor(Color.BLACK)

                if (pv != null && tv != null && tv.isAvailable && pv.visibility == View.VISIBLE) {
                    frame = tv.getBitmap()
                    if (frame != null) {
                        val p = IntArray(2); val d = IntArray(2)
                        pv.getLocationInWindow(p); decor.getLocationInWindow(d)
                        val left = p[0]-d[0]; val top = p[1]-d[1]
                        val dst = Rect(left, top, left + pv.width, top + pv.height)
                        canvas.drawBitmap(frame!!, null, dst, null)
                    }
                    drawPlayerOverlays(canvas, decor, pv)

                    if (activity is PlayerActivity) {
                        overlayByName(activity, canvas, decor, "info")
                        overlayByName(activity, canvas, decor, "bufferingBox")
                        overlayByName(activity, canvas, decor, "aspect")
                    } else {
                        overlayByName(activity, canvas, decor, "liveFsInfo")
                        overlayByName(activity, canvas, decor, "liveBufferingBox")
                        overlayByName(activity, canvas, decor, "liveChannelDrawer")
                        overlayByName(activity, canvas, decor, "liveTrackDrawer")
                    }
                } else {
                    // Ekrany bez aktywnego filmu: zwykły pełny zrzut UI.
                    decor.draw(canvas)
                }

                bytes = ByteArrayOutputStream().use { out ->
                    outBitmap!!.compress(Bitmap.CompressFormat.PNG, 100, out)
                    out.toByteArray()
                }
            } catch (_: Throwable) {
                bytes = null
            } finally {
                try { frame?.recycle() } catch (_: Throwable) {}
                try { outBitmap?.recycle() } catch (_: Throwable) {}
                latch.countDown()
            }
        }

        if (!latch.await(3500, TimeUnit.MILLISECONDS)) return null
        return bytes
    }
}
