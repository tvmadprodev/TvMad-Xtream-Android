package pl.tvmad.xtream

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.view.PixelCopy
import android.view.SurfaceView
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import java.io.ByteArrayOutputStream
import java.lang.ref.WeakReference
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.locks.ReentrantLock

/**
 * Zrzut ekranu na żądanie (panel WWW).
 *
 * Warstwa wideo jest teraz SurfaceView, czyli nie da się jej odczytać zwykłym `View.draw()` —
 * obraz leży na osobnej warstwie kompozytora. Klatka jest więc pobierana przez [PixelCopy],
 * WYŁĄCZNIE w momencie żądania zrzutu. Nic nie działa w tle, nic nie kopiuje klatek na bieżąco,
 * więc odtwarzanie nie płaci za tę funkcję nic, dopóki nikt nie poprosi o screenshot.
 * Ścieżka TextureView została zachowana jako fallback.
 */
object AppScreenshotBridge {
    @Volatile private var active = WeakReference<Activity>(null)
    private const val MAX_SCREENSHOT_WIDTH = 960
    private const val JPEG_QUALITY = 78
    private const val PIXEL_COPY_TIMEOUT_MS = 1500L
    private val captureLock = ReentrantLock()
    private val mainHandler = Handler(Looper.getMainLooper())
    private val blitPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val locTmp = IntArray(2)
    private var destPool: Bitmap? = null
    private var scratchPool: Bitmap? = null
    private var copyThread: HandlerThread? = null
    private var copyHandler: Handler? = null

    fun attach(activity: Activity) { active = WeakReference(activity) }

    fun detach(activity: Activity) {
        if (active.get() === activity) active = WeakReference<Activity>(null)
    }

    fun captureJpeg(): ByteArray? {
        if (Looper.myLooper() == Looper.getMainLooper()) return null
        if (!captureLock.tryLock(3, TimeUnit.SECONDS)) return null
        try {
            return captureLocked()
        } finally {
            captureLock.unlock()
        }
    }

    /** Wszystko, co trzeba wiedzieć o kadrze; liczone raz, na wątku UI. */
    private class Plan(
        val decor: View,
        val scale: Float,
        val outW: Int,
        val outH: Int,
        val video: View?,
        val videoHost: View?,
        val bounds: RectF,
        val fullscreen: Boolean
    )

    private fun captureLocked(): ByteArray? {
        val activity = active.get() ?: return null
        if (activity.isFinishing || activity.isDestroyed) return null

        var plan: Plan? = null
        if (!runOnMain(400) { plan = buildPlan(activity); plan != null }) return null
        val p = plan ?: return null

        val dest = obtainDest(p.outW, p.outH) ?: return null

        val ok = if (p.fullscreen && p.video != null) {
            // Wideo wypełnia cały kadr: klatka trafia wprost do bitmapy wynikowej,
            // a na wierzchu dorysowujemy tylko to, co w hierarchii leży nad obrazem.
            val gotFrame = captureVideoFrame(p.video, dest)
            runOnMain(400) {
                if (!gotFrame) dest.eraseColor(Color.BLACK)
                val canvas = Canvas(dest)
                canvas.scale(p.scale, p.scale)
                p.videoHost?.let { drawViewsAboveVideo(p.decor, it, canvas) }
                true
            }
        } else {
            // MiniTV (albo brak wideo): najpierw pełne OSD bez przekształconego PlayerView,
            // potem klatka wkomponowana dokładnie w prostokąt MiniTV.
            var frame: Bitmap? = null
            if (p.video != null) {
                val vw = (p.bounds.width() * p.scale).toInt().coerceAtLeast(1)
                val vh = (p.bounds.height() * p.scale).toInt().coerceAtLeast(1)
                val scratch = obtainScratch(vw, vh)
                if (scratch != null && captureVideoFrame(p.video, scratch)) frame = scratch
            }
            runOnMain(400) {
                dest.eraseColor(Color.BLACK)
                val canvas = Canvas(dest)
                canvas.scale(p.scale, p.scale)
                drawSkippingView(p.decor, p.videoHost, canvas)
                frame?.let { canvas.drawBitmap(it, null, p.bounds, blitPaint) }
                true
            }
        }
        if (!ok) return null

        return try {
            ByteArrayOutputStream(96 * 1024).use { out ->
                if (!dest.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, out)) null
                else out.toByteArray()
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun buildPlan(activity: Activity): Plan? {
        if (activity.isFinishing || activity.isDestroyed) return null
        val decor = activity.window.peekDecorView() ?: return null
        val sourceW = decor.width
        val sourceH = decor.height
        if (sourceW <= 0 || sourceH <= 0 || !decor.isShown) return null

        val scale = minOf(1f, MAX_SCREENSHOT_WIDTH.toFloat() / sourceW.toFloat())
        val outW = (sourceW * scale).toInt().coerceAtLeast(1)
        val outH = (sourceH * scale).toInt().coerceAtLeast(1)

        val video = findVideoView(decor)
            ?: return Plan(decor, scale, outW, outH, null, null, RectF(), false)

        // Powierzchnia LIVE jest utrzymywana w rozmiarze pełnego ekranu i tylko przesuwana
        // / skalowana do kafla MiniTV, więc jej własne width/height nic nie mówi o tym, co
        // widzi użytkownik. Decyduje wizualny prostokąt hosta wideo.
        val videoHost = findVideoHost(video)
        val bounds = visualBounds(videoHost)
        val windowArea = sourceW.toLong().coerceAtLeast(1) * sourceH.toLong().coerceAtLeast(1)
        val videoArea = bounds.width().toLong().coerceAtLeast(1) * bounds.height().toLong().coerceAtLeast(1)
        val fullscreen = videoArea * 100L >= windowArea * 55L
        return Plan(decor, scale, outW, outH, video, videoHost, bounds, fullscreen)
    }

    /** Pobiera bieżącą klatkę wideo do [into]. Źródło jest skalowane do rozmiaru bitmapy. */
    private fun captureVideoFrame(view: View, into: Bitmap): Boolean = when (view) {
        is SurfaceView -> copyFromSurface(view, into)
        is TextureView -> runOnMain(400) { view.isAvailable && view.getBitmap(into) != null }
        else -> false
    }

    private fun copyFromSurface(view: SurfaceView, into: Bitmap): Boolean {
        val surface = try { view.holder?.surface } catch (_: Throwable) { null } ?: return false
        if (!surface.isValid) return false
        val latch = CountDownLatch(1)
        val status = AtomicInteger(PixelCopy.ERROR_UNKNOWN)
        return try {
            PixelCopy.request(view, into, { result ->
                status.set(result)
                latch.countDown()
            }, pixelCopyHandler())
            if (!latch.await(PIXEL_COPY_TIMEOUT_MS, TimeUnit.MILLISECONDS)) false
            else status.get() == PixelCopy.SUCCESS
        } catch (_: Throwable) {
            false
        }
    }

    /**
     * Callback PixelCopy nie może wracać na wątek UI — zrzut jest robiony z wątku serwera WWW,
     * a wątek UI w tym czasie rysuje. Dedykowany, leniwie tworzony wątek nic nie kosztuje,
     * dopóki nikt nie zażąda screenshota.
     */
    @Synchronized
    private fun pixelCopyHandler(): Handler {
        copyHandler?.let { return it }
        val thread = HandlerThread("TvMad-PixelCopy").apply { start() }
        copyThread = thread
        return Handler(thread.looper).also { copyHandler = it }
    }

    private fun findVideoView(view: View): View? {
        if ((view is SurfaceView || view is TextureView) && view.isShown && view.width > 0 && view.height > 0) {
            if (view !is TextureView || view.isAvailable) return view
        }
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                findVideoView(view.getChildAt(i))?.let { return it }
            }
        }
        return null
    }

    private fun findVideoHost(video: View): View {
        var v: View = video
        var p = video.parent
        while (p is View) {
            v = p
            if (p.id == R.id.miniPlayer) return p
            p = p.parent
        }
        return v
    }

    private fun visualBounds(view: View): RectF {
        view.getLocationInWindow(locTmp)
        val w = (view.width * kotlin.math.abs(view.scaleX)).coerceAtLeast(1f)
        val h = (view.height * kotlin.math.abs(view.scaleY)).coerceAtLeast(1f)
        return RectF(locTmp[0].toFloat(), locTmp[1].toFloat(), locTmp[0] + w, locTmp[1] + h)
    }

    private fun drawSkippingView(view: View, skip: View?, canvas: Canvas) {
        if (!view.isShown || view === skip) return
        if (skip != null && view is ViewGroup && containsView(view, skip)) {
            view.getLocationInWindow(locTmp)
            val save = canvas.save()
            try {
                canvas.translate(locTmp[0].toFloat(), locTmp[1].toFloat())
                view.background?.let { bg ->
                    bg.setBounds(0, 0, view.width, view.height)
                    bg.draw(canvas)
                }
            } finally {
                canvas.restoreToCount(save)
            }
            for (i in 0 until view.childCount) drawSkippingView(view.getChildAt(i), skip, canvas)
            return
        }
        view.getLocationInWindow(locTmp)
        val save = canvas.save()
        try {
            canvas.translate(locTmp[0].toFloat(), locTmp[1].toFloat())
            view.draw(canvas)
        } finally {
            canvas.restoreToCount(save)
        }
    }

    private fun drawViewsAboveVideo(view: View, video: View, canvas: Canvas) {
        if (!view.isShown || view === video) return
        if (view is ViewGroup && containsView(view, video)) {
            for (i in 0 until view.childCount) drawViewsAboveVideo(view.getChildAt(i), video, canvas)
            return
        }
        if (!isDrawnAbove(view, video)) return
        view.getLocationInWindow(locTmp)
        val save = canvas.save()
        try {
            canvas.translate(locTmp[0].toFloat(), locTmp[1].toFloat())
            view.draw(canvas)
        } finally {
            canvas.restoreToCount(save)
        }
    }

    private fun containsView(group: ViewGroup, target: View): Boolean {
        var v: View? = target
        while (v != null) {
            if (v === group) return true
            v = v.parent as? View
        }
        return false
    }

    private fun isDrawnAbove(view: View, video: View): Boolean {
        if (view.elevation > video.elevation + 0.01f) return true
        val viewChain = ancestors(view)
        val videoChain = ancestors(video)
        val videoSet = videoChain.toSet()
        var common: ViewGroup? = null
        var viewChild: View = view
        for (item in viewChain) {
            if (item in videoSet && item is ViewGroup) {
                common = item
                break
            }
            viewChild = item
        }
        if (common == null) return true
        var videoChild: View = video
        for (item in videoChain) {
            if (item === common) break
            videoChild = item
        }
        return common.indexOfChild(viewChild) > common.indexOfChild(videoChild)
    }

    private fun ancestors(view: View): List<View> {
        val out = ArrayList<View>(8)
        var v: View? = view
        while (v != null) {
            out += v
            v = v.parent as? View
        }
        return out
    }

    /**
     * Runs [block] on the main thread. If the wait times out, this still waits for the
     * posted work to finish so the caller never recycles/reuses a bitmap the UI is filling.
     */
    private fun runOnMain(timeoutMs: Long, block: () -> Boolean): Boolean {
        if (Looper.myLooper() == Looper.getMainLooper()) {
            return try { block() } catch (_: Throwable) { false }
        }
        val ok = AtomicBoolean(false)
        val latch = CountDownLatch(1)
        mainHandler.post {
            try {
                ok.set(block())
            } catch (_: Throwable) {
                ok.set(false)
            } finally {
                latch.countDown()
            }
        }
        if (!latch.await(timeoutMs, TimeUnit.MILLISECONDS)) {
            latch.await(3, TimeUnit.SECONDS)
        }
        return ok.get()
    }

    private fun obtainDest(w: Int, h: Int): Bitmap? {
        val cur = destPool
        if (cur != null && !cur.isRecycled && cur.width == w && cur.height == h) return cur
        recycleQuietly(cur)
        return try {
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { destPool = it }
        } catch (_: Throwable) {
            destPool = null
            null
        }
    }

    private fun obtainScratch(w: Int, h: Int): Bitmap? {
        val cur = scratchPool
        if (cur != null && !cur.isRecycled && cur.width == w && cur.height == h) return cur
        recycleQuietly(cur)
        return try {
            Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888).also { scratchPool = it }
        } catch (_: Throwable) {
            scratchPool = null
            null
        }
    }

    private fun recycleQuietly(bitmap: Bitmap?) {
        try { if (bitmap != null && !bitmap.isRecycled) bitmap.recycle() } catch (_: Throwable) {}
    }
}
