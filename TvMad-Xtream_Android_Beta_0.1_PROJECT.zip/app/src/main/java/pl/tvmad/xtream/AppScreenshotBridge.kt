package pl.tvmad.xtream

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.TextureView
import android.view.View
import android.view.ViewGroup
import androidx.media3.ui.PlayerView
import java.io.ByteArrayOutputStream
import java.lang.ref.WeakReference
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

object AppScreenshotBridge {
    @Volatile private var active = WeakReference<Activity>(null)
    private const val MAX_SCREENSHOT_WIDTH = 1280

    fun attach(activity: Activity) { active = WeakReference(activity) }
    fun detach(activity: Activity) {
        if (active.get() === activity) active = WeakReference<Activity>(null)
    }

    private fun findTexture(v: View): TextureView? {
        if (v is TextureView) return v
        if (v is ViewGroup) for (i in 0 until v.childCount) {
            findTexture(v.getChildAt(i))?.let { return it }
        }
        return null
    }

    private fun containsTexture(v: View): Boolean = findTexture(v) != null

    private fun drawAt(canvas: Canvas, decor: View, view: View) {
        if (view.visibility != View.VISIBLE || view.width <= 0 || view.height <= 0) return
        val a = IntArray(2); val d = IntArray(2)
        view.getLocationInWindow(a); decor.getLocationInWindow(d)
        canvas.save()
        canvas.translate((a[0]-d[0]).toFloat(), (a[1]-d[1]).toFloat())
        view.draw(canvas)
        canvas.restore()
    }

    private fun drawPlayerOverlays(canvas: Canvas, decor: View, playerView: PlayerView) {
        for (i in 0 until playerView.childCount) {
            val child = playerView.getChildAt(i)
            if (!containsTexture(child)) drawAt(canvas, decor, child)
        }
    }

    private fun overlayByName(activity: Activity, canvas: Canvas, decor: View, name: String) {
        val id = activity.resources.getIdentifier(name, "id", activity.packageName)
        if (id != 0) activity.findViewById<View>(id)?.let { drawAt(canvas, decor, it) }
    }

    fun capturePng(): ByteArray? {
        val activity = active.get() ?: return null
        if (activity.isFinishing || activity.isDestroyed) return null
        if (Looper.myLooper() == Looper.getMainLooper()) return null

        val latch = CountDownLatch(1)
        var captured: Bitmap? = null

        // Only the actual view/TextureView read happens on the UI thread. PNG compression is
        // deliberately done below on the WebInterface worker thread so taking a screenshot
        // cannot stall Media3 playback for hundreds of milliseconds.
        Handler(Looper.getMainLooper()).post {
            var frame: Bitmap? = null
            try {
                val decor = activity.window.decorView
                if (decor.width <= 0 || decor.height <= 0 || !decor.isShown) return@post

                val scale = minOf(1f, MAX_SCREENSHOT_WIDTH.toFloat() / decor.width.toFloat())
                val outW = (decor.width * scale).toInt().coerceAtLeast(1)
                val outH = (decor.height * scale).toInt().coerceAtLeast(1)
                val outBitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(outBitmap)
                canvas.drawColor(Color.BLACK)
                canvas.scale(scale, scale)

                val playerId = activity.resources.getIdentifier(
                    if (activity is PlayerActivity) "playerView" else "miniPlayer",
                    "id", activity.packageName
                )
                val pv = if (playerId != 0) activity.findViewById<PlayerView>(playerId) else null
                val tv = pv?.let { findTexture(it) }

                if (pv != null && tv != null && tv.isAvailable && pv.visibility == View.VISIBLE) {
                    val fw=(pv.width*scale).toInt().coerceAtLeast(1)
                    val fh=(pv.height*scale).toInt().coerceAtLeast(1)
                    frame = tv.getBitmap(fw,fh)
                    frame?.let {
                        val p = IntArray(2); val d = IntArray(2)
                        pv.getLocationInWindow(p); decor.getLocationInWindow(d)
                        val left = p[0]-d[0]; val top = p[1]-d[1]
                        val dst = Rect(left, top, left + pv.width, top + pv.height)
                        canvas.drawBitmap(it, null, dst, null)
                    }
                    drawPlayerOverlays(canvas, decor, pv)

                    if (activity is PlayerActivity) {
                        overlayByName(activity, canvas, decor, "info")
                        overlayByName(activity, canvas, decor, "bufferingBox")
                        overlayByName(activity, canvas, decor, "aspect")
                    } else {
                        overlayByName(activity, canvas, decor, "liveFsInfo")
                        overlayByName(activity, canvas, decor, "liveBufferingBox")
                        overlayByName(activity, canvas, decor, "liveChannelDrawer")
                        overlayByName(activity, canvas, decor, "liveTrackDrawer")
                    }
                } else {
                    decor.draw(canvas)
                }
                captured = outBitmap
            } catch (_: Throwable) {
                captured = null
            } finally {
                try { frame?.recycle() } catch (_: Throwable) {}
                latch.countDown()
            }
        }

        if (!latch.await(1800, TimeUnit.MILLISECONDS)) return null
        val bitmap=captured ?: return null
        return try {
            ByteArrayOutputStream().use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                out.toByteArray()
            }
        } catch (_:Throwable) {
            null
        } finally {
            try { bitmap.recycle() } catch (_:Throwable) {}
        }
    }
}
