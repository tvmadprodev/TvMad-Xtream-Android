package pl.tvmad.xtream

data class Channel(val name:String,val url:String,val group:String="",val logo:String="",val epgId:String="")
data class Source(val type:String,val name:String,val host:String="",val user:String="",val pass:String="",val url:String="")
