package pl.tvmad.xtream

data class Channel(
    val name:String,
    val url:String,
    val group:String="",
    val logo:String="",
    val epgId:String="",
    val streamId:String=""
)

data class Source(val type:String,val name:String,val host:String="",val user:String="",val pass:String="",val url:String="")
data class EpgEvent(val title:String,val start:String="",val end:String="")
data class MediaCategory(val id:String,val name:String)
data class MediaItem(val id:String,val name:String,val categoryId:String="",val icon:String="",val ext:String="mp4",val url:String="")
data class SeriesItem(val id:String,val name:String,val categoryId:String="",val cover:String="")
data class SeasonItem(val id:String,val name:String)
data class EpisodeItem(val id:String,val name:String,val ext:String="mp4",val season:String="")
