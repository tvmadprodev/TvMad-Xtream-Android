package pl.tvmad.xtream

import android.app.*
import android.animation.ValueAnimator
import android.os.*
import android.content.*
import android.graphics.BitmapFactory
import android.text.InputType
import android.text.Editable
import android.text.TextWatcher
import android.view.inputmethod.InputMethodManager
import android.view.*
import android.view.animation.LinearInterpolator
import android.widget.*
import androidx.media3.common.*
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.common.util.UnstableApi
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.text.SimpleDateFormat
import java.text.Normalizer
import java.util.Date
import java.util.Locale

@UnstableApi
class MainActivity:Activity(){
 private lateinit var list:ListView; private lateinit var channelList:ListView; private lateinit var posterGrid:GridView; private lateinit var status:TextView; private lateinit var sourceBar:View; private lateinit var dashboard:View; private lateinit var livePane:View; private lateinit var listPanel:View
 private lateinit var rootFrame:FrameLayout; private lateinit var baseContent:View; private lateinit var miniVideoSlot:View
 private lateinit var homeTimeBlock:View; private lateinit var homeServers:Button; private lateinit var homeOptions:Button; private lateinit var multiEpgButton:Button; private lateinit var homeClock:TextView; private lateinit var homeDay:TextView; private lateinit var homeDate:TextView; private lateinit var liveListCard:View
 private lateinit var miniPlayerView:PlayerView; private lateinit var miniPicon:ImageView; private lateinit var miniChannel:TextView; private lateinit var miniNow:TextView; private lateinit var miniDesc:TextView; private lateinit var miniProgress:ProgressBar
 private lateinit var liveFsInfo:View; private lateinit var fsNumber:TextView; private lateinit var fsPicon:ImageView; private lateinit var fsChannel:TextView; private lateinit var fsNow:TextView; private lateinit var fsNext:TextView; private lateinit var fsProgress:ProgressBar; private lateinit var fsAudio:Button; private lateinit var fsSubtitles:Button; private lateinit var fsClock:TextView; private lateinit var fsDate:TextView
 private lateinit var liveBufferingBox:View; private lateinit var liveBufferingText:TextView
 private lateinit var liveChannelDrawer:LinearLayout; private lateinit var liveChannelDrawerTitle:TextView; private lateinit var liveChannelDrawerList:ListView
 private lateinit var liveTrackDrawer:LinearLayout; private lateinit var liveTrackDrawerTitle:TextView; private lateinit var liveTrackDrawerList:ListView
 private val pool=Executors.newFixedThreadPool(2); private val epgPool=Executors.newFixedThreadPool(2); private val scanPool=Executors.newSingleThreadExecutor(); private val catalogPool=scanPool; private val searchPool=Executors.newSingleThreadExecutor(); private val externalEpgPool=Executors.newSingleThreadExecutor{r->Thread(r,"TvMad-XMLTV").apply{priority=Thread.NORM_PRIORITY}}; private val handler=Handler(Looper.getMainLooper())
 private val autoServerRefresh=object:Runnable{override fun run(){val src=selectedSource;if(src!=null&&src.type!="e2"&&screen==Screen.HOME){scheduleLiveRefresh(src);scheduleCatalogSync(src)};handler.postDelayed(this,30L*60L*1000L)}}
 private var miniPlayer:ExoPlayer?=null; private var miniGeneration=0; private var miniCurrentChannel:Channel?=null; private var piconAdapter:PiconAdapter?=null; private var posterAdapter:PosterGridAdapter?=null
 private var visibleChannels=listOf<Channel>(); private var groups=listOf<LiveGroup>(); private var currentLiveGroup:LiveGroup?=null; private var sources=mutableListOf<Source>(); private var selectedSource:Source?=null; private var piconMode=2
 private var lastChannelListSelection=-1
 private var vodCats=listOf<MediaCategory>(); private var vodItems=listOf<MediaItem>(); private var currentVodCat:MediaCategory?=null
 private var seriesCats=listOf<MediaCategory>(); private var seriesItems=listOf<SeriesItem>(); private var currentSeriesCat:MediaCategory?=null; private var seasons=listOf<SeasonItem>(); private var seasonEpisodes:Map<String,List<EpisodeItem>> = emptyMap(); private var episodes=listOf<EpisodeItem>(); private var selectedSeries:SeriesItem?=null
 private var allVodItems=listOf<MediaItem>(); private var allSeriesItems=listOf<SeriesItem>(); private var searchVodItems=listOf<MediaItem>(); private var searchSeriesItems=listOf<SeriesItem>(); private var recentEntries=listOf<VodHistoryEntry>()
 private lateinit var vodSidePanel:LinearLayout; private lateinit var vodSearchBox:EditText; private lateinit var vodRecentButton:Button; private var vodSidePanelOpen=false; private var vodSidePanelSeries=false; private var vodPanelTextReset=false; private var searchGeneration=0; private var searchRenderGeneration=0; private var searchPaintGeneration=0; private var searchDebounce:Runnable?=null
 private var vodCatalogSourceKey=""; private var seriesCatalogSourceKey=""; private var vodCatalogLoadingKey=""; private var seriesCatalogLoadingKey=""
 private val searchMarksRegex=Regex("\\p{Mn}+"); private val searchNonWordRegex=Regex("[^\\p{L}\\p{N}]+")
 private var favorites=mutableListOf<Channel>(); private val epgText=ConcurrentHashMap<String,String>(); private val epgEvents=ConcurrentHashMap<String,List<EpgEvent>>(); private val epgPending=ConcurrentHashMap.newKeySet<String>()
 private var web:WebConfigServer?=null; private val catalogSyncing=ConcurrentHashMap.newKeySet<String>(); private val liveGroupsSyncing=ConcurrentHashMap.newKeySet<String>(); private val externalEpgSyncing=ConcurrentHashMap.newKeySet<String>()
 private enum class Screen { SOURCES, HOME, LIVE_GROUPS, LIVE_CHANNELS, VOD_CATS, VOD_ITEMS, VOD_SEARCH, VOD_RECENT, SERIES_CATS, SERIES_ITEMS, SERIES_SEARCH, SERIES_RECENT, SEASONS, EPISODES, FAVORITES }
 private var screen=Screen.SOURCES
 private data class Pos(val first:Int=0,val top:Int=0)
 private var liveGroupsPos=Pos();private var liveGroupSelected=0;private var liveGroupAnchorTop=0;private var liveChannelSelected=0;private var vodCatsPos=Pos();private var vodItemSelected=0;private var seriesCatsPos=Pos();private var seriesItemSelected=0;private var seriesItemsPos=Pos();private var seasonsPos=Pos()
 private var liveFullscreen=false;private var liveSurfaceReady=false;private var liveListenerInstalled=false;private var liveHasPlayed=false;private var liveRetryCount=0;private var liveRetryScheduled=false;private var suppressLiveBufferUntil=0L;private var liveRecoveryArmed=false
 private var liveChannelDrawerOpen=false;private var liveTrackDrawerOpen=false;private var liveDrawerSelected=0;private var liveTrackSelected=0;private var liveChannelPageStart=0;private var liveDrawerPageStart=0
 private var liveDrawerAdapter:FullscreenChannelAdapter?=null;private var liveTrackChoices=listOf<LiveTrackPanelChoice>()
 private var miniEventAnimator:ValueAnimator?=null
 private var miniEventScrollToken=0
 private lateinit var multiEpgOverlay:LinearLayout; private lateinit var multiEpgGrid:MultiEpgGridView; private lateinit var multiEpgGroupTitle:TextView; private lateinit var multiEpgEventTitle:TextView; private lateinit var multiEpgEventTime:TextView; private lateinit var multiEpgDesc:TextView; private lateinit var multiEpgProgress:ProgressBar
 private var multiEpgOpen=false; private var multiEpgReturnChannel=0; private val multiEpgSchedules=ConcurrentHashMap<String,List<EpgEvent>>(); private val multiEpgPending=ConcurrentHashMap.newKeySet<String>(); private val multiEpgPicons=ConcurrentHashMap.newKeySet<String>(); private var multiEpgDescAnimator:ValueAnimator?=null; private var multiEpgDescToken=0
 private val hideLiveInfo=Runnable{if(liveFullscreen)liveFsInfo.visibility=View.GONE}
 private val liveProgressTick=object:Runnable{override fun run(){
  refreshEpgClock()
  handler.postDelayed(this,10000)
 }}
 private val liveBufferTick=object:Runnable{override fun run(){if(liveBufferingBox.visibility==View.VISIBLE){liveBufferingText.text="Buforowanie ${(miniPlayer?.bufferedPercentage?:0).coerceIn(0,100)}%";handler.postDelayed(this,250)}}}
 private val liveRetry=Runnable{liveRetryScheduled=false;if(liveBufferingBox.visibility==View.VISIBLE&&liveRetryCount<3){liveRetryCount++;LivePlayerSession.restartCurrent();scheduleLiveRetry()}}

 override fun onCreate(b:Bundle?){
  super.onCreate(b);setContentView(R.layout.activity_main)
  rootFrame=findViewById(R.id.rootFrame);baseContent=findViewById(R.id.baseContent);miniVideoSlot=findViewById(R.id.miniVideoSlot);homeTimeBlock=findViewById(R.id.homeTimeBlock);homeServers=findViewById(R.id.homeServers);homeOptions=findViewById(R.id.homeOptions);multiEpgButton=findViewById(R.id.multiEpgButton);homeClock=findViewById(R.id.homeClock);homeDay=findViewById(R.id.homeDay);homeDate=findViewById(R.id.homeDate);liveListCard=findViewById(R.id.liveListCard)
  list=findViewById(R.id.list);channelList=findViewById(R.id.channelList);posterGrid=findViewById(R.id.posterGrid);status=findViewById(R.id.status);sourceBar=findViewById(R.id.sourceBar);dashboard=findViewById(R.id.dashboard);livePane=findViewById(R.id.livePane);listPanel=findViewById(R.id.listPanel)
  miniPlayerView=findViewById(R.id.miniPlayer);miniPicon=findViewById(R.id.miniPicon);miniChannel=findViewById(R.id.miniChannel);miniNow=findViewById(R.id.miniNow);miniDesc=findViewById(R.id.miniDesc);miniProgress=findViewById(R.id.miniProgress)
  liveFsInfo=findViewById(R.id.liveFsInfo);fsNumber=findViewById(R.id.fsNumber);fsPicon=findViewById(R.id.fsPicon);fsChannel=findViewById(R.id.fsChannel);fsNow=findViewById(R.id.fsNow);fsNext=findViewById(R.id.fsNext);fsProgress=findViewById(R.id.fsProgress);fsAudio=findViewById(R.id.fsAudio);fsSubtitles=findViewById(R.id.fsSubtitles);fsClock=findViewById(R.id.fsClock);fsDate=findViewById(R.id.fsDate);liveBufferingBox=findViewById(R.id.liveBufferingBox);liveBufferingText=findViewById(R.id.liveBufferingText)
  setupLiveSidePanels();setupVodSidePanel();setupMultiEpg()
  miniPlayerView.useController=false;miniPlayerView.setKeepContentOnPlayerReset(true);miniPlayerView.resizeMode=androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
  fsAudio.setOnClickListener{showLiveTrackDialog(C.TRACK_TYPE_AUDIO,"Ścieżka audio")};fsSubtitles.setOnClickListener{showLiveTrackDialog(C.TRACK_TYPE_TEXT,"Napisy")}
  sources=SourceStore.load(this);favorites=FavoriteStore.load(this)
  findViewById<Button>(R.id.addXtream).setOnClickListener{xtreamDialog()};findViewById<Button>(R.id.addM3u).setOnClickListener{m3uDialog()};findViewById<Button>(R.id.addE2).setOnClickListener{e2Dialog()}
  findViewById<Button>(R.id.piconMode).setOnClickListener{v->piconMode=(piconMode+1)%3;(v as Button).text="Picony: "+arrayOf("lokalne","źródło","oba")[piconMode];if(screen==Screen.LIVE_CHANNELS||screen==Screen.FAVORITES)refreshChannelsAdapter()}
  homeServers.setOnClickListener{showSources()};homeOptions.setOnClickListener{showOptionsMenu()};multiEpgButton.setOnClickListener{openMultiEpg()};multiEpgButton.setOnKeyListener{_,key,e->if(e.action==KeyEvent.ACTION_DOWN&&(key==KeyEvent.KEYCODE_DPAD_LEFT||key==KeyEvent.KEYCODE_DPAD_DOWN)){channelList.requestFocus();true}else false};findViewById<View>(R.id.tileLive).setOnClickListener{loadLive()};findViewById<View>(R.id.tileVod).setOnClickListener{loadVodCategories()};findViewById<View>(R.id.tileSeries).setOnClickListener{loadSeriesCategories()}
  list.setOnItemClickListener{_,_,i,_->onItem(i)};list.setOnItemLongClickListener{_,_,i,_->onLongItem(i)};posterGrid.setOnItemClickListener{_,_,i,_->onItem(i)};posterGrid.setOnItemLongClickListener{_,_,i,_->onPosterLongItem(i)};posterGrid.setOnItemSelectedListener(object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){if(screen==Screen.VOD_ITEMS)vodItemSelected=pos else if(screen==Screen.SERIES_ITEMS)seriesItemSelected=pos;updatePosterSelection(pos)}})
  channelList.setOnItemClickListener{_,_,i,_->onChannelItem(i)};channelList.setOnItemLongClickListener{_,_,i,_->if(screen==Screen.LIVE_CHANNELS&&i in visibleChannels.indices){showChannelOptions(visibleChannels[i]);true}else false}
  channelList.setOnItemSelectedListener(object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){
   lastChannelListSelection=pos
   // W LIVE zaznaczenie jest sterowane przez liveChannelSelected, niezależnie od kotwicy ListView.
   // Dzięki temu Android nie przewija listy o kilka pikseli przy każdym DPAD góra/dół.
   if(screen!=Screen.LIVE_CHANNELS)piconAdapter?.notifyDataSetChanged()}})
  channelList.setOnKeyListener{_,key,e->if(e.action!=KeyEvent.ACTION_DOWN)false else when{screen==Screen.LIVE_CHANNELS&&key==KeyEvent.KEYCODE_DPAD_UP->{moveMainChannelSelection(-1);true};screen==Screen.LIVE_CHANNELS&&key==KeyEvent.KEYCODE_DPAD_DOWN->{moveMainChannelSelection(1);true};screen==Screen.LIVE_CHANNELS&&key==KeyEvent.KEYCODE_DPAD_RIGHT->{multiEpgButton.requestFocus();true};key==KeyEvent.KEYCODE_DPAD_CENTER||key==KeyEvent.KEYCODE_ENTER->{val pos=if(screen==Screen.LIVE_CHANNELS)liveChannelSelected else channelList.selectedItemPosition;if(pos>=0){onChannelItem(pos);true}else false};else->false}}
  web=WebConfigServer(applicationContext,5557,{PiconMemoryCache.clear();runOnUiThread{sources=SourceStore.load(this);selectedSource?.let{cur->sources.firstOrNull{sourceScanKey(it)==sourceScanKey(cur)}?.let{fresh->selectedSource=fresh;scheduleExternalEpgRefresh(fresh)}};if(screen==Screen.SOURCES)showSources();refreshChannelsAdapter()}},{AppScreenshotBridge.capturePng()}).also{it.start()}
  startAtHome()
 }


 private fun startAtHome(){
  val saved=LastLiveStore.load(this)
  val src=saved?.let{sv->sources.firstOrNull{LastLiveStore.sourceMatches(sv.source,it)}}?:sources.firstOrNull()
  selectedSource=src;visibleChannels=emptyList();currentLiveGroup=null
  if(src!=null && src.type!="e2"){
   groups=LiveCacheStore.loadGroups(this,src).filterNot{it.name.equals("Other",true)}
  }else groups=emptyList()
  showHome()
  if(src!=null && src.type!="e2"){
   if(groups.isEmpty()) scheduleLiveRefresh(src) else scheduleIdleRefresh(src)
   scheduleExternalEpgRefresh(src)
  }else if(src?.type=="e2"){
   status.text="${src.name}  •  Enigma2 / OpenWebIF  •  Live TV bezpośrednio z dekodera"
  }
 }

 private fun fetchAndCacheLiveGroups(src:Source):List<LiveGroup>{
  if(src.type=="m3u"){
   val catalog=Api.m3uCatalog(src.url)
   val fresh=catalog.groups.filterNot{it.name.equals("Other",true)}
   LiveCacheStore.saveGroups(this,src,fresh)
   val byGroup=catalog.channels.groupBy{it.group.lowercase(Locale.ROOT)}
   for(g in fresh){
    val rows=byGroup[g.name.lowercase(Locale.ROOT)].orEmpty().map{it.copy(group=g.name,groupId=g.id)}
    LiveCacheStore.saveGroupChannels(this,src,g,rows)
   }
   return fresh
  }
  val fresh=Api.liveGroups(src).filterNot{it.name.equals("Other",true)}
  LiveCacheStore.saveGroups(this,src,fresh)
  return fresh
 }

 private fun ensureLiveGroups(then:()->Unit){
  val src=selectedSource?:run{status.text="Najpierw wybierz serwer";showSources();return}
  if(src.type=="e2"){
   status.text="Telewizja  •  pobieranie bouquetów z OpenWebIF…"
   pool.execute{
    try{val fresh=Api.liveGroups(src).filterNot{it.name.equals("Other",true)};runOnUiThread{if(selectedSource==src){groups=fresh;then()}}}
    catch(e:Exception){runOnUiThread{if(selectedSource==src)status.text="Telewizja  •  ${e.message.orEmpty()}"}}
   }
   return
  }
  if(groups.isNotEmpty()){then();return}
  val key=sourceScanKey(src)
  if(liveGroupsSyncing.contains(key)){handler.postDelayed({if(selectedSource==src)ensureLiveGroups(then)},250);return}
  status.text="Telewizja  •  ładowanie grup…"
  if(!liveGroupsSyncing.add(key))return
  scanPool.execute{
   try{
    val fresh=fetchAndCacheLiveGroups(src)
    runOnUiThread{if(selectedSource==src){groups=fresh;then()}}
   }catch(e:Exception){runOnUiThread{if(selectedSource==src)status.text="Telewizja  •  ${e.message.orEmpty()}"}}
   finally{liveGroupsSyncing.remove(key)}
  }
 }

 private fun findGroupFor(c:Channel):LiveGroup? {
  if(c.groupId.isNotBlank())groups.firstOrNull{it.id==c.groupId}?.let{return it}
  return groups.firstOrNull{it.name.equals(c.group,true)}
 }

 private fun openLastLiveOrGroups(){
  val src=selectedSource?:run{status.text="Najpierw wybierz serwer";showSources();return}
  ensureLiveGroups{
   val saved=LastLiveStore.load(this)
   val c=saved?.takeIf{LastLiveStore.sourceMatches(it.source,src)}?.channel
   val g=c?.let{findGroupFor(it)}
   if(c==null||g==null){showLiveGroups();return@ensureLiveGroups}
   liveGroupSelected=groups.indexOfFirst{it.id==g.id}.coerceAtLeast(0)
   // Po starcie ustawiamy grupę w okolicy środka listy, nie na początku wszystkich grup.
   liveGroupAnchorTop=(resources.displayMetrics.density*95f).toInt()
   openLiveGroup(g,c.url,true,c)
  }
 }

 private fun openLiveGroup(group:LiveGroup, selectUrl:String="", autoFullscreen:Boolean=false, fallbackChannel:Channel?=null){
  val src=selectedSource?:return
  currentLiveGroup=group
  // E2 nie używa cache kanałów: wejście do bouquetu zawsze czyta aktualną listę z OpenWebIF.
  if(src.type=="e2"){
   screen=Screen.LIVE_CHANNELS;applyTheme(2);setMode(live=true);visibleChannels=emptyList();refreshChannelsAdapter(false)
   status.text="${group.name}  •  pobieranie kanałów z OpenWebIF…"
   pool.execute{
    try{val fresh=Api.liveChannels(src,group);runOnUiThread{if(selectedSource==src&&currentLiveGroup?.id==group.id){showChannels(group,fresh,selectUrl);if(autoFullscreen){val c=fresh.firstOrNull{it.url==selectUrl}?:fallbackChannel;if(c!=null)channelList.post{startMini(c);enterLiveFullscreen(c,false);loadEpgForChannels(listOf(c))}}}}}
    catch(e:Exception){runOnUiThread{if(selectedSource==src&&currentLiveGroup?.id==group.id)status.text="${group.name}  •  ${e.message.orEmpty()}"}}
   }
   return
  }
  val cached=LiveCacheStore.loadGroupChannels(this,src,group)
  if(cached.isNotEmpty()){
   showChannels(group,cached,selectUrl)
   scheduleGroupRefresh(src,group)
   if(autoFullscreen){
    val c=cached.firstOrNull{it.url==selectUrl}?:fallbackChannel
    if(c!=null)channelList.post{startMini(c);enterLiveFullscreen(c,false);loadEpgForChannels(listOf(c))}
   }
   return
  }
  if(src.type=="m3u"&&liveGroupsSyncing.contains(sourceScanKey(src))){
   status.text="${group.name}  •  kończenie lekkiego skanu…"
   handler.postDelayed({if(selectedSource==src&&currentLiveGroup?.id==group.id)openLiveGroup(group,selectUrl,autoFullscreen,fallbackChannel)},250)
   return
  }
  screen=Screen.LIVE_CHANNELS;applyTheme(2);setMode(live=true);visibleChannels=emptyList();refreshChannelsAdapter(false)
  status.text="${group.name}  •  ładowanie kanałów…"
  pool.execute{
   try{
    val actualGroup:LiveGroup
    val fresh:List<Channel>
    if(src.type=="m3u"){
     val freshGroups=fetchAndCacheLiveGroups(src)
     actualGroup=freshGroups.firstOrNull{it.id==group.id}?:freshGroups.firstOrNull{it.name.equals(group.name,true)}?:group
     fresh=LiveCacheStore.loadGroupChannels(this,src,actualGroup)
     runOnUiThread{if(selectedSource==src)groups=freshGroups}
    }else{
     actualGroup=group;fresh=Api.liveChannels(src,group);LiveCacheStore.saveGroupChannels(this,src,group,fresh)
    }
    runOnUiThread{
     if(selectedSource==src&&currentLiveGroup?.id==group.id){
      currentLiveGroup=actualGroup;liveGroupSelected=groups.indexOfFirst{it.id==actualGroup.id}.takeIf{it>=0}?:liveGroupSelected
      showChannels(actualGroup,fresh,selectUrl)
      if(autoFullscreen){
       val c=fresh.firstOrNull{it.url==selectUrl}?:fallbackChannel
       if(c!=null)channelList.post{startMini(c);enterLiveFullscreen(c,false);loadEpgForChannels(listOf(c))}
      }
     }
    }
   }catch(e:Exception){runOnUiThread{if(selectedSource==src&&currentLiveGroup?.id==group.id)status.text="${group.name}  •  ${e.message.orEmpty()}"}}
  }
 }

 private fun scheduleGroupRefresh(src:Source,group:LiveGroup){
  if(src.type!="xtream")return
  pool.execute{try{LiveCacheStore.saveGroupChannels(this,src,group,Api.liveChannels(src,group))}catch(_:Exception){}}
 }

 private fun currentList():ListView=if(screen==Screen.LIVE_CHANNELS||screen==Screen.LIVE_GROUPS)channelList else list
 private fun position():Pos{val l:AbsListView=if(screen==Screen.VOD_ITEMS||screen==Screen.SERIES_ITEMS||screen==Screen.VOD_SEARCH||screen==Screen.SERIES_SEARCH||screen==Screen.VOD_RECENT||screen==Screen.SERIES_RECENT)posterGrid else currentList();return if(l.childCount>0)Pos(l.firstVisiblePosition,l.getChildAt(0).top)else Pos()}
 private fun restore(p:Pos){val l:AbsListView=if(screen==Screen.VOD_ITEMS||screen==Screen.SERIES_ITEMS||screen==Screen.VOD_SEARCH||screen==Screen.SERIES_SEARCH||screen==Screen.VOD_RECENT||screen==Screen.SERIES_RECENT)posterGrid else currentList();l.post{l.setSelectionFromTop(p.first,p.top)}}
 private fun setMode(sourcesMode:Boolean=false,home:Boolean=false,live:Boolean=false){sourceBar.visibility=if(sourcesMode)View.VISIBLE else View.GONE;dashboard.visibility=if(home)View.VISIBLE else View.GONE;homeServers.visibility=if(home)View.VISIBLE else View.GONE;homeOptions.visibility=if(home)View.VISIBLE else View.GONE;multiEpgButton.visibility=if(live&&screen==Screen.LIVE_CHANNELS)View.VISIBLE else View.GONE;homeTimeBlock.visibility=View.VISIBLE;updateClocks();livePane.visibility=if(live)View.VISIBLE else View.GONE;listPanel.visibility=if(!home&&!live)View.VISIBLE else View.GONE;val posters=!home&&!live&&(screen==Screen.VOD_ITEMS||screen==Screen.SERIES_ITEMS||screen==Screen.VOD_SEARCH||screen==Screen.SERIES_SEARCH||screen==Screen.VOD_RECENT||screen==Screen.SERIES_RECENT);posterGrid.visibility=if(posters)View.VISIBLE else View.GONE;list.visibility=if(!home&&!live&&!posters)View.VISIBLE else View.GONE}
 private fun updatePosterSelection(pos:Int){posterAdapter?.setSelectedPosition(pos);val first=posterGrid.firstVisiblePosition;for(i in 0 until posterGrid.childCount){val child=posterGrid.getChildAt(i);val selected=(first+i)==pos;child.isSelected=selected;val vg=child as? ViewGroup;val titleView=vg?.getChildAt(1) as? TextView;titleView?.isSelected=selected}}
 private fun applyTheme(kind:Int){val bg=when(kind){1->R.drawable.bg_home_premium;2->R.drawable.bg_live_premium;3->R.drawable.bg_vod_premium;4->R.drawable.bg_series_premium;else->R.drawable.bg_root};rootFrame.setBackgroundResource(bg);listPanel.setBackgroundResource(when(kind){2->R.drawable.panel_live_glass;3->R.drawable.panel_vod_glass;4->R.drawable.panel_series_glass;else->R.drawable.panel_glass});liveListCard.setBackgroundResource(R.drawable.panel_live_glass)}
 private fun updateClocks(){val now=Date();homeClock.text=SimpleDateFormat("HH:mm",Locale.getDefault()).format(now);homeDay.text=SimpleDateFormat("EEEE",Locale.getDefault()).format(now).replaceFirstChar{if(it.isLowerCase())it.titlecase(Locale.getDefault()) else it.toString()};homeDate.text=SimpleDateFormat("d MMM yyyy",Locale.getDefault()).format(now);fsClock.text=SimpleDateFormat("HH:mm",Locale.getDefault()).format(now);fsDate.text=SimpleDateFormat("d MMM yyyy",Locale.getDefault()).format(now)}
 private fun field(h:String)=EditText(this).apply{hint=h;setSingleLine(true)}
 private fun xtreamDialog(){val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,0,28,0)};val n=field("Nazwa serwera, np. Dom");val h=field("http://serwer:port");val u=field("Użytkownik");val p=field("Hasło").apply{inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD};val e=field("Dodatkowe EPG XMLTV URL (.xml lub .gz)");listOf(n,h,u,p,e).forEach{box.addView(it)};AlertDialog.Builder(this).setTitle("Dodaj Xtream Codes").setView(box).setPositiveButton("Zapisz i wczytaj"){_,_->val host=h.text.toString().trim();saveAndLoad(Source("xtream",n.text.toString().trim().ifBlank{host},host,u.text.toString(),p.text.toString(),epgUrl=e.text.toString().trim()))}.setNegativeButton("Anuluj",null).show()}
 private fun m3uDialog(){val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,0,28,0)};val n=field("Nazwa listy");val u=field("Pełny URL listy M3U");val e=field("Dodatkowe EPG XMLTV URL (.xml lub .gz)");listOf(n,u,e).forEach{box.addView(it)};AlertDialog.Builder(this).setTitle("Dodaj M3U").setView(box).setPositiveButton("Zapisz i wczytaj"){_,_->val url=u.text.toString().trim();saveAndLoad(Source("m3u",n.text.toString().trim().ifBlank{"M3U ${sources.size+1}"},url=url,epgUrl=e.text.toString().trim()))}.setNegativeButton("Anuluj",null).show()}

 private fun e2Dialog(){
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,0,28,0)}
  val n=field("Nazwa dekodera, np. SF8008");val h=field("IP / host, np. 192.168.8.115")
  val wp=field("Port OpenWebIF (domyślnie 80)").apply{inputType=InputType.TYPE_CLASS_NUMBER;setText("80")}
  val sp=field("Port streamu (domyślnie 8001)").apply{inputType=InputType.TYPE_CLASS_NUMBER;setText("8001")}
  val u=field("Użytkownik OpenWebIF (np. root)");val pa=field("Hasło OpenWebIF").apply{inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
  val zap=CheckBox(this).apply{text="Przełączaj kanał także na dekoderze (ZAP)";isChecked=false}
  val piconLabel=TextView(this).apply{text="Picony Enigma2:";setPadding(0,12,0,0)}
  val picons=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("Z WebInterface Enigma2","Lokalne TvMad"));setSelection(0)}
  listOf<View>(n,h,wp,sp,u,pa,zap,piconLabel,picons).forEach{box.addView(it)}
  val dlg=AlertDialog.Builder(this).setTitle("Dodaj Enigma2 / OpenWebIF").setView(box).setPositiveButton("Zapisz i wczytaj",null).setNeutralButton("Test połączenia",null).setNegativeButton("Anuluj",null).create()
  dlg.setOnShowListener{
   fun value()=Source("e2",n.text.toString().trim().ifBlank{h.text.toString().trim()},h.text.toString().trim(),u.text.toString().trim(),pa.text.toString(),webPort=wp.text.toString().toIntOrNull()?:80,streamPort=sp.text.toString().toIntOrNull()?:8001,e2ZapOnBox=zap.isChecked,e2PiconSource=if(picons.selectedItemPosition==1)"local" else "web")
   dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener{val src=value();pool.execute{try{val r=Api.e2Test(src);runOnUiThread{wp.setText(r.source.webPort.toString());Toast.makeText(this,r.message,Toast.LENGTH_LONG).show()}}catch(e:Exception){runOnUiThread{Toast.makeText(this,e.message?:"Brak połączenia",Toast.LENGTH_LONG).show()}}}}
   dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{val src=value();pool.execute{try{val r=Api.e2Test(src);runOnUiThread{wp.setText(r.source.webPort.toString());dlg.dismiss();saveAndLoad(r.source)}}catch(e:Exception){runOnUiThread{Toast.makeText(this,e.message?:"Brak połączenia",Toast.LENGTH_LONG).show()}}}}
  };dlg.show()
 }
 private fun editSource(i:Int){if(i !in sources.indices)return;val old=sources[i];val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,0,28,0)}
  if(old.type=="xtream"){val n=field("Nazwa serwera").apply{setText(old.name)};val h=field("http://serwer:port").apply{setText(old.host)};val u=field("Użytkownik").apply{setText(old.user)};val p=field("Hasło").apply{inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD;setText(old.pass)};val e=field("Dodatkowe EPG XMLTV URL (.xml lub .gz)").apply{setText(old.epgUrl)};listOf(n,h,u,p,e).forEach{box.addView(it)};AlertDialog.Builder(this).setTitle("Edytuj Xtream Codes").setView(box).setPositiveButton("Zapisz"){_,_->val host=h.text.toString().trim();val updated=old.copy(name=n.text.toString().trim().ifBlank{host},host=host,user=u.text.toString(),pass=p.text.toString(),epgUrl=e.text.toString().trim());sources[i]=updated;SourceStore.save(this,sources);if(sourceScanKey(selectedSource?:old)==sourceScanKey(old))selectedSource=updated;showSources()}.setNegativeButton("Anuluj",null).show()}
  else if(old.type=="e2"){
   val n=field("Nazwa dekodera").apply{setText(old.name)};val h=field("IP / host").apply{setText(old.host)};val wp=field("Port OpenWebIF").apply{inputType=InputType.TYPE_CLASS_NUMBER;setText(old.webPort.toString())};val sp=field("Port streamu").apply{inputType=InputType.TYPE_CLASS_NUMBER;setText(old.streamPort.toString())};val u=field("Użytkownik OpenWebIF").apply{setText(old.user)};val pa=field("Hasło OpenWebIF").apply{inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD;setText(old.pass)}
   val zap=CheckBox(this).apply{text="Przełączaj kanał także na dekoderze (ZAP)";isChecked=old.e2ZapOnBox}
   val piconLabel=TextView(this).apply{text="Picony Enigma2:";setPadding(0,12,0,0)};val picons=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("Z WebInterface Enigma2","Lokalne TvMad"));setSelection(if(old.e2PiconSource.equals("local",true))1 else 0)}
   listOf<View>(n,h,wp,sp,u,pa,zap,piconLabel,picons).forEach{box.addView(it)}
   val dlg=AlertDialog.Builder(this).setTitle("Edytuj Enigma2 / OpenWebIF").setView(box).setPositiveButton("Zapisz",null).setNeutralButton("Test połączenia",null).setNegativeButton("Anuluj",null).create()
   dlg.setOnShowListener{
    fun value()=old.copy(name=n.text.toString().trim().ifBlank{h.text.toString().trim()},host=h.text.toString().trim(),user=u.text.toString().trim(),pass=pa.text.toString(),webPort=wp.text.toString().toIntOrNull()?:80,streamPort=sp.text.toString().toIntOrNull()?:8001,e2ZapOnBox=zap.isChecked,e2PiconSource=if(picons.selectedItemPosition==1)"local" else "web")
    dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener{val src=value();pool.execute{try{val r=Api.e2Test(src);runOnUiThread{wp.setText(r.source.webPort.toString());Toast.makeText(this,r.message,Toast.LENGTH_LONG).show()}}catch(e:Exception){runOnUiThread{Toast.makeText(this,e.message?:"Brak połączenia",Toast.LENGTH_LONG).show()}}}}
    dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{val src=value();pool.execute{try{val r=Api.e2Test(src);runOnUiThread{val updated=r.source;sources[i]=updated;SourceStore.save(this,sources);if(sourceScanKey(selectedSource?:old)==sourceScanKey(old))selectedSource=updated;dlg.dismiss();showSources()}}catch(e:Exception){runOnUiThread{Toast.makeText(this,e.message?:"Brak połączenia",Toast.LENGTH_LONG).show()}}}}
   };dlg.show()
  }
  else{val n=field("Nazwa listy").apply{setText(old.name)};val u=field("Pełny URL listy M3U").apply{setText(old.url)};val e=field("Dodatkowe EPG XMLTV URL (.xml lub .gz)").apply{setText(old.epgUrl)};listOf(n,u,e).forEach{box.addView(it)};AlertDialog.Builder(this).setTitle("Edytuj M3U").setView(box).setPositiveButton("Zapisz"){_,_->val url=u.text.toString().trim();val updated=old.copy(name=n.text.toString().trim().ifBlank{"M3U"},url=url,epgUrl=e.text.toString().trim());sources[i]=updated;SourceStore.save(this,sources);if(sourceScanKey(selectedSource?:old)==sourceScanKey(old))selectedSource=updated;showSources()}.setNegativeButton("Anuluj",null).show()}
 }
 private fun showSourceOptions(i:Int){if(i !in sources.indices)return;val s=sources[i];AlertDialog.Builder(this).setTitle(s.name).setItems(arrayOf("Edytuj","Usuń")){_,which->if(which==0)editSource(i)else confirmDelete(i)}.setNegativeButton("Anuluj",null).show()}
 private fun saveAndLoad(src:Source){val same=sources.indexOfFirst{sourceScanKey(it)==sourceScanKey(src)};val saved=if(same>=0&&src.epgUrl.isBlank())src.copy(epgUrl=sources[same].epgUrl,expiry=sources[same].expiry) else src;if(same>=0)sources[same]=saved else sources.add(saved);SourceStore.save(this,sources);loadSource(saved)}
 private fun firstScanPrefs()=getSharedPreferences("first_server_scan_v1",Context.MODE_PRIVATE)
 private fun firstScanDone(src:Source)=firstScanPrefs().getBoolean(sourceScanKey(src),false)
 private fun markFirstScanDone(src:Source){firstScanPrefs().edit().putBoolean(sourceScanKey(src),true).apply()}
 private fun runFirstServerScan(src:Source){
  selectedSource=src;epgText.clear();epgEvents.clear();epgPending.clear();visibleChannels=emptyList();currentLiveGroup=null
  showSources()
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(36,12,36,8)}
  val msg=TextView(this).apply{text="Może to zająć kilka minut.\nProszę czekać.";textSize=16f;setPadding(0,0,0,18)}
  val bar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progress=0;isIndeterminate=false}
  val pct=TextView(this).apply{text="0%";textSize=14f;gravity=Gravity.CENTER_HORIZONTAL;setPadding(0,8,0,4)}
  box.addView(msg);box.addView(bar,LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT));box.addView(pct)
  val dlg=AlertDialog.Builder(this).setTitle("Pierwsze skanowanie serwera...").setView(box).setCancelable(false).create();dlg.show()
  fun progress(v:Int,t:String){runOnUiThread{if(dlg.isShowing){bar.progress=v.coerceIn(0,100);pct.text="${v.coerceIn(0,100)}%";msg.text="Może to zająć kilka minut.\nProszę czekać.\n\n$t"}}}
  val key=sourceScanKey(src);if(!liveGroupsSyncing.add(key)){dlg.dismiss();return}
  scanPool.execute{
   var liveCount=0;var vodCount=0;var seriesCount=0;var liveGroups=emptyList<LiveGroup>()
   try{
    progress(4,"Pobieranie grup kanałów...")
    liveGroups=fetchAndCacheLiveGroups(src)
    progress(12,"Grupy kanałów: ${liveGroups.size}")
    if(src.type=="m3u"){
     for((i,g) in liveGroups.withIndex()){
      liveCount+=LiveCacheStore.loadGroupChannels(this,src,g).size
      val v=12+((i+1)*43/(liveGroups.size.coerceAtLeast(1)));progress(v,"Zapisywanie kanałów LIVE: $liveCount")
     }
    }else{
     val workers=Executors.newFixedThreadPool(3)
     try{
      val cs=java.util.concurrent.ExecutorCompletionService<Int>(workers)
      liveGroups.forEach{g->cs.submit<Int>{try{val rows=Api.liveChannels(src,g);LiveCacheStore.saveGroupChannels(this,src,g,rows);rows.size}catch(_:Exception){0}}}
      for(i in liveGroups.indices){liveCount+=cs.take().get();val v=12+((i+1)*43/(liveGroups.size.coerceAtLeast(1)));progress(v,"Kanały LIVE: $liveCount")}
     }finally{workers.shutdownNow()}
    }
    val xc=Api.xtreamParams(src)
    if(xc!=null){
     progress(58,"Aktualizowanie filmów i seriali...")
     val mediaWorkers=Executors.newFixedThreadPool(2)
     try{
      val vf=mediaWorkers.submit<Int>{try{val v=Api.vodCategories(src);CatalogCacheStore.saveVodCategories(this,src,v);Api.vodCount(src)}catch(_:Exception){0}}
      val sf=mediaWorkers.submit<Int>{try{val se=Api.seriesCategories(src);CatalogCacheStore.saveSeriesCategories(this,src,se);Api.seriesCount(src)}catch(_:Exception){0}}
      vodCount=vf.get();progress(77,"Filmy VOD: $vodCount")
      seriesCount=sf.get();progress(96,"Seriale: $seriesCount")
     }finally{mediaWorkers.shutdownNow()}
    }else progress(96,"Kończenie skanowania...")
    markFirstScanDone(src)
    progress(100,"Gotowe")
    runOnUiThread{
     if(selectedSource==src){groups=liveGroups}
     if(dlg.isShowing){
      dlg.setTitle("Skanowanie zakończone")
      msg.text="Kanały LIVE: $liveCount\nFilmy VOD: $vodCount\nSeriale: $seriesCount"
      bar.progress=100;pct.text="100%"
      dlg.setButton(AlertDialog.BUTTON_POSITIVE,"OK"){_,_->if(selectedSource==src){showSources();scheduleExternalEpgRefresh(src);scheduleIdleRefresh(src)}}
     }
    }
   }catch(e:Exception){
    runOnUiThread{if(dlg.isShowing){dlg.setTitle("Skanowanie zakończone");msg.text="Nie udało się dokończyć pierwszego skanu.\n${e.message.orEmpty()}";dlg.setButton(AlertDialog.BUTTON_POSITIVE,"OK"){_,_->showSources()}}}
   }finally{liveGroupsSyncing.remove(key)}
  }
 }
 private fun confirmDelete(i:Int){val s=sources[i];AlertDialog.Builder(this).setTitle("Usunąć serwer?").setMessage(s.name).setPositiveButton("Usuń"){_,_->sources.removeAt(i);SourceStore.save(this,sources);showSources()}.setNegativeButton("Anuluj",null).show()}
 private fun showSources(){releaseMini();miniCurrentChannel=null;screen=Screen.SOURCES;visibleChannels=emptyList();applyTheme(0);setMode(sourcesMode=true);val addr=web?.address()?.removePrefix("http://")?:"IP urządzenia:5557";status.text="WebInfo: $addr  •  dodawanie serwerów z telefonu/PC przez IP i port";list.adapter=TvListAdapter(this,sources.map{val kind=when(it.type){"xtream"->"XCODES";"e2"->"ENIGMA2";else->"M3U"};val exp=it.expiry.takeIf{x->x.isNotBlank()}?.let{x->"  •  ważny do: $x"}.orEmpty();"$kind  •  ${it.name}$exp"},0);list.requestFocus();refreshSourceExpiries()}
 private fun loadSource(src:Source){
  // Enigma2/OpenWebIF działa bez importu i bez pierwszego skanu. Bouquety i kanały
  // są pobierane bezpośrednio z dekodera dopiero po wejściu do LIVE / wybranej grupy.
  if(src.type=="e2"){
   selectedSource=src;epgText.clear();epgEvents.clear();epgPending.clear();visibleChannels=emptyList();currentLiveGroup=null;groups=emptyList()
   showHome();status.text="${src.name}  •  Enigma2 / OpenWebIF  •  Live TV bezpośrednio z dekodera"
   return
  }
  if(!firstScanDone(src)){runFirstServerScan(src);return}
  selectedSource=src;epgText.clear();epgEvents.clear();epgPending.clear();visibleChannels=emptyList();currentLiveGroup=null
  groups=LiveCacheStore.loadGroups(this,src).filterNot{it.name.equals("Other",true)}
  showHome()
  scheduleExternalEpgRefresh(src)
  if(groups.isEmpty()){status.text="${src.name}  •  trwa lekki skan grup w tle";scheduleLiveRefresh(src)} else scheduleIdleRefresh(src)
  handler.removeCallbacks(autoServerRefresh);handler.postDelayed(autoServerRefresh,30L*60L*1000L)
 }

 private fun refreshSourceExpiries(){val snap=sources.toList();snap.forEach{src->if(src.type!="e2")pool.execute{val exp=Api.accountExpiry(src);if(exp.isNotBlank()&&exp!=src.expiry)runOnUiThread{val i=sources.indexOfFirst{sourceScanKey(it)==sourceScanKey(src)};if(i>=0){sources[i]=sources[i].copy(expiry=exp);SourceStore.save(this,sources);if(screen==Screen.SOURCES)showSources()}}}}}
 private fun sourceScanKey(src:Source)=when(src.type){"xtream"->"x|${src.host}|${src.user}";"e2"->"e2|${src.host}|${src.webPort}|${src.streamPort}|${src.user}";else->"m|${src.url}"}
 private fun scheduleIdleRefresh(src:Source){
  // Na słabszych Android Boxach nie skanujemy dużych list równolegle ze startem UI/playera.
  // Cichy refresh rusza dopiero po chwili i tylko gdy użytkownik nadal jest na ekranie głównym.
  handler.postDelayed({
   if(selectedSource==src && screen==Screen.HOME){scheduleLiveRefresh(src);scheduleCatalogSync(src)}
  },45000L)
 }
 private fun scheduleLiveRefresh(src:Source){
  if(groups.isNotEmpty()&&LiveCacheStore.groupsAgeMs(this,src)<30L*60L*1000L)return
  val key=sourceScanKey(src);if(!liveGroupsSyncing.add(key))return
  scanPool.execute{
   try{
    val fresh=fetchAndCacheLiveGroups(src)
    runOnUiThread{if(selectedSource==src&&groups.isEmpty()){groups=fresh;if(screen==Screen.HOME)status.text="${src.name}  •  wybierz dział"};if(selectedSource==src)scheduleExternalEpgRefresh(src)}
   }catch(_:Exception){}
   finally{liveGroupsSyncing.remove(key)}
  }
 }
 private fun scheduleCatalogSync(src:Source){
  if(Api.xtreamParams(src)==null)return
  val k=sourceScanKey(src);if(!catalogSyncing.add(k))return
  catalogPool.execute{
   try{
    // Lekki skan: tylko kategorie. Nie pobieramy całych bibliotek VOD/seriali przy starcie,
    // bo na słabszych boxach powodowało to skoki pamięci i crashe podczas LIVE.
    try{CatalogCacheStore.saveVodCategories(this,src,Api.vodCategories(src))}catch(_:Exception){}
    try{CatalogCacheStore.saveSeriesCategories(this,src,Api.seriesCategories(src))}catch(_:Exception){}
   }finally{catalogSyncing.remove(k)}
  }
 }
 private fun showHome(){releaseMini();screen=Screen.HOME;applyTheme(1);setMode(home=true);updateClocks();status.text="${selectedSource?.name?.takeIf{it.isNotBlank()}?:"Brak wybranego serwera"}  •  wybierz dział";findViewById<View>(R.id.tileLive).requestFocus()}
 private fun loadLive(){openLastLiveOrGroups()}
 private fun showLiveGroups(restorePos:Pos?=null){
  lastChannelListSelection=-1
  screen=Screen.LIVE_GROUPS;applyTheme(2);setMode(live=true);visibleChannels=emptyList();currentLiveGroup=null;piconAdapter?.close();piconAdapter=null
  groups=groups.filterNot{it.name.equals("Other",true)}
  status.text="Telewizja  •  ${groups.size} grup  •  OK = wejdź do grupy"
  channelList.adapter=TvListAdapter(this,groups.map{it.name},0)
  channelList.setOnScrollListener(null)
  channelList.post{
   channelList.clearChoices();channelList.choiceMode=AbsListView.CHOICE_MODE_NONE
   if(groups.isNotEmpty()){
    val idx=liveGroupSelected.coerceIn(0,groups.lastIndex)
    val top=if(restorePos!=null)liveGroupAnchorTop else (resources.displayMetrics.density*95f).toInt()
    channelList.setSelectionFromTop(idx,top)
   }
   channelList.requestFocus()
  }
  miniCurrentChannel?.let{c->updateMiniInfo(c);loadEpgForChannels(listOf(c));startMini(c)}
 }

 private fun showChannels(group:LiveGroup,channels:List<Channel>,selectUrl:String=""){
  lastChannelListSelection=-1
  screen=Screen.LIVE_CHANNELS;currentLiveGroup=group;applyTheme(2);setMode(live=true)
  // Zasada twarda: lista dostaje WYŁĄCZNIE kanały pobrane/zapisane dla tej jednej kategorii.
  visibleChannels=channels.filter{it.groupId==group.id || (it.groupId.isBlank()&&it.group.equals(group.name,true))}
  // Gdy użytkownik wchodzi do LIVE, zewnętrzne XMLTV ma być gotowe możliwie od razu.
  // Jeśli cache jest świeży, refreshIfDue kończy się natychmiast. Jeśli URL jest nowy
  // albo minęły 24 h, skan startuje od razu (bez dawnego 8-sekundowego opóźnienia).
  selectedSource?.let { scheduleExternalEpgRefresh(it,true) }
  status.text="${group.name}  •  ${visibleChannels.size} kanałów  •  OK = pełny ekran, przytrzymaj = opcje"
  if(selectUrl.isNotBlank())liveChannelSelected=visibleChannels.indexOfFirst{it.url==selectUrl}.takeIf{it>=0}?:liveChannelSelected
  if(visibleChannels.isNotEmpty())liveChannelSelected=liveChannelSelected.coerceIn(0,visibleChannels.lastIndex) else liveChannelSelected=0
  liveChannelPageStart=(liveChannelSelected/8)*8
  refreshChannelsAdapter(false);channelList.clearChoices();channelList.choiceMode=AbsListView.CHOICE_MODE_NONE
  channelList.setOnScrollListener(object:AbsListView.OnScrollListener{override fun onScrollStateChanged(v:AbsListView?,state:Int){if(state==AbsListView.OnScrollListener.SCROLL_STATE_IDLE)loadVisibleEpg()};override fun onScroll(v:AbsListView?,first:Int,count:Int,total:Int){}})
  channelList.post{
   if(visibleChannels.isNotEmpty()){positionPagedList(channelList,liveChannelSelected,8,visibleChannels.size,true);updateMiniInfo(visibleChannels[liveChannelSelected]);loadVisibleEpg()}
   channelList.requestFocus()
  }
  miniCurrentChannel?.takeIf{c->visibleChannels.any{it.url==c.url}}?.let{startMini(it)}
 }

 private fun loadVisibleEpg(){
  if(screen!=Screen.LIVE_CHANNELS||visibleChannels.isEmpty())return
  // EPG śledzi logiczną stronę/zaznaczenie, a nie chwilową pozycję ListView.
  // Dzięki temu po powrocie z fullscreen i przy skoku strony dane są ładowane
  // zanim ListView zdąży zakończyć pozycjonowanie swoich widoków.
  val selected=liveChannelSelected.coerceIn(0,visibleChannels.lastIndex)
  val pageStart=(selected/8)*8
  val from=(pageStart-8).coerceAtLeast(0)
  val to=(pageStart+16).coerceAtMost(visibleChannels.size)
  if(from<to)loadEpgForChannels(visibleChannels.subList(from,to))
 }
 private fun activePiconMode():Int = selectedSource?.takeIf{it.type=="e2"}?.let{if(it.e2PiconSource.equals("local",true))0 else 1} ?: piconMode
 private fun refreshChannelsAdapter(preserve:Boolean=true){if(screen!=Screen.LIVE_CHANNELS&&screen!=Screen.FAVORITES)return;val p=if(preserve)position()else Pos();val items=if(screen==Screen.FAVORITES)favorites else visibleChannels;piconAdapter?.close();piconAdapter=PiconAdapter(this,items,epgText,epgEvents,activePiconMode(),selectedSource,if(screen==Screen.LIVE_CHANNELS)liveChannelSelected else -1,if(screen==Screen.LIVE_CHANNELS)8 else 0);currentList().adapter=piconAdapter;if(preserve)restore(p)}

 private val refreshScheduled=AtomicBoolean(false)
 private fun scheduleEpgUiRefresh(){if(refreshScheduled.compareAndSet(false,true)){handler.postDelayed({refreshScheduled.set(false);if(screen==Screen.LIVE_CHANNELS||screen==Screen.FAVORITES)piconAdapter?.notifyDataSetChanged();if(screen==Screen.LIVE_CHANNELS){val pos=liveChannelSelected;if(pos in visibleChannels.indices)updateMiniInfo(visibleChannels[pos])}else if(screen==Screen.LIVE_GROUPS){miniCurrentChannel?.let{updateMiniInfo(it)}};if(liveFullscreen){updateFullscreenInfo(miniCurrentChannel);if(liveChannelDrawerOpen)liveDrawerAdapter?.notifyDataSetChanged()}},180)}}
 private fun loadEpgForChannels(items:List<Channel>,force:Boolean=false){
  val src=selectedSource?:return
  items.forEach { c ->
   if((force || epgEvents[c.url].isNullOrEmpty()) && epgPending.add(c.url)){
    epgPool.execute {
     try {
      var ev=Api.epgNowNext(src,c)
      if(ev.isEmpty())ev=ExternalEpgStore.nowNext(this,src,c)
      if(ev.isNotEmpty()){
       epgEvents[c.url]=ev
       if(miniCurrentChannel?.url==c.url)LiveCacheStore.saveLastEpg(this,src,c,ev)
       updateEpgText(c,ev.first())
      }
     } finally {
      epgPending.remove(c.url)
      scheduleEpgUiRefresh()
     }
    }
   }
  }
 }

 private fun updateEpgText(c:Channel,e:EpgEvent?){
  if(e==null){epgText.remove(c.url);return}
  val times=if(e.start.isNotBlank()||e.end.isNotBlank()) "${e.start} - ${e.end}  " else ""
  epgText[c.url]="$times${e.title}"
 }

 private fun refreshEpgClock(){
  val now=System.currentTimeMillis()
  val candidates=(visibleChannels + favorites + listOfNotNull(miniCurrentChannel)).distinctBy{it.url}
  val needsRefresh=ArrayList<Channel>()
  var changed=false
  for(c in candidates){
   val old=epgEvents[c.url].orEmpty()
   if(old.isEmpty())continue
   val first=old.first()
   if(first.endEpoch>0L && now>=first.endEpoch){
    val remaining=old.dropWhile{it.endEpoch>0L && now>=it.endEpoch}
    if(remaining.isNotEmpty()){
     epgEvents[c.url]=remaining
     updateEpgText(c,remaining.first())
    }else{
     epgEvents.remove(c.url)
     epgText.remove(c.url)
    }
    changed=true
    needsRefresh+=c
   }
  }
  if(changed || screen==Screen.LIVE_CHANNELS || screen==Screen.FAVORITES){
   if(screen==Screen.LIVE_CHANNELS||screen==Screen.FAVORITES)piconAdapter?.notifyDataSetChanged()
   if(screen==Screen.LIVE_CHANNELS){val pos=liveChannelSelected;if(pos in visibleChannels.indices)updateMiniInfo(visibleChannels[pos])}
   else if(screen==Screen.LIVE_GROUPS)miniCurrentChannel?.let{updateMiniInfo(it)}
   if(liveFullscreen){updateFullscreenInfo(miniCurrentChannel);if(liveChannelDrawerOpen)liveDrawerAdapter?.notifyDataSetChanged()}
  }
  if(needsRefresh.isNotEmpty())loadEpgForChannels(needsRefresh.distinctBy{it.url},true)
 }

 private fun scheduleExternalEpgRefresh(src:Source,immediate:Boolean=false){
  if(!ExternalEpgStore.isConfigured(src))return
  val key=sourceScanKey(src)+"|"+src.epgUrl
  val runScan={
   if(externalEpgSyncing.add(key)){
    externalEpgPool.execute{
     try{
      val changed=ExternalEpgStore.refreshIfDue(this,src)
      if(changed)runOnUiThread{
       if(selectedSource?.let{sourceScanKey(it)}==sourceScanKey(src)){
        val affected=(visibleChannels + listOfNotNull(miniCurrentChannel)).distinctBy{it.url}
        affected.forEach{c->epgText.remove(c.url);epgEvents.remove(c.url);epgPending.remove(c.url)}
        if(screen==Screen.LIVE_CHANNELS&&visibleChannels.isNotEmpty())loadVisibleEpg()
        miniCurrentChannel?.let{loadEpgForChannels(listOf(it))}
       }
      }
     }catch(_:Exception){}finally{externalEpgSyncing.remove(key)}
    }
   }
  }
  if(immediate)runScan() else handler.postDelayed({runScan()},8000L)
 }

 private fun updateMiniInfo(c:Channel){miniChannel.text=c.name;val ev=epgEvents[c.url].orEmpty();val now=ev.firstOrNull();val eventText=if(now==null)epgText[c.url].orEmpty() else (if(now.start.isNotBlank()||now.end.isNotBlank())"${now.start} - ${now.end}  " else "")+now.title;miniNow.text=eventText;miniNow.scrollTo(0,0);setMiniDescriptionText(now?.description.orEmpty());if(now!=null&&now.startEpoch>0&&now.endEpoch>now.startEpoch){val n=System.currentTimeMillis();miniProgress.progress=(((n-now.startEpoch).coerceIn(0,now.endEpoch-now.startEpoch)*1000)/(now.endEpoch-now.startEpoch)).toInt()}else miniProgress.progress=0;loadMiniPicon(c)}
 private fun setMiniDescriptionText(text:String){
  miniEventScrollToken++;val token=miniEventScrollToken
  miniEventAnimator?.cancel();miniEventAnimator=null;miniDesc.scrollTo(0,0);miniDesc.text=text
  // The long EPG description under MiniTV remains still for 3 seconds, then scrolls
  // vertically at a constant, readable speed. Short descriptions never move.
  miniDesc.post{
   if(token!=miniEventScrollToken)return@post
   fun schedule(){
    miniDesc.postDelayed({
     if(token!=miniEventScrollToken)return@postDelayed
     val layout=miniDesc.layout?:return@postDelayed
     val contentBottom=if(layout.lineCount>0)layout.getLineBottom(layout.lineCount-1) else 0
     val visibleHeight=(miniDesc.height-miniDesc.compoundPaddingTop-miniDesc.compoundPaddingBottom).coerceAtLeast(1)
     val maxScroll=(contentBottom-visibleHeight).coerceAtLeast(0)
     if(maxScroll<=0){miniDesc.scrollTo(0,0);return@postDelayed}
     val start=miniDesc.scrollY.coerceIn(0,maxScroll)
     val distance=(maxScroll-start).coerceAtLeast(1)
     miniEventAnimator=ValueAnimator.ofInt(start,maxScroll).apply{
      duration=(distance*42L).coerceIn(2800L,18000L)
      interpolator=LinearInterpolator()
      addUpdateListener{a->if(token==miniEventScrollToken)miniDesc.scrollTo(0,a.animatedValue as Int)}
      addListener(object:android.animation.AnimatorListenerAdapter(){override fun onAnimationEnd(animation:android.animation.Animator){
       if(token!=miniEventScrollToken)return
       miniDesc.postDelayed({if(token==miniEventScrollToken){miniDesc.scrollTo(0,0);schedule()}},1600L)
      }})
      start()
     }
    },3000L)
   }
   schedule()
  }
 }
 private fun loadMiniPicon(c:Channel){
  miniPicon.setImageDrawable(null);val pm=activePiconMode();val local=if(pm==0||pm==2)PiconRepository.find(this,c.name)else null
  if(local!=null){val cacheKey="local:${local.absolutePath}";PiconMemoryCache.get(cacheKey)?.let{miniPicon.setImageBitmap(it);return};val channelKey=c.url;pool.execute{val bm=PiconRepository.decodeScaled(local,220,140)?:return@execute;PiconMemoryCache.put(cacheKey,bm);runOnUiThread{if(miniCurrentChannel?.url==channelKey||miniChannel.text==c.name)miniPicon.setImageBitmap(bm)}};return}
  if((pm==1||pm==2)&&c.logo.isNotBlank())pool.execute{try{val b=selectedSource?.let{Api.loadRemotePicon(it,c.logo)}?:URL(c.logo).openStream().use{it.readBytes()};runOnUiThread{if((screen==Screen.LIVE_CHANNELS||screen==Screen.LIVE_GROUPS)&&miniChannel.text==c.name)miniPicon.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.size))}}catch(_:Exception){}}
 }
 private fun startMini(c:Channel){if(screen!=Screen.LIVE_CHANNELS&&screen!=Screen.LIVE_GROUPS)return;miniCurrentChannel=c;miniGeneration++;selectedSource?.takeIf{it.type=="e2"&&it.e2ZapOnBox}?.let{src->pool.execute{try{Api.e2Zap(src,c)}catch(_:Exception){}}};try{val p=LivePlayerSession.ensure(this,c.url,Api.streamAuthHeader(selectedSource));miniPlayer=p;if(miniPlayerView.player!==p)miniPlayerView.player=p;p.volume=1f;installLiveListenerOnce(p);miniPlayerView.visibility=View.VISIBLE;positionLiveSurfaceToMini(false)}catch(_:Exception){}}
 private fun releaseMini(){miniEventScrollToken++;miniEventAnimator?.cancel();miniEventAnimator=null;miniDesc.scrollTo(0,0);miniNow.scrollTo(0,0);miniGeneration++;liveFullscreen=false;liveFsInfo.visibility=View.GONE;liveBufferingBox.visibility=View.GONE;miniPlayerView.visibility=View.GONE;miniPlayerView.player=null;try{LivePlayerSession.release()}catch(_:Exception){};miniPlayer=null;liveSurfaceReady=false;liveListenerInstalled=false}

 private fun scheduleVodGroupRefresh(src:Source,cat:MediaCategory){catalogPool.execute{try{CatalogCacheStore.saveVodItems(this,src,cat.id,Api.vodItems(src,cat.id))}catch(_:Exception){}}}
 private fun scheduleSeriesGroupRefresh(src:Source,cat:MediaCategory){catalogPool.execute{try{CatalogCacheStore.saveSeriesItems(this,src,cat.id,Api.seriesItems(src,cat.id))}catch(_:Exception){}}}

 private fun renderVodCats(p:Pos?=null){screen=Screen.VOD_CATS;applyTheme(3);setMode();status.text="Filmy  •  ${vodCats.size} kategorii  •  Kliknij w lewo aby uzyskać więcej opcji";list.adapter=TvListAdapter(this,vodCats.map{it.name},1);p?.let{restore(it)};list.requestFocus()}
 private fun loadVodCategories(){
  releaseMini();val src=selectedSource?:return;screen=Screen.VOD_CATS;setMode()
  val cached=CatalogCacheStore.loadVodCategories(this,src)
  if(cached.isNotEmpty()){vodCats=cached;renderVodCats();scheduleCatalogSync(src);return}
  status.text="Ładowanie kategorii filmów…";pool.execute{try{val x=Api.vodCategories(src);CatalogCacheStore.saveVodCategories(this,src,x);runOnUiThread{if(selectedSource==src){vodCats=x;renderVodCats();scheduleCatalogSync(src)}}}catch(e:Exception){runOnUiThread{status.text="Filmy: ${e.message}"}}}
 }
 private fun loadVodItems(cat:MediaCategory){
  val src=selectedSource?:return;currentVodCat=cat;vodItemSelected=0
  val cached=CatalogCacheStore.loadVodItems(this,src,cat.id)
  if(cached.isNotEmpty()){vodItems=cached;renderVodItems();scheduleVodGroupRefresh(src,cat);return}
  status.text="Ładowanie: ${cat.name}…";pool.execute{try{val x=Api.vodItems(src,cat.id);CatalogCacheStore.saveVodItems(this,src,cat.id,x);runOnUiThread{if(selectedSource==src&&currentVodCat?.id==cat.id){vodItems=x;renderVodItems()}}}catch(e:Exception){runOnUiThread{status.text="Błąd filmów: ${e.message}"}}}
 }
 private fun renderVodItems(p:Pos?=null){screen=Screen.VOD_ITEMS;applyTheme(3);setMode();status.text="${currentVodCat?.name.orEmpty()}  •  ${vodItems.size} filmów";posterAdapter=PosterGridAdapter(this,vodItems.map{it.name},vodItems.map{it.icon},false);posterGrid.adapter=posterAdapter;posterGrid.clearChoices();posterGrid.choiceMode=AbsListView.CHOICE_MODE_SINGLE;p?.let{restore(it)};posterGrid.post{val pos=vodItemSelected.coerceIn(0,(vodItems.size-1).coerceAtLeast(0));posterGrid.setSelection(pos);updatePosterSelection(pos);posterGrid.requestFocus()}}
 private fun renderSeriesCats(p:Pos?=null){screen=Screen.SERIES_CATS;applyTheme(4);setMode();status.text="Seriale  •  ${seriesCats.size} kategorii  •  Kliknij w lewo aby uzyskać więcej opcji";list.adapter=TvListAdapter(this,seriesCats.map{it.name},2);p?.let{restore(it)};list.requestFocus()}
 private fun loadSeriesCategories(){
  releaseMini();val src=selectedSource?:return;screen=Screen.SERIES_CATS;setMode()
  val cached=CatalogCacheStore.loadSeriesCategories(this,src)
  if(cached.isNotEmpty()){seriesCats=cached;renderSeriesCats();scheduleCatalogSync(src);return}
  status.text="Ładowanie kategorii seriali…";pool.execute{try{val x=Api.seriesCategories(src);CatalogCacheStore.saveSeriesCategories(this,src,x);runOnUiThread{if(selectedSource==src){seriesCats=x;renderSeriesCats();scheduleCatalogSync(src)}}}catch(e:Exception){runOnUiThread{status.text="Seriale: ${e.message}"}}}
 }
 private fun loadSeriesItems(cat:MediaCategory){
  val src=selectedSource?:return;currentSeriesCat=cat;seriesItemSelected=0
  val cached=CatalogCacheStore.loadSeriesItems(this,src,cat.id)
  if(cached.isNotEmpty()){seriesItems=cached;renderSeriesItems();scheduleSeriesGroupRefresh(src,cat);return}
  status.text="Ładowanie: ${cat.name}…";pool.execute{try{val x=Api.seriesItems(src,cat.id);CatalogCacheStore.saveSeriesItems(this,src,cat.id,x);runOnUiThread{if(selectedSource==src&&currentSeriesCat?.id==cat.id){seriesItems=x;renderSeriesItems()}}}catch(e:Exception){runOnUiThread{status.text="Błąd seriali: ${e.message}"}}}
 }
 private fun renderSeriesItems(p:Pos?=null){screen=Screen.SERIES_ITEMS;applyTheme(4);setMode();status.text="${currentSeriesCat?.name.orEmpty()}  •  ${seriesItems.size} seriali";posterAdapter=PosterGridAdapter(this,seriesItems.map{it.name},seriesItems.map{it.cover},true);posterGrid.adapter=posterAdapter;posterGrid.clearChoices();posterGrid.choiceMode=AbsListView.CHOICE_MODE_SINGLE;p?.let{restore(it)};posterGrid.post{val pos=seriesItemSelected.coerceIn(0,(seriesItems.size-1).coerceAtLeast(0));posterGrid.setSelection(pos);updatePosterSelection(pos);posterGrid.requestFocus()}}
 private fun loadSeasons(item:SeriesItem){val src=selectedSource?:return;selectedSeries=item;status.text="Ładowanie sezonów: ${item.name}…";pool.execute{try{val p=Api.seasons(src,item.id);runOnUiThread{seasons=p.first;seasonEpisodes=p.second;renderSeasons()}}catch(e:Exception){runOnUiThread{status.text="Błąd sezonów: ${e.message}"}}}}
 private fun renderSeasons(p:Pos?=null){screen=Screen.SEASONS;applyTheme(4);setMode();status.text="${selectedSeries?.name.orEmpty()}  •  ${seasons.size} sezonów";list.adapter=TvListAdapter(this,seasons.map{it.name},2,true);p?.let{restore(it)};list.requestFocus()}
 private fun showEpisodes(season:SeasonItem){screen=Screen.EPISODES;applyTheme(4);setMode();episodes=seasonEpisodes[season.id].orEmpty();status.text="${selectedSeries?.name.orEmpty()}  •  ${season.name}";list.adapter=TvListAdapter(this,episodes.map{it.name},2,true);list.requestFocus()}
 private fun showFavorites(){releaseMini();screen=Screen.FAVORITES;applyTheme(2);setMode();status.text="Ulubione  •  ${favorites.size} kanałów";piconAdapter?.close();piconAdapter=PiconAdapter(this,favorites,epgText,epgEvents,activePiconMode(),selectedSource);list.adapter=piconAdapter;loadEpgForChannels(favorites);list.requestFocus()}
 private fun toggleFavorite(c:Channel){val i=favorites.indexOfFirst{it.url==c.url};val added=i<0;if(added)favorites.add(c)else favorites.removeAt(i);FavoriteStore.save(this,favorites);Toast.makeText(this,if(added)"Dodano do ulubionych" else "Usunięto z ulubionych",Toast.LENGTH_SHORT).show();if(screen==Screen.FAVORITES)showFavorites()}

 private fun launchExternalPlayer(url:String,name:String):Boolean{
  val pkg=AppOptionsStore.externalPlayerPackage(this).trim();if(pkg.isBlank())return false
  return try{
   val uri=android.net.Uri.parse(url)
   val i=Intent(Intent.ACTION_VIEW).apply{setDataAndType(uri,"video/*");setPackage(pkg);putExtra(Intent.EXTRA_TITLE,name);addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)}
   startActivity(i);true
  }catch(_:Exception){
   Toast.makeText(this,"Nie udało się uruchomić wybranego zewnętrznego playera. Używam wbudowanego TvMad.",Toast.LENGTH_LONG).show();false
  }
 }
 private fun play(url:String,name:String,epg:String="",vod:Boolean=false,channel:Channel?=null,recentKey:String="",recentKind:String="movie",poster:String="",recentTitle:String=name,resumeMs:Long=0L){
  if(!vod&&channel!=null){
   miniCurrentChannel=channel;selectedSource?.let{LastLiveStore.save(this,it,channel)}
   if(AppOptionsStore.externalPlayerPackage(this).isNotBlank()){releaseMini();if(launchExternalPlayer(url,name))return}
   startMini(channel);enterLiveFullscreen(channel,true);return
  }
  releaseMini()
  if(AppOptionsStore.externalPlayerPackage(this).isNotBlank()&&launchExternalPlayer(url,name))return
  val i=Intent(this,PlayerActivity::class.java).putExtra("url",url).putExtra("name",name).putExtra("epg",epg).putExtra("vod",true).putExtra("recentKey",recentKey.ifBlank{url}).putExtra("recentKind",recentKind).putExtra("recentPoster",poster).putExtra("recentTitle",recentTitle).putExtra("resumeMs",resumeMs)
  selectedSource?.let{src->i.putExtra("sourceType",src.type).putExtra("sourceName",src.name).putExtra("sourceHost",src.host).putExtra("sourceUser",src.user).putExtra("sourcePass",src.pass).putExtra("sourceUrl",src.url)}
  startActivity(i)
 }
 private fun onChannelItem(i:Int){when(screen){
  Screen.LIVE_GROUPS->if(i in groups.indices){
   liveGroupsPos=position();liveGroupSelected=i;liveChannelSelected=0
   val child=channelList.getChildAt(i-channelList.firstVisiblePosition);liveGroupAnchorTop=child?.top?:(resources.displayMetrics.density*95f).toInt()
   openLiveGroup(groups[i])
  }
  Screen.LIVE_CHANNELS->if(i in visibleChannels.indices){liveChannelSelected=i;val c=visibleChannels[i];play(c.url,c.name,epgText[c.url].orEmpty(),false,c)}
  else->{}
 }}
 private fun showDetails(kind:String,title:String,fallbackPoster:String,actionText:String,action:()->Unit){val p=position();val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,16,24,8);setBackgroundResource(R.drawable.panel_dark)};val iv=ImageView(this).apply{adjustViewBounds=true;scaleType=ImageView.ScaleType.CENTER_INSIDE;maxHeight=(resources.displayMetrics.heightPixels*0.45).toInt()};val tt=TextView(this).apply{text=title;textSize=23f;setTextColor(0xFFF5A623.toInt());setPadding(0,8,0,6)};val meta=TextView(this).apply{text="Ładowanie informacji TMDB…";setTextColor(0xFFCCCCCC.toInt())};val desc=TextView(this).apply{setTextColor(0xFFFFFFFF.toInt());setPadding(0,8,0,0)};box.addView(iv);box.addView(tt);box.addView(meta);box.addView(desc);val dlg=AlertDialog.Builder(this).setView(ScrollView(this).apply{addView(box)}).setPositiveButton(actionText){_,_->restore(p);action()}.setNegativeButton("Wróć",null).create();dlg.setOnDismissListener{restore(p)};dlg.show();if(fallbackPoster.isNotBlank())pool.execute{Tmdb.loadImage(fallbackPoster)?.let{b->runOnUiThread{iv.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.size))}}};pool.execute{val m=Tmdb.fetch(kind,title);runOnUiThread{if(m==null){meta.text="TMDB: nie znaleziono danych"}else{tt.text=m.title;meta.text=listOf(m.year,m.rating,m.runtime,m.genres).filter{it.isNotBlank()}.joinToString("  •  ");desc.text=m.overview;if(m.poster.isNotBlank())pool.execute{Tmdb.loadImage(m.poster)?.let{b->runOnUiThread{iv.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.size))}}}}}}}
 private fun onItem(i:Int){when(screen){
  Screen.SOURCES->if(i<sources.size)loadSource(sources[i]);Screen.LIVE_GROUPS->if(i<groups.size){liveGroupsPos=position();liveGroupSelected=i;liveChannelSelected=0;openLiveGroup(groups[i])};
  Screen.VOD_CATS->if(i<vodCats.size){vodCatsPos=position();loadVodItems(vodCats[i])};
  Screen.VOD_ITEMS->if(i<vodItems.size){vodItemSelected=i;val x=vodItems[i];showDetails("movie",x.name,x.icon,"PLAY"){play(x.url,x.name,"",true,null,"movie:${x.id}","movie",x.icon,x.name)}};
  Screen.VOD_SEARCH->if(i<searchVodItems.size){val x=searchVodItems[i];showDetails("movie",x.name,x.icon,"PLAY"){play(x.url,x.name,"",true,null,"movie:${x.id}","movie",x.icon,x.name)}};
  Screen.VOD_RECENT,Screen.SERIES_RECENT->if(i<recentEntries.size)openRecentEntry(recentEntries[i]);
  Screen.SERIES_CATS->if(i<seriesCats.size){seriesCatsPos=position();loadSeriesItems(seriesCats[i])};
  Screen.SERIES_ITEMS->if(i<seriesItems.size){seriesItemSelected=i;val x=seriesItems[i];seriesItemsPos=position();showDetails("tv",x.name,x.cover,"SEZONY"){loadSeasons(x)}};
  Screen.SERIES_SEARCH->if(i<searchSeriesItems.size){val x=searchSeriesItems[i];selectedSeries=x;showDetails("tv",x.name,x.cover,"SEZONY"){loadSeasons(x)}};
  Screen.SEASONS->if(i<seasons.size){seasonsPos=position();showEpisodes(seasons[i])};
  Screen.EPISODES->if(i<episodes.size){val ep=episodes[i];val src=selectedSource?:return;val se=selectedSeries;play(Api.episodeUrl(src,ep),ep.name,"",true,null,"series:${se?.id.orEmpty()}","series",se?.cover.orEmpty(),se?.name?:ep.name)};
  Screen.FAVORITES->if(i<favorites.size){val c=favorites[i];play(c.url,c.name,epgText[c.url].orEmpty(),false,c)};else->{}}}
 private fun showChannelOptions(c:Channel){val isFav=favorites.any{it.url==c.url};AlertDialog.Builder(this).setTitle(c.name).setItems(arrayOf(if(isFav)"Usuń z ulubionych" else "Dodaj do ulubionych","Wyświetl EPG")){_,w->if(w==0)toggleFavorite(c)else showEpgSchedule(c)}.setNegativeButton("Anuluj",null).show()}
 private fun showEpgSchedule(c:Channel){val src=selectedSource?:return;val loading=AlertDialog.Builder(this).setTitle("EPG • ${c.name}").setMessage("Ładowanie pełnego EPG…").setNegativeButton("Anuluj",null).create();loading.show();pool.execute{val events=try{Api.epgSchedule(src,c)}catch(_:Exception){emptyList()};runOnUiThread{if(!loading.isShowing)return@runOnUiThread;loading.dismiss();if(events.isEmpty()){AlertDialog.Builder(this).setTitle("EPG • ${c.name}").setMessage("Brak pełnego EPG dla tego kanału.").setPositiveButton("Wróć",null).show();return@runOnUiThread};val rows=events.map{e->(if(e.start.isNotBlank()||e.end.isNotBlank())"${e.start} - ${e.end}   " else "")+e.title};val lv=ListView(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_list_item_1,rows);dividerHeight=1};val dlg=AlertDialog.Builder(this).setTitle("EPG • ${c.name}").setView(lv).setNegativeButton("Wróć",null).create();lv.setOnItemClickListener{_,_,pos,_->val e=events[pos];val wt=if(e.start.isNotBlank()||e.end.isNotBlank())"${e.start} - ${e.end}" else "";AlertDialog.Builder(this).setTitle(e.title).setMessage(listOf(wt,e.description.ifBlank{"Brak szczegółowego opisu."}).filter{it.isNotBlank()}.joinToString("\n\n")).setPositiveButton("Wróć",null).show()};dlg.show()}}}
 private fun onLongItem(i:Int):Boolean{when(screen){Screen.SOURCES->{if(i<sources.size)showSourceOptions(i);return true};Screen.FAVORITES->{if(i<favorites.size)showChannelOptions(favorites[i]);return true};else->return false}}
 private fun onPosterLongItem(i:Int):Boolean{
  if((screen!=Screen.VOD_RECENT&&screen!=Screen.SERIES_RECENT)||i !in recentEntries.indices)return false
  val entry=recentEntries[i];val wasSeries=screen==Screen.SERIES_RECENT
  AlertDialog.Builder(this).setTitle(entry.title).setMessage("Usunąć z listy?").setPositiveButton("Tak"){_,_->
   VodHistoryStore.remove(this,entry.sourceKey,entry.key)
   handler.post{
    if(screen!=(if(wasSeries)Screen.SERIES_RECENT else Screen.VOD_RECENT))return@post
    recentEntries=recentEntries.filterNot{it.key==entry.key&&it.sourceKey==entry.sourceKey}
    posterAdapter?.updateData(recentEntries.map{if(it.subtitle.isBlank())it.title else "${it.title}\n${it.subtitle}"},recentEntries.map{it.poster})
    status.text=(if(wasSeries)"Ostatnio oglądane seriale" else "Ostatnio oglądane filmy")+"  •  ${recentEntries.size}  •  Przytrzymaj OK aby usunąć pozycję"
    if(recentEntries.isNotEmpty()){
     val next=i.coerceAtMost(recentEntries.lastIndex);posterGrid.setSelection(next);posterGrid.post{posterGrid.requestFocus();updatePosterSelection(next)}
    }else posterGrid.requestFocus()
   }
  }.setNegativeButton("Nie",null).show();return true
 }

 private fun showOptionsMenu(){
  val rows=arrayOf("Wybierz język","Wybierz zewnętrzny player","Wybierz nośnik nagrywania","Wybierz tło")
  AlertDialog.Builder(this).setTitle("Opcje").setItems(rows){_,which->when(which){0->showLanguageOption();1->showExternalPlayerOption();2->showStorageOption();3->showBackgroundOption()}}.setNegativeButton("Wróć",null).show()
 }
 private fun showLanguageOption(){
  AlertDialog.Builder(this).setTitle("Wybierz język").setItems(arrayOf("✓ Polski")){d,_->Toast.makeText(this,"Polski jest obecnie aktywnym językiem.",Toast.LENGTH_SHORT).show();d.dismiss()}.setNegativeButton("Wróć",null).show()
 }
 private fun showBackgroundOption(){
  AlertDialog.Builder(this).setTitle("Wybierz tło").setItems(arrayOf("✓ Domyślne TvMad")){d,_->Toast.makeText(this,"Domyślne tło TvMad jest aktywne.",Toast.LENGTH_SHORT).show();d.dismiss()}.setNegativeButton("Wróć",null).show()
 }
 private fun showExternalPlayerOption(){
  val probe=Intent(Intent.ACTION_VIEW).apply{setDataAndType(android.net.Uri.parse("http://127.0.0.1/video.mp4"),"video/*")}
  val resolved=packageManager.queryIntentActivities(probe,0).filter{it.activityInfo.packageName!=packageName}.distinctBy{it.activityInfo.packageName}.sortedBy{it.loadLabel(packageManager).toString().lowercase(Locale.ROOT)}
  val labels=mutableListOf("Wbudowany TvMad");val pkgs=mutableListOf("")
  resolved.forEach{labels+=it.loadLabel(packageManager).toString();pkgs+=it.activityInfo.packageName}
  val current=AppOptionsStore.externalPlayerPackage(this);val checked=pkgs.indexOf(current).let{if(it<0)0 else it}
  AlertDialog.Builder(this).setTitle("Wybierz zewnętrzny player").setSingleChoiceItems(labels.toTypedArray(),checked){d,which->AppOptionsStore.setExternalPlayerPackage(this,pkgs[which]);Toast.makeText(this,"Wybrano: ${labels[which]}",Toast.LENGTH_SHORT).show();d.dismiss()}.setNegativeButton("Anuluj",null).show()
 }
 private fun showStorageOption(){
  val dirs=getExternalFilesDirs(null).filterNotNull().distinctBy{it.absolutePath}
  if(dirs.isEmpty()){AlertDialog.Builder(this).setTitle("Wybierz nośnik nagrywania").setMessage("Nie znaleziono dostępnego nośnika.").setPositiveButton("OK",null).show();return}
  val labels=dirs.mapIndexed{i,f->if(i==0)"Pamięć urządzenia" else "Nośnik zewnętrzny ${i}"+"\n${f.absolutePath.substringBefore("/Android/")}"}
  val current=AppOptionsStore.storagePath(this);val checked=dirs.indexOfFirst{it.absolutePath==current}.let{if(it<0)0 else it}
  AlertDialog.Builder(this).setTitle("Wybierz nośnik nagrywania").setSingleChoiceItems(labels.toTypedArray(),checked){d,which->
   val base=dirs[which];val rec=java.io.File(base,"Recordings");val ts=java.io.File(base,"Timeshift");val ok=rec.mkdirs()||rec.isDirectory;val ok2=ts.mkdirs()||ts.isDirectory
   if(ok&&ok2){AppOptionsStore.setStoragePath(this,base.absolutePath);Toast.makeText(this,"Wybrano nośnik. Utworzono Recordings i Timeshift.",Toast.LENGTH_LONG).show();d.dismiss()}else Toast.makeText(this,"Nie udało się utworzyć folderów na tym nośniku.",Toast.LENGTH_LONG).show()
  }.setNegativeButton("Anuluj",null).show()
 }

 private fun miniSlotRect():android.graphics.Rect{
  val rootLoc=IntArray(2);val slotLoc=IntArray(2);rootFrame.getLocationOnScreen(rootLoc);miniVideoSlot.getLocationOnScreen(slotLoc)
  return android.graphics.Rect(slotLoc[0]-rootLoc[0],slotLoc[1]-rootLoc[1],slotLoc[0]-rootLoc[0]+miniVideoSlot.width,slotLoc[1]-rootLoc[1]+miniVideoSlot.height)
 }
 private fun setLiveSurfaceBounds(x:Int,y:Int,w:Int,h:Int){val lp=miniPlayerView.layoutParams as FrameLayout.LayoutParams;lp.width=w.coerceAtLeast(1);lp.height=h.coerceAtLeast(1);miniPlayerView.layoutParams=lp;miniPlayerView.x=x.toFloat();miniPlayerView.y=y.toFloat();miniPlayerView.scaleX=1f;miniPlayerView.scaleY=1f}
 private fun positionLiveSurfaceToMini(animate:Boolean){if(miniVideoSlot.width<=0||miniVideoSlot.height<=0){miniVideoSlot.post{if(!liveFullscreen)positionLiveSurfaceToMini(animate)};return};val r=miniSlotRect();miniPlayerView.visibility=View.VISIBLE
  if(!animate||!liveSurfaceReady){setLiveSurfaceBounds(r.left,r.top,r.width(),r.height());liveSurfaceReady=true;return}
  val sx=r.width().toFloat()/rootFrame.width.coerceAtLeast(1);val sy=r.height().toFloat()/rootFrame.height.coerceAtLeast(1)
  miniPlayerView.pivotX=0f;miniPlayerView.pivotY=0f;miniPlayerView.animate().cancel();miniPlayerView.animate().x(r.left.toFloat()).y(r.top.toFloat()).scaleX(sx).scaleY(sy).setDuration(260).withEndAction{setLiveSurfaceBounds(r.left,r.top,r.width(),r.height());channelList.requestFocus()}.start()
 }
 private fun enterLiveFullscreen(c:Channel,animate:Boolean){suppressLiveBufferUntil=SystemClock.uptimeMillis()+5000;liveRecoveryArmed=false;hideLiveBuffer();handler.postDelayed({if(liveFullscreen&&miniPlayer?.isPlaying==true)liveRecoveryArmed=true},1800);miniCurrentChannel=c;selectedSource?.let{LastLiveStore.save(this,it,c)};val idx=visibleChannels.indexOfFirst{it.url==c.url};if(idx>=0)liveChannelSelected=idx;updateFullscreenInfo(c);liveFullscreen=true;showLiveInfo(5000);miniPlayerView.bringToFront();liveFsInfo.bringToFront();liveBufferingBox.bringToFront();miniPlayerView.visibility=View.VISIBLE
  if(!liveSurfaceReady){positionLiveSurfaceToMini(false)}
  val r=miniSlotRect();if(animate&&rootFrame.width>0&&rootFrame.height>0){setLiveSurfaceBounds(r.left,r.top,r.width(),r.height());val sx=rootFrame.width.toFloat()/r.width().coerceAtLeast(1);val sy=rootFrame.height.toFloat()/r.height().coerceAtLeast(1);miniPlayerView.pivotX=0f;miniPlayerView.pivotY=0f;miniPlayerView.animate().cancel();miniPlayerView.animate().x(0f).y(0f).scaleX(sx).scaleY(sy).setDuration(260).withEndAction{setLiveSurfaceBounds(0,0,rootFrame.width,rootFrame.height);liveFsInfo.bringToFront();liveBufferingBox.bringToFront()}.start()}else setLiveSurfaceBounds(0,0,rootFrame.width.coerceAtLeast(resources.displayMetrics.widthPixels),rootFrame.height.coerceAtLeast(resources.displayMetrics.heightPixels))
  immersiveLive()
 }
 private fun exitLiveFullscreen(){
  if(!liveFullscreen)return
  liveFullscreen=false;handler.removeCallbacks(hideLiveInfo);hideLiveChannelDrawer(false);hideLiveTrackDrawer(false);liveFsInfo.visibility=View.GONE;liveBufferingBox.visibility=View.GONE;positionLiveSurfaceToMini(true)
  val c=miniCurrentChannel
  if(screen==Screen.LIVE_CHANNELS&&c!=null){
   // Nie odbudowujemy listy po fullscreen. To jest dokładnie ta sama, zamrożona lista
   // konkretnej grupy, z której kanał został uruchomiony.
   val idx=visibleChannels.indexOfFirst{it.url==c.url}
   if(idx>=0)liveChannelSelected=idx
   loadVisibleEpg()
   channelList.post{
    if(idx>=0){piconAdapter?.setSelectedPosition(idx);positionPagedList(channelList,idx,8,visibleChannels.size,true)}
    updateMiniInfo(c);channelList.requestFocus();loadVisibleEpg()
   }
  }else c?.let{updateMiniInfo(it)}
 }


 private fun showLiveInfo(delay:Long=5000){if(!liveFullscreen)return;updateClocks();updateFullscreenInfo(miniCurrentChannel);liveFsInfo.visibility=View.VISIBLE;liveFsInfo.bringToFront();handler.removeCallbacks(hideLiveInfo);handler.postDelayed(hideLiveInfo,delay)}
 private fun updateFullscreenInfo(c:Channel?){c?:return;fsNumber.text=(visibleChannels.indexOfFirst{it.url==c.url}.takeIf{it>=0}?.plus(1)?:0).takeIf{it>0}?.toString().orEmpty();fsChannel.text=c.name;val ev=epgEvents[c.url].orEmpty();val now=ev.getOrNull(0);val next=ev.getOrNull(1);fsNow.text=if(now==null)epgText[c.url].orEmpty() else (if(now.start.isNotBlank()||now.end.isNotBlank())"${now.start} - ${now.end}  " else "")+now.title;fsNext.text=if(next==null)"" else "Następnie: "+(if(next.start.isNotBlank()||next.end.isNotBlank())"${next.start} - ${next.end}  " else "")+next.title;if(now!=null&&now.startEpoch>0&&now.endEpoch>now.startEpoch){val n=System.currentTimeMillis();fsProgress.progress=(((n-now.startEpoch).coerceIn(0,now.endEpoch-now.startEpoch)*1000)/(now.endEpoch-now.startEpoch)).toInt()}else fsProgress.progress=0;loadFsPicon(c)}
 private fun loadFsPicon(c:Channel){
  fsPicon.setImageDrawable(null);val pm=activePiconMode();val local=if(pm==0||pm==2)PiconRepository.find(this,c.name)else null
  if(local!=null){val cacheKey="local:${local.absolutePath}";PiconMemoryCache.get(cacheKey)?.let{fsPicon.setImageBitmap(it);return};val channelKey=c.url;pool.execute{val bm=PiconRepository.decodeScaled(local,220,140)?:return@execute;PiconMemoryCache.put(cacheKey,bm);runOnUiThread{if(miniCurrentChannel?.url==channelKey)fsPicon.setImageBitmap(bm)}};return}
  if((pm==1||pm==2)&&c.logo.isNotBlank())pool.execute{try{val b=selectedSource?.let{Api.loadRemotePicon(it,c.logo)}?:URL(c.logo).openStream().use{it.readBytes()};runOnUiThread{if(miniCurrentChannel?.url==c.url)fsPicon.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.size))}}catch(_:Exception){}}
 }
 private fun switchLiveInline(delta:Int){if(visibleChannels.isEmpty())return;suppressLiveBufferUntil=SystemClock.uptimeMillis()+5000;liveRecoveryArmed=false;liveChannelSelected=(liveChannelSelected+delta+visibleChannels.size)%visibleChannels.size;val c=visibleChannels[liveChannelSelected];miniCurrentChannel=c;selectedSource?.let{LastLiveStore.save(this,it,c)};liveHasPlayed=false;liveRetryCount=0;hideLiveBuffer();selectedSource?.takeIf{it.type=="e2"&&it.e2ZapOnBox}?.let{src->pool.execute{try{Api.e2Zap(src,c)}catch(_:Exception){}}};val p=LivePlayerSession.ensure(this,c.url,Api.streamAuthHeader(selectedSource));miniPlayer=p;if(miniPlayerView.player!==p)miniPlayerView.player=p;loadEpgForChannels(listOf(c));updateFullscreenInfo(c);liveDrawerSelected=liveChannelSelected;liveDrawerAdapter?.notifyDataSetChanged();showLiveInfo(5000)}
 private fun installLiveListenerOnce(p:ExoPlayer){if(liveListenerInstalled)return;liveListenerInstalled=true;p.addListener(object:Player.Listener{
  override fun onIsPlayingChanged(v:Boolean){if(v){liveHasPlayed=true;liveRetryCount=0;hideLiveBuffer();handler.postDelayed({if(miniPlayer?.isPlaying==true)liveRecoveryArmed=true},1500)}}
  override fun onPlaybackStateChanged(state:Int){if(state==Player.STATE_BUFFERING&&liveHasPlayed&&liveRecoveryArmed&&SystemClock.uptimeMillis()>=suppressLiveBufferUntil){showLiveBuffer();scheduleLiveRetry()}else if(state==Player.STATE_READY){hideLiveBuffer()}}
  override fun onTracksChanged(tracks:Tracks){updateLiveTrackButtons(tracks)}
  override fun onPlayerError(error:PlaybackException){if(liveHasPlayed&&liveRecoveryArmed&&SystemClock.uptimeMillis()>=suppressLiveBufferUntil){showLiveBuffer();scheduleLiveRetry(700)}}
 })}
 private fun updateLiveTrackButtons(tracks:Tracks){var ac=0;var tc=0;for(g in tracks.groups){if(g.type==C.TRACK_TYPE_AUDIO)for(i in 0 until g.length)if(g.isTrackSupported(i))ac++;if(g.type==C.TRACK_TYPE_TEXT)for(i in 0 until g.length)if(g.isTrackSupported(i))tc++};fsAudio.visibility=if(ac>1)View.VISIBLE else View.GONE;fsSubtitles.visibility=if(tc>0)View.VISIBLE else View.GONE}
 private data class LiveTrackChoice(val label:String,val group:Tracks.Group?,val index:Int)
 private fun showLiveTrackDialog(type:Int,title:String){val p=miniPlayer?:return;val choices=ArrayList<LiveTrackChoice>();if(type==C.TRACK_TYPE_TEXT)choices+=LiveTrackChoice("Wyłącz napisy",null,-1);for(g in p.currentTracks.groups){if(g.type!=type)continue;for(i in 0 until g.length){if(!g.isTrackSupported(i))continue;val f=g.getTrackFormat(i);val lang=f.language?.uppercase().orEmpty();val label=f.label?.takeIf{it.isNotBlank()}?:if(type==C.TRACK_TYPE_AUDIO)"Audio ${choices.size+1}" else "Napisy ${choices.size+1}";choices+=LiveTrackChoice(if(lang.isBlank())label else "$label  [$lang]",g,i)}};if(choices.isEmpty()||(type==C.TRACK_TYPE_TEXT&&choices.size==1))return;AlertDialog.Builder(this).setTitle(title).setItems(choices.map{it.label}.toTypedArray()){_,w->val c=choices[w];val b=p.trackSelectionParameters.buildUpon().clearOverridesOfType(type);if(c.group==null)b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT,true)else{b.setTrackTypeDisabled(type,false);b.setOverrideForType(TrackSelectionOverride(c.group.mediaTrackGroup,listOf(c.index)))};p.trackSelectionParameters=b.build();showLiveInfo(5000)}.setNegativeButton("Anuluj",null).show()}
 private fun showLiveBuffer(){if(!liveHasPlayed)return;liveBufferingBox.visibility=View.VISIBLE;liveBufferingBox.bringToFront();handler.removeCallbacks(liveBufferTick);handler.post(liveBufferTick)}
 private fun hideLiveBuffer(){liveBufferingBox.visibility=View.GONE;handler.removeCallbacks(liveBufferTick);handler.removeCallbacks(liveRetry);liveRetryScheduled=false}
 private fun scheduleLiveRetry(delay:Long=3500){if(!liveHasPlayed||liveRetryScheduled||liveRetryCount>=3)return;liveRetryScheduled=true;handler.postDelayed(liveRetry,delay)}
 private fun immersiveLive(){window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);if(Build.VERSION.SDK_INT>=30){window.setDecorFitsSystemWindows(false);window.insetsController?.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())}else{@Suppress("DEPRECATION")window.decorView.systemUiVisibility=View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY}}
 private fun setupVodSidePanel(){
  val title=TextView(this).apply{id=6201;text="WYSZUKIWANIE FILMÓW";setTextColor(0xFFFFFFFF.toInt());textSize=19f;setPadding(dp(18),dp(18),dp(12),dp(10))}
  val searchRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(5),dp(14),dp(5))}
  val lens=ImageView(this).apply{setImageResource(R.drawable.ic_search);scaleType=ImageView.ScaleType.CENTER_INSIDE;setPadding(dp(8),dp(8),dp(8),dp(8))}
  vodSearchBox=EditText(this).apply{
   hint="Wpisz tytuł filmu…";setHintTextColor(0xFF8FA6B8.toInt());setTextColor(0xFFFFFFFF.toInt());textSize=17f;setSingleLine(true)
   inputType=InputType.TYPE_CLASS_TEXT;imeOptions=android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH;setBackgroundResource(R.drawable.button_dark);setPadding(dp(14),0,dp(12),0)
  }
  searchRow.addView(lens,LinearLayout.LayoutParams(dp(44),dp(52)));searchRow.addView(vodSearchBox,LinearLayout.LayoutParams(0,dp(52),1f))
  vodRecentButton=Button(this).apply{text="Ostatnio oglądane";setAllCaps(false);textSize=16f;setTextColor(0xFFFFFFFF.toInt());setBackgroundResource(R.drawable.button_dark);setPadding(dp(14),0,dp(14),0);setOnClickListener{showRecentVod(vodSidePanelSeries)}}
  val hint=TextView(this).apply{text="Wpisuj kolejne litery — wyniki zawężają się automatycznie.";setTextColor(0xFFAAB8C4.toInt());textSize=12f;setPadding(dp(18),dp(10),dp(18),dp(8))}
  vodSidePanel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE;elevation=dp(15).toFloat();setBackgroundResource(R.drawable.panel_glass);addView(title,LinearLayout.LayoutParams(-1,dp(58)));addView(searchRow,LinearLayout.LayoutParams(-1,dp(66)));addView(vodRecentButton,LinearLayout.LayoutParams(-1,dp(52)).apply{leftMargin=dp(18);rightMargin=dp(18);topMargin=dp(12)});addView(hint,LinearLayout.LayoutParams(-1,-2))}
  rootFrame.addView(vodSidePanel,FrameLayout.LayoutParams((resources.displayMetrics.widthPixels*0.40f).toInt(),-1,Gravity.START).apply{topMargin=dp(34);bottomMargin=dp(34);leftMargin=dp(20)})
  vodSearchBox.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){if(vodSidePanelOpen&&!vodPanelTextReset)filterAndRenderVodSearch(s?.toString().orEmpty(),vodSidePanelSeries)};override fun afterTextChanged(s:Editable?){}})
  vodSearchBox.setOnEditorActionListener{_,action,event->
   if(action==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH||(event?.keyCode==KeyEvent.KEYCODE_ENTER&&event.action==KeyEvent.ACTION_DOWN)){if(vodSearchBox.text.toString().trim().isNotEmpty()){hideVodSidePanel(false);posterGrid.post{posterGrid.requestFocus()}};true}else false
  }
 }
 private fun showVodSidePanel(series:Boolean){
  if(vodSidePanelOpen)return;vodSidePanelSeries=series;vodSidePanelOpen=true
  (vodSidePanel.findViewById<TextView>(6201)).text=if(series)"WYSZUKIWANIE SERIALI" else "WYSZUKIWANIE FILMÓW"
  vodSearchBox.hint=if(series)"Wpisz tytuł serialu…" else "Wpisz tytuł filmu…"
  vodPanelTextReset=true;vodSearchBox.setText("");vodPanelTextReset=false;vodRecentButton.text="Ostatnio oglądane"
  vodSidePanel.setBackgroundResource(if(series)R.drawable.panel_series_glass else R.drawable.panel_vod_glass)
  // Panel ma pojawić się od razu. Ładowanie dużego katalogu nigdy nie blokuje wątku UI.
  vodSidePanel.animate().cancel();vodSidePanel.translationX=0f;vodSidePanel.visibility=View.VISIBLE;vodSidePanel.bringToFront()
  prepareSearchCatalog(series);vodSearchBox.requestFocus();vodSearchBox.postDelayed({if(vodSidePanelOpen)(getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)?.showSoftInput(vodSearchBox,InputMethodManager.SHOW_IMPLICIT)},100)
 }
 private fun hideVodSidePanel(returnToCatsIfEmpty:Boolean){
  if(!vodSidePanelOpen)return;vodSidePanelOpen=false
  (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)?.hideSoftInputFromWindow(vodSearchBox.windowToken,0)
  val empty=vodSearchBox.text.toString().trim().isEmpty()
  // Bez animacji i bez ponownego budowania listy kategorii przy szybkim LEFT/RIGHT.
  vodSidePanel.animate().cancel();vodSidePanel.visibility=View.GONE;vodSidePanel.translationX=0f
  if(returnToCatsIfEmpty&&empty){list.requestFocus()}
 }
 private fun prepareSearchCatalog(series:Boolean){
  val src=selectedSource?:return
  val key=VodHistoryStore.sourceKey(src)
  if(series){
   if(seriesCatalogSourceKey==key&&allSeriesItems.isNotEmpty())return
   if(seriesCatalogLoadingKey==key)return
   seriesCatalogLoadingKey=key
  }else{
   if(vodCatalogSourceKey==key&&allVodItems.isNotEmpty())return
   if(vodCatalogLoadingKey==key)return
   vodCatalogLoadingKey=key
  }
  val gen=++searchGeneration
  // Odczyt dużego JSON cache odbywa się poza UI; panel nie czeka na parsowanie katalogu.
  searchPool.execute{
   if(series){
    val cached=CatalogCacheStore.loadSeriesAll(this,src)
    runOnUiThread{
     if(seriesCatalogLoadingKey==key)seriesCatalogLoadingKey=""
     if(selectedSource?.let{VodHistoryStore.sourceKey(it)}!=key||gen!=searchGeneration)return@runOnUiThread
     seriesCatalogSourceKey=key;allSeriesItems=cached
     val q=vodSearchBox.text.toString();if(vodSidePanelOpen&&vodSidePanelSeries&&q.isNotBlank())filterAndRenderVodSearch(q,true)
     if(cached.isEmpty())loadSearchCatalogFromServer(src,key,true,gen)
    }
   }else{
    val cached=CatalogCacheStore.loadVodAll(this,src)
    runOnUiThread{
     if(vodCatalogLoadingKey==key)vodCatalogLoadingKey=""
     if(selectedSource?.let{VodHistoryStore.sourceKey(it)}!=key||gen!=searchGeneration)return@runOnUiThread
     vodCatalogSourceKey=key;allVodItems=cached
     val q=vodSearchBox.text.toString();if(vodSidePanelOpen&&!vodSidePanelSeries&&q.isNotBlank())filterAndRenderVodSearch(q,false)
     if(cached.isEmpty())loadSearchCatalogFromServer(src,key,false,gen)
    }
   }
  }
 }
 private fun loadSearchCatalogFromServer(src:Source,key:String,series:Boolean,gen:Int){
  if(series){if(seriesCatalogLoadingKey==key)return;seriesCatalogLoadingKey=key}else{if(vodCatalogLoadingKey==key)return;vodCatalogLoadingKey=key}
  catalogPool.execute{
   try{
    if(series){
     val fresh=Api.seriesAllItems(src);CatalogCacheStore.saveSeriesAll(this,src,fresh)
     runOnUiThread{if(seriesCatalogLoadingKey==key)seriesCatalogLoadingKey="";if(selectedSource?.let{VodHistoryStore.sourceKey(it)}==key&&gen==searchGeneration){seriesCatalogSourceKey=key;allSeriesItems=fresh;val q=vodSearchBox.text.toString();if(vodSidePanelOpen&&vodSidePanelSeries&&q.isNotBlank())filterAndRenderVodSearch(q,true)}}
    }else{
     val fresh=Api.vodAllItems(src);CatalogCacheStore.saveVodAll(this,src,fresh)
     runOnUiThread{if(vodCatalogLoadingKey==key)vodCatalogLoadingKey="";if(selectedSource?.let{VodHistoryStore.sourceKey(it)}==key&&gen==searchGeneration){vodCatalogSourceKey=key;allVodItems=fresh;val q=vodSearchBox.text.toString();if(vodSidePanelOpen&&!vodSidePanelSeries&&q.isNotBlank())filterAndRenderVodSearch(q,false)}}
    }
   }catch(_:Exception){runOnUiThread{if(series&&seriesCatalogLoadingKey==key)seriesCatalogLoadingKey="";if(!series&&vodCatalogLoadingKey==key)vodCatalogLoadingKey=""}}
  }
 }
 private fun normalizedSearch(s:String):String=Normalizer.normalize(s.lowercase(Locale.getDefault()),Normalizer.Form.NFD).replace(searchMarksRegex,"").replace(searchNonWordRegex," ").trim()
 private fun exactWholeSearchWord(title:String,q:String):Boolean{
  if(q.length<3||q.indexOf(' ')>=0)return false
  return (" $title ").contains(" $q ")
 }
 private fun filterAndRenderVodSearch(query:String,series:Boolean){
  val raw=query.trim();val myGen=++searchRenderGeneration
  searchDebounce?.let{handler.removeCallbacks(it)};searchDebounce=null
  if(raw.isBlank()){
   // Samo otwarcie panelu nie przebudowuje ekranu kategorii.
   if(series)searchSeriesItems=emptyList() else searchVodItems=emptyList()
   return
  }
  if(series&&allSeriesItems.isEmpty()){screen=Screen.SERIES_SEARCH;applyTheme(4);setMode();status.text="Wyszukiwanie seriali  •  ładowanie katalogu…";posterGrid.adapter=null;return}
  if(!series&&allVodItems.isEmpty()){screen=Screen.VOD_SEARCH;applyTheme(3);setMode();status.text="Wyszukiwanie filmów  •  ładowanie katalogu…";posterGrid.adapter=null;return}
  // Wyszukiwanie jest lekkie dla Android TV: krótki debounce, praca poza UI,
  // dopasowanie głównie od początku tytułu i małe porcje wyników.
  status.text=if(series)"Wyszukiwanie seriali…" else "Wyszukiwanie filmów…"
  val task=Runnable{
   if(myGen!=searchRenderGeneration)return@Runnable
   val q=normalizedSearch(raw)
   searchPool.execute{
    if(myGen!=searchRenderGeneration)return@execute
    if(series){
     val prefix=ArrayList<SeriesItem>();val whole=ArrayList<SeriesItem>();var lastPublish=0L
     for(x in allSeriesItems){
      if(myGen!=searchRenderGeneration)return@execute
      val n=normalizedSearch(x.name)
      if(n.startsWith(q)){
       if(prefix.size<160)prefix+=x
       val now=SystemClock.uptimeMillis()
       if(prefix.size==1||(prefix.size%8==0&&now-lastPublish>=90L)){
        lastPublish=now;val snapshot=prefix.toList()
        runOnUiThread{if(myGen==searchRenderGeneration)renderSeriesSearchSnapshot(snapshot,myGen,false)}
       }
      }else if(whole.size<80&&exactWholeSearchWord(n,q))whole+=x
      if(prefix.size>=160&&whole.size>=80)break
     }
     val matches=(prefix+whole).distinctBy{it.id}.take(200)
     runOnUiThread{if(myGen==searchRenderGeneration)renderSeriesSearchSnapshot(matches,myGen,true)}
    }else{
     val prefix=ArrayList<MediaItem>();val whole=ArrayList<MediaItem>();var lastPublish=0L
     for(x in allVodItems){
      if(myGen!=searchRenderGeneration)return@execute
      val n=normalizedSearch(x.name)
      if(n.startsWith(q)){
       if(prefix.size<160)prefix+=x
       val now=SystemClock.uptimeMillis()
       if(prefix.size==1||(prefix.size%8==0&&now-lastPublish>=90L)){
        lastPublish=now;val snapshot=prefix.toList()
        runOnUiThread{if(myGen==searchRenderGeneration)renderVodSearchSnapshot(snapshot,myGen,false)}
       }
      }else if(whole.size<80&&exactWholeSearchWord(n,q))whole+=x
      if(prefix.size>=160&&whole.size>=80)break
     }
     val matches=(prefix+whole).distinctBy{it.id}.take(200)
     runOnUiThread{if(myGen==searchRenderGeneration)renderVodSearchSnapshot(matches,myGen,true)}
    }
   }
  }
  searchDebounce=task;handler.postDelayed(task,140)
 }
 private fun renderVodSearchSnapshot(all:List<MediaItem>,gen:Int,final:Boolean){
  if(gen!=searchRenderGeneration)return
  val firstPaint=searchPaintGeneration!=gen||screen!=Screen.VOD_SEARCH||posterGrid.adapter==null
  val count=if(final)minOf(maxOf(searchVodItems.size,8),all.size) else all.size
  val initial=if(final)all.take(count) else all
  searchVodItems=initial
  if(firstPaint){searchPaintGeneration=gen;screen=Screen.VOD_SEARCH;applyTheme(3);setMode();posterAdapter=PosterGridAdapter(this,searchVodItems.map{it.name},searchVodItems.map{it.icon},false);posterGrid.adapter=posterAdapter;posterGrid.clearChoices();posterGrid.choiceMode=AbsListView.CHOICE_MODE_SINGLE;if(searchVodItems.isNotEmpty())posterGrid.setSelection(0)}
  else posterAdapter?.updateData(searchVodItems.map{it.name},searchVodItems.map{it.icon})
  status.text="Wyniki filmów  •  ${searchVodItems.size}${if(final&&searchVodItems.size<all.size)" / ${all.size}" else ""}"
  if(final&&count<all.size)handler.postDelayed({if(gen==searchRenderGeneration)renderVodSearchProgressively(all,gen,count+8)},110)
 }
 private fun renderSeriesSearchSnapshot(all:List<SeriesItem>,gen:Int,final:Boolean){
  if(gen!=searchRenderGeneration)return
  val firstPaint=searchPaintGeneration!=gen||screen!=Screen.SERIES_SEARCH||posterGrid.adapter==null
  val count=if(final)minOf(maxOf(searchSeriesItems.size,8),all.size) else all.size
  val initial=if(final)all.take(count) else all
  searchSeriesItems=initial
  if(firstPaint){searchPaintGeneration=gen;screen=Screen.SERIES_SEARCH;applyTheme(4);setMode();posterAdapter=PosterGridAdapter(this,searchSeriesItems.map{it.name},searchSeriesItems.map{it.cover},true);posterGrid.adapter=posterAdapter;posterGrid.clearChoices();posterGrid.choiceMode=AbsListView.CHOICE_MODE_SINGLE;if(searchSeriesItems.isNotEmpty())posterGrid.setSelection(0)}
  else posterAdapter?.updateData(searchSeriesItems.map{it.name},searchSeriesItems.map{it.cover})
  status.text="Wyniki seriali  •  ${searchSeriesItems.size}${if(final&&searchSeriesItems.size<all.size)" / ${all.size}" else ""}"
  if(final&&count<all.size)handler.postDelayed({if(gen==searchRenderGeneration)renderSeriesSearchProgressively(all,gen,count+8)},110)
 }
 private fun renderVodSearchProgressively(all:List<MediaItem>,gen:Int,shown:Int){
  if(gen!=searchRenderGeneration||screen!=Screen.VOD_SEARCH)return
  val count=minOf(shown,all.size);searchVodItems=all.take(count);posterAdapter?.updateData(searchVodItems.map{it.name},searchVodItems.map{it.icon})
  status.text="Wyniki filmów  •  $count${if(count<all.size)" / ${all.size}" else ""}"
  if(count<all.size)handler.postDelayed({if(gen==searchRenderGeneration)renderVodSearchProgressively(all,gen,count+8)},110)
 }
 private fun renderSeriesSearchProgressively(all:List<SeriesItem>,gen:Int,shown:Int){
  if(gen!=searchRenderGeneration||screen!=Screen.SERIES_SEARCH)return
  val count=minOf(shown,all.size);searchSeriesItems=all.take(count);posterAdapter?.updateData(searchSeriesItems.map{it.name},searchSeriesItems.map{it.cover})
  status.text="Wyniki seriali  •  $count${if(count<all.size)" / ${all.size}" else ""}"
  if(count<all.size)handler.postDelayed({if(gen==searchRenderGeneration)renderSeriesSearchProgressively(all,gen,count+8)},110)
 }
 private fun showRecentVod(series:Boolean){
  hideVodSidePanel(false);val src=selectedSource?:return;recentEntries=VodHistoryStore.list(this,VodHistoryStore.sourceKey(src),if(series)"series" else "movie")
  screen=if(series)Screen.SERIES_RECENT else Screen.VOD_RECENT;applyTheme(if(series)4 else 3);setMode();status.text=(if(series)"Ostatnio oglądane seriale" else "Ostatnio oglądane filmy")+"  •  ${recentEntries.size}  •  Przytrzymaj OK aby usunąć pozycję"
  posterAdapter=PosterGridAdapter(this,recentEntries.map{if(it.subtitle.isBlank())it.title else "${it.title}\n${it.subtitle}"},recentEntries.map{it.poster},series);posterGrid.adapter=posterAdapter;posterGrid.clearChoices();posterGrid.choiceMode=AbsListView.CHOICE_MODE_SINGLE;posterGrid.post{if(recentEntries.isNotEmpty())posterGrid.setSelection(0);posterGrid.requestFocus()}
 }
 private fun openRecentEntry(entry:VodHistoryEntry){
  val at=fmtResume(entry.positionMs);AlertDialog.Builder(this).setTitle(entry.title).setMessage("Odtworzyć z ostatniej pozycji${if(at.isBlank())"" else " ($at)"}?").setPositiveButton("Tak"){_,_->play(entry.url,entry.subtitle.ifBlank{entry.title},"",true,null,entry.key,entry.kind,entry.poster,entry.title,entry.positionMs)}.setNegativeButton("Nie"){_,_->play(entry.url,entry.subtitle.ifBlank{entry.title},"",true,null,entry.key,entry.kind,entry.poster,entry.title,0L)}.show()
 }
 private fun fmtResume(ms:Long):String{if(ms<=0)return "";val t=ms/1000;val h=t/3600;val m=(t%3600)/60;val sec=t%60;return if(h>0)String.format(Locale.getDefault(),"%d:%02d:%02d",h,m,sec) else String.format(Locale.getDefault(),"%02d:%02d",m,sec)}

 override fun dispatchKeyEvent(e:KeyEvent):Boolean{
  if(vodSidePanelOpen){
   if(e.action==KeyEvent.ACTION_DOWN){
    when(e.keyCode){
     KeyEvent.KEYCODE_BACK,KeyEvent.KEYCODE_DPAD_RIGHT->{hideVodSidePanel(true);return true}
     KeyEvent.KEYCODE_DPAD_DOWN->{if(currentFocus===vodSearchBox){vodRecentButton.requestFocus();return true}}
     KeyEvent.KEYCODE_DPAD_UP->{if(currentFocus===vodRecentButton){vodSearchBox.requestFocus();return true}}
    }
   }
   return super.dispatchKeyEvent(e)
  }
  if(e.action==KeyEvent.ACTION_DOWN&&e.keyCode==KeyEvent.KEYCODE_DPAD_LEFT&&(screen==Screen.VOD_CATS||screen==Screen.SERIES_CATS)){showVodSidePanel(screen==Screen.SERIES_CATS);return true}
  if(liveFullscreen){
   if(e.action!=KeyEvent.ACTION_DOWN)return true
   if(liveChannelDrawerOpen){
    when(e.keyCode){
     KeyEvent.KEYCODE_DPAD_UP->{moveLiveDrawerSelection(-1);return true}
     KeyEvent.KEYCODE_DPAD_DOWN->{moveLiveDrawerSelection(1);return true}
     KeyEvent.KEYCODE_DPAD_RIGHT,KeyEvent.KEYCODE_BACK->{hideLiveChannelDrawer(true);return true}
     KeyEvent.KEYCODE_DPAD_CENTER,KeyEvent.KEYCODE_ENTER->{selectLiveDrawerChannel();return true}
    };return true
   }
   if(liveTrackDrawerOpen){
    when(e.keyCode){
     KeyEvent.KEYCODE_DPAD_UP->{moveLiveTrackSelection(-1);return true}
     KeyEvent.KEYCODE_DPAD_DOWN->{moveLiveTrackSelection(1);return true}
     KeyEvent.KEYCODE_DPAD_LEFT,KeyEvent.KEYCODE_BACK->{hideLiveTrackDrawer(true);return true}
     KeyEvent.KEYCODE_DPAD_CENTER,KeyEvent.KEYCODE_ENTER->{applyLiveTrackChoice();return true}
    };return true
   }
   when(e.keyCode){
    KeyEvent.KEYCODE_DPAD_LEFT->{showLiveChannelDrawer();return true}
    KeyEvent.KEYCODE_DPAD_RIGHT->{showLiveTrackDrawer();return true}
    KeyEvent.KEYCODE_DPAD_UP,KeyEvent.KEYCODE_CHANNEL_UP->{switchLiveInline(1);return true}
    KeyEvent.KEYCODE_DPAD_DOWN,KeyEvent.KEYCODE_CHANNEL_DOWN->{switchLiveInline(-1);return true}
    KeyEvent.KEYCODE_DPAD_CENTER,KeyEvent.KEYCODE_ENTER->{showLiveInfo(5000);return true}
    KeyEvent.KEYCODE_BACK->{exitLiveFullscreen();return true}
   }
   return true
  }
  return super.dispatchKeyEvent(e)
 }
 private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
 private fun setupLiveSidePanels(){
  liveChannelDrawerTitle=TextView(this).apply{text="KANAŁY";setTextColor(0xFFBBD8F2.toInt());textSize=13f;setPadding(dp(16),dp(12),dp(10),dp(8))}
  liveChannelDrawerList=ListView(this).apply{divider=android.graphics.drawable.ColorDrawable(0xFF294052.toInt());dividerHeight=dp(1);setPadding(dp(8),0,dp(8),0);clipToPadding=true;isFocusable=false;overScrollMode=View.OVER_SCROLL_NEVER}
  liveChannelDrawer=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE;setBackgroundResource(R.drawable.panel_live_glass);elevation=dp(12).toFloat();addView(liveChannelDrawerTitle,LinearLayout.LayoutParams(-1,dp(46)));addView(liveChannelDrawerList,LinearLayout.LayoutParams(-1,0,1f))}
  rootFrame.addView(liveChannelDrawer,FrameLayout.LayoutParams((resources.displayMetrics.widthPixels*0.47f).toInt(),-1,Gravity.START).apply{topMargin=dp(24);bottomMargin=dp(24);leftMargin=dp(18)})
  liveTrackDrawerTitle=TextView(this).apply{text="AUDIO I NAPISY";setTextColor(0xFFF5A623.toInt());textSize=17f;setPadding(dp(18),dp(18),dp(12),dp(10))}
  liveTrackDrawerList=ListView(this).apply{dividerHeight=0;setPadding(dp(10),0,dp(10),dp(12));clipToPadding=false;isFocusable=false}
  liveTrackDrawer=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE;setBackgroundResource(R.drawable.panel_live_glass);elevation=dp(12).toFloat();addView(liveTrackDrawerTitle,LinearLayout.LayoutParams(-1,dp(58)));addView(liveTrackDrawerList,LinearLayout.LayoutParams(-1,0,1f))}
  rootFrame.addView(liveTrackDrawer,FrameLayout.LayoutParams((resources.displayMetrics.widthPixels*0.34f).toInt(),-1,Gravity.END).apply{topMargin=dp(36);bottomMargin=dp(36);rightMargin=dp(20)})
 }
 private fun showLiveChannelDrawer(){
  if(!liveFullscreen||visibleChannels.isEmpty())return
  handler.removeCallbacks(hideLiveInfo);liveFsInfo.visibility=View.GONE;hideLiveTrackDrawer(false)
  liveDrawerSelected=visibleChannels.indexOfFirst{it.url==miniCurrentChannel?.url}.takeIf{it>=0}?:liveChannelSelected.coerceIn(0,visibleChannels.lastIndex)
  liveChannelDrawerTitle.text=(currentLiveGroup?.name?:"Kanały")+"   •   ${visibleChannels.size}"
  liveDrawerPageStart=(liveDrawerSelected/9)*9
  liveDrawerAdapter=FullscreenChannelAdapter();liveChannelDrawerList.adapter=liveDrawerAdapter
  liveChannelDrawer.visibility=View.VISIBLE;liveChannelDrawer.bringToFront();liveChannelDrawer.translationX=-liveChannelDrawer.layoutParams.width.toFloat()-dp(30)
  liveChannelDrawer.animate().cancel();liveChannelDrawer.animate().translationX(0f).setDuration(230).start();liveChannelDrawerOpen=true
  liveChannelDrawerList.post{positionPagedList(liveChannelDrawerList,liveDrawerSelected,9,visibleChannels.size,true)}
  prefetchDrawerEpg(liveDrawerSelected)
 }
 private fun hideLiveChannelDrawer(showInfoAfter:Boolean){
  if(!::liveChannelDrawer.isInitialized||!liveChannelDrawerOpen){if(showInfoAfter&&liveFullscreen)showLiveInfo(5000);return}
  liveChannelDrawerOpen=false;liveChannelDrawer.animate().cancel();liveChannelDrawer.animate().translationX(-liveChannelDrawer.width.toFloat()-dp(30)).setDuration(210).withEndAction{liveChannelDrawer.visibility=View.GONE;liveChannelDrawer.translationX=0f}.start()
  if(showInfoAfter)showLiveInfo(5000)
 }
 private fun moveMainChannelSelection(delta:Int){
  if(visibleChannels.isEmpty())return
  val next=(liveChannelSelected+delta).coerceIn(0,visibleChannels.lastIndex);if(next==liveChannelSelected)return
  liveChannelSelected=next
  piconAdapter?.setSelectedPosition(next)
  positionPagedList(channelList,next,8,visibleChannels.size,false)
  updateMiniInfo(visibleChannels[next]);loadVisibleEpg()
 }
 private fun positionPagedList(lv:ListView,target:Int,pageSize:Int,total:Int,force:Boolean=false){
  // Twarde strony bez "pełzania" ListView. W obrębie strony rusza się WYŁĄCZNIE
  // niebieskie zaznaczenie. Sama lista zmienia pozycję tylko po przekroczeniu granicy strony.
  if(total<=0||pageSize<=0)return
  val safeTarget=target.coerceIn(0,total-1)
  val pageStart=(safeTarget/pageSize)*pageSize
  val isMain=lv===channelList
  val oldStart=if(isMain)liveChannelPageStart else liveDrawerPageStart
  if(force||pageStart!=oldStart){
   if(isMain)liveChannelPageStart=pageStart else liveDrawerPageStart=pageStart
   lv.setSelectionFromTop(pageStart,lv.paddingTop)
  }
  lv.post{lv.invalidateViews()}
 }
 private fun moveLiveDrawerSelection(delta:Int){
  if(visibleChannels.isEmpty())return
  val next=(liveDrawerSelected+delta).coerceIn(0,visibleChannels.lastIndex);if(next==liveDrawerSelected)return
  liveDrawerSelected=next;liveDrawerAdapter?.notifyDataSetChanged();positionPagedList(liveChannelDrawerList,liveDrawerSelected,9,visibleChannels.size,false);prefetchDrawerEpg(liveDrawerSelected)
 }
 private fun selectLiveDrawerChannel(){
  val i=liveDrawerSelected.takeIf{it in visibleChannels.indices}?:return;liveChannelSelected=i;val c=visibleChannels[i];miniCurrentChannel=c;selectedSource?.let{LastLiveStore.save(this,it,c)};liveHasPlayed=false;liveRetryCount=0;hideLiveBuffer();selectedSource?.takeIf{it.type=="e2"&&it.e2ZapOnBox}?.let{src->pool.execute{try{Api.e2Zap(src,c)}catch(_:Exception){}}};val p=LivePlayerSession.ensure(this,c.url,Api.streamAuthHeader(selectedSource));miniPlayer=p;if(miniPlayerView.player!==p)miniPlayerView.player=p;loadEpgForChannels(listOf(c));updateFullscreenInfo(c);hideLiveChannelDrawer(false);showLiveInfo(5000)
 }
 private fun prefetchDrawerEpg(center:Int){if(visibleChannels.isEmpty())return;val a=(center-6).coerceAtLeast(0);val b=(center+7).coerceAtMost(visibleChannels.size);loadEpgForChannels(visibleChannels.subList(a,b))}
 private inner class FullscreenChannelAdapter:BaseAdapter(){
  override fun getCount()=visibleChannels.size;override fun getItem(position:Int)=visibleChannels[position];override fun getItemId(position:Int)=position.toLong()
  override fun getView(position:Int,convertView:View?,parent:ViewGroup):View{
   val row=(convertView as? LinearLayout)?:LinearLayout(this@MainActivity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),dp(2),dp(10),dp(2));addView(TextView(this@MainActivity).apply{id=5101;textSize=12f;gravity=Gravity.CENTER;setTextColor(0xFF8FB9DA.toInt())},LinearLayout.LayoutParams(dp(32),dp(50)));addView(ImageView(this@MainActivity).apply{id=5102;scaleType=ImageView.ScaleType.CENTER_INSIDE},LinearLayout.LayoutParams(dp(54),dp(44)).apply{rightMargin=dp(8)});addView(LinearLayout(this@MainActivity).apply{id=5103;orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;addView(TextView(this@MainActivity).apply{id=5104;textSize=16f;setTextColor(0xFFFFFFFF.toInt());maxLines=1},LinearLayout.LayoutParams(-1,dp(23)));addView(TextView(this@MainActivity).apply{id=5105;textSize=11f;setTextColor(0xFFC1CDD8.toInt());maxLines=1},LinearLayout.LayoutParams(-1,dp(17)));addView(ProgressBar(this@MainActivity,null,android.R.attr.progressBarStyleHorizontal).apply{id=5106;max=1000;progressTintList=android.content.res.ColorStateList.valueOf(0xFF20C9E8.toInt());progressBackgroundTintList=android.content.res.ColorStateList.valueOf(0xFF263B4B.toInt())},LinearLayout.LayoutParams(-1,dp(4)).apply{topMargin=dp(1)})},LinearLayout.LayoutParams(0,dp(52),1f))}
   if(parent.height>0){val lv=parent as? ListView;val usable=parent.height-parent.paddingTop-parent.paddingBottom-((lv?.dividerHeight?:0)*8);val h=(usable/9).coerceAtLeast(dp(54));val lp=row.layoutParams as? AbsListView.LayoutParams;if(lp==null||lp.height!=h)row.layoutParams=AbsListView.LayoutParams(AbsListView.LayoutParams.MATCH_PARENT,h)}
   val c=visibleChannels[position];row.setBackgroundResource(if(position==liveDrawerSelected)R.drawable.row_focus_active else android.R.color.transparent);row.findViewById<TextView>(5101).text=(position+1).toString();row.findViewById<TextView>(5104).text=c.name
   val now=epgEvents[c.url].orEmpty().firstOrNull();row.findViewById<TextView>(5105).text=now?.title?:epgText[c.url].orEmpty().replace(Regex("^\\d{1,2}:\\d{2}\\s*-\\s*\\d{1,2}:\\d{2}\\s+"),"")
   val pb=row.findViewById<ProgressBar>(5106);pb.progress=if(now!=null&&now.startEpoch>0&&now.endEpoch>now.startEpoch){(((System.currentTimeMillis()-now.startEpoch).coerceIn(0,now.endEpoch-now.startEpoch)*1000)/(now.endEpoch-now.startEpoch)).toInt()}else 0
   val iv=row.findViewById<ImageView>(5102);val oldTag=iv.tag as? String;iv.tag=c.url;loadDrawerPicon(iv,c,oldTag);return row
  }
 }
 private fun loadDrawerPicon(iv:ImageView,c:Channel,oldTag:String?=null){
  val pm=activePiconMode();val local=if(pm==0||pm==2)PiconRepository.find(this,c.name)else null
  if(local!=null){val cacheKey="local:${local.absolutePath}";PiconMemoryCache.get(cacheKey)?.let{iv.setImageBitmap(it);return};if(oldTag!=c.url)iv.setImageDrawable(null);val rowKey=c.url;pool.execute{val bm=PiconRepository.decodeScaled(local,140,90)?:return@execute;PiconMemoryCache.put(cacheKey,bm);runOnUiThread{if(iv.tag==rowKey)iv.setImageBitmap(bm)}};return}
  if((pm==1||pm==2)&&c.logo.isNotBlank()){val cacheKey="remote:${selectedSource?.type}:${selectedSource?.host}:${c.logo}";PiconMemoryCache.get(cacheKey)?.let{iv.setImageBitmap(it);return};if(oldTag!=c.url)iv.setImageDrawable(null);val rowKey=c.url;pool.execute{try{val b=selectedSource?.let{Api.loadRemotePicon(it,c.logo)}?:URL(c.logo).openStream().use{it.readBytes()};val bm=BitmapFactory.decodeByteArray(b,0,b.size)?:return@execute;PiconMemoryCache.put(cacheKey,bm);runOnUiThread{if(iv.tag==rowKey)iv.setImageBitmap(bm)}}catch(_:Exception){}}}else if(oldTag!=c.url)iv.setImageDrawable(null)
 }
 private data class LiveTrackPanelChoice(val label:String,val type:Int,val group:Tracks.Group?,val index:Int,val selected:Boolean=false)
 private fun buildLiveTrackPanelChoices():List<LiveTrackPanelChoice>{
  val p=miniPlayer?:return emptyList();val out=ArrayList<LiveTrackPanelChoice>();var audioNo=1;var subNo=1
  for(g in p.currentTracks.groups){if(g.type!=C.TRACK_TYPE_AUDIO)continue;for(i in 0 until g.length){if(!g.isTrackSupported(i))continue;val f=g.getTrackFormat(i);val lang=f.language?.uppercase().orEmpty();val label=f.label?.takeIf{it.isNotBlank()}?:"Audio ${audioNo++}";out+=LiveTrackPanelChoice("🔊  "+(if(lang.isBlank())label else "$label  [$lang]"),C.TRACK_TYPE_AUDIO,g,i,g.isTrackSelected(i))}}
  val textGroups=p.currentTracks.groups.filter{it.type==C.TRACK_TYPE_TEXT};val anyTextSelected=textGroups.any{g->(0 until g.length).any{i->g.isTrackSelected(i)}};out+=LiveTrackPanelChoice("▤  Napisy: wyłączone",C.TRACK_TYPE_TEXT,null,-1,!anyTextSelected)
  for(g in textGroups){for(i in 0 until g.length){if(!g.isTrackSupported(i))continue;val f=g.getTrackFormat(i);val lang=f.language?.uppercase().orEmpty();val label=f.label?.takeIf{it.isNotBlank()}?:"Napisy ${subNo++}";out+=LiveTrackPanelChoice("▤  "+(if(lang.isBlank())label else "$label  [$lang]"),C.TRACK_TYPE_TEXT,g,i,g.isTrackSelected(i))}}
  return out
 }
 private fun refreshLiveTrackDrawerList(){
  liveTrackDrawerList.adapter=object:ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,liveTrackChoices.map{(if(it.selected)"✓  " else "   ")+it.label}){override fun getView(position:Int,convertView:View?,parent:ViewGroup):View{val v=super.getView(position,convertView,parent) as TextView;v.setTextColor(0xFFFFFFFF.toInt());v.textSize=15f;v.setPadding(dp(14),dp(12),dp(12),dp(12));v.setBackgroundResource(if(position==liveTrackSelected)R.drawable.row_focus_active else android.R.color.transparent);return v}}
  liveTrackDrawerList.setSelection((liveTrackSelected-2).coerceAtLeast(0))
 }
 private fun showLiveTrackDrawer(){
  if(!liveFullscreen)return;handler.removeCallbacks(hideLiveInfo);liveFsInfo.visibility=View.GONE;hideLiveChannelDrawer(false);liveTrackChoices=buildLiveTrackPanelChoices();if(liveTrackChoices.isEmpty()){showLiveInfo(3000);Toast.makeText(this,"Brak dostępnych ścieżek audio/napisów",Toast.LENGTH_SHORT).show();return};liveTrackSelected=liveTrackChoices.indexOfFirst{it.selected}.takeIf{it>=0}?:0;refreshLiveTrackDrawerList()
  liveTrackDrawer.visibility=View.VISIBLE;liveTrackDrawer.bringToFront();liveTrackDrawer.translationX=liveTrackDrawer.layoutParams.width.toFloat()+dp(30);liveTrackDrawer.animate().cancel();liveTrackDrawer.animate().translationX(0f).setDuration(230).start();liveTrackDrawerOpen=true
 }
 private fun hideLiveTrackDrawer(showInfoAfter:Boolean){if(!::liveTrackDrawer.isInitialized||!liveTrackDrawerOpen){if(showInfoAfter&&liveFullscreen)showLiveInfo(5000);return};liveTrackDrawerOpen=false;liveTrackDrawer.animate().cancel();liveTrackDrawer.animate().translationX(liveTrackDrawer.width.toFloat()+dp(30)).setDuration(210).withEndAction{liveTrackDrawer.visibility=View.GONE;liveTrackDrawer.translationX=0f}.start();if(showInfoAfter)showLiveInfo(5000)}
 private fun moveLiveTrackSelection(delta:Int){if(liveTrackChoices.isEmpty())return;liveTrackSelected=(liveTrackSelected+delta+liveTrackChoices.size)%liveTrackChoices.size;refreshLiveTrackDrawerList()}
 private fun applyLiveTrackChoice(){val p=miniPlayer?:return;val c=liveTrackChoices.getOrNull(liveTrackSelected)?:return;val chosenType=c.type;val chosenGroup=c.group?.mediaTrackGroup;val chosenIndex=c.index;val b=p.trackSelectionParameters.buildUpon().clearOverridesOfType(c.type);if(c.group==null)b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT,true)else{b.setTrackTypeDisabled(c.type,false);b.setOverrideForType(TrackSelectionOverride(c.group.mediaTrackGroup,listOf(c.index)))};p.trackSelectionParameters=b.build();liveTrackChoices=buildLiveTrackPanelChoices();liveTrackSelected=liveTrackChoices.indexOfFirst{it.type==chosenType&&it.index==chosenIndex&&it.group?.mediaTrackGroup==chosenGroup}.takeIf{it>=0}?:liveTrackSelected.coerceIn(0,(liveTrackChoices.size-1).coerceAtLeast(0));refreshLiveTrackDrawerList()}

 private fun setupMultiEpg(){
  multiEpgOverlay=LinearLayout(this).apply{
   orientation=LinearLayout.VERTICAL;visibility=View.GONE;isFocusable=true;setPadding(dp(26),dp(18),dp(26),dp(16));setBackgroundColor(0xFA02070D.toInt())
  }
  val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
  multiEpgGroupTitle=TextView(this).apply{setTextColor(0xFFF5A623.toInt());textSize=25f;setTypeface(typeface,android.graphics.Typeface.BOLD)}
  val clock=TextView(this).apply{setTextColor(0xFFE5EBF2.toInt());textSize=20f;gravity=Gravity.END}
  top.addView(multiEpgGroupTitle,LinearLayout.LayoutParams(0,dp(42),1f));top.addView(clock,LinearLayout.LayoutParams(dp(110),dp(42)))
  multiEpgOverlay.addView(top,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(44)))
  multiEpgEventTitle=TextView(this).apply{setTextColor(0xFFF5A623.toInt());textSize=20f;setTypeface(typeface,android.graphics.Typeface.BOLD);maxLines=1}
  multiEpgOverlay.addView(multiEpgEventTitle,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(34)))
  val timeRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
  multiEpgEventTime=TextView(this).apply{setTextColor(0xFFE2E9F0.toInt());textSize=14f}
  multiEpgProgress=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=1000;progressTintList=android.content.res.ColorStateList.valueOf(0xFFF5A623.toInt());progressBackgroundTintList=android.content.res.ColorStateList.valueOf(0xFF263746.toInt())}
  timeRow.addView(multiEpgEventTime,LinearLayout.LayoutParams(dp(150),dp(28)));timeRow.addView(multiEpgProgress,LinearLayout.LayoutParams(0,dp(6),1f))
  multiEpgOverlay.addView(timeRow,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(30)))
  multiEpgDesc=TextView(this).apply{setTextColor(0xFFD3DCE5.toInt());textSize=14f;maxLines=100;setPadding(0,dp(5),0,dp(7))}
  multiEpgOverlay.addView(multiEpgDesc,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(104)))
  multiEpgGrid=MultiEpgGridView(this).apply{
   listener=object:MultiEpgGridView.Listener{
    override fun onSelectionChanged(channelIndex:Int,event:EpgEvent?){updateMultiEpgInfo(channelIndex,event)}
    override fun onNeedData(channelIndex:Int){loadMultiEpgAround(channelIndex);loadMultiEpgPicons(channelIndex)}
    override fun onExitRequested(){closeMultiEpg()}
   }
  }
  multiEpgOverlay.addView(multiEpgGrid,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1f))
  val footer=TextView(this).apply{text="↑↓ kanały     ←→ wydarzenia     EXIT = powrót";setTextColor(0xFF91A0AF.toInt());textSize=12f;gravity=Gravity.END or Gravity.CENTER_VERTICAL}
  multiEpgOverlay.addView(footer,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(28)))
  rootFrame.addView(multiEpgOverlay,FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT))
  val clockTick=object:Runnable{override fun run(){if(multiEpgOpen){clock.text=SimpleDateFormat("HH:mm",Locale.getDefault()).format(Date());handler.postDelayed(this,30000L)}}}
  multiEpgOverlay.tag=clockTick
 }

 private fun openMultiEpg(){
  if(screen!=Screen.LIVE_CHANNELS||visibleChannels.isEmpty())return
  multiEpgReturnChannel=liveChannelSelected.coerceIn(0,visibleChannels.lastIndex)
  multiEpgOpen=true;multiEpgSchedules.clear();multiEpgPending.clear();multiEpgPicons.clear();multiEpgDescToken++;multiEpgDescAnimator?.cancel();multiEpgDescAnimator=null
  for(c in visibleChannels){epgEvents[c.url]?.takeIf{it.isNotEmpty()}?.let{multiEpgSchedules[c.url]=it}}
  multiEpgGroupTitle.text=currentLiveGroup?.name?:"Multi-EPG"
  multiEpgOverlay.visibility=View.VISIBLE;multiEpgOverlay.bringToFront()
  multiEpgGrid.setData(visibleChannels,multiEpgReturnChannel);multiEpgGrid.setSchedules(multiEpgSchedules)
  (multiEpgOverlay.tag as? Runnable)?.let{handler.removeCallbacks(it);handler.post(it)}
  multiEpgGrid.post{multiEpgGrid.requestFocus()}
  val src=selectedSource
  if(src?.type=="e2"){
   val gid=currentLiveGroup?.id.orEmpty()
   if(gid.isNotBlank())pool.execute{
    try{
     val byRef=Api.e2MultiEpg(src,gid)
     val mapped=HashMap<String,List<EpgEvent>>()
     for(c in visibleChannels){val ref=c.streamId.ifBlank{c.epgId};byRef[ref]?.let{mapped[c.url]=it}}
     runOnUiThread{if(multiEpgOpen&&selectedSource==src){multiEpgSchedules.putAll(mapped);multiEpgGrid.setSchedules(mapped);updateMultiEpgInfo(multiEpgGrid.currentChannelIndex(),mapped[visibleChannels.getOrNull(multiEpgGrid.currentChannelIndex())?.url]?.let{events->events.firstOrNull{System.currentTimeMillis() in it.startEpoch until it.endEpoch}?:events.firstOrNull()})}}
    }catch(_:Exception){}
   }
  }else loadMultiEpgAround(multiEpgReturnChannel)
  loadMultiEpgPicons(multiEpgReturnChannel)
 }

 private fun closeMultiEpg(){
  if(!multiEpgOpen)return
  multiEpgOpen=false;multiEpgDescToken++;multiEpgDescAnimator?.cancel();multiEpgDescAnimator=null;multiEpgDesc.scrollTo(0,0)
  (multiEpgOverlay.tag as? Runnable)?.let{handler.removeCallbacks(it)}
  multiEpgOverlay.visibility=View.GONE
  liveChannelSelected=multiEpgReturnChannel.coerceIn(0,(visibleChannels.size-1).coerceAtLeast(0))
  channelList.post{if(visibleChannels.isNotEmpty()){piconAdapter?.setSelectedPosition(liveChannelSelected);positionPagedList(channelList,liveChannelSelected,8,visibleChannels.size,true)};channelList.requestFocus()}
 }

 private fun loadMultiEpgAround(center:Int){
  if(!multiEpgOpen)return
  val src=selectedSource?:return
  if(src.type=="e2")return
  val from=(center-7).coerceAtLeast(0);val to=(center+8).coerceAtMost(visibleChannels.size)
  for(i in from until to){
   val c=visibleChannels[i]
   val existing=multiEpgSchedules[c.url].orEmpty()
   if(existing.size>2||!multiEpgPending.add(c.url))continue
   epgPool.execute{
    try{
     var events=try{Api.epgSchedule(src,c)}catch(_:Exception){emptyList()}
     if(events.isEmpty())events=ExternalEpgStore.schedule(this,src,c)
     if(events.isEmpty())events=epgEvents[c.url].orEmpty()
     if(events.isNotEmpty())multiEpgSchedules[c.url]=events
     runOnUiThread{if(multiEpgOpen&&selectedSource==src){multiEpgGrid.setSchedule(c.url,events)}}
    }finally{multiEpgPending.remove(c.url)}
   }
  }
 }

 private fun loadMultiEpgPicons(center:Int){
  if(!multiEpgOpen)return
  val src=selectedSource
  val from=(center-9).coerceAtLeast(0);val to=(center+10).coerceAtMost(visibleChannels.size)
  for(i in from until to){
   val c=visibleChannels[i];if(!multiEpgPicons.add(c.url))continue
   val pm=activePiconMode();val local=if(pm==0||pm==2)PiconRepository.find(this,c.name)else null
   if(local!=null){val channelKey=c.url;pool.execute{val cacheKey="local:${local.absolutePath}";val bm=PiconMemoryCache.get(cacheKey)?:PiconRepository.decodeScaled(local,160,100)?.also{PiconMemoryCache.put(cacheKey,it)};runOnUiThread{if(multiEpgOpen&&bm!=null)multiEpgGrid.setPicon(channelKey,bm)}};continue}
   if((pm==1||pm==2)&&c.logo.isNotBlank())pool.execute{try{val b=src?.let{Api.loadRemotePicon(it,c.logo)}?:URL(c.logo).openStream().use{it.readBytes()};val bm=BitmapFactory.decodeByteArray(b,0,b.size);runOnUiThread{if(multiEpgOpen)multiEpgGrid.setPicon(c.url,bm)}}catch(_:Exception){}}
  }
 }

 private fun updateMultiEpgInfo(channelIndex:Int,event:EpgEvent?){
  if(!multiEpgOpen)return
  val c=visibleChannels.getOrNull(channelIndex)?:return
  multiEpgReturnChannel=channelIndex
  multiEpgEventTitle.text=if(event==null)c.name else event.title
  multiEpgEventTime.text=if(event==null)"Ładowanie EPG…" else "${event.start}  –  ${event.end}"
  if(event!=null&&event.startEpoch>0&&event.endEpoch>event.startEpoch){val now=System.currentTimeMillis();multiEpgProgress.progress=(((now-event.startEpoch).coerceIn(0,event.endEpoch-event.startEpoch)*1000)/(event.endEpoch-event.startEpoch)).toInt()}else multiEpgProgress.progress=0
  setMultiEpgDescription(event?.description.orEmpty())
 }

 private fun setMultiEpgDescription(text:String){
  multiEpgDescToken++;val token=multiEpgDescToken;multiEpgDescAnimator?.cancel();multiEpgDescAnimator=null;multiEpgDesc.scrollTo(0,0);multiEpgDesc.text=text.ifBlank{"Brak szczegółowego opisu wydarzenia."}
  multiEpgDesc.post{
   if(token!=multiEpgDescToken)return@post
   multiEpgDesc.postDelayed({
    if(token!=multiEpgDescToken)return@postDelayed
    val layout=multiEpgDesc.layout?:return@postDelayed;val bottom=if(layout.lineCount>0)layout.getLineBottom(layout.lineCount-1)else 0;val visible=(multiEpgDesc.height-multiEpgDesc.compoundPaddingTop-multiEpgDesc.compoundPaddingBottom).coerceAtLeast(1);val maxScroll=(bottom-visible).coerceAtLeast(0)
    if(maxScroll<=0)return@postDelayed
    multiEpgDescAnimator=ValueAnimator.ofInt(0,maxScroll).apply{duration=(maxScroll*48L).coerceIn(3200L,22000L);interpolator=LinearInterpolator();addUpdateListener{a->if(token==multiEpgDescToken)multiEpgDesc.scrollTo(0,a.animatedValue as Int)};start()}
   },3000L)
  }
 }

 private fun confirmExit(){AlertDialog.Builder(this).setTitle("Wyjść z TvMad-Xtream TV?").setMessage("Czy na pewno chcesz zamknąć aplikację?").setPositiveButton("Tak"){_,_->finishAffinity()}.setNegativeButton("Nie",null).show()}
 @Deprecated("Deprecated in Java") override fun onBackPressed(){if(vodSidePanelOpen){hideVodSidePanel(true);return};if(multiEpgOpen){closeMultiEpg();return};if(liveFullscreen){exitLiveFullscreen();return};when(screen){Screen.SOURCES->showHome();Screen.HOME->confirmExit();Screen.LIVE_GROUPS->showHome();Screen.LIVE_CHANNELS->showLiveGroups(liveGroupsPos);Screen.VOD_CATS->showHome();Screen.VOD_ITEMS,Screen.VOD_SEARCH,Screen.VOD_RECENT->renderVodCats(vodCatsPos);Screen.SERIES_CATS->showHome();Screen.SERIES_ITEMS,Screen.SERIES_SEARCH,Screen.SERIES_RECENT->renderSeriesCats(seriesCatsPos);Screen.SEASONS->renderSeriesItems(seriesItemsPos);Screen.EPISODES->renderSeasons(seasonsPos);Screen.FAVORITES->showHome()}}
 override fun onResume(){super.onResume();AppScreenshotBridge.attach(this);handler.removeCallbacks(liveProgressTick);handler.post(liveProgressTick);if(screen==Screen.VOD_ITEMS||screen==Screen.SERIES_ITEMS||screen==Screen.VOD_SEARCH||screen==Screen.SERIES_SEARCH||screen==Screen.VOD_RECENT||screen==Screen.SERIES_RECENT){posterGrid.post{posterGrid.requestFocus()}};if((screen==Screen.LIVE_CHANNELS||screen==Screen.LIVE_GROUPS)&&!liveFullscreen)miniCurrentChannel?.let{startMini(it)}}
 override fun onPause(){handler.removeCallbacks(liveProgressTick);AppScreenshotBridge.detach(this);super.onPause()}
 override fun onDestroy(){releaseMini();web?.stop();piconAdapter?.close();handler.removeCallbacksAndMessages(null);pool.shutdownNow();epgPool.shutdownNow();catalogPool.shutdownNow();externalEpgPool.shutdownNow();super.onDestroy()}
}
