package pl.tvmad.xtream

import android.app.*
import android.os.*
import android.content.*
import android.text.InputType
import android.view.View
import android.widget.*
import java.util.concurrent.Executors

class MainActivity:Activity(){
 private lateinit var list:ListView; private lateinit var status:TextView; private lateinit var sourceBar:View; private lateinit var contentBar:View
 private val pool=Executors.newFixedThreadPool(4)
 private var allChannels=listOf<Channel>(); private var visibleChannels=listOf<Channel>(); private var groups=listOf<String>(); private var sources=mutableListOf<Source>(); private var selectedSource:Source?=null; private var piconMode=2
 private var vodCats=listOf<MediaCategory>(); private var vodItems=listOf<MediaItem>(); private var seriesCats=listOf<MediaCategory>(); private var seriesItems=listOf<SeriesItem>(); private var seasons=listOf<SeasonItem>(); private var seasonEpisodes:Map<String,List<EpisodeItem>> = emptyMap(); private var episodes=listOf<EpisodeItem>(); private var selectedSeries:SeriesItem?=null
 private var favorites=mutableListOf<Channel>(); private val epgText=mutableMapOf<String,String>()
 private enum class Screen { SOURCES, LIVE_GROUPS, LIVE_CHANNELS, VOD_CATS, VOD_ITEMS, SERIES_CATS, SERIES_ITEMS, SEASONS, EPISODES, FAVORITES }
 private var screen=Screen.SOURCES

 override fun onCreate(b:Bundle?){
  super.onCreate(b); setContentView(R.layout.activity_main); list=findViewById(R.id.list); status=findViewById(R.id.status); sourceBar=findViewById(R.id.sourceBar); contentBar=findViewById(R.id.contentBar); sources=SourceStore.load(this); favorites=FavoriteStore.load(this)
  findViewById<Button>(R.id.addXtream).setOnClickListener{xtreamDialog()}; findViewById<Button>(R.id.addM3u).setOnClickListener{m3uDialog()}
  findViewById<Button>(R.id.piconMode).setOnClickListener{v->piconMode=(piconMode+1)%3;(v as Button).text="Picony: "+arrayOf("lokalne","źródło","oba")[piconMode]}
  findViewById<Button>(R.id.navLive).setOnClickListener{loadLive()}; findViewById<Button>(R.id.navVod).setOnClickListener{loadVodCategories()}; findViewById<Button>(R.id.navSeries).setOnClickListener{loadSeriesCategories()}; findViewById<Button>(R.id.navFav).setOnClickListener{showFavorites()}
  list.setOnItemClickListener{_,_,i,_->onItem(i)}
  list.setOnItemLongClickListener{_,_,i,_->onLongItem(i)}
  showSources()
 }

 private fun field(h:String)=EditText(this).apply{hint=h;setSingleLine(true)}
 private fun xtreamDialog(){
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,0,28,0)}; val n=field("Nazwa serwera, np. Dom"); val h=field("http://serwer:port"); val u=field("Użytkownik"); val p=field("Hasło").apply{inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
  box.addView(n);box.addView(h);box.addView(u);box.addView(p)
  AlertDialog.Builder(this).setTitle("Dodaj Xtream Codes").setView(box).setPositiveButton("Zapisz i wczytaj"){_,_->val host=h.text.toString().trim();saveAndLoad(Source("xtream",n.text.toString().trim().ifBlank{host},host,u.text.toString(),p.text.toString()))}.setNegativeButton("Anuluj",null).show()
 }
 private fun m3uDialog(){
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,0,28,0)}; val n=field("Nazwa listy, np. IPTV"); val u=field("Pełny URL listy M3U");box.addView(n);box.addView(u)
  AlertDialog.Builder(this).setTitle("Dodaj M3U").setView(box).setPositiveButton("Zapisz i wczytaj"){_,_->val url=u.text.toString().trim();saveAndLoad(Source("m3u",n.text.toString().trim().ifBlank{"M3U ${sources.size+1}"},url=url))}.setNegativeButton("Anuluj",null).show()
 }
 private fun saveAndLoad(src:Source){val same=sources.indexOfFirst{it.type==src.type&&((src.type=="xtream"&&it.host==src.host&&it.user==src.user)||(src.type=="m3u"&&it.url==src.url))};if(same>=0)sources[same]=src else sources.add(src);SourceStore.save(this,sources);loadSource(src)}
 private fun confirmDelete(i:Int){val s=sources[i];AlertDialog.Builder(this).setTitle("Usunąć serwer?").setMessage(s.name).setPositiveButton("Usuń"){_,_->sources.removeAt(i);SourceStore.save(this,sources);showSources()}.setNegativeButton("Anuluj",null).show()}

 private fun selectBars(inSource:Boolean){sourceBar.visibility=if(inSource)View.VISIBLE else View.GONE;contentBar.visibility=if(inSource)View.GONE else View.VISIBLE}
 private fun showSources(){screen=Screen.SOURCES;selectedSource=null;allChannels=emptyList();visibleChannels=emptyList();selectBars(true);status.text="Serwery: ${sources.size}  •  dotknij aby wczytać, przytrzymaj aby usunąć";list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,sources.map{"${if(it.type=="xtream") "XCODES" else "M3U"}  •  ${it.name}"})}
 private fun loadSource(src:Source){selectedSource=src;selectBars(false);status.text="Ładowanie ${src.name}…";pool.execute{try{val x=if(src.type=="xtream")Api.xtream(src.host,src.user,src.pass)else Api.m3u(src.url);runOnUiThread{allChannels=x;showLiveGroups()}}catch(e:Exception){runOnUiThread{status.text="Błąd: ${e.message}"}}}}
 private fun loadLive(){if(selectedSource==null)return;if(allChannels.isEmpty())loadSource(selectedSource!!) else showLiveGroups()}
 private fun showLiveGroups(){screen=Screen.LIVE_GROUPS;selectBars(false);groups=allChannels.map{it.group.ifBlank{"Other"}}.distinct().sortedBy{it.lowercase()};status.text="${selectedSource?.name.orEmpty()}  •  Telewizja: ${groups.size} grup / ${allChannels.size} kanałów";list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,groups.map{g->"$g   (${allChannels.count{it.group.ifBlank{"Other"}==g}})"})}
 private fun showChannels(group:String){screen=Screen.LIVE_CHANNELS;visibleChannels=allChannels.filter{it.group.ifBlank{"Other"}==group};status.text="$group  •  ${visibleChannels.size} kanałów  •  przytrzymaj kanał = ulubione";refreshChannelsAdapter();loadEpgForVisible()}
 private fun channelAdapter(items:List<Channel>):ArrayAdapter<Array<String>>{
  return object:ArrayAdapter<Array<String>>(this,android.R.layout.simple_list_item_2,android.R.id.text1,items.map{c->arrayOf(c.name,epgText[c.url].orEmpty())}){
   override fun getView(position:Int,convertView:View?,parent:android.view.ViewGroup):View{val v=super.getView(position,convertView,parent);val a=getItem(position)!!;v.findViewById<TextView>(android.R.id.text1).text=a[0];v.findViewById<TextView>(android.R.id.text2).apply{text=a[1];setTextColor(0xFFD4AF37.toInt())};return v}
  }
 }
 private fun refreshChannelsAdapter(){val items=if(screen==Screen.FAVORITES)favorites else visibleChannels;list.adapter=channelAdapter(items)}
 private fun loadEpgForVisible(){val src=selectedSource?:return;val items=(if(screen==Screen.FAVORITES)favorites else visibleChannels).take(80);refreshChannelsAdapter();items.forEach{c->if(!epgText.containsKey(c.url)){pool.execute{val e=Api.epgNow(src,c);if(e!=null){val times=if(e.start.isNotBlank()||e.end.isNotBlank())"${e.start} - ${e.end}  " else "";epgText[c.url]="$times${e.title}";runOnUiThread{if(screen==Screen.LIVE_CHANNELS||screen==Screen.FAVORITES)refreshChannelsAdapter()}}}}}}

 private fun loadVodCategories(){val src=selectedSource?:return;screen=Screen.VOD_CATS;selectBars(false);status.text="Ładowanie kategorii filmów…";pool.execute{try{val x=Api.vodCategories(src);runOnUiThread{vodCats=x;status.text="Filmy  •  ${x.size} kategorii";list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,x.map{it.name})}}catch(e:Exception){runOnUiThread{status.text="Filmy: ${e.message}";list.adapter=null}}}}
 private fun loadVodItems(cat:MediaCategory){val src=selectedSource?:return;screen=Screen.VOD_ITEMS;status.text="Ładowanie: ${cat.name}…";pool.execute{try{val x=Api.vodItems(src,cat.id);runOnUiThread{vodItems=x;status.text="${cat.name}  •  ${x.size} filmów";list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,x.map{it.name})}}catch(e:Exception){runOnUiThread{status.text="Błąd filmów: ${e.message}"}}}}

 private fun loadSeriesCategories(){val src=selectedSource?:return;screen=Screen.SERIES_CATS;selectBars(false);status.text="Ładowanie kategorii seriali…";pool.execute{try{val x=Api.seriesCategories(src);runOnUiThread{seriesCats=x;status.text="Seriale  •  ${x.size} kategorii";list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,x.map{it.name})}}catch(e:Exception){runOnUiThread{status.text="Seriale: ${e.message}";list.adapter=null}}}}
 private fun loadSeriesItems(cat:MediaCategory){val src=selectedSource?:return;screen=Screen.SERIES_ITEMS;status.text="Ładowanie: ${cat.name}…";pool.execute{try{val x=Api.seriesItems(src,cat.id);runOnUiThread{seriesItems=x;status.text="${cat.name}  •  ${x.size} seriali";list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,x.map{it.name})}}catch(e:Exception){runOnUiThread{status.text="Błąd seriali: ${e.message}"}}}}
 private fun loadSeasons(item:SeriesItem){val src=selectedSource?:return;selectedSeries=item;screen=Screen.SEASONS;status.text="Ładowanie sezonów: ${item.name}…";pool.execute{try{val p=Api.seasons(src,item.id);runOnUiThread{seasons=p.first;seasonEpisodes=p.second;status.text="${item.name}  •  ${seasons.size} sezonów";list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,seasons.map{it.name})}}catch(e:Exception){runOnUiThread{status.text="Błąd sezonów: ${e.message}"}}}}
 private fun showEpisodes(season:SeasonItem){screen=Screen.EPISODES;episodes=seasonEpisodes[season.id].orEmpty();status.text="${selectedSeries?.name.orEmpty()}  •  ${season.name}";list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,episodes.map{it.name})}

 private fun showFavorites(){screen=Screen.FAVORITES;selectBars(false);status.text="Ulubione  •  ${favorites.size} kanałów  •  przytrzymaj aby usunąć";refreshChannelsAdapter();loadEpgForVisible()}
 private fun toggleFavorite(c:Channel){val i=favorites.indexOfFirst{it.url==c.url};val added=i<0;if(added)favorites.add(c) else favorites.removeAt(i);FavoriteStore.save(this,favorites);Toast.makeText(this,if(added)"Dodano do ulubionych" else "Usunięto z ulubionych",Toast.LENGTH_SHORT).show();if(screen==Screen.FAVORITES)showFavorites()}

 private fun play(url:String,name:String,epg:String=""){startActivity(Intent(this,PlayerActivity::class.java).putExtra("url",url).putExtra("name",name).putExtra("epg",epg))}
 private fun onItem(i:Int){when(screen){
  Screen.SOURCES->if(i<sources.size)loadSource(sources[i]);Screen.LIVE_GROUPS->if(i<groups.size)showChannels(groups[i]);Screen.LIVE_CHANNELS->if(i<visibleChannels.size){val c=visibleChannels[i];play(c.url,c.name,epgText[c.url].orEmpty())}
  Screen.VOD_CATS->if(i<vodCats.size)loadVodItems(vodCats[i]);Screen.VOD_ITEMS->if(i<vodItems.size){val x=vodItems[i];play(x.url,x.name)}
  Screen.SERIES_CATS->if(i<seriesCats.size)loadSeriesItems(seriesCats[i]);Screen.SERIES_ITEMS->if(i<seriesItems.size)loadSeasons(seriesItems[i]);Screen.SEASONS->if(i<seasons.size)showEpisodes(seasons[i]);Screen.EPISODES->if(i<episodes.size){val ep=episodes[i];val src=selectedSource?:return;try{play(Api.episodeUrl(src,ep),ep.name)}catch(e:Exception){status.text=e.message}}
  Screen.FAVORITES->if(i<favorites.size){val c=favorites[i];play(c.url,c.name,epgText[c.url].orEmpty())}
 }}
 private fun onLongItem(i:Int):Boolean{when(screen){Screen.SOURCES->{if(i<sources.size)confirmDelete(i);return true};Screen.LIVE_CHANNELS->{if(i<visibleChannels.size)toggleFavorite(visibleChannels[i]);return true};Screen.FAVORITES->{if(i<favorites.size)toggleFavorite(favorites[i]);return true};else->return false}}

 private fun confirmExit(){AlertDialog.Builder(this).setTitle("Wyjść z TvMad-Xtream?").setMessage("Czy na pewno chcesz zamknąć aplikację?").setPositiveButton("Tak"){_,_->finishAffinity()}.setNegativeButton("Nie",null).show()}
 @Deprecated("Deprecated in Java") override fun onBackPressed(){when(screen){
  Screen.SOURCES->confirmExit();Screen.LIVE_GROUPS->showSources();Screen.LIVE_CHANNELS->showLiveGroups();Screen.VOD_CATS->showSources();Screen.VOD_ITEMS->loadVodCategories();Screen.SERIES_CATS->showSources();Screen.SERIES_ITEMS->loadSeriesCategories();Screen.SEASONS->{screen=Screen.SERIES_ITEMS;status.text="Seriale";list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,seriesItems.map{it.name})};Screen.EPISODES->{screen=Screen.SEASONS;status.text=selectedSeries?.name.orEmpty();list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,seasons.map{it.name})};Screen.FAVORITES->showLiveGroups()
 }}
 override fun onDestroy(){pool.shutdownNow();super.onDestroy()}
}
