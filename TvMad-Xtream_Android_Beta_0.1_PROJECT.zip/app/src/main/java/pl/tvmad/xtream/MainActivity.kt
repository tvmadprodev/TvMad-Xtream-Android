package pl.tvmad.xtream

import android.app.*
import android.os.*
import android.content.*
import android.graphics.BitmapFactory
import android.text.InputType
import android.view.*
import android.widget.*
import androidx.media3.common.*
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.common.util.UnstableApi
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean

@UnstableApi
class MainActivity:Activity(){
 private lateinit var list:ListView; private lateinit var channelList:ListView; private lateinit var status:TextView; private lateinit var sourceBar:View; private lateinit var dashboard:View; private lateinit var livePane:View
 private lateinit var rootFrame:FrameLayout; private lateinit var baseContent:View; private lateinit var miniVideoSlot:View
 private lateinit var miniPlayerView:PlayerView; private lateinit var miniPicon:ImageView; private lateinit var miniChannel:TextView; private lateinit var miniNow:TextView; private lateinit var miniDesc:TextView; private lateinit var miniProgress:ProgressBar
 private lateinit var liveFsInfo:View; private lateinit var fsPicon:ImageView; private lateinit var fsChannel:TextView; private lateinit var fsNow:TextView; private lateinit var fsNext:TextView; private lateinit var fsProgress:ProgressBar; private lateinit var fsAudio:Button; private lateinit var fsSubtitles:Button
 private lateinit var liveBufferingBox:View; private lateinit var liveBufferingText:TextView
 private val pool=Executors.newFixedThreadPool(2); private val epgPool=Executors.newFixedThreadPool(2); private val handler=Handler(Looper.getMainLooper())
 private var miniPlayer:ExoPlayer?=null; private var miniGeneration=0; private var miniCurrentChannel:Channel?=null; private var piconAdapter:PiconAdapter?=null
 private var allChannels=listOf<Channel>(); private var visibleChannels=listOf<Channel>(); private var groups=listOf<String>(); private var sources=mutableListOf<Source>(); private var selectedSource:Source?=null; private var piconMode=2
 private var vodCats=listOf<MediaCategory>(); private var vodItems=listOf<MediaItem>(); private var currentVodCat:MediaCategory?=null
 private var seriesCats=listOf<MediaCategory>(); private var seriesItems=listOf<SeriesItem>(); private var currentSeriesCat:MediaCategory?=null; private var seasons=listOf<SeasonItem>(); private var seasonEpisodes:Map<String,List<EpisodeItem>> = emptyMap(); private var episodes=listOf<EpisodeItem>(); private var selectedSeries:SeriesItem?=null
 private var favorites=mutableListOf<Channel>(); private val epgText=ConcurrentHashMap<String,String>(); private val epgEvents=ConcurrentHashMap<String,List<EpgEvent>>(); private val epgPending=ConcurrentHashMap.newKeySet<String>()
 private var web:WebConfigServer?=null
 private enum class Screen { SOURCES, HOME, LIVE_GROUPS, LIVE_CHANNELS, VOD_CATS, VOD_ITEMS, SERIES_CATS, SERIES_ITEMS, SEASONS, EPISODES, FAVORITES }
 private var screen=Screen.SOURCES
 private data class Pos(val first:Int=0,val top:Int=0)
 private var liveGroupsPos=Pos();private var liveGroupSelected=0;private var liveChannelSelected=0;private var autoResumeStarted=false;private var vodCatsPos=Pos();private var seriesCatsPos=Pos();private var seriesItemsPos=Pos();private var seasonsPos=Pos()
 private var liveFullscreen=false;private var liveSurfaceReady=false;private var liveListenerInstalled=false;private var liveHasPlayed=false;private var liveRetryCount=0;private var liveRetryScheduled=false
 private val hideLiveInfo=Runnable{if(liveFullscreen)liveFsInfo.visibility=View.GONE}
 private val liveProgressTick=object:Runnable{override fun run(){if(liveFullscreen)updateFullscreenInfo(miniCurrentChannel);handler.postDelayed(this,15000)}}
 private val liveBufferTick=object:Runnable{override fun run(){if(liveBufferingBox.visibility==View.VISIBLE){liveBufferingText.text="Buforowanie ${(miniPlayer?.bufferedPercentage?:0).coerceIn(0,100)}%  •  próba ${liveRetryCount.coerceAtLeast(1)}/3";handler.postDelayed(this,250)}}}
 private val liveRetry=Runnable{liveRetryScheduled=false;if(liveBufferingBox.visibility==View.VISIBLE&&liveRetryCount<3){liveRetryCount++;LivePlayerSession.restartCurrent();scheduleLiveRetry()}}

 override fun onCreate(b:Bundle?){
  super.onCreate(b);setContentView(R.layout.activity_main)
  rootFrame=findViewById(R.id.rootFrame);baseContent=findViewById(R.id.baseContent);miniVideoSlot=findViewById(R.id.miniVideoSlot)
  list=findViewById(R.id.list);channelList=findViewById(R.id.channelList);status=findViewById(R.id.status);sourceBar=findViewById(R.id.sourceBar);dashboard=findViewById(R.id.dashboard);livePane=findViewById(R.id.livePane)
  miniPlayerView=findViewById(R.id.miniPlayer);miniPicon=findViewById(R.id.miniPicon);miniChannel=findViewById(R.id.miniChannel);miniNow=findViewById(R.id.miniNow);miniDesc=findViewById(R.id.miniDesc);miniProgress=findViewById(R.id.miniProgress)
  liveFsInfo=findViewById(R.id.liveFsInfo);fsPicon=findViewById(R.id.fsPicon);fsChannel=findViewById(R.id.fsChannel);fsNow=findViewById(R.id.fsNow);fsNext=findViewById(R.id.fsNext);fsProgress=findViewById(R.id.fsProgress);fsAudio=findViewById(R.id.fsAudio);fsSubtitles=findViewById(R.id.fsSubtitles);liveBufferingBox=findViewById(R.id.liveBufferingBox);liveBufferingText=findViewById(R.id.liveBufferingText)
  miniPlayerView.useController=false;miniPlayerView.setKeepContentOnPlayerReset(true);miniPlayerView.resizeMode=androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
  fsAudio.setOnClickListener{showLiveTrackDialog(C.TRACK_TYPE_AUDIO,"Ścieżka audio")};fsSubtitles.setOnClickListener{showLiveTrackDialog(C.TRACK_TYPE_TEXT,"Napisy")}
  sources=SourceStore.load(this);favorites=FavoriteStore.load(this)
  findViewById<Button>(R.id.addXtream).setOnClickListener{xtreamDialog()};findViewById<Button>(R.id.addM3u).setOnClickListener{m3uDialog()}
  findViewById<Button>(R.id.piconMode).setOnClickListener{v->piconMode=(piconMode+1)%3;(v as Button).text="Picony: "+arrayOf("lokalne","źródło","oba")[piconMode];if(screen==Screen.LIVE_CHANNELS||screen==Screen.FAVORITES)refreshChannelsAdapter()}
  findViewById<Button>(R.id.tileLive).setOnClickListener{loadLive()};findViewById<Button>(R.id.tileVod).setOnClickListener{loadVodCategories()};findViewById<Button>(R.id.tileSeries).setOnClickListener{loadSeriesCategories()}
  list.setOnItemClickListener{_,_,i,_->onItem(i)};list.setOnItemLongClickListener{_,_,i,_->onLongItem(i)}
  channelList.setOnItemClickListener{_,_,i,_->onChannelItem(i)};channelList.setOnItemLongClickListener{_,_,i,_->if(screen==Screen.LIVE_CHANNELS&&i in visibleChannels.indices){showChannelOptions(visibleChannels[i]);true}else false}
  channelList.setOnItemSelectedListener(object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){if(screen==Screen.LIVE_CHANNELS&&pos in visibleChannels.indices){updateMiniInfo(visibleChannels[pos]);loadVisibleEpg()}}})
  channelList.setOnKeyListener{_,key,e->if(e.action==KeyEvent.ACTION_DOWN&&(key==KeyEvent.KEYCODE_DPAD_CENTER||key==KeyEvent.KEYCODE_ENTER)){val pos=channelList.selectedItemPosition;if(pos>=0){onChannelItem(pos);true}else false}else false}
  web=WebConfigServer(applicationContext,5557){runOnUiThread{sources=SourceStore.load(this);if(screen==Screen.SOURCES)showSources();refreshChannelsAdapter()}}.also{it.start()}
  findViewById<TextView>(R.id.webAddress).text="WWW: ${web?.address()}"
  if(!tryAutoResumeLastLive())showSources()
 }


 private fun tryAutoResumeLastLive():Boolean{
  if(autoResumeStarted||sources.isEmpty())return false
  val saved=LastLiveStore.load(this)?:return false
  val src=sources.firstOrNull{LastLiveStore.sourceMatches(saved.source,it)}?:return false
  autoResumeStarted=true;selectedSource=src
  val cached=LiveCacheStore.loadChannels(this,src)
  allChannels=if(cached.isNotEmpty())cached else listOf(saved.channel)
  val c=allChannels.firstOrNull{it.url==saved.channel.url}?:saved.channel
  LiveCacheStore.loadLastEpg(this,src,c).takeIf{it.isNotEmpty()}?.let{ev->epgEvents[c.url]=ev;val e=ev.first();epgText[c.url]=(if(e.start.isNotBlank()||e.end.isNotBlank())"${e.start} - ${e.end}  " else "")+e.title}
  prepareLiveStateFor(c)
  screen=Screen.LIVE_CHANNELS;setMode(live=true);refreshChannelsAdapter(false);miniCurrentChannel=c;updateMiniInfo(c)
  rootFrame.post{if(liveChannelSelected in visibleChannels.indices)channelList.setSelection(liveChannelSelected);startMini(c);enterLiveFullscreen(c,false)}
  loadEpgForChannels(listOf(c))
  pool.execute{try{val fresh=if(src.type=="xtream")Api.xtream(src.host,src.user,src.pass)else Api.m3u(src.url);LiveCacheStore.saveChannels(this,src,fresh);runOnUiThread{allChannels=fresh;prepareLiveStateFor(c);refreshChannelsAdapter(false);channelList.setSelection(liveChannelSelected);loadVisibleEpg()}}catch(_:Exception){}}
  return true
 }
 private fun prepareLiveStateFor(c:Channel){val counts=LinkedHashMap<String,Int>();allChannels.forEach{ch->val g=ch.group.ifBlank{"Other"};counts[g]=(counts[g]?:0)+1};groups=counts.keys.sortedBy{it.lowercase()};val group=c.group.ifBlank{"Other"};liveGroupSelected=groups.indexOf(group).coerceAtLeast(0);visibleChannels=allChannels.filter{it.group.ifBlank{"Other"}==group};if(visibleChannels.isEmpty())visibleChannels=listOf(c);liveChannelSelected=visibleChannels.indexOfFirst{it.url==c.url}.coerceAtLeast(0)}

 private fun currentList():ListView=if(screen==Screen.LIVE_CHANNELS||screen==Screen.LIVE_GROUPS)channelList else list
 private fun position():Pos{val l=currentList();return if(l.childCount>0)Pos(l.firstVisiblePosition,l.getChildAt(0).top)else Pos()}
 private fun restore(p:Pos){currentList().post{currentList().setSelectionFromTop(p.first,p.top)}}
 private fun setMode(sourcesMode:Boolean=false,home:Boolean=false,live:Boolean=false){sourceBar.visibility=if(sourcesMode)View.VISIBLE else View.GONE;dashboard.visibility=if(home)View.VISIBLE else View.GONE;livePane.visibility=if(live)View.VISIBLE else View.GONE;list.visibility=if(!home&&!live)View.VISIBLE else View.GONE}
 private fun field(h:String)=EditText(this).apply{hint=h;setSingleLine(true)}
 private fun xtreamDialog(){val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,0,28,0)};val n=field("Nazwa serwera, np. Dom");val h=field("http://serwer:port");val u=field("Użytkownik");val p=field("Hasło").apply{inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD};listOf(n,h,u,p).forEach{box.addView(it)};AlertDialog.Builder(this).setTitle("Dodaj Xtream Codes").setView(box).setPositiveButton("Zapisz i wczytaj"){_,_->val host=h.text.toString().trim();saveAndLoad(Source("xtream",n.text.toString().trim().ifBlank{host},host,u.text.toString(),p.text.toString()))}.setNegativeButton("Anuluj",null).show()}
 private fun m3uDialog(){val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,0,28,0)};val n=field("Nazwa listy");val u=field("Pełny URL listy M3U");box.addView(n);box.addView(u);AlertDialog.Builder(this).setTitle("Dodaj M3U").setView(box).setPositiveButton("Zapisz i wczytaj"){_,_->val url=u.text.toString().trim();saveAndLoad(Source("m3u",n.text.toString().trim().ifBlank{"M3U ${sources.size+1}"},url=url))}.setNegativeButton("Anuluj",null).show()}
 private fun saveAndLoad(src:Source){val same=sources.indexOfFirst{it.type==src.type&&((src.type=="xtream"&&it.host==src.host&&it.user==src.user)||(src.type=="m3u"&&it.url==src.url))};if(same>=0)sources[same]=src else sources.add(src);SourceStore.save(this,sources);loadSource(src)}
 private fun confirmDelete(i:Int){val s=sources[i];AlertDialog.Builder(this).setTitle("Usunąć serwer?").setMessage(s.name).setPositiveButton("Usuń"){_,_->sources.removeAt(i);SourceStore.save(this,sources);showSources()}.setNegativeButton("Anuluj",null).show()}
 private fun showSources(){releaseMini();miniCurrentChannel=null;screen=Screen.SOURCES;selectedSource=null;allChannels=emptyList();visibleChannels=emptyList();setMode(sourcesMode=true);status.text="Serwery: ${sources.size}  •  WWW: ${web?.address()}  •  OK = wczytaj, przytrzymaj = usuń";list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,sources.map{"${if(it.type=="xtream") "XCODES" else "M3U"}  •  ${it.name}"});list.requestFocus()}
 private fun loadSource(src:Source){selectedSource=src;val cached=LiveCacheStore.loadChannels(this,src);if(cached.isNotEmpty()){allChannels=cached;showHome();pool.execute{try{val x=if(src.type=="xtream")Api.xtream(src.host,src.user,src.pass)else Api.m3u(src.url);LiveCacheStore.saveChannels(this,src,x);runOnUiThread{allChannels=x}}catch(_:Exception){}}}else{setMode();status.text="Ładowanie ${src.name}…";pool.execute{try{val x=if(src.type=="xtream")Api.xtream(src.host,src.user,src.pass)else Api.m3u(src.url);LiveCacheStore.saveChannels(this,src,x);runOnUiThread{allChannels=x;showHome()}}catch(e:Exception){runOnUiThread{status.text="Błąd: ${e.message}";showSources()}}}}}
 private fun showHome(){releaseMini();screen=Screen.HOME;setMode(home=true);status.text="${selectedSource?.name.orEmpty()}  •  wybierz dział";findViewById<Button>(R.id.tileLive).requestFocus()}
 private fun loadLive(){if(selectedSource==null)return;if(allChannels.isEmpty())loadSource(selectedSource!!) else showLiveGroups()}
 private fun showLiveGroups(restorePos:Pos?=null){
  screen=Screen.LIVE_GROUPS;setMode(live=true);visibleChannels=emptyList();piconAdapter?.close();piconAdapter=null
  val counts=LinkedHashMap<String,Int>();allChannels.forEach{c->val g=c.group.ifBlank{"Other"};counts[g]=(counts[g]?:0)+1};groups=counts.keys.sortedBy{it.lowercase()}
  status.text="Telewizja  •  ${groups.size} grup / ${allChannels.size} kanałów  •  OK = wejdź do grupy"
  channelList.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,groups.map{g->"$g   (${counts[g]?:0})"})
  channelList.setOnScrollListener(null);restorePos?.let{restore(it)}
  channelList.post{channelList.clearChoices();channelList.choiceMode=AbsListView.CHOICE_MODE_NONE;if(liveGroupSelected in groups.indices)channelList.setSelection(liveGroupSelected);channelList.requestFocus()}
  if(miniCurrentChannel==null&&allChannels.isNotEmpty())miniCurrentChannel=allChannels.first()
  miniCurrentChannel?.let{c->updateMiniInfo(c);loadEpgForChannels(listOf(c));startMini(c)}
 }
 private fun showChannels(group:String){
  screen=Screen.LIVE_CHANNELS;setMode(live=true);visibleChannels=allChannels.filter{it.group.ifBlank{"Other"}==group}
  status.text="$group  •  ${visibleChannels.size} kanałów  •  OK = pełny ekran, przytrzymaj = opcje"
  refreshChannelsAdapter(false);channelList.clearChoices();channelList.choiceMode=AbsListView.CHOICE_MODE_NONE;channelList.requestFocus();channelList.setOnScrollListener(object:AbsListView.OnScrollListener{override fun onScrollStateChanged(v:AbsListView?,state:Int){if(state==AbsListView.OnScrollListener.SCROLL_STATE_IDLE)loadVisibleEpg()};override fun onScroll(v:AbsListView?,first:Int,count:Int,total:Int){}})
  if(visibleChannels.isNotEmpty()){liveChannelSelected=liveChannelSelected.coerceIn(0,visibleChannels.lastIndex);channelList.setSelection(liveChannelSelected);loadVisibleEpg();updateMiniInfo(visibleChannels[liveChannelSelected])}
  miniCurrentChannel?.let{startMini(it)}
 }
 private fun loadVisibleEpg(){if(screen!=Screen.LIVE_CHANNELS)return;val first=channelList.firstVisiblePosition.coerceAtLeast(0);val count=channelList.childCount.coerceAtLeast(8);val from=(first-3).coerceAtLeast(0);val to=(first+count+6).coerceAtMost(visibleChannels.size);if(from<to)loadEpgForChannels(visibleChannels.subList(from,to))}
 private fun refreshChannelsAdapter(preserve:Boolean=true){if(screen!=Screen.LIVE_CHANNELS&&screen!=Screen.FAVORITES)return;val p=if(preserve)position()else Pos();val items=if(screen==Screen.FAVORITES)favorites else visibleChannels;piconAdapter?.close();piconAdapter=PiconAdapter(this,items,epgText,epgEvents,piconMode);currentList().adapter=piconAdapter;if(preserve)restore(p)}

 private val refreshScheduled=AtomicBoolean(false)
 private fun scheduleEpgUiRefresh(){if(refreshScheduled.compareAndSet(false,true)){handler.postDelayed({refreshScheduled.set(false);if(screen==Screen.LIVE_CHANNELS||screen==Screen.FAVORITES)piconAdapter?.notifyDataSetChanged();if(screen==Screen.LIVE_CHANNELS){val pos=channelList.selectedItemPosition;if(pos in visibleChannels.indices)updateMiniInfo(visibleChannels[pos])}else if(screen==Screen.LIVE_GROUPS){miniCurrentChannel?.let{updateMiniInfo(it)}};if(liveFullscreen)updateFullscreenInfo(miniCurrentChannel)},180)}}
 private fun loadEpgForChannels(items:List<Channel>){
  val src=selectedSource?:return
  items.forEach { c ->
   if(!epgText.containsKey(c.url) && epgPending.add(c.url)){
    epgPool.execute {
     try {
      val ev=Api.epgNowNext(src,c)
      if(ev.isNotEmpty()){
       epgEvents[c.url]=ev
       if(miniCurrentChannel?.url==c.url)LiveCacheStore.saveLastEpg(this,src,c,ev)
       val e=ev.first()
       val times=if(e.start.isNotBlank()||e.end.isNotBlank()) "${e.start} - ${e.end}  " else ""
       epgText[c.url]="$times${e.title}"
      }
     } finally {
      epgPending.remove(c.url)
      scheduleEpgUiRefresh()
     }
    }
   }
  }
 }

 private fun updateMiniInfo(c:Channel){miniChannel.text=c.name;val ev=epgEvents[c.url].orEmpty();val now=ev.firstOrNull();miniNow.text=if(now==null)epgText[c.url].orEmpty() else (if(now.start.isNotBlank()||now.end.isNotBlank())"${now.start} - ${now.end}  " else "")+now.title;miniDesc.text=now?.description.orEmpty();if(now!=null&&now.startEpoch>0&&now.endEpoch>now.startEpoch){val n=System.currentTimeMillis();miniProgress.progress=(((n-now.startEpoch).coerceIn(0,now.endEpoch-now.startEpoch)*1000)/(now.endEpoch-now.startEpoch)).toInt()}else miniProgress.progress=0;loadMiniPicon(c)}
 private fun loadMiniPicon(c:Channel){miniPicon.setImageDrawable(null);val local=if(piconMode==0||piconMode==2)PiconRepository.find(this,c.name)else null;if(local!=null){miniPicon.setImageBitmap(BitmapFactory.decodeFile(local.absolutePath));return};if((piconMode==1||piconMode==2)&&c.logo.isNotBlank())pool.execute{try{val b=URL(c.logo).openStream().use{it.readBytes()};runOnUiThread{if((screen==Screen.LIVE_CHANNELS||screen==Screen.LIVE_GROUPS)&&miniChannel.text==c.name)miniPicon.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.size))}}catch(_:Exception){}}}
 private fun startMini(c:Channel){if(screen!=Screen.LIVE_CHANNELS&&screen!=Screen.LIVE_GROUPS)return;miniCurrentChannel=c;miniGeneration++;try{val p=LivePlayerSession.ensure(this,c.url);miniPlayer=p;if(miniPlayerView.player!==p)miniPlayerView.player=p;p.volume=1f;installLiveListenerOnce(p);miniPlayerView.visibility=View.VISIBLE;positionLiveSurfaceToMini(false)}catch(_:Exception){}}
 private fun releaseMini(){miniGeneration++;liveFullscreen=false;liveFsInfo.visibility=View.GONE;liveBufferingBox.visibility=View.GONE;miniPlayerView.visibility=View.GONE;miniPlayerView.player=null;try{LivePlayerSession.release()}catch(_:Exception){};miniPlayer=null;liveSurfaceReady=false;liveListenerInstalled=false}

 private fun renderVodCats(p:Pos?=null){screen=Screen.VOD_CATS;setMode();status.text="Filmy  •  ${vodCats.size} kategorii";list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,vodCats.map{it.name});p?.let{restore(it)};list.requestFocus()}
 private fun loadVodCategories(){releaseMini();val src=selectedSource?:return;screen=Screen.VOD_CATS;setMode();status.text="Ładowanie kategorii filmów…";pool.execute{try{val x=Api.vodCategories(src);runOnUiThread{vodCats=x;renderVodCats()}}catch(e:Exception){runOnUiThread{status.text="Filmy: ${e.message}"}}}}
 private fun loadVodItems(cat:MediaCategory){val src=selectedSource?:return;currentVodCat=cat;status.text="Ładowanie: ${cat.name}…";pool.execute{try{val x=Api.vodItems(src,cat.id);runOnUiThread{screen=Screen.VOD_ITEMS;setMode();vodItems=x;status.text="${cat.name}  •  ${x.size} filmów";list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,x.map{it.name});list.requestFocus()}}catch(e:Exception){runOnUiThread{status.text="Błąd filmów: ${e.message}"}}}}
 private fun renderSeriesCats(p:Pos?=null){screen=Screen.SERIES_CATS;setMode();status.text="Seriale  •  ${seriesCats.size} kategorii";list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,seriesCats.map{it.name});p?.let{restore(it)};list.requestFocus()}
 private fun loadSeriesCategories(){releaseMini();val src=selectedSource?:return;screen=Screen.SERIES_CATS;setMode();status.text="Ładowanie kategorii seriali…";pool.execute{try{val x=Api.seriesCategories(src);runOnUiThread{seriesCats=x;renderSeriesCats()}}catch(e:Exception){runOnUiThread{status.text="Seriale: ${e.message}"}}}}
 private fun loadSeriesItems(cat:MediaCategory){val src=selectedSource?:return;currentSeriesCat=cat;status.text="Ładowanie: ${cat.name}…";pool.execute{try{val x=Api.seriesItems(src,cat.id);runOnUiThread{seriesItems=x;renderSeriesItems()}}catch(e:Exception){runOnUiThread{status.text="Błąd seriali: ${e.message}"}}}}
 private fun renderSeriesItems(p:Pos?=null){screen=Screen.SERIES_ITEMS;setMode();status.text="${currentSeriesCat?.name.orEmpty()}  •  ${seriesItems.size} seriali";list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,seriesItems.map{it.name});p?.let{restore(it)};list.requestFocus()}
 private fun loadSeasons(item:SeriesItem){val src=selectedSource?:return;selectedSeries=item;status.text="Ładowanie sezonów: ${item.name}…";pool.execute{try{val p=Api.seasons(src,item.id);runOnUiThread{seasons=p.first;seasonEpisodes=p.second;renderSeasons()}}catch(e:Exception){runOnUiThread{status.text="Błąd sezonów: ${e.message}"}}}}
 private fun renderSeasons(p:Pos?=null){screen=Screen.SEASONS;setMode();status.text="${selectedSeries?.name.orEmpty()}  •  ${seasons.size} sezonów";list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,seasons.map{it.name});p?.let{restore(it)};list.requestFocus()}
 private fun showEpisodes(season:SeasonItem){screen=Screen.EPISODES;setMode();episodes=seasonEpisodes[season.id].orEmpty();status.text="${selectedSeries?.name.orEmpty()}  •  ${season.name}";list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,episodes.map{it.name});list.requestFocus()}
 private fun showFavorites(){releaseMini();screen=Screen.FAVORITES;setMode();status.text="Ulubione  •  ${favorites.size} kanałów";piconAdapter?.close();piconAdapter=PiconAdapter(this,favorites,epgText,epgEvents,piconMode);list.adapter=piconAdapter;loadEpgForChannels(favorites);list.requestFocus()}
 private fun toggleFavorite(c:Channel){val i=favorites.indexOfFirst{it.url==c.url};val added=i<0;if(added)favorites.add(c)else favorites.removeAt(i);FavoriteStore.save(this,favorites);Toast.makeText(this,if(added)"Dodano do ulubionych" else "Usunięto z ulubionych",Toast.LENGTH_SHORT).show();if(screen==Screen.FAVORITES)showFavorites()}

 private fun play(url:String,name:String,epg:String="",vod:Boolean=false,channel:Channel?=null){
  if(!vod&&channel!=null){miniCurrentChannel=channel;selectedSource?.let{LastLiveStore.save(this,it,channel)};startMini(channel);enterLiveFullscreen(channel,true);return}
  releaseMini()
  val i=Intent(this,PlayerActivity::class.java).putExtra("url",url).putExtra("name",name).putExtra("epg",epg).putExtra("vod",true)
  selectedSource?.let{src->i.putExtra("sourceType",src.type).putExtra("sourceName",src.name).putExtra("sourceHost",src.host).putExtra("sourceUser",src.user).putExtra("sourcePass",src.pass).putExtra("sourceUrl",src.url)}
  startActivity(i)
 }
 private fun onChannelItem(i:Int){when(screen){Screen.LIVE_GROUPS->if(i in groups.indices){liveGroupsPos=position();liveGroupSelected=i;liveChannelSelected=0;showChannels(groups[i])};Screen.LIVE_CHANNELS->if(i in visibleChannels.indices){liveChannelSelected=i;val c=visibleChannels[i];play(c.url,c.name,epgText[c.url].orEmpty(),false,c)};else->{}}}
 private fun showDetails(kind:String,title:String,fallbackPoster:String,actionText:String,action:()->Unit){val p=position();val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,16,24,8);setBackgroundColor(0xFF151515.toInt())};val iv=ImageView(this).apply{adjustViewBounds=true;scaleType=ImageView.ScaleType.CENTER_INSIDE;maxHeight=(resources.displayMetrics.heightPixels*0.45).toInt()};val tt=TextView(this).apply{text=title;textSize=23f;setTextColor(0xFF42A5F5.toInt());setPadding(0,8,0,6)};val meta=TextView(this).apply{text="Ładowanie informacji TMDB…";setTextColor(0xFFCCCCCC.toInt())};val desc=TextView(this).apply{setTextColor(0xFFFFFFFF.toInt());setPadding(0,8,0,0)};box.addView(iv);box.addView(tt);box.addView(meta);box.addView(desc);val dlg=AlertDialog.Builder(this).setView(ScrollView(this).apply{addView(box)}).setPositiveButton(actionText){_,_->restore(p);action()}.setNegativeButton("Wróć",null).create();dlg.setOnDismissListener{restore(p)};dlg.show();if(fallbackPoster.isNotBlank())pool.execute{Tmdb.loadImage(fallbackPoster)?.let{b->runOnUiThread{iv.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.size))}}};pool.execute{val m=Tmdb.fetch(kind,title);runOnUiThread{if(m==null){meta.text="TMDB: nie znaleziono danych"}else{tt.text=m.title;meta.text=listOf(m.year,m.rating,m.runtime,m.genres).filter{it.isNotBlank()}.joinToString("  •  ");desc.text=m.overview;if(m.poster.isNotBlank())pool.execute{Tmdb.loadImage(m.poster)?.let{b->runOnUiThread{iv.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.size))}}}}}}}
 private fun onItem(i:Int){when(screen){Screen.SOURCES->if(i<sources.size)loadSource(sources[i]);Screen.LIVE_GROUPS->if(i<groups.size){liveGroupsPos=position();liveGroupSelected=i;liveChannelSelected=0;showChannels(groups[i])};Screen.VOD_CATS->if(i<vodCats.size){vodCatsPos=position();loadVodItems(vodCats[i])};Screen.VOD_ITEMS->if(i<vodItems.size){val x=vodItems[i];showDetails("movie",x.name,x.icon,"PLAY"){play(x.url,x.name,"",true)}};Screen.SERIES_CATS->if(i<seriesCats.size){seriesCatsPos=position();loadSeriesItems(seriesCats[i])};Screen.SERIES_ITEMS->if(i<seriesItems.size){val x=seriesItems[i];seriesItemsPos=position();showDetails("tv",x.name,x.cover,"SEZONY"){loadSeasons(x)}};Screen.SEASONS->if(i<seasons.size){seasonsPos=position();showEpisodes(seasons[i])};Screen.EPISODES->if(i<episodes.size){val ep=episodes[i];val src=selectedSource?:return;play(Api.episodeUrl(src,ep),ep.name,"",true)};Screen.FAVORITES->if(i<favorites.size){val c=favorites[i];play(c.url,c.name,epgText[c.url].orEmpty(),false,c)};else->{}}}
 private fun showChannelOptions(c:Channel){val isFav=favorites.any{it.url==c.url};AlertDialog.Builder(this).setTitle(c.name).setItems(arrayOf(if(isFav)"Usuń z ulubionych" else "Dodaj do ulubionych","Wyświetl EPG")){_,w->if(w==0)toggleFavorite(c)else showEpgSchedule(c)}.setNegativeButton("Anuluj",null).show()}
 private fun showEpgSchedule(c:Channel){val src=selectedSource?:return;val loading=AlertDialog.Builder(this).setTitle("EPG • ${c.name}").setMessage("Ładowanie pełnego EPG…").setNegativeButton("Anuluj",null).create();loading.show();pool.execute{val events=try{Api.epgSchedule(src,c)}catch(_:Exception){emptyList()};runOnUiThread{if(!loading.isShowing)return@runOnUiThread;loading.dismiss();if(events.isEmpty()){AlertDialog.Builder(this).setTitle("EPG • ${c.name}").setMessage("Brak pełnego EPG dla tego kanału.").setPositiveButton("Wróć",null).show();return@runOnUiThread};val rows=events.map{e->(if(e.start.isNotBlank()||e.end.isNotBlank())"${e.start} - ${e.end}   " else "")+e.title};val lv=ListView(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_list_item_1,rows);dividerHeight=1};val dlg=AlertDialog.Builder(this).setTitle("EPG • ${c.name}").setView(lv).setNegativeButton("Wróć",null).create();lv.setOnItemClickListener{_,_,pos,_->val e=events[pos];val wt=if(e.start.isNotBlank()||e.end.isNotBlank())"${e.start} - ${e.end}" else "";AlertDialog.Builder(this).setTitle(e.title).setMessage(listOf(wt,e.description.ifBlank{"Brak szczegółowego opisu."}).filter{it.isNotBlank()}.joinToString("\n\n")).setPositiveButton("Wróć",null).show()};dlg.show()}}}
 private fun onLongItem(i:Int):Boolean{when(screen){Screen.SOURCES->{if(i<sources.size)confirmDelete(i);return true};Screen.FAVORITES->{if(i<favorites.size)showChannelOptions(favorites[i]);return true};else->return false}}

 private fun miniSlotRect():android.graphics.Rect{
  val rootLoc=IntArray(2);val slotLoc=IntArray(2);rootFrame.getLocationOnScreen(rootLoc);miniVideoSlot.getLocationOnScreen(slotLoc)
  return android.graphics.Rect(slotLoc[0]-rootLoc[0],slotLoc[1]-rootLoc[1],slotLoc[0]-rootLoc[0]+miniVideoSlot.width,slotLoc[1]-rootLoc[1]+miniVideoSlot.height)
 }
 private fun setLiveSurfaceBounds(x:Int,y:Int,w:Int,h:Int){val lp=miniPlayerView.layoutParams as FrameLayout.LayoutParams;lp.width=w.coerceAtLeast(1);lp.height=h.coerceAtLeast(1);miniPlayerView.layoutParams=lp;miniPlayerView.x=x.toFloat();miniPlayerView.y=y.toFloat();miniPlayerView.scaleX=1f;miniPlayerView.scaleY=1f}
 private fun positionLiveSurfaceToMini(animate:Boolean){if(miniVideoSlot.width<=0||miniVideoSlot.height<=0){miniVideoSlot.post{if(!liveFullscreen)positionLiveSurfaceToMini(animate)};return};val r=miniSlotRect();miniPlayerView.visibility=View.VISIBLE
  if(!animate||!liveSurfaceReady){setLiveSurfaceBounds(r.left,r.top,r.width(),r.height());liveSurfaceReady=true;return}
  val sx=r.width().toFloat()/rootFrame.width.coerceAtLeast(1);val sy=r.height().toFloat()/rootFrame.height.coerceAtLeast(1)
  miniPlayerView.pivotX=0f;miniPlayerView.pivotY=0f;miniPlayerView.animate().cancel();miniPlayerView.animate().x(r.left.toFloat()).y(r.top.toFloat()).scaleX(sx).scaleY(sy).setDuration(260).withEndAction{setLiveSurfaceBounds(r.left,r.top,r.width(),r.height());channelList.requestFocus()}.start()
 }
 private fun enterLiveFullscreen(c:Channel,animate:Boolean){miniCurrentChannel=c;selectedSource?.let{LastLiveStore.save(this,it,c)};val idx=visibleChannels.indexOfFirst{it.url==c.url};if(idx>=0)liveChannelSelected=idx;updateFullscreenInfo(c);liveFullscreen=true;showLiveInfo(5000);miniPlayerView.bringToFront();liveFsInfo.bringToFront();liveBufferingBox.bringToFront();miniPlayerView.visibility=View.VISIBLE
  if(!liveSurfaceReady){positionLiveSurfaceToMini(false)}
  val r=miniSlotRect();if(animate&&rootFrame.width>0&&rootFrame.height>0){setLiveSurfaceBounds(r.left,r.top,r.width(),r.height());val sx=rootFrame.width.toFloat()/r.width().coerceAtLeast(1);val sy=rootFrame.height.toFloat()/r.height().coerceAtLeast(1);miniPlayerView.pivotX=0f;miniPlayerView.pivotY=0f;miniPlayerView.animate().cancel();miniPlayerView.animate().x(0f).y(0f).scaleX(sx).scaleY(sy).setDuration(260).withEndAction{setLiveSurfaceBounds(0,0,rootFrame.width,rootFrame.height);liveFsInfo.bringToFront();liveBufferingBox.bringToFront()}.start()}else setLiveSurfaceBounds(0,0,rootFrame.width.coerceAtLeast(resources.displayMetrics.widthPixels),rootFrame.height.coerceAtLeast(resources.displayMetrics.heightPixels))
  immersiveLive()
 }
 private fun exitLiveFullscreen(){if(!liveFullscreen)return;liveFullscreen=false;handler.removeCallbacks(hideLiveInfo);liveFsInfo.visibility=View.GONE;liveBufferingBox.visibility=View.GONE;positionLiveSurfaceToMini(true);val c=miniCurrentChannel;c?.let{updateMiniInfo(it)};if(screen==Screen.LIVE_CHANNELS){val idx=visibleChannels.indexOfFirst{it.url==c?.url};if(idx>=0)liveChannelSelected=idx;channelList.post{channelList.clearChoices();channelList.choiceMode=AbsListView.CHOICE_MODE_NONE;channelList.setSelection(liveChannelSelected);channelList.requestFocus()}}}
 private fun showLiveInfo(delay:Long=5000){if(!liveFullscreen)return;updateFullscreenInfo(miniCurrentChannel);liveFsInfo.visibility=View.VISIBLE;liveFsInfo.bringToFront();handler.removeCallbacks(hideLiveInfo);handler.postDelayed(hideLiveInfo,delay)}
 private fun updateFullscreenInfo(c:Channel?){c?:return;fsChannel.text=c.name;val ev=epgEvents[c.url].orEmpty();val now=ev.getOrNull(0);val next=ev.getOrNull(1);fsNow.text=if(now==null)epgText[c.url].orEmpty() else (if(now.start.isNotBlank()||now.end.isNotBlank())"${now.start} - ${now.end}  " else "")+now.title;fsNext.text=if(next==null)"" else "Następnie: "+(if(next.start.isNotBlank()||next.end.isNotBlank())"${next.start} - ${next.end}  " else "")+next.title;if(now!=null&&now.startEpoch>0&&now.endEpoch>now.startEpoch){val n=System.currentTimeMillis();fsProgress.progress=(((n-now.startEpoch).coerceIn(0,now.endEpoch-now.startEpoch)*1000)/(now.endEpoch-now.startEpoch)).toInt()}else fsProgress.progress=0;loadFsPicon(c)}
 private fun loadFsPicon(c:Channel){fsPicon.setImageDrawable(null);val local=if(piconMode==0||piconMode==2)PiconRepository.find(this,c.name)else null;if(local!=null){fsPicon.setImageBitmap(BitmapFactory.decodeFile(local.absolutePath));return};if((piconMode==1||piconMode==2)&&c.logo.isNotBlank())pool.execute{try{val b=URL(c.logo).openStream().use{it.readBytes()};runOnUiThread{if(miniCurrentChannel?.url==c.url)fsPicon.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.size))}}catch(_:Exception){}}}
 private fun switchLiveInline(delta:Int){if(visibleChannels.isEmpty())return;liveChannelSelected=(liveChannelSelected+delta+visibleChannels.size)%visibleChannels.size;val c=visibleChannels[liveChannelSelected];miniCurrentChannel=c;selectedSource?.let{LastLiveStore.save(this,it,c)};liveHasPlayed=false;liveRetryCount=0;hideLiveBuffer();val p=LivePlayerSession.ensure(this,c.url);miniPlayer=p;if(miniPlayerView.player!==p)miniPlayerView.player=p;loadEpgForChannels(listOf(c));updateFullscreenInfo(c);showLiveInfo(5000)}
 private fun installLiveListenerOnce(p:ExoPlayer){if(liveListenerInstalled)return;liveListenerInstalled=true;p.addListener(object:Player.Listener{
  override fun onIsPlayingChanged(v:Boolean){if(v){liveHasPlayed=true;liveRetryCount=0;hideLiveBuffer()}}
  override fun onPlaybackStateChanged(state:Int){if(state==Player.STATE_BUFFERING&&liveHasPlayed){showLiveBuffer();scheduleLiveRetry()}else if(state==Player.STATE_READY){hideLiveBuffer()}}
  override fun onTracksChanged(tracks:Tracks){updateLiveTrackButtons(tracks)}
  override fun onPlayerError(error:PlaybackException){if(liveHasPlayed){showLiveBuffer();scheduleLiveRetry(700)}}
 })}
 private fun updateLiveTrackButtons(tracks:Tracks){var ac=0;var tc=0;for(g in tracks.groups){if(g.type==C.TRACK_TYPE_AUDIO)for(i in 0 until g.length)if(g.isTrackSupported(i))ac++;if(g.type==C.TRACK_TYPE_TEXT)for(i in 0 until g.length)if(g.isTrackSupported(i))tc++};fsAudio.visibility=if(ac>1)View.VISIBLE else View.GONE;fsSubtitles.visibility=if(tc>0)View.VISIBLE else View.GONE}
 private data class LiveTrackChoice(val label:String,val group:Tracks.Group?,val index:Int)
 private fun showLiveTrackDialog(type:Int,title:String){val p=miniPlayer?:return;val choices=ArrayList<LiveTrackChoice>();if(type==C.TRACK_TYPE_TEXT)choices+=LiveTrackChoice("Wyłącz napisy",null,-1);for(g in p.currentTracks.groups){if(g.type!=type)continue;for(i in 0 until g.length){if(!g.isTrackSupported(i))continue;val f=g.getTrackFormat(i);val lang=f.language?.uppercase().orEmpty();val label=f.label?.takeIf{it.isNotBlank()}?:if(type==C.TRACK_TYPE_AUDIO)"Audio ${choices.size+1}" else "Napisy ${choices.size+1}";choices+=LiveTrackChoice(if(lang.isBlank())label else "$label  [$lang]",g,i)}};if(choices.isEmpty()||(type==C.TRACK_TYPE_TEXT&&choices.size==1))return;AlertDialog.Builder(this).setTitle(title).setItems(choices.map{it.label}.toTypedArray()){_,w->val c=choices[w];val b=p.trackSelectionParameters.buildUpon().clearOverridesOfType(type);if(c.group==null)b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT,true)else{b.setTrackTypeDisabled(type,false);b.setOverrideForType(TrackSelectionOverride(c.group.mediaTrackGroup,listOf(c.index)))};p.trackSelectionParameters=b.build();showLiveInfo(5000)}.setNegativeButton("Anuluj",null).show()}
 private fun showLiveBuffer(){if(!liveHasPlayed)return;liveBufferingBox.visibility=View.VISIBLE;liveBufferingBox.bringToFront();handler.removeCallbacks(liveBufferTick);handler.post(liveBufferTick)}
 private fun hideLiveBuffer(){liveBufferingBox.visibility=View.GONE;handler.removeCallbacks(liveBufferTick);handler.removeCallbacks(liveRetry);liveRetryScheduled=false}
 private fun scheduleLiveRetry(delay:Long=3500){if(!liveHasPlayed||liveRetryScheduled||liveRetryCount>=3)return;liveRetryScheduled=true;handler.postDelayed(liveRetry,delay)}
 private fun immersiveLive(){window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);if(Build.VERSION.SDK_INT>=30){window.setDecorFitsSystemWindows(false);window.insetsController?.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())}else{@Suppress("DEPRECATION")window.decorView.systemUiVisibility=View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY}}
 override fun dispatchKeyEvent(e:KeyEvent):Boolean{if(liveFullscreen){if(e.action==KeyEvent.ACTION_DOWN){when(e.keyCode){KeyEvent.KEYCODE_DPAD_UP,KeyEvent.KEYCODE_CHANNEL_UP->{switchLiveInline(1);return true};KeyEvent.KEYCODE_DPAD_DOWN,KeyEvent.KEYCODE_CHANNEL_DOWN->{switchLiveInline(-1);return true};KeyEvent.KEYCODE_DPAD_CENTER,KeyEvent.KEYCODE_ENTER->{showLiveInfo(5000);return true};KeyEvent.KEYCODE_BACK->{exitLiveFullscreen();return true}}};return true};return super.dispatchKeyEvent(e)}
 private fun confirmExit(){AlertDialog.Builder(this).setTitle("Wyjść z TvMad-Xtream TV?").setMessage("Czy na pewno chcesz zamknąć aplikację?").setPositiveButton("Tak"){_,_->finishAffinity()}.setNegativeButton("Nie",null).show()}
 @Deprecated("Deprecated in Java") override fun onBackPressed(){if(liveFullscreen){exitLiveFullscreen();return};when(screen){Screen.SOURCES->confirmExit();Screen.HOME->showSources();Screen.LIVE_GROUPS->showHome();Screen.LIVE_CHANNELS->showLiveGroups(liveGroupsPos);Screen.VOD_CATS->showHome();Screen.VOD_ITEMS->renderVodCats(vodCatsPos);Screen.SERIES_CATS->showHome();Screen.SERIES_ITEMS->renderSeriesCats(seriesCatsPos);Screen.SEASONS->renderSeriesItems(seriesItemsPos);Screen.EPISODES->renderSeasons(seasonsPos);Screen.FAVORITES->showHome()}}
 override fun onResume(){super.onResume();if((screen==Screen.LIVE_CHANNELS||screen==Screen.LIVE_GROUPS)&&!liveFullscreen)miniCurrentChannel?.let{startMini(it)}}
 override fun onPause(){super.onPause()}
 override fun onDestroy(){releaseMini();web?.stop();piconAdapter?.close();handler.removeCallbacksAndMessages(null);pool.shutdownNow();epgPool.shutdownNow();super.onDestroy()}
}
