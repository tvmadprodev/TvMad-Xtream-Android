package pl.tvmad.xtream

import android.app.*
import android.animation.ValueAnimator
import android.os.*
import android.content.*
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.text.InputType
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.inputmethod.InputMethodManager
import android.view.*
import android.view.animation.LinearInterpolator
import android.widget.*
import androidx.media3.common.*
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.common.util.UnstableApi
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.text.SimpleDateFormat
import java.text.Normalizer
import java.util.Date
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject

private const val LIVE_TAG="TvMadLive"
// Watchdog jak w TiviMate: nie rusza działającego startu. Recovery tylko gdy player
// jest naprawdę martwy. Wolny READY / BUFFERING to normalny zap, nie awaria.
private const val ZAP_WATCHDOG_FIRST_MS=2200L
private const val ZAP_WATCHDOG_PROGRESS_MS=900L
private const val ZAP_WATCHDOG_STALL_MS=2500L
private const val ZAP_MAX_STAGE=3

@UnstableApi
class MainActivity:Activity(){
 private lateinit var list:ListView; private lateinit var channelList:ListView; private lateinit var posterGrid:GridView; private lateinit var status:TextView; private lateinit var sourceBar:View; private lateinit var dashboard:View; private lateinit var livePane:View; private lateinit var listPanel:View
 private lateinit var rootFrame:FrameLayout; private lateinit var miniVideoSlot:View
 private lateinit var homeTimeBlock:View; private lateinit var homeServers:Button; private lateinit var homeOptions:Button; private lateinit var multiServerButton:Button; private lateinit var multiEpgButton:Button; private lateinit var recordingsButton:Button; private lateinit var homeClock:TextView; private lateinit var homeDay:TextView; private lateinit var homeDate:TextView; private lateinit var liveListCard:View
 private lateinit var miniPlayerView:PlayerView; private lateinit var miniPicon:ImageView; private lateinit var miniChannel:TextView; private lateinit var miniNow:TextView; private lateinit var miniDesc:TextView; private lateinit var miniProgress:ProgressBar
 private lateinit var liveFsInfo:View; private lateinit var liveFsInfoMain:View; private lateinit var fsHistoryScroll:HorizontalScrollView; private lateinit var fsHistoryRow:LinearLayout; private lateinit var fsNumber:TextView; private lateinit var fsRec:TextView; private lateinit var fsPicon:ImageView; private lateinit var fsChannel:TextView; private lateinit var fsNow:TextView; private lateinit var fsNext:TextView; private lateinit var fsProgress:ProgressBar; private lateinit var fsAudio:Button; private lateinit var fsSubtitles:Button; private lateinit var fsClock:TextView; private lateinit var fsDate:TextView
 private lateinit var liveBufferingBox:View; private lateinit var liveBufferingText:TextView
 private lateinit var liveChannelDrawer:LinearLayout; private lateinit var liveChannelDrawerTitle:TextView; private lateinit var liveChannelDrawerList:ListView
 private lateinit var liveGroupDrawer:LinearLayout; private lateinit var liveGroupDrawerTitle:TextView; private lateinit var liveGroupDrawerList:ListView
 private lateinit var liveTrackDrawer:LinearLayout; private lateinit var liveTrackDrawerTitle:TextView; private lateinit var liveTrackDrawerList:ListView
 private val pool=Executors.newFixedThreadPool(2); private val piconPool=Executors.newFixedThreadPool(3); private val epgPool=Executors.newFixedThreadPool(2); private val longEpgPool=Executors.newSingleThreadExecutor(); private val scanPool=Executors.newSingleThreadExecutor(); private val catalogPool=scanPool; private val searchPool=Executors.newSingleThreadExecutor(); private val externalEpgPool=Executors.newSingleThreadExecutor{r->Thread(r,"TvMad-XMLTV").apply{priority=Thread.NORM_PRIORITY}}; private val handler=Handler(Looper.getMainLooper())
 private val autoServerRefresh=object:Runnable{override fun run(){val src=selectedSource;if(src!=null&&src.type!="e2"&&screen==Screen.HOME){scheduleLiveRefresh(src);scheduleCatalogSync(src)};handler.postDelayed(this,30L*60L*1000L)}}
 private var miniPlayer:ExoPlayer?=null; private var miniCurrentChannel:Channel?=null; private var piconAdapter:PiconAdapter?=null; private var posterAdapter:PosterGridAdapter?=null
 private var visibleChannels=listOf<Channel>(); private var groups=listOf<LiveGroup>(); private var currentLiveGroup:LiveGroup?=null; private var sources=mutableListOf<Source>(); private var selectedSource:Source?=null; private var piconMode=2
 private var vodCats=listOf<MediaCategory>(); private var vodItems=listOf<MediaItem>(); private var currentVodCat:MediaCategory?=null
 private var seriesCats=listOf<MediaCategory>(); private var seriesItems=listOf<SeriesItem>(); private var currentSeriesCat:MediaCategory?=null; private var seasons=listOf<SeasonItem>(); private var seasonEpisodes:Map<String,List<EpisodeItem>> = emptyMap(); private var episodes=listOf<EpisodeItem>(); private var selectedSeries:SeriesItem?=null
 private var allVodItems=listOf<MediaItem>(); private var allSeriesItems=listOf<SeriesItem>(); private var searchVodItems=listOf<MediaItem>(); private var searchSeriesItems=listOf<SeriesItem>(); private var recentEntries=listOf<VodHistoryEntry>()
 private lateinit var vodSidePanel:LinearLayout; private lateinit var vodSearchBox:EditText; private lateinit var vodRecentButton:Button; private var vodSidePanelOpen=false; private var vodSidePanelSeries=false; private var vodPanelTextReset=false; private var searchGeneration=0; private var searchRenderGeneration=0; private var searchPaintGeneration=0; private var searchDebounce:Runnable?=null
 private var vodCatalogSourceKey=""; private var seriesCatalogSourceKey=""; private var vodCatalogLoadingKey=""; private var seriesCatalogLoadingKey=""
 private val searchMarksRegex=Regex("\\p{Mn}+"); private val searchNonWordRegex=Regex("[^\\p{L}\\p{N}]+")
 private var favorites=mutableListOf<Channel>(); private val epgText=ConcurrentHashMap<String,String>(); private val epgEvents=ConcurrentHashMap<String,List<EpgEvent>>(); private val epgPending=ConcurrentHashMap.newKeySet<String>()
 private var web:WebConfigServer?=null; private val catalogSyncing=ConcurrentHashMap.newKeySet<String>(); private val liveGroupsSyncing=ConcurrentHashMap.newKeySet<String>(); private val externalEpgSyncing=ConcurrentHashMap.newKeySet<String>()
 private val e2GroupsSessionCache=ConcurrentHashMap<String,List<LiveGroup>>(); private val e2ChannelsSessionCache=ConcurrentHashMap<String,List<Channel>>(); private val e2GroupEpgPending=ConcurrentHashMap.newKeySet<String>()
 private val groupPiconPending=ConcurrentHashMap.newKeySet<String>()
 private enum class Screen { SOURCES, HOME, LIVE_GROUPS, LIVE_CHANNELS, VOD_CATS, VOD_ITEMS, VOD_SEARCH, VOD_RECENT, SERIES_CATS, SERIES_ITEMS, SERIES_SEARCH, SERIES_RECENT, SEASONS, EPISODES, FAVORITES }
 private var screen=Screen.SOURCES
 private data class Pos(val first:Int=0,val top:Int=0)
 private var liveGroupsPos=Pos();private var liveGroupSelected=0;private var liveGroupAnchorTop=0;private var liveChannelSelected=0;private var vodCatsPos=Pos();private var vodItemSelected=0;private var seriesCatsPos=Pos();private var seriesItemSelected=0;private var seriesItemsPos=Pos();private var seasonsPos=Pos()
 private var liveFullscreen=false;private var liveSurfaceReady=false;private var liveHasPlayed=false;private var liveRetryCount=0;private var liveRetryScheduled=false;private var suppressLiveBufferUntil=0L;private var liveRecoveryArmed=false
 // Listener jest przypisany do KONKRETNEJ instancji ExoPlayera. LivePlayerSession może
 // zbudować nowego playera (np. po zmianie nagłówka autoryzacji), a wtedy stary listener
 // przestaje istnieć i trzeba go założyć ponownie.
 private var liveListenerPlayer:ExoPlayer?=null
 // Token aktywnego kanału. Każde opóźnione zadanie/callback zapamiętuje token z momentu
 // startu i wykonuje się tylko wtedy, gdy nadal dotyczy aktualnie granego kanału.
 private var liveChannelToken=0
 // Token kanału, który realnie ruszył (READY/PLAYING). Dopóki jest inny niż liveChannelToken,
 // trwa rozruch nowego kanału i pracuje watchdog zappingu.
 private var liveStartedToken=-1
 // Stan watchdoga rozruchu kanału. Żyje wyłącznie między wyborem kanału a jego startem.
 private var liveZapWatchdog:Runnable?=null
 private var liveZapStage=0
 private var liveZapGrace=0
 private var liveZapLastBuffered=0L
 private var liveZapStartedAt=0L
 private var liveRetryToken=-1
 private var liveZapIgnoreIdleUntil=0L
 private val liveRebufferTimes=java.util.ArrayDeque<Long>()
 private var liveRestartCooldownUntil=0L
 private var liveChannelDrawerOpen=false;private var liveGroupDrawerOpen=false;private var liveTrackDrawerOpen=false;private var liveDrawerSelected=0;private var liveGroupDrawerSelected=0;private var liveTrackSelected=0;private var liveChannelPageStart=0;private var liveDrawerPageStart=0
 private var liveHistoryExpanded=false;private var liveHistorySelected=0;private var liveHistoryChannels=listOf<Channel>();private val liveHistoryProgressBars=ArrayList<ProgressBar>();private val liveHistoryEventLabels=ArrayList<TextView>();private var liveInfoHeightAnimator:ValueAnimator?=null;private var fullscreenTouchCaptured=false;private var exitConfirmDialog:Dialog?=null
 private var liveDrawerPreviewToken=0
 private var liveDrawerAdapter:FullscreenChannelAdapter?=null;private var liveGroupDrawerAdapter:FullscreenGroupAdapter?=null;private var liveTrackChoices=listOf<LiveTrackPanelChoice>()
 private var miniEventAnimator:ValueAnimator?=null
 private var miniEventScrollToken=0
 private lateinit var liveGroupFilterPanel:LinearLayout; private lateinit var liveGroupFilterToggle:Button; private lateinit var liveGroupFilterClear:Button; private lateinit var liveGroupFilterAll:Button; private lateinit var liveGroupFilterSave:Button
 private var liveGroupFilterPanelOpen=false; private var liveGroupFilterEdit=false; private var liveGroupFilterWorking=mutableSetOf<String>(); private var allLiveGroups=listOf<LiveGroup>()
 private lateinit var multiEpgOverlay:LinearLayout; private lateinit var multiEpgGrid:MultiEpgGridView; private lateinit var multiEpgGroupTitle:TextView; private lateinit var multiEpgEventTitle:TextView; private lateinit var multiEpgEventTime:TextView; private lateinit var multiEpgDesc:TextView; private lateinit var multiEpgProgress:ProgressBar
 private var multiEpgOpen=false; private var multiEpgReturnChannel=0; private val multiEpgSchedules=ConcurrentHashMap<String,List<EpgEvent>>(); private val longEpgCache=ConcurrentHashMap<String,List<EpgEvent>>(); private val longEpgPending=ConcurrentHashMap.newKeySet<String>(); private val multiEpgPending=ConcurrentHashMap.newKeySet<String>(); private val multiEpgPicons=ConcurrentHashMap.newKeySet<String>(); private var multiEpgDescAnimator:ValueAnimator?=null; private var multiEpgDescToken=0
 private val hideLiveInfo=Runnable{if(liveFullscreen)hideLiveInfoAnimated()}
 private var epgClockCounter=0
 private val liveProgressTick=object:Runnable{override fun run(){
  updateClocks();if(liveHistoryExpanded)updateLiveHistoryProgress()
  epgClockCounter++
  if(epgClockCounter>=10){epgClockCounter=0;refreshEpgClock()}
  handler.postDelayed(this,1000)
 }}
 private val recBlinkTick=object:Runnable{override fun run(){updateRecIndicator();handler.postDelayed(this,700L)}}
 private val liveBufferTick=object:Runnable{override fun run(){if(liveBufferingBox.visibility==View.VISIBLE)handler.postDelayed(this,250)}}
 // Zadanie opóźnione o kilka sekund — musi jawnie potwierdzić, że nadal dotyczy kanału, dla
 // którego zostało zaplanowane. Inaczej retry kanału B potrafiłby zrestartować kanał D.
 private val liveRetry=Runnable{liveRetryScheduled=false;if(liveRetryToken==liveChannelToken&&liveBufferingBox.visibility==View.VISIBLE&&liveHasPlayed&&liveRecoveryArmed&&SystemClock.uptimeMillis()>=suppressLiveBufferUntil)restartLiveStream("ciągłe buforowanie") }

 override fun onCreate(b:Bundle?){
  super.onCreate(b);normalizeUiDensity();setContentView(R.layout.activity_main)
  // onCreate -> startAtHome -> showHome to JEDYNA ścieżka, która potrafi przerwać LIVE
  // i pokazać planszę z trzema kaflami bez udziału użytkownika. Te dwa logi rozstrzygają,
  // który mechanizm ją uruchomił:
  //  * recreated=true + wcześniejszy log "onDestroy isChangingConfigurations=true"
  //    -> Activity zostało odtworzone przez zmianę konfiguracji,
  //  * niedomknięta sesja LIVE bez żadnego logu onDestroy
  //    -> proces zginął w trakcie odtwarzania (crash natywny / kill systemu).
  Log.i(LIVE_TAG,"onCreate recreated=${b!=null}")
  @Suppress("DEPRECATION")
  Log.i("TvMadDisplay","MainActivity running on displayId=${windowManager.defaultDisplay.displayId} requestedExternal=${intent.getBooleanExtra("tvmad_external_display",false)} requestedId=${intent.getIntExtra("tvmad_external_display_id",-1)}")
  if(liveDiagPrefs().getBoolean("livePlaying",false))
   Log.w(LIVE_TAG,"poprzednia sesja LIVE nie została domknięta — proces zginął w trakcie odtwarzania (recreated=${b!=null})")
  markLiveSession(false)
  rootFrame=findViewById(R.id.rootFrame);miniVideoSlot=findViewById(R.id.miniVideoSlot);homeTimeBlock=findViewById(R.id.homeTimeBlock);homeServers=findViewById(R.id.homeServers);homeOptions=findViewById(R.id.homeOptions);multiServerButton=findViewById(R.id.multiServerButton);multiEpgButton=findViewById(R.id.multiEpgButton);recordingsButton=findViewById(R.id.recordingsButton);homeClock=findViewById(R.id.homeClock);homeDay=findViewById(R.id.homeDay);homeDate=findViewById(R.id.homeDate);liveListCard=findViewById(R.id.liveListCard)
  list=findViewById(R.id.list);channelList=findViewById(R.id.channelList);posterGrid=findViewById(R.id.posterGrid);status=findViewById(R.id.status);sourceBar=findViewById(R.id.sourceBar);dashboard=findViewById(R.id.dashboard);livePane=findViewById(R.id.livePane);listPanel=findViewById(R.id.listPanel)
  miniPlayerView=findViewById(R.id.miniPlayer);miniPicon=findViewById(R.id.miniPicon);miniChannel=findViewById(R.id.miniChannel);miniNow=findViewById(R.id.miniNow);miniDesc=findViewById(R.id.miniDesc);miniProgress=findViewById(R.id.miniProgress)
  liveFsInfo=findViewById(R.id.liveFsInfo);liveFsInfoMain=findViewById(R.id.liveFsInfoMain);fsHistoryScroll=findViewById(R.id.fsHistoryScroll);fsHistoryRow=findViewById(R.id.fsHistoryRow);fsNumber=findViewById(R.id.fsNumber);fsRec=findViewById(R.id.fsRec);fsPicon=findViewById(R.id.fsPicon);fsChannel=findViewById(R.id.fsChannel);fsNow=findViewById(R.id.fsNow);fsNext=findViewById(R.id.fsNext);fsProgress=findViewById(R.id.fsProgress);fsAudio=findViewById(R.id.fsAudio);fsSubtitles=findViewById(R.id.fsSubtitles);fsClock=findViewById(R.id.fsClock);fsDate=findViewById(R.id.fsDate);liveBufferingBox=findViewById(R.id.liveBufferingBox);liveBufferingText=findViewById(R.id.liveBufferingText);liveBufferingText.visibility=View.GONE
  setupLiveSidePanels();setupVodSidePanel();setupLiveGroupFilterPanel();setupMultiEpg()
  miniPlayerView.useController=false;miniPlayerView.setKeepContentOnPlayerReset(true);miniPlayerView.resizeMode=androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
  fsAudio.setOnClickListener{showLiveTrackDialog(C.TRACK_TYPE_AUDIO,"Ścieżka audio")};fsSubtitles.setOnClickListener{showLiveTrackDialog(C.TRACK_TYPE_TEXT,"Napisy")}
  sources=SourceStore.load(this);favorites=FavoriteStore.load(this)
  findViewById<Button>(R.id.addXtream).setOnClickListener{xtreamDialog()};findViewById<Button>(R.id.addM3u).setOnClickListener{m3uDialog()};findViewById<Button>(R.id.addE2).setOnClickListener{e2Dialog()}
  findViewById<Button>(R.id.piconMode).setOnClickListener{v->piconMode=(piconMode+1)%3;(v as Button).text="Picony: "+arrayOf("lokalne","źródło","oba")[piconMode];if(screen==Screen.LIVE_CHANNELS||screen==Screen.FAVORITES)refreshChannelsAdapter()}
  homeServers.setOnClickListener{showSources()};homeOptions.setOnClickListener{showOptionsMenu()};multiServerButton.setOnClickListener{showMultiServerPicker()};multiServerButton.setOnKeyListener{_,key,e->if(e.action!=KeyEvent.ACTION_DOWN)false else when(key){KeyEvent.KEYCODE_DPAD_DOWN->{focusCurrentGroupList();true};else->false}};multiEpgButton.setOnClickListener{openMultiEpg()};recordingsButton.setOnClickListener{showRecordings()};multiEpgButton.setOnKeyListener{_,key,e->if(e.action!=KeyEvent.ACTION_DOWN)false else when(key){KeyEvent.KEYCODE_DPAD_LEFT,KeyEvent.KEYCODE_DPAD_DOWN->{channelList.requestFocus();true};KeyEvent.KEYCODE_DPAD_RIGHT->{recordingsButton.requestFocus();true};else->false}};recordingsButton.setOnKeyListener{_,key,e->if(e.action!=KeyEvent.ACTION_DOWN)false else when(key){KeyEvent.KEYCODE_DPAD_LEFT->{multiEpgButton.requestFocus();true};KeyEvent.KEYCODE_DPAD_DOWN->{channelList.requestFocus();true};else->false}};findViewById<View>(R.id.tileLive).setOnClickListener{loadLive()};findViewById<View>(R.id.tileVod).setOnClickListener{loadVodCategories()};findViewById<View>(R.id.tileSeries).setOnClickListener{loadSeriesCategories()}
  list.setOnItemClickListener{_,_,i,_->onItem(i)};list.setOnItemLongClickListener{_,_,i,_->onLongItem(i)};posterGrid.setOnItemClickListener{_,_,i,_->onItem(i)};posterGrid.setOnItemLongClickListener{_,_,i,_->onPosterLongItem(i)};posterGrid.setOnItemSelectedListener(object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){if(screen==Screen.VOD_ITEMS)vodItemSelected=pos else if(screen==Screen.SERIES_ITEMS)seriesItemSelected=pos;updatePosterSelection(pos)}})
  channelList.setOnItemClickListener{_,_,i,_->onChannelItem(i)};channelList.setOnItemLongClickListener{_,_,i,_->if(screen==Screen.LIVE_CHANNELS&&i in visibleChannels.indices){showChannelOptions(visibleChannels[i]);true}else false}
  channelList.setOnItemSelectedListener(object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){
   // W LIVE zaznaczenie jest sterowane przez liveChannelSelected, niezależnie od kotwicy ListView.
   // Dzięki temu Android nie przewija listy o kilka pikseli przy każdym DPAD góra/dół.
   if(screen!=Screen.LIVE_CHANNELS)piconAdapter?.notifyDataSetChanged()}})
  channelList.setOnKeyListener{_,key,e->if(e.action!=KeyEvent.ACTION_DOWN)false else when{screen==Screen.LIVE_CHANNELS&&key==KeyEvent.KEYCODE_DPAD_UP->{moveMainChannelSelection(-1);true};screen==Screen.LIVE_CHANNELS&&key==KeyEvent.KEYCODE_DPAD_DOWN->{moveMainChannelSelection(1);true};screen==Screen.LIVE_CHANNELS&&key==KeyEvent.KEYCODE_DPAD_RIGHT->{multiEpgButton.requestFocus();true};key==KeyEvent.KEYCODE_DPAD_CENTER||key==KeyEvent.KEYCODE_ENTER->{val pos=if(screen==Screen.LIVE_CHANNELS)liveChannelSelected else channelList.selectedItemPosition;if(pos>=0){onChannelItem(pos);true}else false};else->false}}
  web=WebConfigServer(applicationContext,5557,{PiconMemoryCache.clear();runOnUiThread{sources=SourceStore.load(this);selectedSource?.let{cur->sources.firstOrNull{sourceScanKey(it)==sourceScanKey(cur)}?.let{fresh->selectedSource=fresh;scheduleExternalEpgRefresh(fresh)}};if(screen==Screen.SOURCES)showSources();refreshChannelsAdapter()}},{AppScreenshotBridge.captureJpeg()}).also{it.start()}
  startAtHome()
 }


 @Suppress("DEPRECATION")
 private fun normalizeUiDensity(){
  // Layout referencyjny TvMad powstał dla 1536x864. Na Galaxy S9+ Samsung potrafi po
  // uruchomieniu/wyjściu z drugiej Activity albo po zmianie timingu HDMI chwilowo podmienić
  // LOGICZNE displayMetrics/density. To właśnie powodowało, że po powrocie z posterów/VOD
  // kategorie nagle mieściły prawie dwa razy więcej wierszy i tekst robił się mikroskopijny.
  // Dla wersji S9 opieramy skalę na fizycznym trybie zewnętrznego Display, który pozostaje
  // stabilny (np. 1920x1080 niezależnie od 50/60 Hz), a dopiero awaryjnie na displayMetrics.
  val dm=resources.displayMetrics
  val mode=display?.mode
  val pxW=(mode?.physicalWidth?:dm.widthPixels).coerceAtLeast(1)
  val pxH=(mode?.physicalHeight?:dm.heightPixels).coerceAtLeast(1)
  val landscapeW=maxOf(pxW,pxH).toFloat();val landscapeH=minOf(pxW,pxH).toFloat()
  val scale=minOf(landscapeW/1536f,landscapeH/864f).coerceIn(0.75f,2.5f)
  val dpi=(160f*scale).toInt().coerceIn(120,400)
  if(resources.configuration.densityDpi!=dpi){
   val cfg=android.content.res.Configuration(resources.configuration);cfg.densityDpi=dpi
   resources.updateConfiguration(cfg,resources.displayMetrics)
  }
 }


 private fun startAtHome(){
  val saved=LastLiveStore.load(this)
  val src=saved?.let{sv->sources.firstOrNull{LastLiveStore.sourceMatches(sv.source,it)}}?:sources.firstOrNull()
  selectedSource=src;visibleChannels=emptyList();currentLiveGroup=null
  if(src!=null && src.type!="e2"){
   allLiveGroups=LiveCacheStore.loadGroups(this,src).filterNot{it.name.equals("Other",true)};groups=filteredLiveGroups(src,allLiveGroups)
  }else groups=emptyList()
  showHome("cold-start")
  if(src!=null && src.type!="e2"){
   if(groups.isEmpty()) scheduleLiveRefresh(src) else scheduleIdleRefresh(src)
   scheduleExternalEpgRefresh(src)
  }else if(src?.type=="e2"){
   status.text="${src.name}  •  Enigma2 / OpenWebIF  •  Live TV bezpośrednio z dekodera"
  }
 }

 private fun fetchAndCacheLiveGroups(src:Source):List<LiveGroup>{
  if(src.type=="m3u"){
   // get.php/M3U z danymi Xtream: używamy lekkiego player_api, tak jak plugin E2.
   // Czysty M3U jest parsowany strumieniowo, bez trzymania całego pliku w RAM.
   val xc=Api.xtreamParams(src)
   if(xc!=null){
    val fresh=Api.lightweightLiveGroups(src).filterNot{it.name.equals("Other",true)}
    LiveCacheStore.saveGroups(this,src,fresh)
    return fresh
   }
   val scan=Api.scanM3uLowMemory(src.url);val catalog=scan.catalog
   val fresh=catalog.groups.filterNot{it.name.equals("Other",true)}
   LiveCacheStore.saveGroups(this,src,fresh)
   val byGroup=catalog.channels.groupBy{it.group.lowercase(Locale.ROOT)}
   for(g in fresh){
    val rows=byGroup[g.name.lowercase(Locale.ROOT)].orEmpty().map{it.copy(group=g.name,groupId=g.id)}
    LiveCacheStore.saveGroupChannels(this,src,g,rows)
   }
   return fresh
  }
  val fresh=Api.lightweightLiveGroups(src).filterNot{it.name.equals("Other",true)}
  LiveCacheStore.saveGroups(this,src,fresh)
  return fresh
 }

 private fun ensureLiveGroups(then:()->Unit){
  val src=selectedSource?:run{status.text="Najpierw wybierz serwer";showSources();return}
  if(src.type=="e2"){
   val cacheKey=sourceScanKey(src)
   e2GroupsSessionCache[cacheKey]?.takeIf{it.isNotEmpty()}?.let{cached->
    allLiveGroups=cached;groups=if(liveGroupFilterEdit)cached else filteredLiveGroups(src,cached);then();return
   }
   status.text="Telewizja  •  pobieranie bouquetów z OpenWebIF…"
   pool.execute{
    try{val fresh=Api.liveGroups(src).filterNot{it.name.equals("Other",true)};if(fresh.isNotEmpty())e2GroupsSessionCache[cacheKey]=fresh;runOnUiThread{if(selectedSource==src){allLiveGroups=fresh;groups=if(liveGroupFilterEdit)fresh else filteredLiveGroups(src,fresh);then()}}}
    catch(e:Exception){runOnUiThread{if(selectedSource==src)status.text="Telewizja  •  ${e.message.orEmpty()}"}}
   }
   return
  }
  if(groups.isNotEmpty()){then();return}
  val key=sourceScanKey(src)
  if(liveGroupsSyncing.contains(key)){handler.postDelayed({if(selectedSource==src)ensureLiveGroups(then)},250);return}
  status.text="Telewizja  •  ładowanie grup…"
  if(!liveGroupsSyncing.add(key))return
  scanPool.execute{
   try{
    val fresh=fetchAndCacheLiveGroups(src)
    runOnUiThread{if(selectedSource==src){allLiveGroups=fresh;groups=if(liveGroupFilterEdit)fresh else filteredLiveGroups(src,fresh);then()}}
   }catch(e:Exception){runOnUiThread{if(selectedSource==src)status.text="Telewizja  •  ${e.message.orEmpty()}"}}
   finally{liveGroupsSyncing.remove(key)}
  }
 }

 private fun findGroupFor(c:Channel):LiveGroup? {
  if(c.groupId.isNotBlank())groups.firstOrNull{it.id==c.groupId}?.let{return it}
  return groups.firstOrNull{it.name.equals(c.group,true)}
 }

 private fun openLastLiveOrGroups(){
  val src=selectedSource?:run{status.text="Najpierw wybierz serwer";showSources();return}
  ensureLiveGroups{
   val saved=LastLiveStore.load(this)
   val c=saved?.takeIf{LastLiveStore.sourceMatches(it.source,src)}?.channel
   val g=c?.let{findGroupFor(it)}
   if(c==null||g==null){showLiveGroups();return@ensureLiveGroups}
   liveGroupSelected=groups.indexOfFirst{it.id==g.id}.coerceAtLeast(0)
   // Po starcie ustawiamy grupę w okolicy środka listy, nie na początku wszystkich grup.
   liveGroupAnchorTop=(resources.displayMetrics.density*95f).toInt()
   openLiveGroup(g,c.url,true,c)
  }
 }

 private fun openLiveGroup(group:LiveGroup, selectUrl:String="", autoFullscreen:Boolean=false, fallbackChannel:Channel?=null){
  val src=selectedSource?:return
  currentLiveGroup=group
  // Enigma2: kanały bouquetu trzymamy w pamięci tylko przez bieżącą sesję aplikacji.
  // Pierwsze wejście czyta OpenWebIF, kolejne wejścia w ten sam bouquet są natychmiastowe.
  if(src.type=="e2"){
   val cacheKey=sourceScanKey(src)+"|"+group.id
   e2ChannelsSessionCache[cacheKey]?.takeIf{it.isNotEmpty()}?.let{cached->
    showChannels(group,cached,selectUrl)
    if(autoFullscreen){val c=cached.firstOrNull{it.url==selectUrl}?:fallbackChannel;if(c!=null)channelList.post{startMini(c);enterLiveFullscreen(c,false);loadEpgForChannels(listOf(c))}}
    return
   }
   screen=Screen.LIVE_CHANNELS;applyTheme(2);setMode(live=true);visibleChannels=emptyList();refreshChannelsAdapter(false)
   status.text="${group.name}  •  pobieranie kanałów z OpenWebIF…"
   pool.execute{
    try{val fresh=Api.liveChannels(src,group);if(fresh.isNotEmpty())e2ChannelsSessionCache[cacheKey]=fresh;runOnUiThread{if(selectedSource==src&&currentLiveGroup?.id==group.id){showChannels(group,fresh,selectUrl);if(autoFullscreen){val c=fresh.firstOrNull{it.url==selectUrl}?:fallbackChannel;if(c!=null)channelList.post{startMini(c);enterLiveFullscreen(c,false);loadEpgForChannels(listOf(c))}}}}}
    catch(e:Exception){runOnUiThread{if(selectedSource==src&&currentLiveGroup?.id==group.id)status.text="${group.name}  •  ${e.message.orEmpty()}"}}
   }
   return
  }
  val cached=LiveCacheStore.loadGroupChannels(this,src,group)
  if(cached.isNotEmpty()){
   showChannels(group,cached,selectUrl)
   scheduleGroupRefresh(src,group)
   if(autoFullscreen){
    val c=cached.firstOrNull{it.url==selectUrl}?:fallbackChannel
    if(c!=null)channelList.post{startMini(c);enterLiveFullscreen(c,false);loadEpgForChannels(listOf(c))}
   }
   return
  }
  if(src.type=="m3u"&&liveGroupsSyncing.contains(sourceScanKey(src))){
   status.text="${group.name}  •  kończenie lekkiego skanu…"
   handler.postDelayed({if(selectedSource==src&&currentLiveGroup?.id==group.id)openLiveGroup(group,selectUrl,autoFullscreen,fallbackChannel)},250)
   return
  }
  screen=Screen.LIVE_CHANNELS;applyTheme(2);setMode(live=true);visibleChannels=emptyList();refreshChannelsAdapter(false)
  status.text="${group.name}  •  ładowanie kanałów…"
  pool.execute{
   try{
    val actualGroup:LiveGroup
    val fresh:List<Channel>
    if(src.type=="m3u"){
     if(Api.xtreamParams(src)!=null){
      actualGroup=group
      fresh=Api.lightweightLiveChannels(src,group)
      LiveCacheStore.saveGroupChannels(this,src,group,fresh)
     }else{
      val freshGroups=fetchAndCacheLiveGroups(src)
      actualGroup=freshGroups.firstOrNull{it.id==group.id}?:freshGroups.firstOrNull{it.name.equals(group.name,true)}?:group
      fresh=LiveCacheStore.loadGroupChannels(this,src,actualGroup)
      runOnUiThread{if(selectedSource==src){allLiveGroups=freshGroups;groups=if(liveGroupFilterEdit)freshGroups else filteredLiveGroups(src,freshGroups)}}
     }
    }else{
     actualGroup=group;fresh=Api.liveChannels(src,group);LiveCacheStore.saveGroupChannels(this,src,group,fresh)
    }
    runOnUiThread{
     if(selectedSource==src&&currentLiveGroup?.id==group.id){
      currentLiveGroup=actualGroup;liveGroupSelected=groups.indexOfFirst{it.id==actualGroup.id}.takeIf{it>=0}?:liveGroupSelected
      showChannels(actualGroup,fresh,selectUrl)
      if(autoFullscreen){
       val c=fresh.firstOrNull{it.url==selectUrl}?:fallbackChannel
       if(c!=null)channelList.post{startMini(c);enterLiveFullscreen(c,false);loadEpgForChannels(listOf(c))}
      }
     }
    }
   }catch(e:Exception){runOnUiThread{if(selectedSource==src&&currentLiveGroup?.id==group.id)status.text="${group.name}  •  ${e.message.orEmpty()}"}}
  }
 }

 private fun scheduleGroupRefresh(src:Source,group:LiveGroup){
  if(src.type!="xtream")return
  pool.execute{try{LiveCacheStore.saveGroupChannels(this,src,group,Api.liveChannels(src,group))}catch(_:Exception){}}
 }

 private fun currentList():ListView=if(screen==Screen.LIVE_CHANNELS||screen==Screen.LIVE_GROUPS)channelList else list
 private fun position():Pos{val l:AbsListView=if(screen==Screen.VOD_ITEMS||screen==Screen.SERIES_ITEMS||screen==Screen.VOD_SEARCH||screen==Screen.SERIES_SEARCH||screen==Screen.VOD_RECENT||screen==Screen.SERIES_RECENT)posterGrid else currentList();return if(l.childCount>0)Pos(l.firstVisiblePosition,l.getChildAt(0).top)else Pos()}
 private fun restore(p:Pos){val l:AbsListView=if(screen==Screen.VOD_ITEMS||screen==Screen.SERIES_ITEMS||screen==Screen.VOD_SEARCH||screen==Screen.SERIES_SEARCH||screen==Screen.VOD_RECENT||screen==Screen.SERIES_RECENT)posterGrid else currentList();l.post{l.setSelectionFromTop(p.first,p.top)}}
 private fun setMode(sourcesMode:Boolean=false,home:Boolean=false,live:Boolean=false){sourceBar.visibility=if(sourcesMode)View.VISIBLE else View.GONE;dashboard.visibility=if(home)View.VISIBLE else View.GONE;homeServers.visibility=if(home)View.VISIBLE else View.GONE;homeOptions.visibility=if(home)View.VISIBLE else View.GONE;multiServerButton.visibility=if(screen==Screen.LIVE_GROUPS||screen==Screen.VOD_CATS||screen==Screen.SERIES_CATS)View.VISIBLE else View.GONE;multiEpgButton.visibility=if(live&&screen==Screen.LIVE_CHANNELS)View.VISIBLE else View.GONE;recordingsButton.visibility=if(live&&screen==Screen.LIVE_CHANNELS)View.VISIBLE else View.GONE;homeTimeBlock.visibility=View.VISIBLE;updateClocks();livePane.visibility=if(live)View.VISIBLE else View.GONE;listPanel.visibility=if(!home&&!live)View.VISIBLE else View.GONE;val posters=!home&&!live&&(screen==Screen.VOD_ITEMS||screen==Screen.SERIES_ITEMS||screen==Screen.VOD_SEARCH||screen==Screen.SERIES_SEARCH||screen==Screen.VOD_RECENT||screen==Screen.SERIES_RECENT);posterGrid.visibility=if(posters)View.VISIBLE else View.GONE;list.visibility=if(!home&&!live&&!posters)View.VISIBLE else View.GONE}
 private fun updatePosterSelection(pos:Int){posterAdapter?.setSelectedPosition(pos);val first=posterGrid.firstVisiblePosition;for(i in 0 until posterGrid.childCount){val child=posterGrid.getChildAt(i);val selected=(first+i)==pos;child.isSelected=selected;val vg=child as? ViewGroup;val titleView=vg?.getChildAt(1) as? TextView;titleView?.isSelected=selected}}
 private fun applyTheme(kind:Int){val bg=when(AppOptionsStore.background(this)){"charcoal"->R.drawable.bg_charcoal;"green"->R.drawable.bg_green;else->R.drawable.bg_navy};rootFrame.setBackgroundResource(bg);listPanel.setBackgroundResource(when(kind){2->R.drawable.panel_live_glass;3->R.drawable.panel_vod_glass;4->R.drawable.panel_series_glass;else->R.drawable.panel_glass});liveListCard.setBackgroundResource(R.drawable.panel_live_glass)}
 // Zegar tyka co sekundę, ale jego treść zmienia się raz na minutę. Wcześniej każde tyknięcie
 // budowało pięć nowych SimpleDateFormat i wywoływało setText na pięciu TextView, co za każdym
 // razem unieważniało kawałki okna w trakcie odtwarzania 50 fps. Formaty są teraz buforowane,
 // a tekst ustawiany tylko wtedy, gdy faktycznie się zmienił. Wygląd i format są identyczne.
 private var clockLocale:Locale?=null
 private var fmtClock=SimpleDateFormat("HH:mm",Locale.getDefault());private var fmtDay=SimpleDateFormat("EEEE",Locale.getDefault());private var fmtDate=SimpleDateFormat("d MMM yyyy",Locale.getDefault());private var fmtFsDate=SimpleDateFormat("EEEE\nd MMMM",Locale.getDefault())
 private fun ensureClockFormats(){val l=Locale.getDefault();if(clockLocale==l)return;clockLocale=l;fmtClock=SimpleDateFormat("HH:mm",l);fmtDay=SimpleDateFormat("EEEE",l);fmtDate=SimpleDateFormat("d MMM yyyy",l);fmtFsDate=SimpleDateFormat("EEEE\nd MMMM",l)}
 private fun setTextIfChanged(v:TextView,s:String){if(v.text?.toString()!=s)v.text=s}
 private fun updateClocks(){
  ensureClockFormats();val now=Date();val clock=fmtClock.format(now)
  setTextIfChanged(homeClock,clock);setTextIfChanged(fsClock,clock)
  setTextIfChanged(homeDay,fmtDay.format(now).replaceFirstChar{if(it.isLowerCase())it.titlecase(Locale.getDefault()) else it.toString()})
  setTextIfChanged(homeDate,fmtDate.format(now))
  setTextIfChanged(fsDate,fmtFsDate.format(now))
 }
 private fun field(h:String)=EditText(this).apply{hint=h;setSingleLine(true)}
 private fun xtreamDialog(){val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,0,28,0)};val n=field("Nazwa serwera, np. Dom");val h=field("http://serwer:port");val u=field("Użytkownik");val p=field("Hasło").apply{inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD};val e=field("Dodatkowe EPG XMLTV URL (.xml lub .gz)");listOf(n,h,u,p,e).forEach{box.addView(it)};AlertDialog.Builder(this).setTitle("Dodaj Xtream Codes").setView(box).setPositiveButton("Zapisz i wczytaj"){_,_->val host=h.text.toString().trim();saveAndLoad(Source("xtream",n.text.toString().trim().ifBlank{host},host,u.text.toString(),p.text.toString(),epgUrl=e.text.toString().trim()))}.setNegativeButton("Anuluj",null).show()}
 private fun m3uDialog(){val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,0,28,0)};val n=field("Nazwa listy");val u=field("Pełny URL listy M3U");val e=field("Dodatkowe EPG XMLTV URL (.xml lub .gz)");listOf(n,u,e).forEach{box.addView(it)};AlertDialog.Builder(this).setTitle("Dodaj M3U").setView(box).setPositiveButton("Zapisz i wczytaj"){_,_->val url=u.text.toString().trim();saveAndLoad(Source("m3u",n.text.toString().trim().ifBlank{"M3U ${sources.size+1}"},url=url,epgUrl=e.text.toString().trim()))}.setNegativeButton("Anuluj",null).show()}

 private fun e2Dialog(){
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,0,28,0)}
  val n=field("Nazwa dekodera, np. SF8008");val h=field("IP / host, np. 192.168.8.115")
  val wp=field("Port OpenWebIF (domyślnie 80)").apply{inputType=InputType.TYPE_CLASS_NUMBER;setText("80")}
  val sp=field("Port streamu (domyślnie 8001)").apply{inputType=InputType.TYPE_CLASS_NUMBER;setText("8001")}
  val u=field("Użytkownik OpenWebIF (np. root)");val pa=field("Hasło OpenWebIF").apply{inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
  val zap=CheckBox(this).apply{text="Przełączaj kanał także na dekoderze (ZAP)";isChecked=false}
  val piconLabel=TextView(this).apply{text="Picony Enigma2:";setPadding(0,12,0,0)}
  val picons=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("Z WebInterface Enigma2","Lokalne TvMad"));setSelection(0)}
  listOf<View>(n,h,wp,sp,u,pa,zap,piconLabel,picons).forEach{box.addView(it)}
  val dlg=AlertDialog.Builder(this).setTitle("Dodaj Enigma2 / OpenWebIF").setView(box).setPositiveButton("Zapisz i wczytaj",null).setNeutralButton("Test połączenia",null).setNegativeButton("Anuluj",null).create()
  dlg.setOnShowListener{
   fun value()=Source("e2",n.text.toString().trim().ifBlank{h.text.toString().trim()},h.text.toString().trim(),u.text.toString().trim(),pa.text.toString(),webPort=wp.text.toString().toIntOrNull()?:80,streamPort=sp.text.toString().toIntOrNull()?:8001,e2ZapOnBox=zap.isChecked,e2PiconSource=if(picons.selectedItemPosition==1)"local" else "web")
   dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener{val src=value();pool.execute{try{val r=Api.e2Test(src);runOnUiThread{wp.setText(r.source.webPort.toString());Toast.makeText(this,r.message,Toast.LENGTH_LONG).show()}}catch(e:Exception){runOnUiThread{Toast.makeText(this,e.message?:"Brak połączenia",Toast.LENGTH_LONG).show()}}}}
   dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{val src=value();pool.execute{try{val r=Api.e2Test(src);runOnUiThread{wp.setText(r.source.webPort.toString());dlg.dismiss();saveAndLoad(r.source)}}catch(e:Exception){runOnUiThread{Toast.makeText(this,e.message?:"Brak połączenia",Toast.LENGTH_LONG).show()}}}}
  };dlg.show()
 }
 private fun editSource(i:Int){if(i !in sources.indices)return;val old=sources[i];val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,0,28,0)}
  if(old.type=="xtream"){val n=field("Nazwa serwera").apply{setText(old.name)};val h=field("http://serwer:port").apply{setText(old.host)};val u=field("Użytkownik").apply{setText(old.user)};val p=field("Hasło").apply{inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD;setText(old.pass)};val e=field("Dodatkowe EPG XMLTV URL (.xml lub .gz)").apply{setText(old.epgUrl)};listOf(n,h,u,p,e).forEach{box.addView(it)};AlertDialog.Builder(this).setTitle("Edytuj Xtream Codes").setView(box).setPositiveButton("Zapisz"){_,_->val host=h.text.toString().trim();val updated=old.copy(name=n.text.toString().trim().ifBlank{host},host=host,user=u.text.toString(),pass=p.text.toString(),epgUrl=e.text.toString().trim());sources[i]=updated;SourceStore.save(this,sources);if(sourceScanKey(selectedSource?:old)==sourceScanKey(old))selectedSource=updated;showSources()}.setNegativeButton("Anuluj",null).show()}
  else if(old.type=="e2"){
   val n=field("Nazwa dekodera").apply{setText(old.name)};val h=field("IP / host").apply{setText(old.host)};val wp=field("Port OpenWebIF").apply{inputType=InputType.TYPE_CLASS_NUMBER;setText(old.webPort.toString())};val sp=field("Port streamu").apply{inputType=InputType.TYPE_CLASS_NUMBER;setText(old.streamPort.toString())};val u=field("Użytkownik OpenWebIF").apply{setText(old.user)};val pa=field("Hasło OpenWebIF").apply{inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD;setText(old.pass)}
   val zap=CheckBox(this).apply{text="Przełączaj kanał także na dekoderze (ZAP)";isChecked=old.e2ZapOnBox}
   val piconLabel=TextView(this).apply{text="Picony Enigma2:";setPadding(0,12,0,0)};val picons=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("Z WebInterface Enigma2","Lokalne TvMad"));setSelection(if(old.e2PiconSource.equals("local",true))1 else 0)}
   listOf<View>(n,h,wp,sp,u,pa,zap,piconLabel,picons).forEach{box.addView(it)}
   val dlg=AlertDialog.Builder(this).setTitle("Edytuj Enigma2 / OpenWebIF").setView(box).setPositiveButton("Zapisz",null).setNeutralButton("Test połączenia",null).setNegativeButton("Anuluj",null).create()
   dlg.setOnShowListener{
    fun value()=old.copy(name=n.text.toString().trim().ifBlank{h.text.toString().trim()},host=h.text.toString().trim(),user=u.text.toString().trim(),pass=pa.text.toString(),webPort=wp.text.toString().toIntOrNull()?:80,streamPort=sp.text.toString().toIntOrNull()?:8001,e2ZapOnBox=zap.isChecked,e2PiconSource=if(picons.selectedItemPosition==1)"local" else "web")
    dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener{val src=value();pool.execute{try{val r=Api.e2Test(src);runOnUiThread{wp.setText(r.source.webPort.toString());Toast.makeText(this,r.message,Toast.LENGTH_LONG).show()}}catch(e:Exception){runOnUiThread{Toast.makeText(this,e.message?:"Brak połączenia",Toast.LENGTH_LONG).show()}}}}
    dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{val src=value();pool.execute{try{val r=Api.e2Test(src);runOnUiThread{val updated=r.source;sources[i]=updated;SourceStore.save(this,sources);if(sourceScanKey(selectedSource?:old)==sourceScanKey(old))selectedSource=updated;dlg.dismiss();showSources()}}catch(e:Exception){runOnUiThread{Toast.makeText(this,e.message?:"Brak połączenia",Toast.LENGTH_LONG).show()}}}}
   };dlg.show()
  }
  else{val n=field("Nazwa listy").apply{setText(old.name)};val u=field("Pełny URL listy M3U").apply{setText(old.url)};val e=field("Dodatkowe EPG XMLTV URL (.xml lub .gz)").apply{setText(old.epgUrl)};listOf(n,u,e).forEach{box.addView(it)};AlertDialog.Builder(this).setTitle("Edytuj M3U").setView(box).setPositiveButton("Zapisz"){_,_->val url=u.text.toString().trim();val updated=old.copy(name=n.text.toString().trim().ifBlank{"M3U"},url=url,epgUrl=e.text.toString().trim());sources[i]=updated;SourceStore.save(this,sources);if(sourceScanKey(selectedSource?:old)==sourceScanKey(old))selectedSource=updated;showSources()}.setNegativeButton("Anuluj",null).show()}
 }
 private fun showSourceOptions(i:Int){if(i !in sources.indices)return;val s=sources[i];AlertDialog.Builder(this).setTitle(s.name).setItems(arrayOf("Edytuj","Usuń")){_,which->if(which==0)editSource(i)else confirmDelete(i)}.setNegativeButton("Anuluj",null).show()}
 private fun saveAndLoad(src:Source){val same=sources.indexOfFirst{sourceScanKey(it)==sourceScanKey(src)};val saved=if(same>=0&&src.epgUrl.isBlank())src.copy(epgUrl=sources[same].epgUrl,expiry=sources[same].expiry) else src;if(same>=0)sources[same]=saved else sources.add(saved);SourceStore.save(this,sources);loadSource(saved)}
 private fun firstScanPrefs()=getSharedPreferences("first_server_scan_v1",Context.MODE_PRIVATE)
 private fun firstScanDone(src:Source)=firstScanPrefs().getBoolean(sourceScanKey(src),false)
 private fun markFirstScanDone(src:Source){firstScanPrefs().edit().putBoolean(sourceScanKey(src),true).apply()}
 private fun runFirstServerScan(src:Source){
  selectedSource=src;epgText.clear();epgEvents.clear();epgPending.clear();visibleChannels=emptyList();currentLiveGroup=null
  showSources()
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(36,12,36,8)}
  val msg=TextView(this).apply{text="Może to zająć kilka minut.\nProszę czekać.";textSize=16f;setPadding(0,0,0,18)}
  val bar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progress=0;isIndeterminate=false}
  val pct=TextView(this).apply{text="0%";textSize=14f;gravity=Gravity.CENTER_HORIZONTAL;setPadding(0,8,0,4)}
  val doneButton=Button(this).apply{text="OK";setAllCaps(false);visibility=View.GONE;isFocusable=true}
  box.addView(msg);box.addView(bar,LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,LinearLayout.LayoutParams.WRAP_CONTENT));box.addView(pct);box.addView(doneButton,LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,dp(52)).apply{topMargin=dp(12)})
  val dlg=AlertDialog.Builder(this).setTitle("Pierwsze skanowanie serwera...").setView(box).setCancelable(false).create();dlg.show()
  fun progress(v:Int,t:String){runOnUiThread{if(dlg.isShowing){bar.progress=v.coerceIn(0,100);pct.text="${v.coerceIn(0,100)}%";msg.text="Może to zająć kilka minut.\nProszę czekać.\n\n$t"}}}
  val key=sourceScanKey(src);if(!liveGroupsSyncing.add(key)){dlg.dismiss();return}
  scanPool.execute{
   var liveCount=0;var vodCount=0;var seriesCount=0;var liveGroups=emptyList<LiveGroup>()
   try{
    progress(4,"Pobieranie informacji o serwerze...")
    val xc=Api.xtreamParams(src)
    if(src.type=="m3u"&&xc==null){
     // Jedno przejście po zwykłym M3U: bez readText(), bez wielkich kopii w heapie.
     val scan=Api.scanM3uLowMemory(src.url)
     liveGroups=scan.catalog.groups.filterNot{it.name.equals("Other",true)}
     liveCount=scan.liveCount;vodCount=scan.vodCount;seriesCount=scan.seriesCount
     progress(55,"Zapisywanie kanałów LIVE: $liveCount")
     LiveCacheStore.saveGroups(this,src,liveGroups)
     val byGroup=scan.catalog.channels.groupBy{it.group.lowercase(Locale.ROOT)}
     for(g in liveGroups){
      val rows=byGroup[g.name.lowercase(Locale.ROOT)].orEmpty().map{it.copy(group=g.name,groupId=g.id)}
      LiveCacheStore.saveGroupChannels(this,src,g,rows)
     }
     progress(92,"Kończenie skanowania...")
    }else{
     // Xtream oraz M3U/get.php: dokładnie lekka ścieżka API. Na pierwszym skanie
     // nie pobieramy równolegle wielkich list JSON i nie trzymamy ich w RAM.
     liveGroups=Api.lightweightLiveGroups(src).filterNot{it.name.equals("Other",true)}
     LiveCacheStore.saveGroups(this,src,liveGroups)
     progress(24,"Grupy LIVE: ${liveGroups.size}")

     liveCount=try{Api.lightweightXtreamCount(src,"get_live_streams")}catch(_:Exception){0}
     progress(48,"Kanały LIVE: $liveCount")

     try{val v=Api.vodCategories(src);CatalogCacheStore.saveVodCategories(this,src,v)}catch(_:Exception){}
     vodCount=try{Api.lightweightXtreamCount(src,"get_vod_streams")}catch(_:Exception){0}
     progress(70,"Filmy VOD: $vodCount")

     try{val se=Api.seriesCategories(src);CatalogCacheStore.saveSeriesCategories(this,src,se)}catch(_:Exception){}
     seriesCount=try{Api.lightweightXtreamCount(src,"get_series")}catch(_:Exception){0}
     progress(92,"Seriale: $seriesCount")
    }
    markFirstScanDone(src)
    progress(100,"Gotowe")
    runOnUiThread{
     if(selectedSource==src){allLiveGroups=liveGroups;groups=filteredLiveGroups(src,liveGroups)}
     if(dlg.isShowing){
      dlg.setTitle("Skanowanie zakończone")
      msg.text="Kanały LIVE: $liveCount\nFilmy VOD: $vodCount\nSeriale: $seriesCount"
      bar.progress=100;pct.text="100%"
      doneButton.visibility=View.VISIBLE;doneButton.setOnClickListener{dlg.dismiss();if(selectedSource==src){showSources();scheduleExternalEpgRefresh(src);scheduleIdleRefresh(src)}};doneButton.requestFocus()
     }
    }
   }catch(e:Throwable){
    runOnUiThread{if(dlg.isShowing){dlg.setTitle("Skanowanie zakończone");msg.text="Nie udało się dokończyć pierwszego skanu.\n${e.message.orEmpty()}";doneButton.visibility=View.VISIBLE;doneButton.setOnClickListener{dlg.dismiss();showSources()};doneButton.requestFocus()}}
   }finally{liveGroupsSyncing.remove(key)}
  }
 }
 private fun confirmDelete(i:Int){val s=sources[i];AlertDialog.Builder(this).setTitle("Usunąć serwer?").setMessage(s.name).setPositiveButton("Usuń"){_,_->sources.removeAt(i);SourceStore.save(this,sources);showSources()}.setNegativeButton("Anuluj",null).show()}
 private fun showSources(){releaseMini();miniCurrentChannel=null;screen=Screen.SOURCES;visibleChannels=emptyList();applyTheme(0);setMode(sourcesMode=true);val addr=web?.address()?.removePrefix("http://")?:"IP urządzenia:5557";status.text="WebInfo: $addr  •  dodawanie serwerów z telefonu/PC przez IP i port";list.adapter=TvListAdapter(this,sources.map{val kind=when(it.type){"xtream"->"XCODES";"e2"->"ENIGMA2";else->"M3U"};val exp=it.expiry.takeIf{x->x.isNotBlank()}?.let{x->"  •  ważny do: $x"}.orEmpty();"$kind  •  ${it.name}$exp"},0);val sel=selectedSource?.let{cur->sources.indexOfFirst{sourceScanKey(it)==sourceScanKey(cur)}}?.takeIf{it>=0}?:list.selectedItemPosition.takeIf{it>=0}?:0;list.post{if(sources.isNotEmpty())list.setSelection(sel.coerceIn(0,sources.lastIndex));list.requestFocus()};refreshSourceExpiries()}
 private fun loadSource(src:Source){
  // Enigma2/OpenWebIF działa bez importu i bez pierwszego skanu. Bouquety i kanały
  // są pobierane bezpośrednio z dekodera dopiero po wejściu do LIVE / wybranej grupy.
  if(src.type=="e2"){
   selectedSource=src;epgText.clear();epgEvents.clear();epgPending.clear();visibleChannels=emptyList();currentLiveGroup=null;groups=emptyList()
   showHome("source-selected-e2");status.text="${src.name}  •  Enigma2 / OpenWebIF  •  Live TV bezpośrednio z dekodera"
   return
  }
  if(!firstScanDone(src)){runFirstServerScan(src);return}
  selectedSource=src;epgText.clear();epgEvents.clear();epgPending.clear();visibleChannels=emptyList();currentLiveGroup=null
  allLiveGroups=LiveCacheStore.loadGroups(this,src).filterNot{it.name.equals("Other",true)};groups=filteredLiveGroups(src,allLiveGroups)
  showHome("source-selected")
  scheduleExternalEpgRefresh(src)
  if(groups.isEmpty()){status.text="${src.name}  •  trwa lekki skan grup w tle";scheduleLiveRefresh(src)} else scheduleIdleRefresh(src)
  handler.removeCallbacks(autoServerRefresh);handler.postDelayed(autoServerRefresh,30L*60L*1000L)
 }

 private fun focusCurrentGroupList(){
  when(screen){
   Screen.LIVE_GROUPS->channelList.requestFocus()
   Screen.VOD_CATS,Screen.SERIES_CATS->list.requestFocus()
   else->{}
  }
 }
 private fun showMultiServerPicker(){
  if(screen!=Screen.LIVE_GROUPS&&screen!=Screen.VOD_CATS&&screen!=Screen.SERIES_CATS)return
  if(sources.isEmpty()){Toast.makeText(this,"Brak zapisanych serwerów",Toast.LENGTH_SHORT).show();return}
  val target=screen
  val labels=sources.map{src->
   val kind=when(src.type){"xtream"->"XCODES";"e2"->"ENIGMA2";else->"M3U"}
   val current=selectedSource?.let{sourceScanKey(it)==sourceScanKey(src)}==true
   (if(current)"✓  " else "")+"${src.name}  •  $kind"
  }.toTypedArray()
  val dlg=AlertDialog.Builder(this).setTitle("Multi Serwer").setItems(labels){_,which->
   val src=sources.getOrNull(which)?:return@setItems
   switchGroupServer(src,target)
  }.setNegativeButton("Anuluj",null).create()
  dlg.setOnDismissListener{focusCurrentGroupList()}
  dlg.show()
 }
 private fun switchGroupServer(src:Source,target:Screen){
  if(target!=Screen.LIVE_GROUPS&&target!=Screen.VOD_CATS&&target!=Screen.SERIES_CATS)return
  val same=selectedSource?.let{sourceScanKey(it)==sourceScanKey(src)}==true
  if(same){
   when(target){Screen.LIVE_GROUPS->showLiveGroups();Screen.VOD_CATS->renderVodCats();Screen.SERIES_CATS->renderSeriesCats();else->{}}
   return
  }
  releaseMini()
  selectedSource=src
  epgText.clear();epgEvents.clear();epgPending.clear();longEpgCache.clear();longEpgPending.clear();multiEpgSchedules.clear()
  visibleChannels=emptyList();currentLiveGroup=null;currentVodCat=null;currentSeriesCat=null
  liveGroupSelected=0;liveChannelSelected=0;vodItemSelected=0;seriesItemSelected=0
  liveGroupFilterEdit=false;liveGroupFilterPanelOpen=false;liveGroupFilterPanel.visibility=View.GONE
  allLiveGroups=emptyList();groups=emptyList();vodCats=emptyList();vodItems=emptyList();seriesCats=emptyList();seriesItems=emptyList()
  when(target){
   Screen.LIVE_GROUPS->{
    val cached=LiveCacheStore.loadGroups(this,src).filterNot{it.name.equals("Other",true)}
    allLiveGroups=cached;groups=filteredLiveGroups(src,cached)
    if(groups.isNotEmpty())showLiveGroups() else ensureLiveGroups{showLiveGroups()}
    scheduleExternalEpgRefresh(src)
   }
   Screen.VOD_CATS->loadVodCategories()
   Screen.SERIES_CATS->loadSeriesCategories()
   else->{}
  }
 }
 private fun refreshSourceExpiries(){val snap=sources.toList();snap.forEach{src->if(src.type!="e2")pool.execute{val exp=Api.accountExpiry(src);if(exp.isNotBlank()&&exp!=src.expiry)runOnUiThread{val i=sources.indexOfFirst{sourceScanKey(it)==sourceScanKey(src)};if(i>=0){sources[i]=sources[i].copy(expiry=exp);SourceStore.save(this,sources);if(screen==Screen.SOURCES)showSources()}}}}}
 private fun sourceScanKey(src:Source)=when(src.type){"xtream"->"x|${src.host}|${src.user}";"e2"->"e2|${src.host}|${src.webPort}|${src.streamPort}|${src.user}";else->"m|${src.url}"}
 private fun scheduleIdleRefresh(src:Source){
  // Na słabszych Android Boxach nie skanujemy dużych list równolegle ze startem UI/playera.
  // Cichy refresh rusza dopiero po chwili i tylko gdy użytkownik nadal jest na ekranie głównym.
  handler.postDelayed({
   if(selectedSource==src && screen==Screen.HOME){scheduleLiveRefresh(src);scheduleCatalogSync(src)}
  },45000L)
 }
 private fun scheduleLiveRefresh(src:Source){
  if(groups.isNotEmpty()&&LiveCacheStore.groupsAgeMs(this,src)<30L*60L*1000L)return
  val key=sourceScanKey(src);if(!liveGroupsSyncing.add(key))return
  scanPool.execute{
   try{
    val fresh=fetchAndCacheLiveGroups(src)
    runOnUiThread{if(selectedSource==src){allLiveGroups=fresh;if(groups.isEmpty()||screen==Screen.HOME)groups=if(liveGroupFilterEdit)fresh else filteredLiveGroups(src,fresh);if(screen==Screen.HOME)status.text="${src.name}  •  wybierz dział";scheduleExternalEpgRefresh(src)}}
   }catch(_:Exception){}
   finally{liveGroupsSyncing.remove(key)}
  }
 }
 private fun scheduleCatalogSync(src:Source){
  if(Api.xtreamParams(src)==null)return
  val k=sourceScanKey(src);if(!catalogSyncing.add(k))return
  catalogPool.execute{
   try{
    // Lekki skan: tylko kategorie. Nie pobieramy całych bibliotek VOD/seriali przy starcie,
    // bo na słabszych boxach powodowało to skoki pamięci i crashe podczas LIVE.
    try{CatalogCacheStore.saveVodCategories(this,src,Api.vodCategories(src))}catch(_:Exception){}
    try{CatalogCacheStore.saveSeriesCategories(this,src,Api.seriesCategories(src))}catch(_:Exception){}
   }finally{catalogSyncing.remove(k)}
  }
 }
 private fun liveGroupFilterPrefs()=getSharedPreferences("live_group_filter_v1",Context.MODE_PRIVATE)
 private fun liveGroupHiddenKey(src:Source)=sourceScanKey(src)+"|hidden"
 private fun savedHiddenLiveGroups(src:Source):Set<String> = liveGroupFilterPrefs().getStringSet(liveGroupHiddenKey(src),mutableSetOf<String>())?.toSet()?:emptySet()
 private fun saveHiddenLiveGroups(src:Source,hidden:Set<String>){liveGroupFilterPrefs().edit().putStringSet(liveGroupHiddenKey(src),hidden.toSet()).apply()}
 private fun filteredLiveGroups(src:Source,sourceGroups:List<LiveGroup>):List<LiveGroup>{val hidden=savedHiddenLiveGroups(src);return sourceGroups.filterNot{hidden.contains(it.id)}}
 private fun currentAllLiveGroups():List<LiveGroup>{val src=selectedSource?:return groups;val cached=LiveCacheStore.loadGroups(this,src).filterNot{it.name.equals("Other",true)};return (if(cached.isNotEmpty())cached else allLiveGroups.ifEmpty{groups}).distinctBy{it.id}}
 private fun setupLiveGroupFilterPanel(){
  fun btn(label:String)=Button(this).apply{text=label;setAllCaps(false);textSize=16f;setTextColor(0xFFFFFFFF.toInt());setBackgroundResource(R.drawable.button_dark);gravity=Gravity.START or Gravity.CENTER_VERTICAL;setPadding(dp(16),0,dp(12),0)}
  liveGroupFilterToggle=btn("Filtruj grupy").apply{setOnClickListener{setLiveGroupFilterEdit(!liveGroupFilterEdit)}}
  liveGroupFilterClear=btn("Odznacz wszystko").apply{setOnClickListener{if(liveGroupFilterEdit){liveGroupFilterWorking.clear();renderLiveGroupFilterEditing()}}}
  liveGroupFilterAll=btn("Zaznacz wszystko").apply{setOnClickListener{if(liveGroupFilterEdit){liveGroupFilterWorking=currentAllLiveGroups().map{it.id}.toMutableSet();renderLiveGroupFilterEditing()}}}
  liveGroupFilterSave=btn("Zapisz").apply{setOnClickListener{saveLiveGroupFilter()}}
  val title=TextView(this).apply{text="FILTROWANIE GRUP";setTextColor(0xFFFFFFFF.toInt());textSize=19f;setPadding(dp(18),dp(18),dp(12),dp(10))}
  liveGroupFilterPanel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE;elevation=dp(15).toFloat();setBackgroundResource(R.drawable.panel_live_glass);addView(title,LinearLayout.LayoutParams(-1,dp(58)));listOf(liveGroupFilterToggle,liveGroupFilterClear,liveGroupFilterAll,liveGroupFilterSave).forEach{addView(it,LinearLayout.LayoutParams(-1,dp(54)).apply{leftMargin=dp(14);rightMargin=dp(14);topMargin=dp(7)})}}
  rootFrame.addView(liveGroupFilterPanel,FrameLayout.LayoutParams((resources.displayMetrics.widthPixels*0.34f).toInt(),-2,Gravity.START or Gravity.CENTER_VERTICAL).apply{leftMargin=dp(20)})
  updateLiveGroupFilterPanelState()
 }
 private fun updateLiveGroupFilterPanelState(){
  liveGroupFilterToggle.text=if(liveGroupFilterEdit)"✓  Filtruj grupy" else "Filtruj grupy"
  listOf(liveGroupFilterClear,liveGroupFilterAll,liveGroupFilterSave).forEach{b->b.isEnabled=liveGroupFilterEdit;b.isFocusable=liveGroupFilterEdit;b.alpha=if(liveGroupFilterEdit)1f else 0.35f}
 }
 private fun showLiveGroupFilterPanel(){if(screen!=Screen.LIVE_GROUPS||liveGroupFilterPanelOpen)return;liveGroupFilterPanelOpen=true;updateLiveGroupFilterPanelState();liveGroupFilterPanel.visibility=View.VISIBLE;liveGroupFilterPanel.bringToFront();liveGroupFilterToggle.requestFocus()}
 private fun hideLiveGroupFilterPanel(){if(!liveGroupFilterPanelOpen)return;liveGroupFilterPanelOpen=false;liveGroupFilterPanel.visibility=View.GONE;channelList.requestFocus()}
 private fun setLiveGroupFilterEdit(enable:Boolean){
  val src=selectedSource?:return
  liveGroupFilterEdit=enable
  if(enable){val all=currentAllLiveGroups();allLiveGroups=all;val hidden=savedHiddenLiveGroups(src);liveGroupFilterWorking=all.filterNot{hidden.contains(it.id)}.map{it.id}.toMutableSet();renderLiveGroupFilterEditing()}else{val all=currentAllLiveGroups();allLiveGroups=all;groups=filteredLiveGroups(src,all);renderLiveGroupRows(false)}
  updateLiveGroupFilterPanelState();liveGroupFilterToggle.requestFocus()
 }
 private fun saveLiveGroupFilter(){
  if(!liveGroupFilterEdit)return
  val src=selectedSource?:return;val all=currentAllLiveGroups();allLiveGroups=all;val hidden=all.map{it.id}.filterNot{liveGroupFilterWorking.contains(it)}.toSet();saveHiddenLiveGroups(src,hidden);Toast.makeText(this,"Zapisano filtr grup",Toast.LENGTH_SHORT).show();renderLiveGroupFilterEditing();liveGroupFilterSave.requestFocus()
 }
 private fun renderLiveGroupFilterEditing(){allLiveGroups=currentAllLiveGroups();groups=allLiveGroups;renderLiveGroupRows(true)}
 private fun renderLiveGroupRows(edit:Boolean){
  val pos=channelList.selectedItemPosition.coerceAtLeast(0)
  val rows=if(edit)groups.map{(if(liveGroupFilterWorking.contains(it.id))"☑  " else "☐  ")+it.name}else groups.map{it.name}
  status.text=if(edit)"Telewizja  •  filtrowanie grup  •  OK = zaznacz/odznacz, LEWO = opcje" else "Telewizja  •  ${groups.size} grup  •  OK = wejdź do grupy"
  channelList.adapter=TvListAdapter(this,rows,0);channelList.setOnScrollListener(null);channelList.post{if(groups.isNotEmpty())channelList.setSelection(pos.coerceIn(0,groups.lastIndex));if(!liveGroupFilterPanelOpen)channelList.requestFocus()}
 }
 private fun toggleLiveGroupSelection(i:Int){if(!liveGroupFilterEdit||i !in groups.indices)return;val id=groups[i].id;if(!liveGroupFilterWorking.add(id))liveGroupFilterWorking.remove(id);renderLiveGroupRows(true);channelList.post{if(groups.isNotEmpty())channelList.setSelection(i.coerceIn(0,groups.lastIndex))}}
 /**
  * Jedyne wejście na planszę z trzema kaflami. [reason] trafia do logu, więc każdy powrót
  * na ekran główny da się jednoznacznie przypisać do konkretnej ścieżki w kodzie.
  */
 private fun showHome(reason:String){Log.i(LIVE_TAG,"showHome reason=$reason previousScreen=$screen liveFullscreen=$liveFullscreen");releaseMini();screen=Screen.HOME;applyTheme(1);setMode(home=true);updateClocks();status.text="${selectedSource?.name?.takeIf{it.isNotBlank()}?:"Brak wybranego serwera"}  •  wybierz dział";findViewById<View>(R.id.tileLive).requestFocus()}
 private fun loadLive(){openLastLiveOrGroups()}
 private fun showLiveGroups(restorePos:Pos?=null){
  screen=Screen.LIVE_GROUPS;applyTheme(2);setMode(live=true);visibleChannels=emptyList();currentLiveGroup=null;piconAdapter?.close();piconAdapter=null
  val src=selectedSource
  val baseGroups=if(src!=null){val cached=LiveCacheStore.loadGroups(this,src).filterNot{it.name.equals("Other",true)};if(cached.isNotEmpty())cached else if(allLiveGroups.isNotEmpty()&&groups.all{g->allLiveGroups.any{it.id==g.id}})allLiveGroups else groups.filterNot{it.name.equals("Other",true)}}else groups.filterNot{it.name.equals("Other",true)}
  allLiveGroups=baseGroups
  if(src!=null&&!liveGroupFilterEdit)groups=filteredLiveGroups(src,allLiveGroups) else groups=allLiveGroups
  status.text=if(liveGroupFilterEdit)"Telewizja  •  ${selectedSource?.name.orEmpty()}  •  filtrowanie grup  •  OK = zaznacz/odznacz, LEWO = opcje" else "Telewizja  •  ${selectedSource?.name.orEmpty()}  •  ${groups.size} grup  •  OK = wejdź do grupy"
  val rows=if(liveGroupFilterEdit)groups.map{(if(liveGroupFilterWorking.contains(it.id))"☑  " else "☐  ")+it.name}else groups.map{it.name}
  channelList.adapter=TvListAdapter(this,rows,0)
  channelList.setOnScrollListener(null)
  channelList.post{
   channelList.clearChoices();channelList.choiceMode=AbsListView.CHOICE_MODE_NONE
   if(groups.isNotEmpty()){
    val idx=liveGroupSelected.coerceIn(0,groups.lastIndex)
    val top=if(restorePos!=null)liveGroupAnchorTop else (resources.displayMetrics.density*95f).toInt()
    channelList.setSelectionFromTop(idx,top)
   }
   channelList.requestFocus()
  }
  miniCurrentChannel?.let{c->updateMiniInfo(c);loadEpgForChannels(listOf(c));startMini(c)}
 }

 private fun showChannels(group:LiveGroup,channels:List<Channel>,selectUrl:String=""){
  screen=Screen.LIVE_CHANNELS;currentLiveGroup=group;applyTheme(2);setMode(live=true)
  // Zasada twarda: lista dostaje WYŁĄCZNIE kanały pobrane/zapisane dla tej jednej kategorii.
  visibleChannels=channels.filter{it.groupId==group.id || (it.groupId.isBlank()&&it.group.equals(group.name,true))}
  // Gdy użytkownik wchodzi do LIVE, zewnętrzne XMLTV ma być gotowe możliwie od razu.
  // Jeśli cache jest świeży, refreshIfDue kończy się natychmiast. Jeśli URL jest nowy
  // albo minęły 24 h, skan startuje od razu (bez dawnego 8-sekundowego opóźnienia).
  selectedSource?.let { scheduleExternalEpgRefresh(it,true) }
  status.text="${group.name}  •  ${visibleChannels.size} kanałów  •  OK = pełny ekran, przytrzymaj = opcje"
  if(selectUrl.isNotBlank())liveChannelSelected=visibleChannels.indexOfFirst{it.url==selectUrl}.takeIf{it>=0}?:liveChannelSelected
  if(visibleChannels.isNotEmpty())liveChannelSelected=liveChannelSelected.coerceIn(0,visibleChannels.lastIndex) else liveChannelSelected=0
  liveChannelPageStart=(liveChannelSelected/8)*8
  refreshChannelsAdapter(false);channelList.clearChoices();channelList.choiceMode=AbsListView.CHOICE_MODE_NONE
  if(liveFullscreen&&liveChannelDrawerOpen){
   val playingIndex=visibleChannels.indexOfFirst{it.url==miniCurrentChannel?.url}
   liveDrawerSelected=if(playingIndex>=0)playingIndex else 0
   liveDrawerPageStart=(liveDrawerSelected/9)*9
   liveChannelDrawerTitle.text=group.name+"   •   ${visibleChannels.size}"
   liveDrawerAdapter=FullscreenChannelAdapter();liveChannelDrawerList.adapter=liveDrawerAdapter
   liveChannelDrawerList.post{if(visibleChannels.isNotEmpty())positionPagedList(liveChannelDrawerList,liveDrawerSelected,9,visibleChannels.size,true)}
   liveGroupDrawerAdapter?.notifyDataSetChanged()
  }
  channelList.setOnScrollListener(object:AbsListView.OnScrollListener{override fun onScrollStateChanged(v:AbsListView?,state:Int){if(state==AbsListView.OnScrollListener.SCROLL_STATE_IDLE)loadVisibleEpg()};override fun onScroll(v:AbsListView?,first:Int,count:Int,total:Int){}})
  // Po wejściu do grupy pobieramy EPG dla CAŁEJ grupy od razu. epgEvents/epgText są
  // pamięciowym cache i pozostają dostępne aż do zamknięcia aplikacji lub zmiany serwera.
  preloadGroupEpg(visibleChannels)
  // Picony źródła ładujemy razem z EPG dla całej grupy, żeby podczas przewijania były już w RAM.
  // Enigma2 ma osobną, szybką ścieżkę piconów i celowo jej tu nie obciążamy masowym prefetchingiem.
  preloadGroupPicons(visibleChannels)
  channelList.post{
   if(visibleChannels.isNotEmpty()){positionPagedList(channelList,liveChannelSelected,8,visibleChannels.size,true);updateMiniInfo(visibleChannels[liveChannelSelected])}
   channelList.requestFocus()
  }
  miniCurrentChannel?.takeIf{c->visibleChannels.any{it.url==c.url}}?.let{startMini(it)}
 }

 private fun loadVisibleEpg(){
  if(screen!=Screen.LIVE_CHANNELS||visibleChannels.isEmpty())return
  // EPG całej grupy jest prefetchowane przy wejściu; kolejne wywołania tylko upewniają się,
  // że brakujące dane są dociągnięte, bez ponownego pobierania tego co już jest w RAM.
  preloadGroupEpg(visibleChannels)
 }
 private fun preloadGroupEpg(items:List<Channel>){
  val src=selectedSource?:return
  if(items.isEmpty())return
  if(src.type!="e2"){loadEpgForChannels(items);return}
  val group=currentLiveGroup?:run{loadEpgForChannels(items);return}
  val pendingKey=sourceScanKey(src)+"|"+group.id
  // Jeśli cała grupa ma już EPG w RAM, nie wykonujemy żadnego requestu.
  if(items.all{!epgEvents[it.url].isNullOrEmpty()})return
  if(!e2GroupEpgPending.add(pendingKey))return
  epgPool.execute{
   try{
    val byRef=Api.e2MultiEpg(src,group.id)
    val now=System.currentTimeMillis()
    val missing=ArrayList<Channel>()
    for(c in items){
     if(!epgEvents[c.url].isNullOrEmpty())continue
     val ref=c.streamId.ifBlank{c.epgId}
     val all=byRef[ref].orEmpty().filter{it.endEpoch<=0L||it.endEpoch>now}.sortedBy{it.startEpoch}
     val currentIndex=all.indexOfFirst{it.startEpoch>0L&&it.endEpoch>it.startEpoch&&now>=it.startEpoch&&now<it.endEpoch}
     val picked=when{currentIndex>=0->all.drop(currentIndex).take(2);else->all.filter{it.startEpoch<=0L||it.startEpoch>now}.take(2)}
     if(picked.isNotEmpty()){
      epgEvents[c.url]=picked;updateEpgText(c,picked.first())
      if(miniCurrentChannel?.url==c.url)LiveCacheStore.saveLastEpg(this,src,c,picked)
     }else missing+=c
    }
    // Starsze OpenWebIF-y czasem nie zwracają wszystkich pozycji z epgmulti.
    // Uzupełniamy wyłącznie brakujące kanały sprawdzoną ścieżką per-channel.
    if(missing.isNotEmpty())loadEpgForChannels(missing)
   }catch(_:Exception){loadEpgForChannels(items)}
   finally{e2GroupEpgPending.remove(pendingKey);if(selectedSource?.let{sourceScanKey(it)}==sourceScanKey(src))scheduleEpgUiRefresh()}
  }
 }
 private fun preloadGroupPicons(items:List<Channel>){
  val src=selectedSource?:return
  if(items.isEmpty()||src.type=="e2")return
  val mode=activePiconMode()
  for(c in items){
   val local=if(mode==0||mode==2)PiconRepository.find(this,c.name) else null
   if(local!=null){
    val key="local:${local.absolutePath}"
    if(PiconMemoryCache.get(key)!=null||!groupPiconPending.add(key))continue
    piconPool.execute{try{PiconRepository.decodeScaled(local,160,100)?.let{PiconMemoryCache.put(key,it)}}finally{groupPiconPending.remove(key)}}
    continue
   }
   if((mode==1||mode==2)&&c.logo.isNotBlank()){
    val key=remotePiconCacheKey(src,c.logo)
    if(PiconMemoryCache.get(key)!=null||!groupPiconPending.add(key))continue
    piconPool.execute{try{
     val bytes=try{Api.loadRemotePicon(src,c.logo)}catch(_:Exception){URL(c.logo).openStream().use{it.readBytes()}}
     BitmapFactory.decodeByteArray(bytes,0,bytes.size)?.let{PiconMemoryCache.put(key,it)}
    }catch(_:Exception){}finally{groupPiconPending.remove(key)}}
   }
  }
 }
 private fun activePiconMode():Int = selectedSource?.takeIf{it.type=="e2"}?.let{if(it.e2PiconSource.equals("local",true))0 else 1} ?: piconMode
 private fun refreshChannelsAdapter(preserve:Boolean=true){if(screen!=Screen.LIVE_CHANNELS&&screen!=Screen.FAVORITES)return;val p=if(preserve)position()else Pos();val items=if(screen==Screen.FAVORITES)favorites else visibleChannels;piconAdapter?.close();piconAdapter=PiconAdapter(this,items,epgText,epgEvents,activePiconMode(),selectedSource,if(screen==Screen.LIVE_CHANNELS)liveChannelSelected else -1,if(screen==Screen.LIVE_CHANNELS)8 else 0);currentList().adapter=piconAdapter;if(preserve)restore(p)}

 private val refreshScheduled=AtomicBoolean(false)
 private fun scheduleEpgUiRefresh(){if(refreshScheduled.compareAndSet(false,true)){handler.postDelayed({refreshScheduled.set(false);if(screen==Screen.LIVE_CHANNELS||screen==Screen.FAVORITES)piconAdapter?.notifyDataSetChanged();if(screen==Screen.LIVE_CHANNELS){val pos=liveChannelSelected;if(pos in visibleChannels.indices)updateMiniInfo(visibleChannels[pos])}else if(screen==Screen.LIVE_GROUPS){miniCurrentChannel?.let{updateMiniInfo(it)}};if(liveFullscreen){updateFullscreenInfo(miniCurrentChannel);if(liveChannelDrawerOpen)liveDrawerAdapter?.notifyDataSetChanged();if(liveHistoryExpanded)updateLiveHistoryProgress()}},180)}}
 private fun loadEpgForChannels(items:List<Channel>,force:Boolean=false){
  val src=selectedSource?:return
  if(items.isEmpty())return
  val srcKey=sourceScanKey(src)
  items.forEach { c ->
   if((force || epgEvents[c.url].isNullOrEmpty()) && epgPending.add(c.url)){
    epgPool.execute {
     try {
      // Enigma2 wraca do sprawdzonej, szybkiej ścieżki OpenWebIF z wersji,
      // w której EPG ładowało się poprawnie: now + next dla konkretnego kanału.
      // loadVisibleEpg() przekazuje tu wyłącznie kanały aktualnej strony/grupy.
      var ev=Api.epgNowNext(src,c)
      if(ev.isEmpty() && src.type!="e2")ev=ExternalEpgStore.nowNext(this,src,c)
      if(ev.isNotEmpty() && selectedSource?.let{sourceScanKey(it)}==srcKey){
       epgEvents[c.url]=ev
       if(miniCurrentChannel?.url==c.url)LiveCacheStore.saveLastEpg(this,src,c,ev)
       updateEpgText(c,ev.first())
      }
     } finally {
      epgPending.remove(c.url)
      if(selectedSource?.let{sourceScanKey(it)}==srcKey)scheduleEpgUiRefresh()
     }
    }
   }
  }
 }

 private fun updateEpgText(c:Channel,e:EpgEvent?){
  if(e==null){epgText.remove(c.url);return}
  val times=if(e.start.isNotBlank()||e.end.isNotBlank()) "${e.start} - ${e.end}  " else ""
  epgText[c.url]="$times${e.title}"
 }

 private fun refreshEpgClock(){
  val now=System.currentTimeMillis()
  val candidates=(visibleChannels + favorites + listOfNotNull(miniCurrentChannel)).distinctBy{it.url}
  val needsRefresh=ArrayList<Channel>()
  var changed=false
  for(c in candidates){
   val old=epgEvents[c.url].orEmpty()
   if(old.isEmpty())continue
   val first=old.first()
   if(first.endEpoch>0L && now>=first.endEpoch){
    val remaining=old.dropWhile{it.endEpoch>0L && now>=it.endEpoch}
    if(remaining.isNotEmpty()){
     epgEvents[c.url]=remaining
     updateEpgText(c,remaining.first())
    }else{
     epgEvents.remove(c.url)
     epgText.remove(c.url)
    }
    changed=true
    needsRefresh+=c
   }
  }
  if(screen==Screen.LIVE_CHANNELS){val pos=liveChannelSelected;if(pos in visibleChannels.indices)updateMiniInfo(visibleChannels[pos])}
  else if(screen==Screen.LIVE_GROUPS)miniCurrentChannel?.let{updateMiniInfo(it)}
  if(liveFullscreen)updateFullscreenInfo(miniCurrentChannel)
  if(changed){
   if(screen==Screen.LIVE_CHANNELS||screen==Screen.FAVORITES)piconAdapter?.notifyDataSetChanged()
   if(liveFullscreen&&liveChannelDrawerOpen)liveDrawerAdapter?.notifyDataSetChanged()
  }
  if(needsRefresh.isNotEmpty())loadEpgForChannels(needsRefresh.distinctBy{it.url},true)
 }

 private fun scheduleExternalEpgRefresh(src:Source,immediate:Boolean=false){
  if(!ExternalEpgStore.isConfigured(src))return
  val key=sourceScanKey(src)+"|"+src.epgUrl
  val runScan={
   if(externalEpgSyncing.add(key)){
    externalEpgPool.execute{
     try{
      val changed=ExternalEpgStore.refreshIfDue(this,src)
      if(changed)runOnUiThread{
       if(selectedSource?.let{sourceScanKey(it)}==sourceScanKey(src)){
        val affected=(visibleChannels + listOfNotNull(miniCurrentChannel)).distinctBy{it.url}
        affected.forEach{c->epgText.remove(c.url);epgEvents.remove(c.url);epgPending.remove(c.url)}
        if(screen==Screen.LIVE_CHANNELS&&visibleChannels.isNotEmpty())preloadGroupEpg(visibleChannels)
        miniCurrentChannel?.let{loadEpgForChannels(listOf(it))}
       }
      }
     }catch(_:Exception){}finally{externalEpgSyncing.remove(key)}
    }
   }
  }
  if(immediate)runScan() else handler.postDelayed({runScan()},8000L)
 }

 private fun updateMiniInfo(c:Channel){miniChannel.text=c.name;val ev=epgEvents[c.url].orEmpty();val now=ev.firstOrNull();val eventText=if(now==null)epgText[c.url].orEmpty() else (if(now.start.isNotBlank()||now.end.isNotBlank())"${now.start} - ${now.end}  " else "")+now.title;miniNow.text=eventText;miniNow.scrollTo(0,0);setMiniDescriptionText(now?.description.orEmpty());if(now!=null&&now.startEpoch>0&&now.endEpoch>now.startEpoch){val n=System.currentTimeMillis();miniProgress.progress=(((n-now.startEpoch).coerceIn(0,now.endEpoch-now.startEpoch)*1000)/(now.endEpoch-now.startEpoch)).toInt()}else miniProgress.progress=0;loadMiniPicon(c)}
 private fun setMiniDescriptionText(text:String){
  miniEventScrollToken++;val token=miniEventScrollToken
  miniEventAnimator?.cancel();miniEventAnimator=null;miniDesc.scrollTo(0,0);miniDesc.text=text
  // The long EPG description under MiniTV remains still for 3 seconds, then scrolls
  // vertically at a constant, readable speed. Short descriptions never move.
  miniDesc.post{
   if(token!=miniEventScrollToken)return@post
   fun schedule(){
    miniDesc.postDelayed({
     if(token!=miniEventScrollToken)return@postDelayed
     val layout=miniDesc.layout?:return@postDelayed
     val contentBottom=if(layout.lineCount>0)layout.getLineBottom(layout.lineCount-1) else 0
     val visibleHeight=(miniDesc.height-miniDesc.compoundPaddingTop-miniDesc.compoundPaddingBottom).coerceAtLeast(1)
     val maxScroll=(contentBottom-visibleHeight).coerceAtLeast(0)
     if(maxScroll<=0){miniDesc.scrollTo(0,0);return@postDelayed}
     val start=miniDesc.scrollY.coerceIn(0,maxScroll)
     val distance=(maxScroll-start).coerceAtLeast(1)
     miniEventAnimator=ValueAnimator.ofInt(start,maxScroll).apply{
      duration=(distance*42L).coerceIn(2800L,18000L)
      interpolator=LinearInterpolator()
      addUpdateListener{a->if(token==miniEventScrollToken)miniDesc.scrollTo(0,a.animatedValue as Int)}
      addListener(object:android.animation.AnimatorListenerAdapter(){override fun onAnimationEnd(animation:android.animation.Animator){
       if(token!=miniEventScrollToken)return
       miniDesc.postDelayed({if(token==miniEventScrollToken){miniDesc.scrollTo(0,0);schedule()}},1600L)
      }})
      start()
     }
    },3000L)
   }
   schedule()
  }
 }
 private fun remotePiconCacheKey(src:Source?,url:String)="remote:${src?.type}:${src?.host}:$url"
 private fun loadMiniPicon(c:Channel){
  val pm=activePiconMode();val local=if(pm==0||pm==2)PiconRepository.find(this,c.name)else null
  if(local!=null){
   val cacheKey="local:${local.absolutePath}";PiconMemoryCache.get(cacheKey)?.let{miniPicon.setImageBitmap(it);return}
   miniPicon.setImageDrawable(null);val channelKey=c.url;piconPool.execute{val bm=PiconRepository.decodeScaled(local,220,140)?:return@execute;PiconMemoryCache.put(cacheKey,bm);runOnUiThread{if(miniCurrentChannel?.url==channelKey||miniChannel.text==c.name)miniPicon.setImageBitmap(bm)}};return
  }
  if((pm==1||pm==2)&&c.logo.isNotBlank()){
   val src=selectedSource;val cacheKey=remotePiconCacheKey(src,c.logo)
   PiconMemoryCache.get(cacheKey)?.let{miniPicon.setImageBitmap(it);return}
   miniPicon.setImageDrawable(null);val channelKey=c.url
   piconPool.execute{try{val b=src?.let{Api.loadRemotePicon(it,c.logo)}?:URL(c.logo).openStream().use{it.readBytes()};val bm=BitmapFactory.decodeByteArray(b,0,b.size)?:return@execute;PiconMemoryCache.put(cacheKey,bm);runOnUiThread{if(miniCurrentChannel?.url==channelKey||miniChannel.text==c.name)miniPicon.setImageBitmap(bm)}}catch(_:Exception){}}
  }else miniPicon.setImageDrawable(null)
 }

 private fun liveDiagPrefs()=getSharedPreferences("live_diag_v1",Context.MODE_PRIVATE)
 /**
  * Znacznik "trwa odtwarzanie LIVE". Zapis następuje tylko przy rzeczywistej zmianie stanu
  * (start / koniec sesji), więc nie generuje ruchu na dysku podczas oglądania.
  */
 private fun markLiveSession(active:Boolean){
  val prefs=liveDiagPrefs()
  if(prefs.getBoolean("livePlaying",false)==active)return
  prefs.edit().putBoolean("livePlaying",active).apply()
 }
 /**
  * Jedyna ścieżka podłączania kanału LIVE do współdzielonego playera. Używają jej MiniTV,
  * przełączanie DPAD w fullscreen i wybór z szuflady kanałów, więc wszystkie trzy mają
  * identyczny reset stanu odtwarzania, ten sam token i ten sam listener.
  */
 private fun bindLiveChannel(c:Channel):ExoPlayer?{
  val previousUrl=LivePlayerSession.currentUrl()
  // Ponowny wybór TEGO SAMEGO kanału na martwym playerze też jest pełnym rozruchem — inaczej
  // "wejdź jeszcze raz w ten kanał" nie robiło absolutnie nic. Token zawsze rośnie, więc
  // watchdog poprzedniego rozruchu staje się nieaktualny i MUSI zostać uzbrojony ponownie,
  // jeżeli nowy materiał jeszcze nie gra.
  val switching=previousUrl!=c.url||LivePlayerSession.isStalled()||!LivePlayerSession.itemHasStarted()
  liveChannelToken++
  miniCurrentChannel=c
  liveZapIgnoreIdleUntil=SystemClock.uptimeMillis()+500L
  if(switching){
   selectedSource?.let{LastLiveStore.save(this,it,c)}
   // Zmiana MediaItem zawsze przechodzi przez IDLE/BUFFERING, a serwery IPTV potrafią
   // zwrócić chwilowy błąd na pierwszym żądaniu. To NIE jest awaria strumienia, więc
   // automatyka odzyskiwania po rebufferach jest rozbrojona na czas rozruchu nowego kanału.
   // Rozruchu pilnuje osobny watchdog uzbrajany niżej.
   suppressLiveBufferUntil=SystemClock.uptimeMillis()+5000
   liveRecoveryArmed=false;liveHasPlayed=false;liveRetryCount=0;liveRebufferTimes.clear();liveRestartCooldownUntil=0L;hideLiveBuffer()
   Log.i(LIVE_TAG,"zap token=$liveChannelToken name=${c.name} url: ${shortUrl(previousUrl)} -> ${shortUrl(c.url)} state=${LivePlayerSession.stateLabel()}")
  }
  selectedSource?.takeIf{it.type=="e2"&&it.e2ZapOnBox}?.let{src->pool.execute{try{Api.e2Zap(src,c)}catch(_:Exception){}}}
  return try{
   val p=LivePlayerSession.ensure(this,c.url,Api.streamAuthHeader(selectedSource))
   miniPlayer=p
   if(miniPlayerView.player!==p)miniPlayerView.player=p
   LivePlayerSession.bindView(miniPlayerView)
   S9VideoOutputTuner.applyFromPlayer(p,miniPlayerView,"live-bind")
   p.volume=1f
   installLiveListener(p)
   markLiveSession(true)
   if(switching)armZapWatchdog(liveChannelToken)
   else if(p.playbackState==Player.STATE_READY||p.isPlaying)liveStartedToken=liveChannelToken
   else armZapWatchdog(liveChannelToken)
   p
  }catch(e:Exception){
   Log.w(LIVE_TAG,"zap token=$liveChannelToken FAILED name=${c.name} err=${e.javaClass.simpleName}:${e.message}")
   null
  }
 }
 private fun shortUrl(u:String):String=if(u.isBlank())"-" else u.substringAfterLast('/').take(48)
 private fun startMini(c:Channel){
  if(screen!=Screen.LIVE_CHANNELS&&screen!=Screen.LIVE_GROUPS)return
  if(bindLiveChannel(c)==null)return
  miniPlayerView.visibility=View.VISIBLE;positionLiveSurfaceToMini(false)
 }
 private fun releaseMini(){
  if(liveFullscreen)Log.i(LIVE_TAG,"releaseMini wywołane podczas fullscreen — player zostaje zwolniony")
  miniEventScrollToken++;miniEventAnimator?.cancel();miniEventAnimator=null;miniDesc.scrollTo(0,0);miniNow.scrollTo(0,0)
  liveChannelToken++
  // Token rośnie, więc wszystkie zaległe callbacki kanału stają się nieaktualne. Watchdog i tak
  // kasujemy jawnie, żeby nie został w kolejce po zwolnieniu playera.
  cancelZapWatchdog();liveZapStage=0;liveZapGrace=0;liveStartedToken=-1
  liveFullscreen=false;hideLiveInfoImmediate();liveBufferingBox.visibility=View.GONE
  miniPlayerView.visibility=View.GONE;miniPlayerView.player=null
  liveListenerPlayer=null
  try{LivePlayerSession.release()}catch(_:Exception){}
  miniPlayer=null;liveSurfaceReady=false
  markLiveSession(false)
 }

 private fun scheduleVodGroupRefresh(src:Source,cat:MediaCategory){catalogPool.execute{try{CatalogCacheStore.saveVodItems(this,src,cat.id,Api.vodItems(src,cat.id))}catch(_:Exception){}}}
 private fun scheduleSeriesGroupRefresh(src:Source,cat:MediaCategory){catalogPool.execute{try{CatalogCacheStore.saveSeriesItems(this,src,cat.id,Api.seriesItems(src,cat.id))}catch(_:Exception){}}}

 private fun renderVodCats(p:Pos?=null){normalizeUiDensity();screen=Screen.VOD_CATS;applyTheme(3);setMode();status.text="Filmy  •  ${selectedSource?.name.orEmpty()}  •  ${vodCats.size} kategorii  •  Kliknij w lewo aby uzyskać więcej opcji";list.adapter=TvListAdapter(this,vodCats.map{it.name},1);p?.let{restore(it)};list.requestFocus()}
 private fun loadVodCategories(){
  releaseMini();val src=selectedSource?:return;screen=Screen.VOD_CATS;setMode()
  val cached=CatalogCacheStore.loadVodCategories(this,src)
  if(cached.isNotEmpty()){vodCats=cached;renderVodCats();scheduleCatalogSync(src);return}
  status.text="Ładowanie kategorii filmów…";pool.execute{try{val x=Api.vodCategories(src);CatalogCacheStore.saveVodCategories(this,src,x);runOnUiThread{if(selectedSource==src){vodCats=x;renderVodCats();scheduleCatalogSync(src)}}}catch(e:Exception){runOnUiThread{status.text="Filmy: ${e.message}"}}}
 }
 private fun loadVodItems(cat:MediaCategory){
  val src=selectedSource?:return;currentVodCat=cat;vodItemSelected=0
  val cached=CatalogCacheStore.loadVodItems(this,src,cat.id)
  if(cached.isNotEmpty()){vodItems=cached;renderVodItems();scheduleVodGroupRefresh(src,cat);return}
  status.text="Ładowanie: ${cat.name}…";pool.execute{try{val x=Api.vodItems(src,cat.id);CatalogCacheStore.saveVodItems(this,src,cat.id,x);runOnUiThread{if(selectedSource==src&&currentVodCat?.id==cat.id){vodItems=x;renderVodItems()}}}catch(e:Exception){runOnUiThread{status.text="Błąd filmów: ${e.message}"}}}
 }
 private fun renderVodItems(p:Pos?=null){screen=Screen.VOD_ITEMS;applyTheme(3);setMode();status.text="${currentVodCat?.name.orEmpty()}  •  ${vodItems.size} filmów";posterAdapter=PosterGridAdapter(this,vodItems.map{it.name},vodItems.map{it.icon},false);posterGrid.adapter=posterAdapter;posterGrid.clearChoices();posterGrid.choiceMode=AbsListView.CHOICE_MODE_SINGLE;p?.let{restore(it)};posterGrid.post{val pos=vodItemSelected.coerceIn(0,(vodItems.size-1).coerceAtLeast(0));posterGrid.setSelection(pos);updatePosterSelection(pos);posterGrid.requestFocus()}}
 private fun renderSeriesCats(p:Pos?=null){normalizeUiDensity();screen=Screen.SERIES_CATS;applyTheme(4);setMode();status.text="Seriale  •  ${selectedSource?.name.orEmpty()}  •  ${seriesCats.size} kategorii  •  Kliknij w lewo aby uzyskać więcej opcji";list.adapter=TvListAdapter(this,seriesCats.map{it.name},2);p?.let{restore(it)};list.requestFocus()}
 private fun loadSeriesCategories(){
  releaseMini();val src=selectedSource?:return;screen=Screen.SERIES_CATS;setMode()
  val cached=CatalogCacheStore.loadSeriesCategories(this,src)
  if(cached.isNotEmpty()){seriesCats=cached;renderSeriesCats();scheduleCatalogSync(src);return}
  status.text="Ładowanie kategorii seriali…";pool.execute{try{val x=Api.seriesCategories(src);CatalogCacheStore.saveSeriesCategories(this,src,x);runOnUiThread{if(selectedSource==src){seriesCats=x;renderSeriesCats();scheduleCatalogSync(src)}}}catch(e:Exception){runOnUiThread{status.text="Seriale: ${e.message}"}}}
 }
 private fun loadSeriesItems(cat:MediaCategory){
  val src=selectedSource?:return;currentSeriesCat=cat;seriesItemSelected=0
  val cached=CatalogCacheStore.loadSeriesItems(this,src,cat.id)
  if(cached.isNotEmpty()){seriesItems=cached;renderSeriesItems();scheduleSeriesGroupRefresh(src,cat);return}
  status.text="Ładowanie: ${cat.name}…";pool.execute{try{val x=Api.seriesItems(src,cat.id);CatalogCacheStore.saveSeriesItems(this,src,cat.id,x);runOnUiThread{if(selectedSource==src&&currentSeriesCat?.id==cat.id){seriesItems=x;renderSeriesItems()}}}catch(e:Exception){runOnUiThread{status.text="Błąd seriali: ${e.message}"}}}
 }
 private fun renderSeriesItems(p:Pos?=null){screen=Screen.SERIES_ITEMS;applyTheme(4);setMode();status.text="${currentSeriesCat?.name.orEmpty()}  •  ${seriesItems.size} seriali";posterAdapter=PosterGridAdapter(this,seriesItems.map{it.name},seriesItems.map{it.cover},true);posterGrid.adapter=posterAdapter;posterGrid.clearChoices();posterGrid.choiceMode=AbsListView.CHOICE_MODE_SINGLE;p?.let{restore(it)};posterGrid.post{val pos=seriesItemSelected.coerceIn(0,(seriesItems.size-1).coerceAtLeast(0));posterGrid.setSelection(pos);updatePosterSelection(pos);posterGrid.requestFocus()}}
 private fun loadSeasons(item:SeriesItem){val src=selectedSource?:return;selectedSeries=item;status.text="Ładowanie sezonów: ${item.name}…";pool.execute{try{val p=Api.seasons(src,item.id);runOnUiThread{seasons=p.first;seasonEpisodes=p.second;renderSeasons()}}catch(e:Exception){runOnUiThread{status.text="Błąd sezonów: ${e.message}"}}}}
 private fun renderSeasons(p:Pos?=null){screen=Screen.SEASONS;applyTheme(4);setMode();status.text="${selectedSeries?.name.orEmpty()}  •  ${seasons.size} sezonów";list.adapter=TvListAdapter(this,seasons.map{it.name},2,true);p?.let{restore(it)};list.requestFocus()}
 private fun showEpisodes(season:SeasonItem){screen=Screen.EPISODES;applyTheme(4);setMode();episodes=seasonEpisodes[season.id].orEmpty();status.text="${selectedSeries?.name.orEmpty()}  •  ${season.name}";list.adapter=TvListAdapter(this,episodes.map{it.name},2,true);list.requestFocus()}
 private fun showFavorites(){releaseMini();screen=Screen.FAVORITES;applyTheme(2);setMode();status.text="Ulubione  •  ${favorites.size} kanałów";piconAdapter?.close();piconAdapter=PiconAdapter(this,favorites,epgText,epgEvents,activePiconMode(),selectedSource);list.adapter=piconAdapter;loadEpgForChannels(favorites);list.requestFocus()}
 private fun toggleFavorite(c:Channel){val i=favorites.indexOfFirst{it.url==c.url};val added=i<0;if(added)favorites.add(c)else favorites.removeAt(i);FavoriteStore.save(this,favorites);Toast.makeText(this,if(added)"Dodano do ulubionych" else "Usunięto z ulubionych",Toast.LENGTH_SHORT).show();if(screen==Screen.FAVORITES)showFavorites()}

 private fun launchExternalPlayer(url:String,name:String):Boolean{
  val pkg=AppOptionsStore.externalPlayerPackage(this).trim();if(pkg.isBlank())return false
  return try{
   val uri=android.net.Uri.parse(url)
   val i=Intent(Intent.ACTION_VIEW).apply{setDataAndType(uri,"video/*");setPackage(pkg);putExtra(Intent.EXTRA_TITLE,name);addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)}
   startActivity(i);true
  }catch(_:Exception){
   Toast.makeText(this,"Nie udało się uruchomić wybranego zewnętrznego playera. Używam wbudowanego TvMad.",Toast.LENGTH_LONG).show();false
  }
 }
 private fun play(url:String,name:String,epg:String="",vod:Boolean=false,channel:Channel?=null,recentKey:String="",recentKind:String="movie",poster:String="",recentTitle:String=name,resumeMs:Long=0L){
  if(!vod&&channel!=null){
   miniCurrentChannel=channel;selectedSource?.let{LastLiveStore.save(this,it,channel)}
   if(AppOptionsStore.externalPlayerPackage(this).isNotBlank()){releaseMini();if(launchExternalPlayer(url,name))return}
   startMini(channel);enterLiveFullscreen(channel,true);return
  }
  releaseMini()
  if(AppOptionsStore.externalPlayerPackage(this).isNotBlank()&&launchExternalPlayer(url,name))return
  val i=Intent(this,PlayerActivity::class.java).putExtra("url",url).putExtra("name",name).putExtra("epg",epg).putExtra("vod",true).putExtra("recentKey",recentKey.ifBlank{url}).putExtra("recentKind",recentKind).putExtra("recentPoster",poster).putExtra("recentTitle",recentTitle).putExtra("resumeMs",resumeMs)
  selectedSource?.let{src->i.putExtra("sourceType",src.type).putExtra("sourceName",src.name).putExtra("sourceHost",src.host).putExtra("sourceUser",src.user).putExtra("sourcePass",src.pass).putExtra("sourceUrl",src.url)}
  startActivity(i)
 }
 private fun onChannelItem(i:Int){when(screen){
  Screen.LIVE_GROUPS->if(i in groups.indices){
   if(liveGroupFilterEdit){toggleLiveGroupSelection(i)}else{
    liveGroupsPos=position();liveGroupSelected=i;liveChannelSelected=0
    val child=channelList.getChildAt(i-channelList.firstVisiblePosition);liveGroupAnchorTop=child?.top?:(resources.displayMetrics.density*95f).toInt()
    openLiveGroup(groups[i])
   }
  }
  Screen.LIVE_CHANNELS->if(i in visibleChannels.indices){liveChannelSelected=i;val c=visibleChannels[i];play(c.url,c.name,epgText[c.url].orEmpty(),false,c)}
  else->{}
 }}
 private fun showDetails(kind:String,title:String,fallbackPoster:String,actionText:String,action:()->Unit){
  val p=position()
  val dlg=Dialog(this);dlg.requestWindowFeature(Window.FEATURE_NO_TITLE);dlg.setCancelable(true);dlg.setCanceledOnTouchOutside(false);dlg.setOwnerActivity(this)
  val panel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundResource(R.drawable.panel_dark);setPadding(dp(22),dp(16),dp(22),dp(14))}
  val scroll=ScrollView(this).apply{isFillViewport=true}
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  val safeH=(rootFrame.height.takeIf{it>0}?:resources.displayMetrics.heightPixels).coerceAtLeast(1)
  val iv=ImageView(this).apply{adjustViewBounds=true;scaleType=ImageView.ScaleType.CENTER_INSIDE;maxHeight=(safeH*0.34f).toInt()}
  val tt=TextView(this).apply{text=title;textSize=23f;setTextColor(0xFFF5A623.toInt());setPadding(0,dp(8),0,dp(6))}
  val meta=TextView(this).apply{text="Ładowanie informacji TMDB…";textSize=16f;setTextColor(0xFFCCCCCC.toInt())}
  val desc=TextView(this).apply{textSize=20f;setTextColor(0xFFFFFFFF.toInt());setLineSpacing(0f,1.10f);setPadding(0,dp(10),0,dp(6))}
  box.addView(iv);box.addView(tt);box.addView(meta);box.addView(desc);scroll.addView(box)
  val actions=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.END or Gravity.CENTER_VERTICAL;setPadding(0,dp(12),0,0)}
  val back=Button(this).apply{text="Wróć";isAllCaps=false;textSize=17f;isFocusable=true;isFocusableInTouchMode=true;setTextColor(0xFFFFFFFF.toInt());setBackgroundResource(R.drawable.button_dark)}
  val play=Button(this).apply{text=actionText;isAllCaps=false;textSize=17f;isFocusable=true;isFocusableInTouchMode=true;setTextColor(0xFFFFFFFF.toInt());setBackgroundResource(R.drawable.button_dark)}
  actions.addView(back,LinearLayout.LayoutParams(dp(150),dp(56)).apply{marginEnd=dp(16)});actions.addView(play,LinearLayout.LayoutParams(dp(170),dp(56)))
  panel.addView(scroll,LinearLayout.LayoutParams(-1,0,1f));panel.addView(actions,LinearLayout.LayoutParams(-1,dp(72)))
  dlg.setContentView(panel)
  dlg.setOnDismissListener{ExternalInputBridge.detachModal(dlg);restore(p)}
  back.setOnClickListener{dlg.dismiss()}
  play.setOnClickListener{dlg.dismiss();restore(p);rootFrame.postDelayed({action()},90L)}
  dlg.show()
  dlg.window?.let{w->
   w.setBackgroundDrawableResource(android.R.color.transparent);w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);val a=w.attributes;a.dimAmount=0.42f;w.attributes=a
   val sw=(rootFrame.width.takeIf{it>0}?:resources.displayMetrics.widthPixels).coerceAtLeast(1);val sh=(rootFrame.height.takeIf{it>0}?:resources.displayMetrics.heightPixels).coerceAtLeast(1)
   w.setLayout((sw*0.72f).toInt().coerceAtLeast(1),(sh*0.76f).toInt().coerceAtLeast(1))
  }
  ExternalInputBridge.attachModal(dlg);play.requestFocus()
  if(fallbackPoster.isNotBlank())pool.execute{Tmdb.loadImage(fallbackPoster)?.let{b->runOnUiThread{if(dlg.isShowing)iv.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.size))}}}
  pool.execute{val m=Tmdb.fetch(kind,title);runOnUiThread{if(!dlg.isShowing)return@runOnUiThread;if(m==null){meta.text="TMDB: nie znaleziono danych"}else{tt.text=m.title;meta.text=listOf(m.year,m.rating,m.runtime,m.genres).filter{it.isNotBlank()}.joinToString("  •  ");desc.text=m.overview;if(m.poster.isNotBlank())pool.execute{Tmdb.loadImage(m.poster)?.let{b->runOnUiThread{if(dlg.isShowing)iv.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.size))}}}}}}
 }
 private fun onItem(i:Int){when(screen){
  Screen.SOURCES->if(i<sources.size)loadSource(sources[i]);Screen.LIVE_GROUPS->if(i<groups.size){if(liveGroupFilterEdit)toggleLiveGroupSelection(i)else{liveGroupsPos=position();liveGroupSelected=i;liveChannelSelected=0;openLiveGroup(groups[i])}};
  Screen.VOD_CATS->if(i<vodCats.size){vodCatsPos=position();loadVodItems(vodCats[i])};
  Screen.VOD_ITEMS->if(i<vodItems.size){vodItemSelected=i;val x=vodItems[i];showDetails("movie",x.name,x.icon,"PLAY"){play(x.url,x.name,"",true,null,"movie:${x.id}","movie",x.icon,x.name)}};
  Screen.VOD_SEARCH->if(i<searchVodItems.size){val x=searchVodItems[i];showDetails("movie",x.name,x.icon,"PLAY"){play(x.url,x.name,"",true,null,"movie:${x.id}","movie",x.icon,x.name)}};
  Screen.VOD_RECENT,Screen.SERIES_RECENT->if(i<recentEntries.size)openRecentEntry(recentEntries[i]);
  Screen.SERIES_CATS->if(i<seriesCats.size){seriesCatsPos=position();loadSeriesItems(seriesCats[i])};
  Screen.SERIES_ITEMS->if(i<seriesItems.size){seriesItemSelected=i;val x=seriesItems[i];seriesItemsPos=position();showDetails("tv",x.name,x.cover,"SEZONY"){loadSeasons(x)}};
  Screen.SERIES_SEARCH->if(i<searchSeriesItems.size){val x=searchSeriesItems[i];selectedSeries=x;showDetails("tv",x.name,x.cover,"SEZONY"){loadSeasons(x)}};
  Screen.SEASONS->if(i<seasons.size){seasonsPos=position();showEpisodes(seasons[i])};
  Screen.EPISODES->if(i<episodes.size){val ep=episodes[i];val src=selectedSource?:return;val se=selectedSeries;play(Api.episodeUrl(src,ep),ep.name,"",true,null,"series:${se?.id.orEmpty()}","series",se?.cover.orEmpty(),se?.name?:ep.name)};
  Screen.FAVORITES->if(i<favorites.size){val c=favorites[i];play(c.url,c.name,epgText[c.url].orEmpty(),false,c)};else->{}}}
 private fun showChannelOptions(c:Channel){val isFav=favorites.any{it.url==c.url};AlertDialog.Builder(this).setTitle(c.name).setItems(arrayOf(if(isFav)"Usuń z ulubionych" else "Dodaj do ulubionych","Wyświetl EPG")){_,w->if(w==0)toggleFavorite(c)else showEpgSchedule(c)}.setNegativeButton("Anuluj",null).show()}
 private fun showEpgSchedule(c:Channel){val src=selectedSource?:return;val loading=AlertDialog.Builder(this).setTitle("EPG • ${c.name}").setMessage("Ładowanie pełnego EPG…").setNegativeButton("Anuluj",null).create();loading.show();pool.execute{val events=try{Api.epgSchedule(src,c)}catch(_:Exception){emptyList()};runOnUiThread{if(!loading.isShowing)return@runOnUiThread;loading.dismiss();if(events.isEmpty()){AlertDialog.Builder(this).setTitle("EPG • ${c.name}").setMessage("Brak pełnego EPG dla tego kanału.").setPositiveButton("Wróć",null).show();return@runOnUiThread};val rows=events.map{e->(if(e.start.isNotBlank()||e.end.isNotBlank())"${e.start} - ${e.end}   " else "")+e.title};val lv=ListView(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_list_item_1,rows);dividerHeight=1};val dlg=AlertDialog.Builder(this).setTitle("EPG • ${c.name}").setView(lv).setNegativeButton("Wróć",null).create();lv.setOnItemClickListener{_,_,pos,_->val e=events[pos];val wt=if(e.start.isNotBlank()||e.end.isNotBlank())"${e.start} - ${e.end}" else "";AlertDialog.Builder(this).setTitle(e.title).setMessage(listOf(wt,e.description.ifBlank{"Brak szczegółowego opisu."}).filter{it.isNotBlank()}.joinToString("\n\n")).setPositiveButton("Wróć",null).show()};dlg.show()}}}
 private fun onLongItem(i:Int):Boolean{when(screen){Screen.SOURCES->{if(i<sources.size)showSourceOptions(i);return true};Screen.FAVORITES->{if(i<favorites.size)showChannelOptions(favorites[i]);return true};else->return false}}
 private fun onPosterLongItem(i:Int):Boolean{
  if((screen!=Screen.VOD_RECENT&&screen!=Screen.SERIES_RECENT)||i !in recentEntries.indices)return false
  val entry=recentEntries[i];val wasSeries=screen==Screen.SERIES_RECENT
  TvMadDialogs.showConfirm(this,entry.title,"Usunąć z listy?",onPositive={
   VodHistoryStore.remove(this,entry.sourceKey,entry.key)
   handler.post{
    if(screen!=(if(wasSeries)Screen.SERIES_RECENT else Screen.VOD_RECENT))return@post
    recentEntries=recentEntries.filterNot{it.key==entry.key&&it.sourceKey==entry.sourceKey}
    posterAdapter?.updateData(recentEntries.map{if(it.subtitle.isBlank())it.title else "${it.title}\n${it.subtitle}"},recentEntries.map{it.poster})
    status.text=(if(wasSeries)"Ostatnio oglądane seriale" else "Ostatnio oglądane filmy")+"  •  ${recentEntries.size}  •  Przytrzymaj OK aby usunąć pozycję"
    if(recentEntries.isNotEmpty()){
     val next=i.coerceAtMost(recentEntries.lastIndex);posterGrid.setSelection(next);posterGrid.post{posterGrid.requestFocus();updatePosterSelection(next)}
    }else posterGrid.requestFocus()
   }
  });return true
 }

 private fun showOptionsMenu(){
  val rows=arrayOf("Wybierz język","Wybierz zewnętrzny player","Wybierz nośnik nagrywania","Wybierz tło")
  AlertDialog.Builder(this).setTitle("Opcje").setItems(rows){_,which->when(which){0->showLanguageOption();1->showExternalPlayerOption();2->showStorageOption();3->showBackgroundOption()}}.setNegativeButton("Wróć",null).show()
 }
 private fun showLanguageOption(){
  AlertDialog.Builder(this).setTitle("Wybierz język").setItems(arrayOf("✓ Polski")){d,_->Toast.makeText(this,"Polski jest obecnie aktywnym językiem.",Toast.LENGTH_SHORT).show();d.dismiss()}.setNegativeButton("Wróć",null).show()
 }
 private fun showBackgroundOption(){
  val labels=arrayOf("Ciemny granat (domyślne)","Prawie czarne / ciemnoszare","Bardzo ciemnozielone")
  val values=arrayOf("navy","charcoal","green")
  val current=AppOptionsStore.background(this).let{if(it in values)it else "navy"}
  val checked=values.indexOf(current).coerceAtLeast(0)
  AlertDialog.Builder(this).setTitle("Wybierz tło").setSingleChoiceItems(labels,checked){d,which->
   AppOptionsStore.setBackground(this,values[which]);rootFrame.setBackgroundResource(when(values[which]){"charcoal"->R.drawable.bg_charcoal;"green"->R.drawable.bg_green;else->R.drawable.bg_navy})
   Toast.makeText(this,"Wybrano: ${labels[which]}",Toast.LENGTH_SHORT).show();d.dismiss()
  }.setNegativeButton("Wróć",null).show()
 }
 private fun showExternalPlayerOption(){
  val probe=Intent(Intent.ACTION_VIEW).apply{setDataAndType(android.net.Uri.parse("http://127.0.0.1/video.mp4"),"video/*")}
  val resolved=packageManager.queryIntentActivities(probe,0).filter{it.activityInfo.packageName!=packageName}.distinctBy{it.activityInfo.packageName}.sortedBy{it.loadLabel(packageManager).toString().lowercase(Locale.ROOT)}
  val labels=mutableListOf("Wbudowany TvMad");val pkgs=mutableListOf("")
  resolved.forEach{labels+=it.loadLabel(packageManager).toString();pkgs+=it.activityInfo.packageName}
  val current=AppOptionsStore.externalPlayerPackage(this);val checked=pkgs.indexOf(current).let{if(it<0)0 else it}
  AlertDialog.Builder(this).setTitle("Wybierz zewnętrzny player").setSingleChoiceItems(labels.toTypedArray(),checked){d,which->AppOptionsStore.setExternalPlayerPackage(this,pkgs[which]);Toast.makeText(this,"Wybrano: ${labels[which]}",Toast.LENGTH_SHORT).show();d.dismiss()}.setNegativeButton("Anuluj",null).show()
 }
 private fun showStorageOption(){
  val dirs=getExternalFilesDirs(null).filterNotNull().distinctBy{it.absolutePath}
  if(dirs.isEmpty()){AlertDialog.Builder(this).setTitle("Wybierz nośnik nagrywania").setMessage("Nie znaleziono dostępnego nośnika.").setPositiveButton("OK",null).show();return}
  val labels=dirs.mapIndexed{i,f->if(i==0)"Pamięć urządzenia" else "Nośnik zewnętrzny ${i}"+"\n${f.absolutePath.substringBefore("/Android/")}"}
  val current=AppOptionsStore.storagePath(this);val checked=dirs.indexOfFirst{it.absolutePath==current}.let{if(it<0)0 else it}
  AlertDialog.Builder(this).setTitle("Wybierz nośnik nagrywania").setSingleChoiceItems(labels.toTypedArray(),checked){d,which->
   val base=dirs[which];val rec=java.io.File(base,"Recordings");val ts=java.io.File(base,"Timeshift");val ok=rec.mkdirs()||rec.isDirectory;val ok2=ts.mkdirs()||ts.isDirectory
   if(ok&&ok2){AppOptionsStore.setStoragePath(this,base.absolutePath);Toast.makeText(this,"Wybrano nośnik. Utworzono Recordings i Timeshift.",Toast.LENGTH_LONG).show();d.dismiss()}else Toast.makeText(this,"Nie udało się utworzyć folderów na tym nośniku.",Toast.LENGTH_LONG).show()
  }.setNegativeButton("Anuluj",null).show()
 }

 private fun miniSlotRect():android.graphics.Rect{
  val rootLoc=IntArray(2);val slotLoc=IntArray(2);rootFrame.getLocationOnScreen(rootLoc);miniVideoSlot.getLocationOnScreen(slotLoc)
  return android.graphics.Rect(slotLoc[0]-rootLoc[0],slotLoc[1]-rootLoc[1],slotLoc[0]-rootLoc[0]+miniVideoSlot.width,slotLoc[1]-rootLoc[1]+miniVideoSlot.height)
 }
 private fun ensureStableLiveSurface(){
  val w=rootFrame.width.coerceAtLeast(resources.displayMetrics.widthPixels).coerceAtLeast(1)
  val h=rootFrame.height.coerceAtLeast(resources.displayMetrics.heightPixels).coerceAtLeast(1)
  val lp=miniPlayerView.layoutParams as FrameLayout.LayoutParams
  if(lp.width!=w||lp.height!=h){lp.width=w;lp.height=h;miniPlayerView.layoutParams=lp}
  miniPlayerView.pivotX=0f;miniPlayerView.pivotY=0f
 }
 private fun positionLiveSurfaceToMini(animate:Boolean){
  miniPlayerView.resizeMode=androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
  if(miniVideoSlot.width<=0||miniVideoSlot.height<=0||rootFrame.width<=0||rootFrame.height<=0){miniVideoSlot.post{if(!liveFullscreen)positionLiveSurfaceToMini(animate)};return}
  val r=miniSlotRect();miniPlayerView.visibility=View.VISIBLE;ensureStableLiveSurface()
  val baseW=miniPlayerView.layoutParams.width.coerceAtLeast(1);val baseH=miniPlayerView.layoutParams.height.coerceAtLeast(1)
  val sx=r.width().toFloat()/baseW;val sy=r.height().toFloat()/baseH
  miniPlayerView.animate().cancel()
  if(!animate||!liveSurfaceReady){miniPlayerView.x=r.left.toFloat();miniPlayerView.y=r.top.toFloat();miniPlayerView.scaleX=sx;miniPlayerView.scaleY=sy;liveSurfaceReady=true;return}
  miniPlayerView.animate().x(r.left.toFloat()).y(r.top.toFloat()).scaleX(sx).scaleY(sy).setDuration(260).withEndAction{if(!liveFullscreen)channelList.requestFocus()}.start()
 }
 private fun enterLiveFullscreen(c:Channel,animate:Boolean){miniPlayerView.resizeMode=androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL;suppressLiveBufferUntil=SystemClock.uptimeMillis()+5000;liveRecoveryArmed=false;hideLiveBuffer();val armToken=liveChannelToken;handler.postDelayed({if(armToken==liveChannelToken&&liveFullscreen&&miniPlayer?.isPlaying==true)liveRecoveryArmed=true},1800);miniCurrentChannel=c;selectedSource?.let{LastLiveStore.save(this,it,c)};val idx=visibleChannels.indexOfFirst{it.url==c.url};if(idx>=0)liveChannelSelected=idx;updateFullscreenInfo(c);liveFullscreen=true;showLiveInfo(5000);miniPlayerView.bringToFront();liveFsInfo.bringToFront();liveBufferingBox.bringToFront();miniPlayerView.visibility=View.VISIBLE
  if(rootFrame.width<=0||rootFrame.height<=0){rootFrame.post{if(liveFullscreen)enterLiveFullscreen(c,animate)};return}
  ensureStableLiveSurface();miniPlayerView.animate().cancel()
  if(animate&&liveSurfaceReady){miniPlayerView.animate().x(0f).y(0f).scaleX(1f).scaleY(1f).setDuration(260).withEndAction{liveFsInfo.bringToFront();liveBufferingBox.bringToFront()}.start()}else{miniPlayerView.x=0f;miniPlayerView.y=0f;miniPlayerView.scaleX=1f;miniPlayerView.scaleY=1f;liveSurfaceReady=true}
  immersiveLive()
 }
 private fun exitLiveFullscreen(){
  if(!liveFullscreen)return
  liveFullscreen=false;handler.removeCallbacks(hideLiveInfo);hideLiveChannelDrawer(false);hideLiveTrackDrawer(false);hideLiveInfoImmediate();liveBufferingBox.visibility=View.GONE;positionLiveSurfaceToMini(true)
  val c=miniCurrentChannel
  if(screen==Screen.LIVE_CHANNELS&&c!=null){
   // Nie odbudowujemy listy po fullscreen. To jest dokładnie ta sama, zamrożona lista
   // konkretnej grupy, z której kanał został uruchomiony.
   val idx=visibleChannels.indexOfFirst{it.url==c.url}
   if(idx>=0)liveChannelSelected=idx
   loadVisibleEpg()
   channelList.post{
    if(idx>=0){piconAdapter?.setSelectedPosition(idx);positionPagedList(channelList,idx,8,visibleChannels.size,true)}
    updateMiniInfo(c);channelList.requestFocus();loadVisibleEpg()
   }
  }else c?.let{updateMiniInfo(it)}
 }


 private fun liveInfoNormalHeight():Int=((resources.displayMetrics.widthPixels*280f)/1536f).toInt().coerceAtLeast(1)
 private fun liveInfoHistoryHeight():Int=((resources.displayMetrics.widthPixels*150f)/1536f).toInt().coerceAtLeast(dp(92))
 private fun liveHistoryPrefKey():String=selectedSource?.let{sourceScanKey(it)}?:"default"
 private fun loadLiveHistory():List<Channel>{
  val raw=getSharedPreferences("tvmad_live_recent",Context.MODE_PRIVATE).getString(liveHistoryPrefKey(),"[]").orEmpty()
  return try{
   val a=JSONArray(raw);val out=ArrayList<Channel>()
   for(i in 0 until a.length()){
    val o=a.optJSONObject(i)?:continue;val url=o.optString("url");if(url.isBlank())continue
    out+=Channel(o.optString("name"),url,o.optString("group"),o.optString("logo"),o.optString("epgId"),o.optString("streamId"),o.optString("groupId"))
   }
   out.distinctBy{it.url}.take(20)
  }catch(_:Exception){emptyList()}
 }
 private fun rememberLiveHistory(c:Channel){
  if(c.url.isBlank())return
  val list=ArrayList<Channel>();list+=c
  loadLiveHistory().filterTo(list){it.url!=c.url}
  val a=JSONArray()
  for(x in list.take(20))a.put(JSONObject().put("name",x.name).put("url",x.url).put("group",x.group).put("logo",x.logo).put("epgId",x.epgId).put("streamId",x.streamId).put("groupId",x.groupId))
  getSharedPreferences("tvmad_live_recent",Context.MODE_PRIVATE).edit().putString(liveHistoryPrefKey(),a.toString()).apply()
 }
 private fun historyCardBackground(selected:Boolean):GradientDrawable=GradientDrawable().apply{
  shape=GradientDrawable.RECTANGLE
  setColor(if(selected)0x763A88C7 else 0x38203140)
  setStroke(dp(if(selected)2 else 1),if(selected)0xFF55D8FF.toInt() else 0x663C566A)
  cornerRadius=dp(5).toFloat()
 }
 private fun historyProgress(c:Channel):Int{
  val now=epgEvents[c.url].orEmpty().firstOrNull()?:return 0
  if(now.startEpoch<=0L||now.endEpoch<=now.startEpoch)return 0
  val t=System.currentTimeMillis();return (((t-now.startEpoch).coerceIn(0,now.endEpoch-now.startEpoch)*1000)/(now.endEpoch-now.startEpoch)).toInt()
 }
 private fun loadHistoryPicon(iv:ImageView,fallback:TextView,c:Channel){
  iv.tag=c.url;fallback.tag=c.url
  val pm=activePiconMode();val local=if(pm==0||pm==2)PiconRepository.find(this,c.name)else null
  if(local!=null){
   val key="local:${local.absolutePath}";PiconMemoryCache.get(key)?.let{iv.setImageBitmap(it);fallback.visibility=View.GONE;return}
   piconPool.execute{val bm=PiconRepository.decodeScaled(local,180,110)?:return@execute;PiconMemoryCache.put(key,bm);runOnUiThread{if(iv.tag==c.url){iv.setImageBitmap(bm);fallback.visibility=View.GONE}}};return
  }
  if((pm==1||pm==2)&&c.logo.isNotBlank()){
   val src=selectedSource;val key=remotePiconCacheKey(src,c.logo);PiconMemoryCache.get(key)?.let{iv.setImageBitmap(it);fallback.visibility=View.GONE;return}
   piconPool.execute{try{val b=src?.let{Api.loadRemotePicon(it,c.logo)}?:URL(c.logo).openStream().use{it.readBytes()};val bm=BitmapFactory.decodeByteArray(b,0,b.size)?:return@execute;PiconMemoryCache.put(key,bm);runOnUiThread{if(iv.tag==c.url){iv.setImageBitmap(bm);fallback.visibility=View.GONE}}}catch(_:Exception){}}
  }
 }
 private fun renderLiveHistory(){
  fsHistoryRow.removeAllViews();liveHistoryProgressBars.clear();liveHistoryEventLabels.clear()
  val hh=liveInfoHistoryHeight();val tileH=(hh*0.78f).toInt().coerceAtLeast(1);val tileW=(tileH*1.25f).toInt();val gap=(hh*0.055f).toInt().coerceAtLeast(4)
  liveHistoryChannels.forEachIndexed{i,c->
   val card=FrameLayout(this).apply{background=historyCardBackground(i==liveHistorySelected);isClickable=true;isFocusable=false;setOnClickListener{liveHistorySelected=i;selectLiveHistoryChannel()}}
   val iv=ImageView(this).apply{scaleType=ImageView.ScaleType.CENTER_INSIDE;setPadding(gap,gap,gap,gap+4)}
   val fallback=TextView(this).apply{text=c.name;textSize=11f;setTextColor(Color.WHITE);gravity=Gravity.CENTER;maxLines=2;ellipsize=android.text.TextUtils.TruncateAt.END;setPadding(6,4,6,8)}
   val progress=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=1000;this.progress=historyProgress(c);progressTintList=android.content.res.ColorStateList.valueOf(0xFF55D8FF.toInt());progressBackgroundTintList=android.content.res.ColorStateList.valueOf(0x5546525B);isIndeterminate=false}
   val event=TextView(this).apply{setTextColor(0xFFE7EDF3.toInt());textSize=10f;setSingleLine(true);ellipsize=android.text.TextUtils.TruncateAt.END;gravity=Gravity.CENTER_VERTICAL;setPadding(gap,0,gap,0)}
   card.addView(iv,FrameLayout.LayoutParams(-1,-1).apply{bottomMargin=(tileH*0.27f).toInt()})
   card.addView(fallback,FrameLayout.LayoutParams(-1,-1).apply{bottomMargin=(tileH*0.27f).toInt()})
   card.addView(progress,FrameLayout.LayoutParams(-1,(tileH*0.055f).toInt().coerceAtLeast(4),Gravity.BOTTOM).apply{leftMargin=gap;rightMargin=gap;bottomMargin=(tileH*0.19f).toInt()})
   card.addView(event,FrameLayout.LayoutParams(-1,(tileH*0.18f).toInt().coerceAtLeast(dp(18)),Gravity.BOTTOM))
   liveHistoryProgressBars+=progress;liveHistoryEventLabels+=event;loadHistoryPicon(iv,fallback,c)
   fsHistoryRow.addView(card,LinearLayout.LayoutParams(tileW,tileH).apply{rightMargin=gap})
  }
 }
 private fun historyEventText(c:Channel):String{
  val nowMs=System.currentTimeMillis();val ev=epgEvents[c.url].orEmpty().firstOrNull{it.startEpoch>0L&&it.endEpoch>it.startEpoch&&nowMs in it.startEpoch until it.endEpoch}?:epgEvents[c.url].orEmpty().firstOrNull()
  return if(ev==null)epgText[c.url].orEmpty() else ((if(ev.start.isNotBlank()||ev.end.isNotBlank())"${ev.start} - ${ev.end}  " else "")+ev.title).trim()
 }
 private fun updateLiveHistoryProgress(){
  if(!liveHistoryExpanded)return
  liveHistoryProgressBars.forEachIndexed{i,p->if(i in liveHistoryChannels.indices)p.progress=historyProgress(liveHistoryChannels[i])}
  liveHistoryEventLabels.forEachIndexed{i,t->if(i in liveHistoryChannels.indices)t.text=historyEventText(liveHistoryChannels[i])}
 }
 private fun setLiveHistorySelection(index:Int,smooth:Boolean=true){
  if(liveHistoryChannels.isEmpty())return
  liveHistorySelected=index.coerceIn(0,liveHistoryChannels.lastIndex)
  for(i in 0 until fsHistoryRow.childCount)fsHistoryRow.getChildAt(i).background=historyCardBackground(i==liveHistorySelected)
  liveHistoryEventLabels.forEachIndexed{i,t->
   val active=i==liveHistorySelected;t.ellipsize=if(active)android.text.TextUtils.TruncateAt.MARQUEE else android.text.TextUtils.TruncateAt.END;t.marqueeRepeatLimit=-1;t.isSelected=active
  }
  val child=fsHistoryRow.getChildAt(liveHistorySelected)?:return
  fsHistoryScroll.post{val target=(child.left-dp(18)).coerceAtLeast(0);if(smooth)fsHistoryScroll.smoothScrollTo(target,0)else fsHistoryScroll.scrollTo(target,0)}
  handler.removeCallbacks(hideLiveInfo)
 }
 private fun moveLiveHistorySelection(delta:Int){if(liveHistoryChannels.isEmpty())return;setLiveHistorySelection((liveHistorySelected+delta+liveHistoryChannels.size)%liveHistoryChannels.size)}
 private fun expandLiveHistory(){
  if(!liveFullscreen||liveHistoryExpanded)return
  liveHistoryChannels=loadLiveHistory().ifEmpty{listOfNotNull(miniCurrentChannel)}.distinctBy{it.url}.take(20)
  if(liveHistoryChannels.isEmpty())return
  liveHistorySelected=0;renderLiveHistory();loadEpgForChannels(liveHistoryChannels);updateLiveHistoryProgress()
  val normal=liveInfoNormalHeight();val history=liveInfoHistoryHeight();liveFsInfoMain.layoutParams=liveFsInfoMain.layoutParams.apply{height=normal};fsHistoryScroll.layoutParams=fsHistoryScroll.layoutParams.apply{height=history};fsHistoryScroll.visibility=View.VISIBLE
  liveHistoryExpanded=true;handler.removeCallbacks(hideLiveInfo);liveInfoHeightAnimator?.cancel()
  val from=liveFsInfo.height.coerceAtLeast(normal);val to=normal+history
  liveInfoHeightAnimator=ValueAnimator.ofInt(from,to).apply{duration=260L;addUpdateListener{a->liveFsInfo.layoutParams=liveFsInfo.layoutParams.apply{height=a.animatedValue as Int}};start()}
  setLiveHistorySelection(0,false)
 }
 private fun collapseLiveHistory(animated:Boolean){
  if(!liveHistoryExpanded){fsHistoryScroll.visibility=View.GONE;return}
  liveHistoryExpanded=false;handler.removeCallbacks(hideLiveInfo);liveInfoHeightAnimator?.cancel();val normal=liveInfoNormalHeight()
  if(!animated){fsHistoryScroll.visibility=View.GONE;liveFsInfo.layoutParams=liveFsInfo.layoutParams.apply{height=normal};liveFsInfoMain.layoutParams=liveFsInfoMain.layoutParams.apply{height=normal};return}
  val from=liveFsInfo.height.coerceAtLeast(normal)
  liveInfoHeightAnimator=ValueAnimator.ofInt(from,normal).apply{duration=230L;addUpdateListener{a->liveFsInfo.layoutParams=liveFsInfo.layoutParams.apply{height=a.animatedValue as Int}};addListener(object:android.animation.AnimatorListenerAdapter(){override fun onAnimationEnd(a:android.animation.Animator){fsHistoryScroll.visibility=View.GONE;handler.postDelayed(hideLiveInfo,5000)}});start()}
 }
 private fun selectLiveHistoryChannel(){
  val c=liveHistoryChannels.getOrNull(liveHistorySelected)?:return
  handler.removeCallbacks(hideLiveInfo);liveInfoHeightAnimator?.cancel();liveHistoryExpanded=false;fsHistoryScroll.visibility=View.GONE;liveFsInfo.visibility=View.GONE;liveFsInfo.translationY=0f
  val normal=liveInfoNormalHeight();liveFsInfo.layoutParams=liveFsInfo.layoutParams.apply{height=normal};liveFsInfoMain.layoutParams=liveFsInfoMain.layoutParams.apply{height=normal}
  bindLiveChannel(c);loadEpgForChannels(listOf(c));updateFullscreenInfo(c)
 }
 private fun hideLiveInfoImmediate(){
  handler.removeCallbacks(hideLiveInfo);liveInfoHeightAnimator?.cancel();liveHistoryExpanded=false;fsHistoryScroll.visibility=View.GONE;liveFsInfo.animate().cancel();liveFsInfo.visibility=View.GONE;liveFsInfo.translationY=0f
  val normal=liveInfoNormalHeight();liveFsInfo.layoutParams=liveFsInfo.layoutParams.apply{height=normal};liveFsInfoMain.layoutParams=liveFsInfoMain.layoutParams.apply{height=normal}
 }
 private fun showLiveInfo(delay:Long=5000){
  if(!liveFullscreen)return
  updateClocks();updateFullscreenInfo(miniCurrentChannel);handler.removeCallbacks(hideLiveInfo)
  val normal=liveInfoNormalHeight();val history=liveInfoHistoryHeight();val targetH=if(liveHistoryExpanded)normal+history else normal
  liveFsInfoMain.layoutParams=liveFsInfoMain.layoutParams.apply{height=normal}
  if(liveHistoryExpanded){fsHistoryScroll.layoutParams=fsHistoryScroll.layoutParams.apply{height=history};fsHistoryScroll.visibility=View.VISIBLE}else fsHistoryScroll.visibility=View.GONE
  liveFsInfo.layoutParams=liveFsInfo.layoutParams.apply{height=targetH}
  val wasHidden=liveFsInfo.visibility!=View.VISIBLE
  liveFsInfo.animate().cancel()
  if(wasHidden)liveFsInfo.translationY=targetH.toFloat()
  liveFsInfo.visibility=View.VISIBLE;liveFsInfo.bringToFront()
  if(wasHidden)liveFsInfo.post{
   if(!liveFullscreen)return@post
   liveFsInfo.animate().translationY(0f).setDuration(280L).start()
  }
  handler.postDelayed(hideLiveInfo,delay)
 }
 private fun hideLiveInfoAnimated(){
  handler.removeCallbacks(hideLiveInfo);liveInfoHeightAnimator?.cancel();liveFsInfo.animate().cancel()
  if(liveFsInfo.visibility!=View.VISIBLE){liveFsInfo.translationY=0f;collapseLiveHistory(false);return}
  liveFsInfo.animate().translationY(liveFsInfo.height.toFloat()).setDuration(260L).withEndAction{
   liveFsInfo.visibility=View.GONE;liveFsInfo.translationY=0f;collapseLiveHistory(false)
  }.start()
 }
 private fun updateFullscreenInfo(c:Channel?){c?:return;fsNumber.text=(visibleChannels.indexOfFirst{it.url==c.url}.takeIf{it>=0}?.plus(1)?:0).takeIf{it>0}?.toString().orEmpty();fsChannel.text=c.name;val ev=epgEvents[c.url].orEmpty();val now=ev.getOrNull(0);val next=ev.getOrNull(1);fsNow.text=if(now==null)epgText[c.url].orEmpty() else (if(now.start.isNotBlank()||now.end.isNotBlank())"${now.start} - ${now.end}  " else "")+now.title;fsNext.text=if(next==null)"" else "Następnie: "+(if(next.start.isNotBlank()||next.end.isNotBlank())"${next.start} - ${next.end}  " else "")+next.title;if(now!=null&&now.startEpoch>0&&now.endEpoch>now.startEpoch){val n=System.currentTimeMillis();fsProgress.progress=(((n-now.startEpoch).coerceIn(0,now.endEpoch-now.startEpoch)*1000)/(now.endEpoch-now.startEpoch)).toInt()}else fsProgress.progress=0;loadFsPicon(c)}
 private fun loadFsPicon(c:Channel){
  val pm=activePiconMode();val local=if(pm==0||pm==2)PiconRepository.find(this,c.name)else null
  if(local!=null){
   val cacheKey="local:${local.absolutePath}";PiconMemoryCache.get(cacheKey)?.let{fsPicon.setImageBitmap(it);return}
   fsPicon.setImageDrawable(null);val channelKey=c.url;piconPool.execute{val bm=PiconRepository.decodeScaled(local,220,140)?:return@execute;PiconMemoryCache.put(cacheKey,bm);runOnUiThread{if(miniCurrentChannel?.url==channelKey)fsPicon.setImageBitmap(bm)}};return
  }
  if((pm==1||pm==2)&&c.logo.isNotBlank()){
   val src=selectedSource;val cacheKey=remotePiconCacheKey(src,c.logo)
   PiconMemoryCache.get(cacheKey)?.let{fsPicon.setImageBitmap(it);return}
   fsPicon.setImageDrawable(null);val channelKey=c.url
   piconPool.execute{try{val b=src?.let{Api.loadRemotePicon(it,c.logo)}?:URL(c.logo).openStream().use{it.readBytes()};val bm=BitmapFactory.decodeByteArray(b,0,b.size)?:return@execute;PiconMemoryCache.put(cacheKey,bm);runOnUiThread{if(miniCurrentChannel?.url==channelKey)fsPicon.setImageBitmap(bm)}}catch(_:Exception){}}
  }else fsPicon.setImageDrawable(null)
 }
 private fun switchLiveInline(delta:Int){
  if(visibleChannels.isEmpty())return
  liveChannelSelected=(liveChannelSelected+delta+visibleChannels.size)%visibleChannels.size
  val c=visibleChannels[liveChannelSelected]
  bindLiveChannel(c)
  loadEpgForChannels(listOf(c));updateFullscreenInfo(c)
  liveDrawerSelected=liveChannelSelected;liveDrawerAdapter?.notifyDataSetChanged()
  showLiveInfo(5000)
 }
 private val liveListener=object:Player.Listener{
  override fun onIsPlayingChanged(v:Boolean){
   if(!v)return
   // Spóźniony PLAYING poprzedniego kanału nie może oznaczać, że NOWY kanał już ruszył,
   // ani chować buforowania, ani uzbrajać recovery.
   if(!markZapStarted("PLAYING"))return
   miniPlayer?.let{S9VideoOutputTuner.applyFromPlayer(it,miniPlayerView,"live-playing")}
   liveHasPlayed=true;liveRetryCount=0;hideLiveBuffer()
   val token=liveChannelToken
   handler.postDelayed({if(token==liveChannelToken&&miniPlayer?.isPlaying==true)liveRecoveryArmed=true},1500)
  }
  override fun onPlaybackStateChanged(state:Int){
   val token=liveChannelToken
   if(state==Player.STATE_BUFFERING){
    if(liveStartedToken!=token){
     Log.i(LIVE_TAG,"zap token=$token BUFFERING po ${SystemClock.uptimeMillis()-liveZapStartedAt}ms")
     // BUFFERING przy starcie to normalny zap — nie recovery.
    }
    if(liveHasPlayed&&liveRecoveryArmed&&SystemClock.uptimeMillis()>=suppressLiveBufferUntil){
     showLiveBuffer()
     if(!noteLiveRebufferAndRestartIfNeeded())scheduleLiveRetry(7000)
    }
   }
   else if(state==Player.STATE_READY){miniPlayer?.let{S9VideoOutputTuner.applyFromPlayer(it,miniPlayerView,"live-ready")};if(markZapStarted("READY")){liveHasPlayed=true;hideLiveBuffer()}}
   else if(state==Player.STATE_IDLE||state==Player.STATE_ENDED){
    // IDLE przy zmianie MediaItem jest przejściowe. Recovery tylko gdy po chwili
    // player nadal stoi — nie przy każdym zapie.
    Log.d(LIVE_TAG,"playbackState=${LivePlayerSession.stateName(state)} token=$token started=${liveStartedToken==token}")
    if(liveStartedToken!=token&&miniPlayer!=null)handler.post{
     if(token!=liveChannelToken||liveStartedToken==token)return@post
     if(SystemClock.uptimeMillis()<liveZapIgnoreIdleUntil)return@post
     if(LivePlayerSession.isStalled())escalateZapRecovery(token,"stan ${LivePlayerSession.stateName(state)} w trakcie rozruchu")
    }
   }
  }
  override fun onTracksChanged(tracks:Tracks){updateLiveTrackButtons(tracks);miniPlayer?.let{S9VideoOutputTuner.applyFromPlayer(it,miniPlayerView,"live-tracks")}}
  override fun onPlayerError(error:PlaybackException){
   val token=liveChannelToken
   Log.w(LIVE_TAG,"playerError=${error.errorCodeName} token=$token started=${liveStartedToken==token} armed=$liveRecoveryArmed hasPlayed=$liveHasPlayed")
   if(liveListenerPlayer==null)return
   if(liveStartedToken!=token){
    // Spóźniony błąd PORZUCONEGO strumienia przychodzi już z tokenem nowego kanału.
    // Recovery tylko gdy nowy player naprawdę stoi — inaczej każdy zap dostawał stop().
    handler.post{
     if(token!=liveChannelToken||liveStartedToken==token||liveListenerPlayer==null)return@post
     if(SystemClock.uptimeMillis()<liveZapIgnoreIdleUntil)return@post
     if(LivePlayerSession.itemSawLoad()&&!LivePlayerSession.isStalled())return@post
     if(LivePlayerSession.isStalled())escalateZapRecovery(token,"błąd ${error.errorCodeName}")
    }
    return
   }
   if(liveHasPlayed&&liveRecoveryArmed&&SystemClock.uptimeMillis()>=suppressLiveBufferUntil){showLiveBuffer();scheduleLiveRetry(1200)}
  }
 }
 private fun installLiveListener(p:ExoPlayer){
  if(liveListenerPlayer===p)return
  liveListenerPlayer?.let{old->try{old.removeListener(liveListener)}catch(_:Exception){}}
  p.addListener(liveListener);liveListenerPlayer=p
 }
 private fun updateLiveTrackButtons(tracks:Tracks){var ac=0;var tc=0;for(g in tracks.groups){if(g.type==C.TRACK_TYPE_AUDIO)for(i in 0 until g.length)if(g.isTrackSupported(i))ac++;if(g.type==C.TRACK_TYPE_TEXT)for(i in 0 until g.length)if(g.isTrackSupported(i))tc++};fsAudio.visibility=if(ac>1)View.VISIBLE else View.GONE;fsSubtitles.visibility=if(tc>0)View.VISIBLE else View.GONE}
 private data class LiveTrackChoice(val label:String,val group:Tracks.Group?,val index:Int)
 private fun showLiveTrackDialog(type:Int,title:String){val p=miniPlayer?:return;val choices=ArrayList<LiveTrackChoice>();if(type==C.TRACK_TYPE_TEXT)choices+=LiveTrackChoice("Wyłącz napisy",null,-1);for(g in p.currentTracks.groups){if(g.type!=type)continue;for(i in 0 until g.length){if(!g.isTrackSupported(i))continue;val f=g.getTrackFormat(i);val lang=f.language?.uppercase().orEmpty();val label=f.label?.takeIf{it.isNotBlank()}?:if(type==C.TRACK_TYPE_AUDIO)"Audio ${choices.size+1}" else "Napisy ${choices.size+1}";choices+=LiveTrackChoice(if(lang.isBlank())label else "$label  [$lang]",g,i)}};if(choices.isEmpty()||(type==C.TRACK_TYPE_TEXT&&choices.size==1))return;AlertDialog.Builder(this).setTitle(title).setItems(choices.map{it.label}.toTypedArray()){_,w->val c=choices[w];val b=p.trackSelectionParameters.buildUpon().clearOverridesOfType(type);if(c.group==null)b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT,true)else{b.setTrackTypeDisabled(type,false);b.setOverrideForType(TrackSelectionOverride(c.group.mediaTrackGroup,listOf(c.index)))};p.trackSelectionParameters=b.build();showLiveInfo(5000)}.setNegativeButton("Anuluj",null).show()}
 private fun showLiveBuffer(){
  if(!liveHasPlayed)return
  showZapSpinner()
 }
 private fun hideLiveBuffer(){liveBufferingBox.visibility=View.GONE;handler.removeCallbacks(liveBufferTick);handler.removeCallbacks(liveRetry);liveRetryScheduled=false}
 private fun scheduleLiveRetry(delay:Long=7000){if(!liveHasPlayed||liveRetryScheduled||liveRetryCount>=2)return;liveRetryScheduled=true;liveRetryToken=liveChannelToken;handler.postDelayed(liveRetry,delay)}
 private fun noteLiveRebufferAndRestartIfNeeded():Boolean{
  val now=SystemClock.uptimeMillis()
  while(liveRebufferTimes.isNotEmpty()&&now-liveRebufferTimes.peekFirst()>15000L)liveRebufferTimes.removeFirst()
  liveRebufferTimes.addLast(now)
  if(liveRebufferTimes.size<3||now<liveRestartCooldownUntil)return false
  restartLiveStream("3 buforowania w 15 s")
  return true
 }
 private fun restartLiveStream(reason:String){
  if(liveRetryCount>=2)return
  val token=liveChannelToken;liveRetryCount++;liveRestartCooldownUntil=SystemClock.uptimeMillis()+10000L
  liveRebufferTimes.clear();suppressLiveBufferUntil=SystemClock.uptimeMillis()+5000L;liveRecoveryArmed=false
  handler.removeCallbacks(liveRetry);liveRetryScheduled=false
  handler.removeCallbacks(liveBufferTick)
  Log.w(LIVE_TAG,"restartLiveStream reason=$reason token=$token attempt=$liveRetryCount")
  LivePlayerSession.restartCurrent()
  handler.postDelayed({if(token==liveChannelToken&&miniPlayer?.isPlaying==true)liveRecoveryArmed=true},1800L)
 }

 // ==========================================================================================
 // Watchdog rozruchu kanału LIVE.
 //
 // Jak TiviMate: milczy przy normalnym starcie (BUFFERING / I/O / wolny READY).
 // Recovery tylko gdy player jest martwy, albo po długim czasie nie ma w ogóle I/O.
 // ==========================================================================================
 private fun armZapWatchdog(token:Int){
  cancelZapWatchdog()
  liveZapStage=0;liveZapGrace=0;liveZapLastBuffered=0L;liveZapStartedAt=SystemClock.uptimeMillis()
  liveZapIgnoreIdleUntil=SystemClock.uptimeMillis()+800L
  scheduleZapWatchdog(token,ZAP_WATCHDOG_FIRST_MS)
 }
 private fun scheduleZapWatchdog(token:Int,delay:Long){
  liveZapWatchdog?.let{handler.removeCallbacks(it)}
  val wd=Runnable{checkZapProgress(token)}
  liveZapWatchdog=wd;handler.postDelayed(wd,delay)
 }
 private fun cancelZapWatchdog(){
  liveZapWatchdog?.let{handler.removeCallbacks(it)};liveZapWatchdog=null
 }
 /** Kanał ruszył. Watchdog kończy pracę i nie wraca aż do kolejnego zappingu. */
 private fun markZapStarted(via:String):Boolean{
  val token=liveChannelToken
  if(liveStartedToken==token)return true
  val p=miniPlayer?:return false
  if(!LivePlayerSession.itemHasStarted())return false
  if(p.playbackState!=Player.STATE_READY&&!p.isPlaying)return false
  liveStartedToken=token
  miniCurrentChannel?.let{rememberLiveHistory(it)}
  Log.i(LIVE_TAG,"zap token=$token $via po ${SystemClock.uptimeMillis()-liveZapStartedAt}ms stage=$liveZapStage")
  cancelZapWatchdog();liveZapStage=0;liveZapGrace=0
  return true
 }
 private fun checkZapProgress(token:Int){
  liveZapWatchdog=null
  if(token!=liveChannelToken||liveStartedToken==token)return
  val p=miniPlayer?:return
  if(markZapStarted("READY(watchdog)")){hideLiveBuffer();return}
  val dead=p.playbackState==Player.STATE_IDLE||p.playbackState==Player.STATE_ENDED||p.playerError!=null
  val realLoad=p.totalBufferedDuration>0L||LivePlayerSession.itemSawLoad()
  val elapsed=SystemClock.uptimeMillis()-liveZapStartedAt
  if(dead){
   escalateZapRecovery(token,"player w martwym stanie")
   return
  }
  // Sam start I/O nie wystarcza: przy sporadycznym klinie stare wideo zostaje na ekranie,
  // Media3 zgłasza load/BUFFERING, ale nowy materiał nigdy nie dochodzi do READY.
  // Dajemy zdrowemu, wolniejszemu startowi krótką furtkę. Jeśli po niej nadal nie ma READY,
  // nie czekamy kilkunastu sekund — restartujemy bieżący materiał na tym samym playerze/Surface.
  if(realLoad){
   val buffered=p.totalBufferedDuration
   if(liveZapGrace==0){
    liveZapGrace=1
    liveZapLastBuffered=buffered
    Log.i(LIVE_TAG,"watchdog token=$token I/O jest, brak READY po ${elapsed}ms buffered=${buffered}ms — krótka furtka")
    scheduleZapWatchdog(token,ZAP_WATCHDOG_PROGRESS_MS)
   }else{
    val grew=buffered>liveZapLastBuffered+250L
    if(grew&&liveZapGrace==1){
     liveZapGrace=2
     liveZapLastBuffered=buffered
     Log.i(LIVE_TAG,"watchdog token=$token bufor rośnie, daję ostatnie ${ZAP_WATCHDOG_PROGRESS_MS}ms")
     scheduleZapWatchdog(token,ZAP_WATCHDOG_PROGRESS_MS)
    }else{
     Log.w(LIVE_TAG,"watchdog token=$token I/O bez READY po ${elapsed}ms — szybki restart bieżącego kanału")
     // retryPrepare() w zamaskowanym BUFFERING jest no-opem; idziemy od razu do kontrolowanego
     // stop -> setMediaItem -> prepare. Spinner pokaże się tylko dla tego faktycznego klina.
     liveZapStage=1
     escalateZapRecovery(token,"I/O bez READY po ${elapsed}ms")
    }
   }
   return
  }
  if(elapsed<ZAP_WATCHDOG_STALL_MS){
   scheduleZapWatchdog(token,ZAP_WATCHDOG_STALL_MS-elapsed)
   return
  }
  escalateZapRecovery(token,"brak I/O po ${elapsed}ms")
 }
 /**
  * Drabinka odzyskiwania bieżącego kanału. Każdy poziom jest droższy od poprzedniego i każdy
  * zostaje na tym samym SurfaceView — nigdy nie wracamy do ekranu głównego i nigdy nie
  * restartujemy poprzedniego kanału.
  */
 private fun escalateZapRecovery(token:Int,reason:String){
  if(token!=liveChannelToken||liveStartedToken==token)return
  if(miniPlayer==null||liveListenerPlayer==null)return
  if(liveZapStage>ZAP_MAX_STAGE)return // drabinka już wyczerpana — bez powtarzania logów
  if(liveZapStage>=ZAP_MAX_STAGE){
   Log.e(LIVE_TAG,"watchdog token=$token ODZYSKIWANIE WYCZERPANE reason=$reason state=${LivePlayerSession.stateLabel()}")
   liveZapStage=ZAP_MAX_STAGE+1
   cancelZapWatchdog();showZapSpinner();return
  }
  val next=liveZapStage+1
  liveZapStage=next;liveZapGrace=0;liveZapLastBuffered=0L
  liveZapIgnoreIdleUntil=SystemClock.uptimeMillis()+800L
  Log.w(LIVE_TAG,"watchdog token=$token FIRED stage=$next reason=$reason state=${LivePlayerSession.stateLabel()}")
  // Kółko dopiero od restartu. Samo prepare() jest niewidoczne.
  if(next>=2)showZapSpinner()
  val ok=when(next){
   1->LivePlayerSession.retryPrepare()
   2->LivePlayerSession.restartCurrent()
   else->adoptRebuiltLivePlayer()
  }
  if(!ok){
   Log.e(LIVE_TAG,"watchdog token=$token odzyskiwanie stage=$next nieudane state=${LivePlayerSession.stateLabel()}")
   liveZapStage=ZAP_MAX_STAGE+1
   cancelZapWatchdog();showZapSpinner();return
  }
  scheduleZapWatchdog(token,ZAP_WATCHDOG_STALL_MS)
 }
 /** Poziom 3: sesja buduje nowy ExoPlayer, my przejmujemy go razem z listenerem i MiniTV. */
 private fun adoptRebuiltLivePlayer():Boolean{
  liveListenerPlayer?.let{old->try{old.removeListener(liveListener)}catch(_:Exception){}}
  liveListenerPlayer=null
  liveZapIgnoreIdleUntil=SystemClock.uptimeMillis()+800L
  val p=LivePlayerSession.rebuild(this)?:return false
  miniPlayer=p
  if(miniPlayerView.player!==p)miniPlayerView.player=p
  p.volume=1f
  installLiveListener(p)
  Log.w(LIVE_TAG,"full player recovery OK token=$liveChannelToken state=${LivePlayerSession.stateLabel()}")
  return true
 }
 /** Tylko kółko — bez tekstu „Buforowanie” / „Odbudowa”. */
 private fun showZapSpinner(){
  if(!liveFullscreen)return
  liveBufferingText.visibility=View.GONE
  liveBufferingBox.visibility=View.VISIBLE;liveBufferingBox.bringToFront()
  handler.removeCallbacks(liveBufferTick)
 }
 private fun immersiveLive(){window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);if(Build.VERSION.SDK_INT>=30){window.setDecorFitsSystemWindows(false);window.insetsController?.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())}else{@Suppress("DEPRECATION")window.decorView.systemUiVisibility=View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY}}
 private fun setupVodSidePanel(){
  val title=TextView(this).apply{id=6201;text="WYSZUKIWANIE FILMÓW";setTextColor(0xFFFFFFFF.toInt());textSize=19f;setPadding(dp(18),dp(18),dp(12),dp(10))}
  val searchRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(5),dp(14),dp(5))}
  val lens=ImageView(this).apply{setImageResource(R.drawable.ic_search);scaleType=ImageView.ScaleType.CENTER_INSIDE;setPadding(dp(8),dp(8),dp(8),dp(8))}
  vodSearchBox=EditText(this).apply{
   hint="Wpisz tytuł filmu…";setHintTextColor(0xFF8FA6B8.toInt());setTextColor(0xFFFFFFFF.toInt());textSize=17f;setSingleLine(true)
   inputType=InputType.TYPE_CLASS_TEXT;imeOptions=android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH;setBackgroundResource(R.drawable.button_dark);setPadding(dp(14),0,dp(12),0)
  }
  searchRow.addView(lens,LinearLayout.LayoutParams(dp(44),dp(52)));searchRow.addView(vodSearchBox,LinearLayout.LayoutParams(0,dp(52),1f))
  vodRecentButton=Button(this).apply{text="Ostatnio oglądane";setAllCaps(false);textSize=16f;setTextColor(0xFFFFFFFF.toInt());setBackgroundResource(R.drawable.button_dark);setPadding(dp(14),0,dp(14),0);setOnClickListener{showRecentVod(vodSidePanelSeries)}}
  val hint=TextView(this).apply{text="Wpisuj kolejne litery — wyniki zawężają się automatycznie.";setTextColor(0xFFAAB8C4.toInt());textSize=12f;setPadding(dp(18),dp(10),dp(18),dp(8))}
  vodSidePanel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE;elevation=dp(15).toFloat();setBackgroundResource(R.drawable.panel_glass);addView(title,LinearLayout.LayoutParams(-1,dp(58)));addView(searchRow,LinearLayout.LayoutParams(-1,dp(66)));addView(vodRecentButton,LinearLayout.LayoutParams(-1,dp(52)).apply{leftMargin=dp(18);rightMargin=dp(18);topMargin=dp(12)});addView(hint,LinearLayout.LayoutParams(-1,-2))}
  rootFrame.addView(vodSidePanel,FrameLayout.LayoutParams((resources.displayMetrics.widthPixels*0.40f).toInt(),-1,Gravity.START).apply{topMargin=dp(34);bottomMargin=dp(34);leftMargin=dp(20)})
  vodSearchBox.addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int){};override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int){if(vodSidePanelOpen&&!vodPanelTextReset)filterAndRenderVodSearch(s?.toString().orEmpty(),vodSidePanelSeries)};override fun afterTextChanged(s:Editable?){}})
  vodSearchBox.setOnEditorActionListener{_,action,event->
   if(action==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH||(event?.keyCode==KeyEvent.KEYCODE_ENTER&&event.action==KeyEvent.ACTION_DOWN)){if(vodSearchBox.text.toString().trim().isNotEmpty()){hideVodSidePanel(false);posterGrid.post{posterGrid.requestFocus()}};true}else false
  }
 }
 private fun showVodSidePanel(series:Boolean){
  if(vodSidePanelOpen)return;vodSidePanelSeries=series;vodSidePanelOpen=true
  (vodSidePanel.findViewById<TextView>(6201)).text=if(series)"WYSZUKIWANIE SERIALI" else "WYSZUKIWANIE FILMÓW"
  vodSearchBox.hint=if(series)"Wpisz tytuł serialu…" else "Wpisz tytuł filmu…"
  vodPanelTextReset=true;vodSearchBox.setText("");vodPanelTextReset=false;vodRecentButton.text="Ostatnio oglądane"
  vodSidePanel.setBackgroundResource(if(series)R.drawable.panel_series_glass else R.drawable.panel_vod_glass)
  // Panel ma pojawić się od razu. Ładowanie dużego katalogu nigdy nie blokuje wątku UI.
  vodSidePanel.animate().cancel();vodSidePanel.translationX=0f;vodSidePanel.visibility=View.VISIBLE;vodSidePanel.bringToFront()
  prepareSearchCatalog(series);vodSearchBox.requestFocus();vodSearchBox.postDelayed({if(vodSidePanelOpen)(getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)?.showSoftInput(vodSearchBox,InputMethodManager.SHOW_IMPLICIT)},100)
 }
 private fun hideVodSidePanel(returnToCatsIfEmpty:Boolean){
  if(!vodSidePanelOpen)return;vodSidePanelOpen=false
  (getSystemService(INPUT_METHOD_SERVICE) as? InputMethodManager)?.hideSoftInputFromWindow(vodSearchBox.windowToken,0)
  val empty=vodSearchBox.text.toString().trim().isEmpty()
  // Bez animacji i bez ponownego budowania listy kategorii przy szybkim LEFT/RIGHT.
  vodSidePanel.animate().cancel();vodSidePanel.visibility=View.GONE;vodSidePanel.translationX=0f
  if(returnToCatsIfEmpty&&empty){list.requestFocus()}
 }
 private fun prepareSearchCatalog(series:Boolean){
  val src=selectedSource?:return
  val key=VodHistoryStore.sourceKey(src)
  if(series){
   if(seriesCatalogSourceKey==key&&allSeriesItems.isNotEmpty())return
   if(seriesCatalogLoadingKey==key)return
   seriesCatalogLoadingKey=key
  }else{
   if(vodCatalogSourceKey==key&&allVodItems.isNotEmpty())return
   if(vodCatalogLoadingKey==key)return
   vodCatalogLoadingKey=key
  }
  val gen=++searchGeneration
  // Odczyt dużego JSON cache odbywa się poza UI; panel nie czeka na parsowanie katalogu.
  searchPool.execute{
   if(series){
    val cached=CatalogCacheStore.loadSeriesAll(this,src)
    runOnUiThread{
     if(seriesCatalogLoadingKey==key)seriesCatalogLoadingKey=""
     if(selectedSource?.let{VodHistoryStore.sourceKey(it)}!=key||gen!=searchGeneration)return@runOnUiThread
     seriesCatalogSourceKey=key;allSeriesItems=cached
     val q=vodSearchBox.text.toString();if(vodSidePanelOpen&&vodSidePanelSeries&&q.isNotBlank())filterAndRenderVodSearch(q,true)
     if(cached.isEmpty())loadSearchCatalogFromServer(src,key,true,gen)
    }
   }else{
    val cached=CatalogCacheStore.loadVodAll(this,src)
    runOnUiThread{
     if(vodCatalogLoadingKey==key)vodCatalogLoadingKey=""
     if(selectedSource?.let{VodHistoryStore.sourceKey(it)}!=key||gen!=searchGeneration)return@runOnUiThread
     vodCatalogSourceKey=key;allVodItems=cached
     val q=vodSearchBox.text.toString();if(vodSidePanelOpen&&!vodSidePanelSeries&&q.isNotBlank())filterAndRenderVodSearch(q,false)
     if(cached.isEmpty())loadSearchCatalogFromServer(src,key,false,gen)
    }
   }
  }
 }
 private fun loadSearchCatalogFromServer(src:Source,key:String,series:Boolean,gen:Int){
  if(series){if(seriesCatalogLoadingKey==key)return;seriesCatalogLoadingKey=key}else{if(vodCatalogLoadingKey==key)return;vodCatalogLoadingKey=key}
  catalogPool.execute{
   try{
    if(series){
     val fresh=Api.seriesAllItems(src);CatalogCacheStore.saveSeriesAll(this,src,fresh)
     runOnUiThread{if(seriesCatalogLoadingKey==key)seriesCatalogLoadingKey="";if(selectedSource?.let{VodHistoryStore.sourceKey(it)}==key&&gen==searchGeneration){seriesCatalogSourceKey=key;allSeriesItems=fresh;val q=vodSearchBox.text.toString();if(vodSidePanelOpen&&vodSidePanelSeries&&q.isNotBlank())filterAndRenderVodSearch(q,true)}}
    }else{
     val fresh=Api.vodAllItems(src);CatalogCacheStore.saveVodAll(this,src,fresh)
     runOnUiThread{if(vodCatalogLoadingKey==key)vodCatalogLoadingKey="";if(selectedSource?.let{VodHistoryStore.sourceKey(it)}==key&&gen==searchGeneration){vodCatalogSourceKey=key;allVodItems=fresh;val q=vodSearchBox.text.toString();if(vodSidePanelOpen&&!vodSidePanelSeries&&q.isNotBlank())filterAndRenderVodSearch(q,false)}}
    }
   }catch(_:Exception){runOnUiThread{if(series&&seriesCatalogLoadingKey==key)seriesCatalogLoadingKey="";if(!series&&vodCatalogLoadingKey==key)vodCatalogLoadingKey=""}}
  }
 }
 private fun normalizedSearch(s:String):String=Normalizer.normalize(s.lowercase(Locale.getDefault()),Normalizer.Form.NFD).replace(searchMarksRegex,"").replace(searchNonWordRegex," ").trim()
 private fun exactWholeSearchWord(title:String,q:String):Boolean{
  if(q.length<3||q.indexOf(' ')>=0)return false
  return (" $title ").contains(" $q ")
 }
 private fun filterAndRenderVodSearch(query:String,series:Boolean){
  val raw=query.trim();val myGen=++searchRenderGeneration
  searchDebounce?.let{handler.removeCallbacks(it)};searchDebounce=null
  if(raw.isBlank()){
   // Samo otwarcie panelu nie przebudowuje ekranu kategorii.
   if(series)searchSeriesItems=emptyList() else searchVodItems=emptyList()
   return
  }
  if(series&&allSeriesItems.isEmpty()){screen=Screen.SERIES_SEARCH;applyTheme(4);setMode();status.text="Wyszukiwanie seriali  •  ładowanie katalogu…";posterGrid.adapter=null;return}
  if(!series&&allVodItems.isEmpty()){screen=Screen.VOD_SEARCH;applyTheme(3);setMode();status.text="Wyszukiwanie filmów  •  ładowanie katalogu…";posterGrid.adapter=null;return}
  // Wyszukiwanie jest lekkie dla Android TV: krótki debounce, praca poza UI,
  // dopasowanie głównie od początku tytułu i małe porcje wyników.
  status.text=if(series)"Wyszukiwanie seriali…" else "Wyszukiwanie filmów…"
  val task=Runnable{
   if(myGen!=searchRenderGeneration)return@Runnable
   val q=normalizedSearch(raw)
   searchPool.execute{
    if(myGen!=searchRenderGeneration)return@execute
    if(series){
     val prefix=ArrayList<SeriesItem>();val whole=ArrayList<SeriesItem>();var lastPublish=0L
     for(x in allSeriesItems){
      if(myGen!=searchRenderGeneration)return@execute
      val n=normalizedSearch(x.name)
      if(n.startsWith(q)){
       if(prefix.size<160)prefix+=x
       val now=SystemClock.uptimeMillis()
       if(prefix.size==1||(prefix.size%8==0&&now-lastPublish>=90L)){
        lastPublish=now;val snapshot=prefix.toList()
        runOnUiThread{if(myGen==searchRenderGeneration)renderSeriesSearchSnapshot(snapshot,myGen,false)}
       }
      }else if(whole.size<80&&exactWholeSearchWord(n,q))whole+=x
      if(prefix.size>=160&&whole.size>=80)break
     }
     val matches=(prefix+whole).distinctBy{it.id}.take(200)
     runOnUiThread{if(myGen==searchRenderGeneration)renderSeriesSearchSnapshot(matches,myGen,true)}
    }else{
     val prefix=ArrayList<MediaItem>();val whole=ArrayList<MediaItem>();var lastPublish=0L
     for(x in allVodItems){
      if(myGen!=searchRenderGeneration)return@execute
      val n=normalizedSearch(x.name)
      if(n.startsWith(q)){
       if(prefix.size<160)prefix+=x
       val now=SystemClock.uptimeMillis()
       if(prefix.size==1||(prefix.size%8==0&&now-lastPublish>=90L)){
        lastPublish=now;val snapshot=prefix.toList()
        runOnUiThread{if(myGen==searchRenderGeneration)renderVodSearchSnapshot(snapshot,myGen,false)}
       }
      }else if(whole.size<80&&exactWholeSearchWord(n,q))whole+=x
      if(prefix.size>=160&&whole.size>=80)break
     }
     val matches=(prefix+whole).distinctBy{it.id}.take(200)
     runOnUiThread{if(myGen==searchRenderGeneration)renderVodSearchSnapshot(matches,myGen,true)}
    }
   }
  }
  searchDebounce=task;handler.postDelayed(task,140)
 }
 private fun renderVodSearchSnapshot(all:List<MediaItem>,gen:Int,final:Boolean){
  if(gen!=searchRenderGeneration)return
  val firstPaint=searchPaintGeneration!=gen||screen!=Screen.VOD_SEARCH||posterGrid.adapter==null
  val count=if(final)minOf(maxOf(searchVodItems.size,8),all.size) else all.size
  val initial=if(final)all.take(count) else all
  searchVodItems=initial
  if(firstPaint){searchPaintGeneration=gen;screen=Screen.VOD_SEARCH;applyTheme(3);setMode();posterAdapter=PosterGridAdapter(this,searchVodItems.map{it.name},searchVodItems.map{it.icon},false);posterGrid.adapter=posterAdapter;posterGrid.clearChoices();posterGrid.choiceMode=AbsListView.CHOICE_MODE_SINGLE;if(searchVodItems.isNotEmpty())posterGrid.setSelection(0)}
  else posterAdapter?.updateData(searchVodItems.map{it.name},searchVodItems.map{it.icon})
  status.text="Wyniki filmów  •  ${searchVodItems.size}${if(final&&searchVodItems.size<all.size)" / ${all.size}" else ""}"
  if(final&&count<all.size)handler.postDelayed({if(gen==searchRenderGeneration)renderVodSearchProgressively(all,gen,count+8)},110)
 }
 private fun renderSeriesSearchSnapshot(all:List<SeriesItem>,gen:Int,final:Boolean){
  if(gen!=searchRenderGeneration)return
  val firstPaint=searchPaintGeneration!=gen||screen!=Screen.SERIES_SEARCH||posterGrid.adapter==null
  val count=if(final)minOf(maxOf(searchSeriesItems.size,8),all.size) else all.size
  val initial=if(final)all.take(count) else all
  searchSeriesItems=initial
  if(firstPaint){searchPaintGeneration=gen;screen=Screen.SERIES_SEARCH;applyTheme(4);setMode();posterAdapter=PosterGridAdapter(this,searchSeriesItems.map{it.name},searchSeriesItems.map{it.cover},true);posterGrid.adapter=posterAdapter;posterGrid.clearChoices();posterGrid.choiceMode=AbsListView.CHOICE_MODE_SINGLE;if(searchSeriesItems.isNotEmpty())posterGrid.setSelection(0)}
  else posterAdapter?.updateData(searchSeriesItems.map{it.name},searchSeriesItems.map{it.cover})
  status.text="Wyniki seriali  •  ${searchSeriesItems.size}${if(final&&searchSeriesItems.size<all.size)" / ${all.size}" else ""}"
  if(final&&count<all.size)handler.postDelayed({if(gen==searchRenderGeneration)renderSeriesSearchProgressively(all,gen,count+8)},110)
 }
 private fun renderVodSearchProgressively(all:List<MediaItem>,gen:Int,shown:Int){
  if(gen!=searchRenderGeneration||screen!=Screen.VOD_SEARCH)return
  val count=minOf(shown,all.size);searchVodItems=all.take(count);posterAdapter?.updateData(searchVodItems.map{it.name},searchVodItems.map{it.icon})
  status.text="Wyniki filmów  •  $count${if(count<all.size)" / ${all.size}" else ""}"
  if(count<all.size)handler.postDelayed({if(gen==searchRenderGeneration)renderVodSearchProgressively(all,gen,count+8)},110)
 }
 private fun renderSeriesSearchProgressively(all:List<SeriesItem>,gen:Int,shown:Int){
  if(gen!=searchRenderGeneration||screen!=Screen.SERIES_SEARCH)return
  val count=minOf(shown,all.size);searchSeriesItems=all.take(count);posterAdapter?.updateData(searchSeriesItems.map{it.name},searchSeriesItems.map{it.cover})
  status.text="Wyniki seriali  •  $count${if(count<all.size)" / ${all.size}" else ""}"
  if(count<all.size)handler.postDelayed({if(gen==searchRenderGeneration)renderSeriesSearchProgressively(all,gen,count+8)},110)
 }
 private fun showRecentVod(series:Boolean){
  hideVodSidePanel(false);val src=selectedSource?:return;recentEntries=VodHistoryStore.list(this,VodHistoryStore.sourceKey(src),if(series)"series" else "movie")
  screen=if(series)Screen.SERIES_RECENT else Screen.VOD_RECENT;applyTheme(if(series)4 else 3);setMode();status.text=(if(series)"Ostatnio oglądane seriale" else "Ostatnio oglądane filmy")+"  •  ${recentEntries.size}  •  Przytrzymaj OK aby usunąć pozycję"
  posterAdapter=PosterGridAdapter(this,recentEntries.map{if(it.subtitle.isBlank())it.title else "${it.title}\n${it.subtitle}"},recentEntries.map{it.poster},series);posterGrid.adapter=posterAdapter;posterGrid.clearChoices();posterGrid.choiceMode=AbsListView.CHOICE_MODE_SINGLE;posterGrid.post{if(recentEntries.isNotEmpty())posterGrid.setSelection(0);posterGrid.requestFocus()}
 }
 private fun openRecentEntry(entry:VodHistoryEntry){
  val at=fmtResume(entry.positionMs)
  TvMadDialogs.showConfirm(this,entry.title,"Odtworzyć z ostatniej pozycji${if(at.isBlank())"" else " ($at)"}?",
   onPositive={play(entry.url,entry.subtitle.ifBlank{entry.title},"",true,null,entry.key,entry.kind,entry.poster,entry.title,entry.positionMs)},
   onNegative={play(entry.url,entry.subtitle.ifBlank{entry.title},"",true,null,entry.key,entry.kind,entry.poster,entry.title,0L)})
 }
 private fun fmtResume(ms:Long):String{if(ms<=0)return "";val t=ms/1000;val h=t/3600;val m=(t%3600)/60;val sec=t%60;return if(h>0)String.format(Locale.getDefault(),"%d:%02d:%02d",h,m,sec) else String.format(Locale.getDefault(),"%02d:%02d",m,sec)}

 override fun dispatchTouchEvent(ev:MotionEvent):Boolean{
  if(liveFullscreen&&!liveChannelDrawerOpen&&!liveGroupDrawerOpen&&!liveTrackDrawerOpen&&!multiEpgOpen){
   val infoTop=if(liveFsInfo.visibility==View.VISIBLE)(rootFrame.height-liveFsInfo.height).coerceAtLeast(0) else rootFrame.height
   val videoArea=ev.y<infoTop
   when(ev.actionMasked){
    MotionEvent.ACTION_DOWN->if(videoArea){fullscreenTouchCaptured=true;return true}
    MotionEvent.ACTION_UP->if(fullscreenTouchCaptured){
     fullscreenTouchCaptured=false
     if(liveFsInfo.visibility==View.VISIBLE){if(!liveHistoryExpanded)expandLiveHistory() else handler.removeCallbacks(hideLiveInfo)}else showLiveInfo(5000)
     return true
    }
    MotionEvent.ACTION_CANCEL->fullscreenTouchCaptured=false
   }
  }else fullscreenTouchCaptured=false
  return super.dispatchTouchEvent(ev)
 }
 override fun dispatchKeyEvent(e:KeyEvent):Boolean{
  // Physical remote input is proxied from the AMOLED Activity. If the exit confirmation
  // dialog is on top of HDMI, feed the proxied key into that dialog window first.
  exitConfirmDialog?.takeIf{it.isShowing}?.let{return try{it.dispatchKeyEvent(KeyEvent(e))}catch(_:Throwable){true}}
  if(liveGroupFilterPanelOpen){
   if(e.action==KeyEvent.ACTION_DOWN&&(e.keyCode==KeyEvent.KEYCODE_BACK||e.keyCode==KeyEvent.KEYCODE_DPAD_RIGHT)){hideLiveGroupFilterPanel();return true}
   return super.dispatchKeyEvent(e)
  }
  if(e.action==KeyEvent.ACTION_DOWN&&e.keyCode==KeyEvent.KEYCODE_DPAD_LEFT&&screen==Screen.LIVE_GROUPS){showLiveGroupFilterPanel();return true}
  if(vodSidePanelOpen){
   if(e.action==KeyEvent.ACTION_DOWN){
    when(e.keyCode){
     KeyEvent.KEYCODE_BACK,KeyEvent.KEYCODE_DPAD_RIGHT->{hideVodSidePanel(true);return true}
     KeyEvent.KEYCODE_DPAD_DOWN->{if(currentFocus===vodSearchBox){vodRecentButton.requestFocus();return true}}
     KeyEvent.KEYCODE_DPAD_UP->{if(currentFocus===vodRecentButton){vodSearchBox.requestFocus();return true}}
    }
   }
   return super.dispatchKeyEvent(e)
  }
  if(e.action==KeyEvent.ACTION_DOWN&&e.keyCode==KeyEvent.KEYCODE_DPAD_LEFT&&(screen==Screen.VOD_CATS||screen==Screen.SERIES_CATS)){showVodSidePanel(screen==Screen.SERIES_CATS);return true}
  if(e.action==KeyEvent.ACTION_DOWN&&e.keyCode==KeyEvent.KEYCODE_DPAD_UP){
   if(screen==Screen.LIVE_GROUPS&&channelList.selectedItemPosition<=0){multiServerButton.requestFocus();return true}
   if((screen==Screen.VOD_CATS||screen==Screen.SERIES_CATS)&&list.selectedItemPosition<=0){multiServerButton.requestFocus();return true}
  }
  if(liveFullscreen){
   if(e.action!=KeyEvent.ACTION_DOWN)return true
   if(liveHistoryExpanded){
    when(e.keyCode){
     KeyEvent.KEYCODE_DPAD_LEFT->{moveLiveHistorySelection(-1);return true}
     KeyEvent.KEYCODE_DPAD_RIGHT->{moveLiveHistorySelection(1);return true}
     KeyEvent.KEYCODE_DPAD_CENTER,KeyEvent.KEYCODE_ENTER->{selectLiveHistoryChannel();return true}
     KeyEvent.KEYCODE_BACK,KeyEvent.KEYCODE_DPAD_UP,KeyEvent.KEYCODE_DPAD_DOWN->{collapseLiveHistory(true);return true}
    };return true
   }
   // Dwupoziomowa nawigacja jak w TiviMate: gdy widoczne są oba panele,
   // klawisze sterują najpierw lewym panelem grup. PRAWO wraca do kanałów.
   if(liveGroupDrawerOpen){
    when(e.keyCode){
     KeyEvent.KEYCODE_DPAD_UP->{moveLiveGroupDrawerSelection(-1);return true}
     KeyEvent.KEYCODE_DPAD_DOWN->{moveLiveGroupDrawerSelection(1);return true}
     KeyEvent.KEYCODE_DPAD_RIGHT,KeyEvent.KEYCODE_BACK->{hideLiveGroupDrawer(true);return true}
     KeyEvent.KEYCODE_DPAD_CENTER,KeyEvent.KEYCODE_ENTER->{selectLiveDrawerGroup();return true}
     KeyEvent.KEYCODE_DPAD_LEFT->{return true}
    };return true
   }
   if(liveChannelDrawerOpen){
    when(e.keyCode){
     KeyEvent.KEYCODE_DPAD_UP->{moveLiveDrawerSelection(-1);return true}
     KeyEvent.KEYCODE_DPAD_DOWN->{moveLiveDrawerSelection(1);return true}
     KeyEvent.KEYCODE_DPAD_LEFT->{showLiveGroupDrawer();return true}
     KeyEvent.KEYCODE_DPAD_RIGHT,KeyEvent.KEYCODE_BACK->{hideLiveChannelDrawer(true);return true}
     KeyEvent.KEYCODE_DPAD_CENTER,KeyEvent.KEYCODE_ENTER->{selectLiveDrawerChannel();return true}
    };return true
   }
   if(liveTrackDrawerOpen){
    when(e.keyCode){
     KeyEvent.KEYCODE_DPAD_UP->{moveLiveTrackSelection(-1);return true}
     KeyEvent.KEYCODE_DPAD_DOWN->{moveLiveTrackSelection(1);return true}
     KeyEvent.KEYCODE_DPAD_LEFT,KeyEvent.KEYCODE_BACK->{hideLiveTrackDrawer(true);return true}
     KeyEvent.KEYCODE_DPAD_CENTER,KeyEvent.KEYCODE_ENTER->{applyLiveTrackChoice();return true}
    };return true
   }
   when(e.keyCode){
    KeyEvent.KEYCODE_DPAD_LEFT->{showLiveChannelDrawer();return true}
    KeyEvent.KEYCODE_DPAD_RIGHT->{showLiveTrackDrawer();return true}
    KeyEvent.KEYCODE_DPAD_UP,KeyEvent.KEYCODE_CHANNEL_UP->{switchLiveInline(1);return true}
    KeyEvent.KEYCODE_DPAD_DOWN,KeyEvent.KEYCODE_CHANNEL_DOWN->{switchLiveInline(-1);return true}
    KeyEvent.KEYCODE_DPAD_CENTER,KeyEvent.KEYCODE_ENTER->{if(liveFsInfo.visibility==View.VISIBLE)expandLiveHistory() else showLiveInfo(5000);return true}
    KeyEvent.KEYCODE_BACK->{exitLiveFullscreen();return true}
   }
   return true
  }
  return super.dispatchKeyEvent(e)
 }
 private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
 private fun setupLiveSidePanels(){
  // Fullscreen LIVE: ostre, pełnowysokościowe panele bez zewnętrznych ramek.
  // Kanały są lekko jaśniejsze, grupy ciemniejsze — oba pozostają półprzezroczyste.
  liveChannelDrawerTitle=TextView(this).apply{text="KANAŁY";setTextColor(0xFFD8E8F5.toInt());textSize=13f;setPadding(dp(14),dp(12),dp(10),dp(7));setBackgroundColor(0x382B6C9E)}
  liveChannelDrawerList=ListView(this).apply{divider=android.graphics.drawable.ColorDrawable(0x552C465A);dividerHeight=dp(1);setPadding(0,0,0,0);setClipToPadding(true);isFocusable=false;overScrollMode=View.OVER_SCROLL_NEVER;setBackgroundColor(android.graphics.Color.TRANSPARENT)}
  liveChannelDrawer=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE;setBackgroundColor(0xC91A3144.toInt());elevation=dp(12).toFloat();addView(liveChannelDrawerTitle,LinearLayout.LayoutParams(-1,dp(44)));addView(liveChannelDrawerList,LinearLayout.LayoutParams(-1,0,1f))}
  rootFrame.addView(liveChannelDrawer,FrameLayout.LayoutParams((resources.displayMetrics.widthPixels*0.36f).toInt(),-1,Gravity.START))

  liveGroupDrawerTitle=TextView(this).apply{text="GRUPY LIVE";setTextColor(0xFFD3E2EE.toInt());textSize=13f;setPadding(dp(14),dp(12),dp(8),dp(7));setBackgroundColor(0x44213D52)}
  liveGroupDrawerList=ListView(this).apply{divider=android.graphics.drawable.ColorDrawable(0x44263B4B);dividerHeight=dp(1);setPadding(0,0,0,0);setClipToPadding(true);isFocusable=false;overScrollMode=View.OVER_SCROLL_NEVER;setBackgroundColor(android.graphics.Color.TRANSPARENT)}
  liveGroupDrawer=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE;setBackgroundColor(0xDE0D1D2A.toInt());elevation=dp(13).toFloat();addView(liveGroupDrawerTitle,LinearLayout.LayoutParams(-1,dp(44)));addView(liveGroupDrawerList,LinearLayout.LayoutParams(-1,0,1f))}
  rootFrame.addView(liveGroupDrawer,FrameLayout.LayoutParams((resources.displayMetrics.widthPixels*0.23f).toInt(),-1,Gravity.START))

  liveTrackDrawerTitle=TextView(this).apply{text="NAGRYWANIE • AUDIO • NAPISY";setTextColor(0xFFF5A623.toInt());textSize=17f;setPadding(dp(18),dp(18),dp(12),dp(10))}
  liveTrackDrawerList=ListView(this).apply{dividerHeight=0;setPadding(dp(10),0,dp(10),dp(12));setClipToPadding(false);isFocusable=false}
  liveTrackDrawer=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;visibility=View.GONE;setBackgroundResource(R.drawable.panel_live_glass);elevation=dp(12).toFloat();addView(liveTrackDrawerTitle,LinearLayout.LayoutParams(-1,dp(58)));addView(liveTrackDrawerList,LinearLayout.LayoutParams(-1,0,1f))}
  rootFrame.addView(liveTrackDrawer,FrameLayout.LayoutParams((resources.displayMetrics.widthPixels*0.34f).toInt(),-1,Gravity.END).apply{topMargin=dp(36);bottomMargin=dp(36);rightMargin=dp(20)})
 }
 private fun showLiveChannelDrawer(){
  if(!liveFullscreen||visibleChannels.isEmpty())return
  handler.removeCallbacks(hideLiveInfo);hideLiveInfoImmediate();hideLiveTrackDrawer(false)
  liveDrawerSelected=visibleChannels.indexOfFirst{it.url==miniCurrentChannel?.url}.takeIf{it>=0}?:liveChannelSelected.coerceIn(0,visibleChannels.lastIndex)
  liveChannelDrawerTitle.text=(currentLiveGroup?.name?:"Kanały")+"   •   ${visibleChannels.size}"
  liveDrawerPageStart=(liveDrawerSelected/9)*9
  liveDrawerAdapter=FullscreenChannelAdapter();liveChannelDrawerList.adapter=liveDrawerAdapter
  liveChannelDrawer.visibility=View.VISIBLE;liveChannelDrawer.bringToFront();liveChannelDrawer.animate().cancel();liveChannelDrawer.x=-liveChannelDrawer.layoutParams.width.toFloat()
  liveChannelDrawer.animate().x(0f).setDuration(220).start();liveChannelDrawerOpen=true
  liveChannelDrawerList.post{positionPagedList(liveChannelDrawerList,liveDrawerSelected,9,visibleChannels.size,true)}
  prefetchDrawerEpg(liveDrawerSelected)
 }
 private fun hideLiveChannelDrawer(showInfoAfter:Boolean){
  if(!::liveChannelDrawer.isInitialized||!liveChannelDrawerOpen){if(showInfoAfter&&liveFullscreen)showLiveInfo(5000);return}
  if(liveGroupDrawerOpen)hideLiveGroupDrawer(false)
  liveChannelDrawerOpen=false;liveChannelDrawer.animate().cancel();liveChannelDrawer.animate().x(-liveChannelDrawer.width.toFloat()).setDuration(190).withEndAction{liveChannelDrawer.visibility=View.GONE;liveChannelDrawer.x=0f}.start()
  if(showInfoAfter)showLiveInfo(5000)
 }
 private fun showLiveGroupDrawer(){
  if(!liveFullscreen||!liveChannelDrawerOpen||groups.isEmpty()||liveGroupDrawerOpen)return
  handler.removeCallbacks(hideLiveInfo);hideLiveInfoImmediate()
  liveGroupDrawerSelected=groups.indexOfFirst{it.id==currentLiveGroup?.id}.takeIf{it>=0}?:liveGroupSelected.coerceIn(0,groups.lastIndex)
  liveGroupDrawerTitle.text="GRUPY LIVE   •   ${groups.size}"
  liveGroupDrawerAdapter=FullscreenGroupAdapter();liveGroupDrawerList.adapter=liveGroupDrawerAdapter
  liveGroupDrawer.visibility=View.VISIBLE;liveGroupDrawer.bringToFront();liveChannelDrawer.bringToFront()
  val gw=liveGroupDrawer.layoutParams.width.toFloat()
  liveGroupDrawer.animate().cancel();liveGroupDrawer.x=-gw
  liveGroupDrawer.animate().x(0f).setDuration(210).start()
  liveChannelDrawer.animate().cancel();liveChannelDrawer.animate().x(gw).setDuration(210).start()
  liveGroupDrawerOpen=true
  liveGroupDrawerList.post{positionLiveGroupDrawerSelection(true)}
 }
 private fun hideLiveGroupDrawer(animated:Boolean){
  if(!::liveGroupDrawer.isInitialized||!liveGroupDrawerOpen)return
  liveGroupDrawerOpen=false
  val gw=liveGroupDrawer.width.toFloat().takeIf{it>0f}?:liveGroupDrawer.layoutParams.width.toFloat()
  liveGroupDrawer.animate().cancel();liveChannelDrawer.animate().cancel()
  if(animated){
   liveGroupDrawer.animate().x(-gw).setDuration(190).withEndAction{liveGroupDrawer.visibility=View.GONE;liveGroupDrawer.x=0f}.start()
   if(liveChannelDrawerOpen)liveChannelDrawer.animate().x(0f).setDuration(190).start()
  }else{
   liveGroupDrawer.visibility=View.GONE;liveGroupDrawer.x=0f
   if(liveChannelDrawerOpen)liveChannelDrawer.x=0f
  }
 }
 private fun positionLiveGroupDrawerSelection(force:Boolean=false){
  if(groups.isEmpty())return
  val first=liveGroupDrawerList.firstVisiblePosition;val last=liveGroupDrawerList.lastVisiblePosition
  if(force||liveGroupDrawerSelected<first||liveGroupDrawerSelected>last)liveGroupDrawerList.setSelectionFromTop(liveGroupDrawerSelected,dp(8))
  liveGroupDrawerList.post{liveGroupDrawerList.invalidateViews()}
 }
 private fun moveLiveGroupDrawerSelection(delta:Int){
  if(groups.isEmpty())return
  val next=(liveGroupDrawerSelected+delta).coerceIn(0,groups.lastIndex);if(next==liveGroupDrawerSelected)return
  liveGroupDrawerSelected=next;liveGroupDrawerAdapter?.notifyDataSetChanged();positionLiveGroupDrawerSelection();previewLiveDrawerGroup(groups[next])
 }
 private fun previewLiveDrawerGroup(g:LiveGroup){
  val src=selectedSource?:return;val token=++liveDrawerPreviewToken
  fun stillCurrent()=token==liveDrawerPreviewToken&&liveGroupDrawerOpen&&groups.getOrNull(liveGroupDrawerSelected)?.id==g.id
  fun apply(ch:List<Channel>){
   if(!stillCurrent())return
   // Wynik należy wyłącznie do grupy, nad którą aktualnie stoi focus. Normalizacja
   // group/groupId zapobiega odrzuceniu poprawnych kanałów przez różnice M3U/Xtream.
   visibleChannels=ch.map{it.copy(group=g.name,groupId=g.id)};liveDrawerSelected=0;liveDrawerPageStart=0
   liveChannelDrawerTitle.text=g.name+"   •   ${visibleChannels.size}";liveDrawerAdapter=FullscreenChannelAdapter();liveChannelDrawerList.adapter=liveDrawerAdapter
   liveChannelDrawerList.post{if(visibleChannels.isNotEmpty())positionPagedList(liveChannelDrawerList,0,9,visibleChannels.size,true)}
   preloadGroupEpg(visibleChannels);preloadGroupPicons(visibleChannels)
  }
  // Od razu pokaż, że prawy panel dotyczy nowej grupy; nigdy nie zostawiaj kanałów
  // poprzedniej grupy podczas szybkiego UP/DOWN.
  visibleChannels=emptyList();liveDrawerSelected=0;liveDrawerPageStart=0
  liveChannelDrawerTitle.text=g.name+"   •   ładowanie…";liveDrawerAdapter=FullscreenChannelAdapter();liveChannelDrawerList.adapter=liveDrawerAdapter
  if(src.type=="e2"){
   val key=sourceScanKey(src)+"|"+g.id;e2ChannelsSessionCache[key]?.takeIf{it.isNotEmpty()}?.let{apply(it);return}
   pool.execute{try{val ch=Api.liveChannels(src,g);if(ch.isNotEmpty())e2ChannelsSessionCache[key]=ch;runOnUiThread{apply(ch)}}catch(_:Exception){runOnUiThread{if(stillCurrent())apply(emptyList())}}}
  }else{
   LiveCacheStore.loadGroupChannels(this,src,g).takeIf{it.isNotEmpty()}?.let{apply(it);return}
   pool.execute{
    try{
     val ch=if(src.type=="m3u"&&Api.xtreamParams(src)!=null)Api.lightweightLiveChannels(src,g) else Api.liveChannels(src,g)
     if(ch.isNotEmpty())LiveCacheStore.saveGroupChannels(this,src,g,ch)
     runOnUiThread{apply(ch)}
    }catch(_:Exception){runOnUiThread{if(stillCurrent())apply(emptyList())}}
   }
  }
 }
 private fun selectLiveDrawerGroup(){
  val i=liveGroupDrawerSelected.takeIf{it in groups.indices}?:return
  val g=groups[i];liveGroupSelected=i
  if(visibleChannels.isNotEmpty()&&liveChannelDrawerTitle.text.toString().startsWith(g.name)){currentLiveGroup=g;liveGroupDrawerAdapter?.notifyDataSetChanged();hideLiveGroupDrawer(true);return}
  if(currentLiveGroup?.id==g.id){liveGroupDrawerAdapter?.notifyDataSetChanged();return}
  // Na czas ewentualnego asynchronicznego wczytania nie zostawiamy w prawym panelu
  // kanałów poprzedniej grupy. Sam odtwarzany kanał pozostaje bez zmian.
  visibleChannels=emptyList();liveDrawerSelected=0;liveDrawerPageStart=0
  liveChannelDrawerTitle.text=g.name+"   •   …"
  liveDrawerAdapter=FullscreenChannelAdapter();liveChannelDrawerList.adapter=liveDrawerAdapter
  liveGroupDrawerAdapter?.notifyDataSetChanged()
  openLiveGroup(g)
 }
 private fun moveMainChannelSelection(delta:Int){
  if(visibleChannels.isEmpty())return
  val next=(liveChannelSelected+delta).coerceIn(0,visibleChannels.lastIndex);if(next==liveChannelSelected)return
  liveChannelSelected=next
  piconAdapter?.setSelectedPosition(next)
  positionPagedList(channelList,next,8,visibleChannels.size,false)
  updateMiniInfo(visibleChannels[next]);loadVisibleEpg()
 }
 private fun positionPagedList(lv:ListView,target:Int,pageSize:Int,total:Int,force:Boolean=false){
  // Twarde strony bez "pełzania" ListView. W obrębie strony rusza się WYŁĄCZNIE
  // niebieskie zaznaczenie. Sama lista zmienia pozycję tylko po przekroczeniu granicy strony.
  if(total<=0||pageSize<=0)return
  val safeTarget=target.coerceIn(0,total-1)
  val pageStart=(safeTarget/pageSize)*pageSize
  val isMain=lv===channelList
  val oldStart=if(isMain)liveChannelPageStart else liveDrawerPageStart
  if(force||pageStart!=oldStart){
   if(isMain)liveChannelPageStart=pageStart else liveDrawerPageStart=pageStart
   lv.setSelectionFromTop(pageStart,lv.paddingTop)
  }
  lv.post{lv.invalidateViews()}
 }
 private fun moveLiveDrawerSelection(delta:Int){
  if(visibleChannels.isEmpty())return
  val next=(liveDrawerSelected+delta).coerceIn(0,visibleChannels.lastIndex);if(next==liveDrawerSelected)return
  liveDrawerSelected=next;liveDrawerAdapter?.notifyDataSetChanged();positionPagedList(liveChannelDrawerList,liveDrawerSelected,9,visibleChannels.size,false);prefetchDrawerEpg(liveDrawerSelected)
 }
 private fun selectLiveDrawerChannel(){
  val i=liveDrawerSelected.takeIf{it in visibleChannels.indices}?:return
  if(liveGroupDrawerOpen)groups.getOrNull(liveGroupDrawerSelected)?.let{currentLiveGroup=it;liveGroupSelected=liveGroupDrawerSelected}
  liveChannelSelected=i
  val c=visibleChannels[i]
  bindLiveChannel(c)
  loadEpgForChannels(listOf(c));updateFullscreenInfo(c);hideLiveChannelDrawer(false);showLiveInfo(5000)
 }
 private fun prefetchDrawerEpg(center:Int){if(visibleChannels.isEmpty())return;val a=(center-6).coerceAtLeast(0);val b=(center+7).coerceAtMost(visibleChannels.size);loadEpgForChannels(visibleChannels.subList(a,b))}
 private inner class FullscreenChannelAdapter:BaseAdapter(){
  override fun getCount()=visibleChannels.size;override fun getItem(position:Int)=visibleChannels[position];override fun getItemId(position:Int)=position.toLong()
  override fun getView(position:Int,convertView:View?,parent:ViewGroup):View{
   val row=(convertView as? LinearLayout)?:LinearLayout(this@MainActivity).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(8),dp(2),dp(10),dp(2));addView(TextView(this@MainActivity).apply{id=5101;textSize=12f;gravity=Gravity.CENTER;setTextColor(0xFF8FB9DA.toInt())},LinearLayout.LayoutParams(dp(32),dp(50)));addView(ImageView(this@MainActivity).apply{id=5102;scaleType=ImageView.ScaleType.CENTER_INSIDE},LinearLayout.LayoutParams(dp(54),dp(44)).apply{rightMargin=dp(8)});addView(LinearLayout(this@MainActivity).apply{id=5103;orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_VERTICAL;addView(TextView(this@MainActivity).apply{id=5104;textSize=16f;setTextColor(0xFFFFFFFF.toInt());maxLines=1},LinearLayout.LayoutParams(-1,dp(23)));addView(TextView(this@MainActivity).apply{id=5105;textSize=11f;setTextColor(0xFFC1CDD8.toInt());maxLines=1},LinearLayout.LayoutParams(-1,dp(17)));addView(ProgressBar(this@MainActivity,null,android.R.attr.progressBarStyleHorizontal).apply{id=5106;max=1000;progressTintList=android.content.res.ColorStateList.valueOf(0xFF20C9E8.toInt());progressBackgroundTintList=android.content.res.ColorStateList.valueOf(0xFF263B4B.toInt())},LinearLayout.LayoutParams(-1,dp(4)).apply{topMargin=dp(1)})},LinearLayout.LayoutParams(0,dp(52),1f))}
   if(parent.height>0){val lv=parent as? ListView;val usable=parent.height-parent.paddingTop-parent.paddingBottom-((lv?.dividerHeight?:0)*8);val h=(usable/9).coerceAtLeast(dp(54));val lp=row.layoutParams as? AbsListView.LayoutParams;if(lp==null||lp.height!=h)row.layoutParams=AbsListView.LayoutParams(AbsListView.LayoutParams.MATCH_PARENT,h)}
   val c=visibleChannels[position];row.setBackgroundColor(if(position==liveDrawerSelected)0xA81A77B8.toInt() else android.graphics.Color.TRANSPARENT);row.findViewById<TextView>(5101).text=(position+1).toString();row.findViewById<TextView>(5104).text=c.name
   val now=epgEvents[c.url].orEmpty().firstOrNull();row.findViewById<TextView>(5105).text=now?.title?:epgText[c.url].orEmpty().replace(Regex("^\\d{1,2}:\\d{2}\\s*-\\s*\\d{1,2}:\\d{2}\\s+"),"")
   val pb=row.findViewById<ProgressBar>(5106);pb.progress=if(now!=null&&now.startEpoch>0&&now.endEpoch>now.startEpoch){(((System.currentTimeMillis()-now.startEpoch).coerceIn(0,now.endEpoch-now.startEpoch)*1000)/(now.endEpoch-now.startEpoch)).toInt()}else 0
   val iv=row.findViewById<ImageView>(5102);val oldTag=iv.tag as? String;iv.tag=c.url;loadDrawerPicon(iv,c,oldTag);return row
  }
 }
 private fun loadDrawerPicon(iv:ImageView,c:Channel,oldTag:String?=null){
  val pm=activePiconMode();val local=if(pm==0||pm==2)PiconRepository.find(this,c.name)else null
  if(local!=null){val cacheKey="local:${local.absolutePath}";PiconMemoryCache.get(cacheKey)?.let{iv.setImageBitmap(it);return};if(oldTag!=c.url)iv.setImageDrawable(null);val rowKey=c.url;pool.execute{val bm=PiconRepository.decodeScaled(local,140,90)?:return@execute;PiconMemoryCache.put(cacheKey,bm);runOnUiThread{if(iv.tag==rowKey)iv.setImageBitmap(bm)}};return}
  if((pm==1||pm==2)&&c.logo.isNotBlank()){val cacheKey="remote:${selectedSource?.type}:${selectedSource?.host}:${c.logo}";PiconMemoryCache.get(cacheKey)?.let{iv.setImageBitmap(it);return};if(oldTag!=c.url)iv.setImageDrawable(null);val rowKey=c.url;pool.execute{try{val b=selectedSource?.let{Api.loadRemotePicon(it,c.logo)}?:URL(c.logo).openStream().use{it.readBytes()};val bm=BitmapFactory.decodeByteArray(b,0,b.size)?:return@execute;PiconMemoryCache.put(cacheKey,bm);runOnUiThread{if(iv.tag==rowKey)iv.setImageBitmap(bm)}}catch(_:Exception){}}}else if(oldTag!=c.url)iv.setImageDrawable(null)
 }
 private inner class FullscreenGroupAdapter:BaseAdapter(){
  override fun getCount()=groups.size;override fun getItem(position:Int)=groups[position];override fun getItemId(position:Int)=position.toLong()
  override fun getView(position:Int,convertView:View?,parent:ViewGroup):View{
   val v=(convertView as? TextView)?:TextView(this@MainActivity).apply{gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),0,dp(8),0);textSize=15f;setTextColor(0xFFE5EEF5.toInt());maxLines=1;ellipsize=android.text.TextUtils.TruncateAt.END}
   v.text=groups[position].name
   v.setBackgroundColor(if(position==liveGroupDrawerSelected)0xB31A77B8.toInt() else android.graphics.Color.TRANSPARENT)
   if(parent.height>0){val usable=parent.height-parent.paddingTop-parent.paddingBottom;val h=(usable/11).coerceAtLeast(dp(48));val lp=v.layoutParams as? AbsListView.LayoutParams;if(lp==null||lp.height!=h)v.layoutParams=AbsListView.LayoutParams(AbsListView.LayoutParams.MATCH_PARENT,h)}
   return v
  }
 }

 private data class LiveTrackPanelChoice(val label:String,val type:Int,val group:Tracks.Group?,val index:Int,val selected:Boolean=false)
 private val RECORD_CHOICE_TYPE=-99
 private fun buildLiveTrackPanelChoices():List<LiveTrackPanelChoice>{
  val p=miniPlayer?:return emptyList();val out=ArrayList<LiveTrackPanelChoice>();val current=miniCurrentChannel;out+=LiveTrackPanelChoice(if(current!=null&&RecordingStore.isActiveForUrl(this,current.url))"■  Zatrzymaj nagrywanie" else "●  Nagrywaj",RECORD_CHOICE_TYPE,null,-1,false);var audioNo=1;var subNo=1
  for(g in p.currentTracks.groups){if(g.type!=C.TRACK_TYPE_AUDIO)continue;for(i in 0 until g.length){if(!g.isTrackSupported(i))continue;val f=g.getTrackFormat(i);val lang=f.language?.uppercase().orEmpty();val label=f.label?.takeIf{it.isNotBlank()}?:"Audio ${audioNo++}";out+=LiveTrackPanelChoice("🔊  "+(if(lang.isBlank())label else "$label  [$lang]"),C.TRACK_TYPE_AUDIO,g,i,g.isTrackSelected(i))}}
  val textGroups=p.currentTracks.groups.filter{it.type==C.TRACK_TYPE_TEXT};val anyTextSelected=textGroups.any{g->(0 until g.length).any{i->g.isTrackSelected(i)}};out+=LiveTrackPanelChoice("▤  Napisy: wyłączone",C.TRACK_TYPE_TEXT,null,-1,!anyTextSelected)
  for(g in textGroups){for(i in 0 until g.length){if(!g.isTrackSupported(i))continue;val f=g.getTrackFormat(i);val lang=f.language?.uppercase().orEmpty();val label=f.label?.takeIf{it.isNotBlank()}?:"Napisy ${subNo++}";out+=LiveTrackPanelChoice("▤  "+(if(lang.isBlank())label else "$label  [$lang]"),C.TRACK_TYPE_TEXT,g,i,g.isTrackSelected(i))}}
  return out
 }
 private fun refreshLiveTrackDrawerList(){
  liveTrackDrawerList.adapter=object:ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,liveTrackChoices.map{(if(it.selected)"✓  " else "   ")+it.label}){override fun getView(position:Int,convertView:View?,parent:ViewGroup):View{val v=super.getView(position,convertView,parent) as TextView;v.setTextColor(0xFFFFFFFF.toInt());v.textSize=15f;v.setPadding(dp(14),dp(12),dp(12),dp(12));v.setBackgroundResource(if(position==liveTrackSelected)R.drawable.row_focus_active else android.R.color.transparent);return v}}
  liveTrackDrawerList.setSelection((liveTrackSelected-2).coerceAtLeast(0))
 }
 private fun showLiveTrackDrawer(){
  if(!liveFullscreen)return;handler.removeCallbacks(hideLiveInfo);hideLiveInfoImmediate();hideLiveChannelDrawer(false);liveTrackChoices=buildLiveTrackPanelChoices();if(liveTrackChoices.isEmpty()){showLiveInfo(3000);Toast.makeText(this,"Brak dostępnych ścieżek audio/napisów",Toast.LENGTH_SHORT).show();return};liveTrackSelected=liveTrackChoices.indexOfFirst{it.selected}.takeIf{it>=0}?:0;refreshLiveTrackDrawerList()
  liveTrackDrawer.visibility=View.VISIBLE;liveTrackDrawer.bringToFront();liveTrackDrawer.translationX=liveTrackDrawer.layoutParams.width.toFloat()+dp(30);liveTrackDrawer.animate().cancel();liveTrackDrawer.animate().translationX(0f).setDuration(230).start();liveTrackDrawerOpen=true
 }
 private fun hideLiveTrackDrawer(showInfoAfter:Boolean){if(!::liveTrackDrawer.isInitialized||!liveTrackDrawerOpen){if(showInfoAfter&&liveFullscreen)showLiveInfo(5000);return};liveTrackDrawerOpen=false;liveTrackDrawer.animate().cancel();liveTrackDrawer.animate().translationX(liveTrackDrawer.width.toFloat()+dp(30)).setDuration(210).withEndAction{liveTrackDrawer.visibility=View.GONE;liveTrackDrawer.translationX=0f}.start();if(showInfoAfter)showLiveInfo(5000)}
 private fun moveLiveTrackSelection(delta:Int){if(liveTrackChoices.isEmpty())return;liveTrackSelected=(liveTrackSelected+delta+liveTrackChoices.size)%liveTrackChoices.size;refreshLiveTrackDrawerList()}
 private fun applyLiveTrackChoice(){val c=liveTrackChoices.getOrNull(liveTrackSelected)?:return;if(c.type==RECORD_CHOICE_TYPE){toggleManualRecording();liveTrackChoices=buildLiveTrackPanelChoices();liveTrackSelected=0;refreshLiveTrackDrawerList();return};val p=miniPlayer?:return;val chosenType=c.type;val chosenGroup=c.group?.mediaTrackGroup;val chosenIndex=c.index;val b=p.trackSelectionParameters.buildUpon().clearOverridesOfType(c.type);if(c.group==null)b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT,true)else{b.setTrackTypeDisabled(c.type,false);b.setOverrideForType(TrackSelectionOverride(c.group.mediaTrackGroup,listOf(c.index)))};p.trackSelectionParameters=b.build();liveTrackChoices=buildLiveTrackPanelChoices();liveTrackSelected=liveTrackChoices.indexOfFirst{it.type==chosenType&&it.index==chosenIndex&&it.group?.mediaTrackGroup==chosenGroup}.takeIf{it>=0}?:liveTrackSelected.coerceIn(0,(liveTrackChoices.size-1).coerceAtLeast(0));refreshLiveTrackDrawerList()}

 private fun setupMultiEpg(){
  multiEpgOverlay=LinearLayout(this).apply{
   orientation=LinearLayout.VERTICAL;visibility=View.GONE;isFocusable=true;setPadding(dp(26),dp(18),dp(26),dp(16));setBackgroundColor(0xFA02070D.toInt())
  }
  val top=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
  multiEpgGroupTitle=TextView(this).apply{setTextColor(0xFFF5A623.toInt());textSize=25f;setTypeface(typeface,android.graphics.Typeface.BOLD)}
  val clock=TextView(this).apply{setTextColor(0xFFE5EBF2.toInt());textSize=20f;gravity=Gravity.END}
  top.addView(multiEpgGroupTitle,LinearLayout.LayoutParams(0,dp(42),1f));top.addView(clock,LinearLayout.LayoutParams(dp(110),dp(42)))
  multiEpgOverlay.addView(top,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(44)))
  multiEpgEventTitle=TextView(this).apply{setTextColor(0xFFF5A623.toInt());textSize=20f;setTypeface(typeface,android.graphics.Typeface.BOLD);maxLines=1}
  multiEpgOverlay.addView(multiEpgEventTitle,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(34)))
  val timeRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
  multiEpgEventTime=TextView(this).apply{setTextColor(0xFFE2E9F0.toInt());textSize=14f}
  multiEpgProgress=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=1000;progressTintList=android.content.res.ColorStateList.valueOf(0xFFF5A623.toInt());progressBackgroundTintList=android.content.res.ColorStateList.valueOf(0xFF263746.toInt())}
  timeRow.addView(multiEpgEventTime,LinearLayout.LayoutParams(dp(150),dp(28)));timeRow.addView(multiEpgProgress,LinearLayout.LayoutParams(0,dp(6),1f))
  multiEpgOverlay.addView(timeRow,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(30)))
  multiEpgDesc=TextView(this).apply{setTextColor(0xFFD3DCE5.toInt());textSize=14f;maxLines=100;setPadding(0,dp(5),0,dp(7))}
  multiEpgOverlay.addView(multiEpgDesc,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(104)))
  multiEpgGrid=MultiEpgGridView(this).apply{
   listener=object:MultiEpgGridView.Listener{
    override fun onSelectionChanged(channelIndex:Int,event:EpgEvent?){updateMultiEpgInfo(channelIndex,event)}
    override fun onNeedData(channelIndex:Int){loadMultiEpgAround(channelIndex);loadMultiEpgPicons(channelIndex)}
    override fun onExitRequested(){closeMultiEpg()}
    override fun onEventClicked(channelIndex:Int,event:EpgEvent?){showMultiEpgRecordDialog(channelIndex,event)}
   }
  }
  multiEpgOverlay.addView(multiEpgGrid,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,0,1f))
  val footer=TextView(this).apply{text="↑↓ kanały     ←→ wydarzenia     EXIT = powrót";setTextColor(0xFF91A0AF.toInt());textSize=12f;gravity=Gravity.END or Gravity.CENTER_VERTICAL}
  multiEpgOverlay.addView(footer,LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(28)))
  rootFrame.addView(multiEpgOverlay,FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT))
  val clockTick=object:Runnable{override fun run(){if(multiEpgOpen){clock.text=SimpleDateFormat("HH:mm",Locale.getDefault()).format(Date());handler.postDelayed(this,30000L)}}}
  multiEpgOverlay.tag=clockTick
 }

 private fun openMultiEpg(){
  if(screen!=Screen.LIVE_CHANNELS||visibleChannels.isEmpty())return
  multiEpgReturnChannel=liveChannelSelected.coerceIn(0,visibleChannels.lastIndex)
  multiEpgOpen=true;multiEpgSchedules.clear();multiEpgPending.clear();multiEpgPicons.clear();multiEpgDescToken++;multiEpgDescAnimator?.cancel();multiEpgDescAnimator=null
  val epgNow=System.currentTimeMillis()
  for(c in visibleChannels){
   val cached=longEpgCache[c.url].orEmpty().filter{it.endEpoch<=0L||it.endEpoch>epgNow}
   val basic=epgEvents[c.url].orEmpty().filter{it.endEpoch<=0L||it.endEpoch>epgNow}
   if(cached.isNotEmpty())multiEpgSchedules[c.url]=cached else if(basic.isNotEmpty())multiEpgSchedules[c.url]=basic
  }
  multiEpgGroupTitle.text=currentLiveGroup?.name?:"Multi-EPG"
  multiEpgOverlay.visibility=View.VISIBLE;multiEpgOverlay.bringToFront()
  multiEpgGrid.setData(visibleChannels,multiEpgReturnChannel);multiEpgGrid.setSchedules(multiEpgSchedules)
  (multiEpgOverlay.tag as? Runnable)?.let{handler.removeCallbacks(it);handler.post(it)}
  multiEpgGrid.post{multiEpgGrid.requestFocus()}
  val src=selectedSource
  if(src?.type=="e2"){
   val gid=currentLiveGroup?.id.orEmpty()
   if(gid.isNotBlank())pool.execute{
    try{
     val byRef=try{Api.e2MultiEpg(src,gid)}catch(_:Exception){emptyMap()}
     val mapped=HashMap<String,List<EpgEvent>>()
     val now=System.currentTimeMillis()
     for(c in visibleChannels){
      val ref=c.streamId.ifBlank{c.epgId}
      var ev=byRef[ref].orEmpty().filter{it.endEpoch<=0L||it.endEpoch>now}
      if(ev.isEmpty())ev=try{Api.e2Epg(src,c,80)}catch(_:Exception){emptyList()}.filter{it.endEpoch<=0L||it.endEpoch>now}
      if(ev.isNotEmpty())mapped[c.url]=ev
      try{Thread.sleep(60L)}catch(_:InterruptedException){break}
     }
     runOnUiThread{if(multiEpgOpen&&selectedSource==src){multiEpgSchedules.putAll(mapped);multiEpgGrid.setSchedules(mapped);updateMultiEpgInfo(multiEpgGrid.currentChannelIndex(),mapped[visibleChannels.getOrNull(multiEpgGrid.currentChannelIndex())?.url]?.let{events->events.firstOrNull{System.currentTimeMillis() in it.startEpoch until it.endEpoch}?:events.firstOrNull()})}}
    }catch(_:Exception){}
   }
  }else {
   loadMultiEpgAround(multiEpgReturnChannel)
   scheduleLongEpgPrefetch()
  }
  loadMultiEpgPicons(multiEpgReturnChannel)
 }

 private fun closeMultiEpg(){
  if(!multiEpgOpen)return
  multiEpgOpen=false;multiEpgDescToken++;multiEpgDescAnimator?.cancel();multiEpgDescAnimator=null;multiEpgDesc.scrollTo(0,0)
  (multiEpgOverlay.tag as? Runnable)?.let{handler.removeCallbacks(it)}
  multiEpgOverlay.visibility=View.GONE
  liveChannelSelected=multiEpgReturnChannel.coerceIn(0,(visibleChannels.size-1).coerceAtLeast(0))
  channelList.post{if(visibleChannels.isNotEmpty()){piconAdapter?.setSelectedPosition(liveChannelSelected);positionPagedList(channelList,liveChannelSelected,8,visibleChannels.size,true)};channelList.requestFocus()}
 }

 private fun loadMultiEpgAround(center:Int){
  if(!multiEpgOpen)return
  val src=selectedSource?:return
  if(src.type=="e2")return
  val from=(center-7).coerceAtLeast(0);val to=(center+8).coerceAtMost(visibleChannels.size)
  for(i in from until to){
   val c=visibleChannels[i]
   val existing=multiEpgSchedules[c.url].orEmpty()
   if(existing.size>2||!multiEpgPending.add(c.url))continue
   longEpgPool.execute{
    try{
     val now=System.currentTimeMillis()
     var events=try{Api.epgSchedule(src,c)}catch(_:Exception){emptyList()}
     if(events.isEmpty())events=ExternalEpgStore.schedule(this,src,c)
     if(events.isEmpty())events=epgEvents[c.url].orEmpty()
     events=events.filter{it.endEpoch<=0L||it.endEpoch>now}
     if(events.isNotEmpty())multiEpgSchedules[c.url]=events
     runOnUiThread{if(multiEpgOpen&&selectedSource==src){multiEpgGrid.setSchedule(c.url,events)}}
    }finally{multiEpgPending.remove(c.url)}
   }
  }
 }

 private fun loadMultiEpgPicons(center:Int){
  if(!multiEpgOpen)return
  val src=selectedSource
  val from=(center-9).coerceAtLeast(0);val to=(center+10).coerceAtMost(visibleChannels.size)
  for(i in from until to){
   val c=visibleChannels[i];if(!multiEpgPicons.add(c.url))continue
   val pm=activePiconMode();val local=if(pm==0||pm==2)PiconRepository.find(this,c.name)else null
   if(local!=null){val channelKey=c.url;pool.execute{val cacheKey="local:${local.absolutePath}";val bm=PiconMemoryCache.get(cacheKey)?:PiconRepository.decodeScaled(local,160,100)?.also{PiconMemoryCache.put(cacheKey,it)};runOnUiThread{if(multiEpgOpen&&bm!=null)multiEpgGrid.setPicon(channelKey,bm)}};continue}
   if((pm==1||pm==2)&&c.logo.isNotBlank())pool.execute{try{val b=src?.let{Api.loadRemotePicon(it,c.logo)}?:URL(c.logo).openStream().use{it.readBytes()};val bm=BitmapFactory.decodeByteArray(b,0,b.size);runOnUiThread{if(multiEpgOpen)multiEpgGrid.setPicon(c.url,bm)}}catch(_:Exception){}}
  }
 }

 private fun updateMultiEpgInfo(channelIndex:Int,event:EpgEvent?){
  if(!multiEpgOpen)return
  val c=visibleChannels.getOrNull(channelIndex)?:return
  multiEpgReturnChannel=channelIndex
  multiEpgEventTitle.text=if(event==null)c.name else event.title
  multiEpgEventTime.text=if(event==null)"Ładowanie EPG…" else "${event.start}  –  ${event.end}"
  if(event!=null&&event.startEpoch>0&&event.endEpoch>event.startEpoch){val now=System.currentTimeMillis();multiEpgProgress.progress=(((now-event.startEpoch).coerceIn(0,event.endEpoch-event.startEpoch)*1000)/(event.endEpoch-event.startEpoch)).toInt()}else multiEpgProgress.progress=0
  setMultiEpgDescription(event?.description.orEmpty())
 }

 private fun setMultiEpgDescription(text:String){
  multiEpgDescToken++;val token=multiEpgDescToken;multiEpgDescAnimator?.cancel();multiEpgDescAnimator=null;multiEpgDesc.scrollTo(0,0);multiEpgDesc.text=text.ifBlank{"Brak szczegółowego opisu wydarzenia."}
  multiEpgDesc.post{
   if(token!=multiEpgDescToken)return@post
   multiEpgDesc.postDelayed({
    if(token!=multiEpgDescToken)return@postDelayed
    val layout=multiEpgDesc.layout?:return@postDelayed;val bottom=if(layout.lineCount>0)layout.getLineBottom(layout.lineCount-1)else 0;val visible=(multiEpgDesc.height-multiEpgDesc.compoundPaddingTop-multiEpgDesc.compoundPaddingBottom).coerceAtLeast(1);val maxScroll=(bottom-visible).coerceAtLeast(0)
    if(maxScroll<=0)return@postDelayed
    multiEpgDescAnimator=ValueAnimator.ofInt(0,maxScroll).apply{duration=(maxScroll*48L).coerceIn(3200L,22000L);interpolator=LinearInterpolator();addUpdateListener{a->if(token==multiEpgDescToken)multiEpgDesc.scrollTo(0,a.animatedValue as Int)};start()}
   },3000L)
  }
 }


 private fun scheduleLongEpgPrefetch(){
  if(!multiEpgOpen)return
  val src=selectedSource?:return
  if(src.type=="e2")return // E2 Multi-EPG pobieramy jednym zapytaniem dla bieżącej grupy.
  val channels=visibleChannels.toList();if(channels.isEmpty())return
  val limit=System.currentTimeMillis()+3L*24L*60L*60L*1000L
  longEpgPool.execute{
   for(c in channels){
    if(!multiEpgOpen||selectedSource!=src||screen!=Screen.LIVE_CHANNELS)break
    val now=System.currentTimeMillis()
    if(longEpgCache[c.url]?.any{it.endEpoch>now+6L*60L*60L*1000L}==true)continue
    if(!longEpgPending.add(c.url))continue
    try{
     var ev=try{Api.epgSchedule(src,c)}catch(_:Exception){emptyList()}
     if(ev.isEmpty())ev=ExternalEpgStore.schedule(this,src,c)
     val future=ev.filter{(it.endEpoch<=0L||it.endEpoch>now)&&(it.startEpoch<=0L||it.startEpoch<=limit)}
     if(future.isNotEmpty()){longEpgCache[c.url]=future;if(multiEpgOpen)runOnUiThread{if(multiEpgOpen&&selectedSource==src)multiEpgGrid.setSchedule(c.url,future)}}
    }finally{longEpgPending.remove(c.url)}
    try{Thread.sleep(350L)}catch(_:InterruptedException){break}
   }
  }
 }

 private fun recordingSourceMeta():Array<String>{val s=selectedSource?:return arrayOf("","","","","","","");return arrayOf(sourceScanKey(s),s.type,s.name,s.host,s.user,s.pass,s.url)}
 private fun showMultiEpgRecordDialog(channelIndex:Int,event:EpgEvent?){
  val c=visibleChannels.getOrNull(channelIndex)?:return
  if(event==null){Toast.makeText(this,"Brak danych wydarzenia",Toast.LENGTH_SHORT).show();return}
  if(event.startEpoch<=0L||event.endEpoch<=event.startEpoch){Toast.makeText(this,"Brak dokładnego czasu wydarzenia — nie można zaplanować nagrania.",Toast.LENGTH_LONG).show();return}
  val fmt=SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault())
  val whenText="${fmt.format(Date(event.startEpoch))} – ${fmt.format(Date(event.endEpoch))}"
  val msg=listOf(whenText,event.description.ifBlank{"Brak szczegółowego opisu."},"Nagrać wydarzenie?").joinToString("\n\n")
  TvMadDialogs.showConfirm(this,event.title,msg,onPositive={
   if(event.endEpoch>0L&&event.endEpoch<=System.currentTimeMillis()){
    Toast.makeText(this,"To wydarzenie już się zakończyło.",Toast.LENGTH_LONG).show()
   }else{
    val id="epg_${selectedSource?.let{sourceScanKey(it).hashCode()}?:0}_${c.url.hashCode()}_${event.startEpoch}_${event.title.hashCode()}"
    val sm=recordingSourceMeta();val r=TvRecording(id,event.title,c.name,event.description,c.url,Api.streamAuthHeader(selectedSource),event.startEpoch.takeIf{it>0L}?:System.currentTimeMillis(),event.endEpoch,sourceKey=sm[0],sourceType=sm[1],sourceName=sm[2],sourceHost=sm[3],sourceUser=sm[4],sourcePass=sm[5],sourceUrl=sm[6])
    if(RecordingStore.schedule(this,r))AlertDialog.Builder(this).setTitle("Zaplanowano nagranie").setMessage("${event.title}\n\n$whenText").setPositiveButton("OK",null).show()
    else Toast.makeText(this,"Nie udało się zaplanować nagrania.",Toast.LENGTH_LONG).show()
   }
  })
 }

 private fun toggleManualRecording(){
  val c=miniCurrentChannel?:return
  val active=RecordingStore.activeForUrl(this,c.url)
  if(active!=null){RecordingStore.stop(this,active.id);Toast.makeText(this,"Zatrzymywanie nagrywania…",Toast.LENGTH_SHORT).show();return}
  val now=epgEvents[c.url].orEmpty().firstOrNull()
  val title=now?.title?.takeIf{it.isNotBlank()}?:c.name
  val id="manual_${System.currentTimeMillis()}_${c.url.hashCode()}"
  val sm=recordingSourceMeta();val r=TvRecording(id,title,c.name,now?.description.orEmpty(),c.url,Api.streamAuthHeader(selectedSource),System.currentTimeMillis(),0L,active=true,sourceKey=sm[0],sourceType=sm[1],sourceName=sm[2],sourceHost=sm[3],sourceUser=sm[4],sourcePass=sm[5],sourceUrl=sm[6])
  try{RecordingStore.startNow(this,r);Toast.makeText(this,"Rozpoczęto nagrywanie: $title",Toast.LENGTH_LONG).show()}catch(e:Exception){RecordingStore.markStopped(this,id);Toast.makeText(this,"Nie udało się rozpocząć nagrywania.",Toast.LENGTH_LONG).show()}
  updateRecIndicator(true)
 }

 private var recBlink=false
 private fun updateRecIndicator(force:Boolean=false){
  if(!::fsRec.isInitialized)return
  val active=miniCurrentChannel?.let{RecordingService.isActiveUrl(it.url)}==true
  if(!active){fsRec.visibility=View.GONE;recBlink=false;return}
  recBlink=if(force)true else !recBlink;fsRec.visibility=if(recBlink)View.VISIBLE else View.INVISIBLE
 }

 private fun showRecordings(){
  val items=RecordingStore.completed(this).toMutableList()
  if(items.isEmpty()){AlertDialog.Builder(this).setTitle("Nagrania").setMessage("Brak zapisanych nagrań.").setPositiveButton("OK",null).show();return}
  val box=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(12),dp(8),dp(12),dp(8))}
  val lv=ListView(this);val desc=TextView(this).apply{setTextColor(0xFFD3DCE5.toInt());textSize=14f;setPadding(dp(14),dp(8),dp(8),dp(8))}
  fun label(r:TvRecording):String{val f=SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault()).format(Date(r.startEpoch));return "$f  •  ${r.channel}\n${r.title}"}
  fun refresh(){lv.adapter=TvListAdapter(this,items.map{label(it)},0);if(items.isNotEmpty()){lv.setSelection(0);desc.text=items[0].description.ifBlank{"Brak opisu wydarzenia."}}}
  box.addView(lv,LinearLayout.LayoutParams(0,dp(370),0.58f));box.addView(desc,LinearLayout.LayoutParams(0,dp(370),0.42f))
  val dlg=AlertDialog.Builder(this).setTitle("Nagrania").setView(box).setNegativeButton("Wróć",null).create()
  lv.setOnItemSelectedListener(object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){items.getOrNull(pos)?.let{desc.text=it.description.ifBlank{"Brak opisu wydarzenia."}}}})
  lv.setOnItemClickListener{_,_,pos,_->items.getOrNull(pos)?.let{r->if(java.io.File(r.filePath).exists()){dlg.dismiss();startActivity(Intent(this,PlayerActivity::class.java).putExtra("url",RecordingStore.fileUri(r).toString()).putExtra("name",r.title).putExtra("vod",true))}else Toast.makeText(this,"Plik nagrania nie istnieje.",Toast.LENGTH_LONG).show()}}
  lv.setOnItemLongClickListener{_,_,pos,_->val r=items.getOrNull(pos)?:return@setOnItemLongClickListener true;TvMadDialogs.showConfirm(this,"Usunąć nagranie?",r.title,onPositive={RecordingStore.remove(this,r.id);items.removeAt(pos);if(items.isEmpty()){dlg.dismiss();Toast.makeText(this,"Nagranie usunięto.",Toast.LENGTH_SHORT).show()}else{refresh();Toast.makeText(this,"Nagranie usunięto.",Toast.LENGTH_SHORT).show()}});true}
  refresh();dlg.show();lv.requestFocus()
 }

 private fun confirmExit(){
  if(exitConfirmDialog?.isShowing==true)return
  val dlg=TvMadDialogs.showConfirm(
   this,
   "Wyjść z TvMad-Xtream TV?",
   "Czy na pewno chcesz zamknąć aplikację?",
   onPositive={PhoneSplashActivity.closePhoneSplash();finishAndRemoveTask()}
  )
  exitConfirmDialog=dlg
  dlg.setOnDismissListener{if(exitConfirmDialog===dlg)exitConfirmDialog=null}
 }
 @Deprecated("Deprecated in Java") override fun onBackPressed(){if(liveGroupFilterPanelOpen){hideLiveGroupFilterPanel();return};if(vodSidePanelOpen){hideVodSidePanel(true);return};if(multiEpgOpen){closeMultiEpg();return};if(liveFullscreen){exitLiveFullscreen();return};when(screen){Screen.SOURCES->showHome("back-from-sources");Screen.HOME->confirmExit();Screen.LIVE_GROUPS->showHome("back-from-live-groups");Screen.LIVE_CHANNELS->showLiveGroups(liveGroupsPos);Screen.VOD_CATS->showHome("back-from-vod-cats");Screen.VOD_ITEMS,Screen.VOD_SEARCH,Screen.VOD_RECENT->renderVodCats(vodCatsPos);Screen.SERIES_CATS->showHome("back-from-series-cats");Screen.SERIES_ITEMS,Screen.SERIES_SEARCH,Screen.SERIES_RECENT->renderSeriesCats(seriesCatsPos);Screen.SEASONS->renderSeriesItems(seriesItemsPos);Screen.EPISODES->renderSeasons(seasonsPos);Screen.FAVORITES->showHome("back-from-favorites")}}
 override fun onResume(){super.onResume();normalizeUiDensity();AppScreenshotBridge.attach(this);ExternalInputBridge.attach(this);handler.removeCallbacks(liveProgressTick);handler.post(liveProgressTick);handler.removeCallbacks(recBlinkTick);handler.post(recBlinkTick);if(screen==Screen.VOD_ITEMS||screen==Screen.SERIES_ITEMS||screen==Screen.VOD_SEARCH||screen==Screen.SERIES_SEARCH||screen==Screen.VOD_RECENT||screen==Screen.SERIES_RECENT){posterGrid.post{posterGrid.requestFocus()}};if((screen==Screen.LIVE_CHANNELS||screen==Screen.LIVE_GROUPS)&&!liveFullscreen)miniCurrentChannel?.let{startMini(it)}}
 override fun onPause(){handler.removeCallbacks(liveProgressTick);handler.removeCallbacks(recBlinkTick);ExternalInputBridge.detach(this);AppScreenshotBridge.detach(this);super.onPause()}

 /**
  * Zmiana konfiguracji podczas LIVE to na Android TV normalna sytuacja: box przełącza
  * wyjście HDMI (rozdzielczość / odświeżanie / HDR) tuż po pierwszych klatkach nowego
  * kanału. Obsługujemy ją tutaj, żeby system NIE niszczył Activity — wcześniej takie
  * odtworzenie Activity uruchamiało onCreate -> startAtHome -> showHome i wyrzucało
  * widza z odtwarzania na planszę z trzema kaflami.
  */
 override fun onConfigurationChanged(newConfig:android.content.res.Configuration){
  super.onConfigurationChanged(newConfig)
  Log.i(LIVE_TAG,"onConfigurationChanged screen=$screen liveFullscreen=$liveFullscreen size=${resources.displayMetrics.widthPixels}x${resources.displayMetrics.heightPixels} — Activity NIE jest odtwarzane")
  normalizeUiDensity();resizeOverlayPanels()
  if(screen!=Screen.LIVE_CHANNELS&&screen!=Screen.LIVE_GROUPS)return
  // Powierzchnia wideo jest pozycjonowana w pikselach, więc po zmianie metryk ekranu
  // trzeba ją przeliczyć od nowa. Sam player i bieżący MediaItem zostają nietknięte.
  miniPlayerView.animate().cancel()
  rootFrame.post{
   liveSurfaceReady=false
   ensureStableLiveSurface()
   if(liveFullscreen){
    miniPlayerView.resizeMode=androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FILL
    miniPlayerView.x=0f;miniPlayerView.y=0f;miniPlayerView.scaleX=1f;miniPlayerView.scaleY=1f;liveSurfaceReady=true
    immersiveLive();miniPlayerView.bringToFront();liveFsInfo.bringToFront();liveBufferingBox.bringToFront()
   }else positionLiveSurfaceToMini(false)
  }
 }

 /** Panele nakładkowe mają szerokość liczoną z metryk ekranu, więc po zmianie trybu HDMI
  *  dostają te same proporcje co przy tworzeniu. Wygląd pozostaje bez zmian. */
 private fun resizeOverlayPanels(){
  val w=resources.displayMetrics.widthPixels
  fun width(view:View,fraction:Float){
   val lp=view.layoutParams as? FrameLayout.LayoutParams?:return
   val target=(w*fraction).toInt()
   if(lp.width!=target){lp.width=target;view.layoutParams=lp}
  }
  if(::liveChannelDrawer.isInitialized)width(liveChannelDrawer,0.36f)
  if(::liveGroupDrawer.isInitialized)width(liveGroupDrawer,0.23f)
  if(::liveGroupDrawer.isInitialized&&liveGroupDrawerOpen&&::liveChannelDrawer.isInitialized)liveChannelDrawer.x=liveGroupDrawer.layoutParams.width.toFloat()
  if(::liveTrackDrawer.isInitialized)width(liveTrackDrawer,0.34f)
  if(::vodSidePanel.isInitialized)width(vodSidePanel,0.40f)
  if(::liveGroupFilterPanel.isInitialized)width(liveGroupFilterPanel,0.34f)
 }

 override fun onDestroy(){Log.i(LIVE_TAG,"onDestroy isFinishing=$isFinishing isChangingConfigurations=$isChangingConfigurations screen=$screen liveFullscreen=$liveFullscreen");ExternalInputBridge.detach(this);exitConfirmDialog=null;releaseMini();web?.stop();piconAdapter?.close();handler.removeCallbacksAndMessages(null);pool.shutdownNow();piconPool.shutdownNow();epgPool.shutdownNow();longEpgPool.shutdownNow();catalogPool.shutdownNow();externalEpgPool.shutdownNow();super.onDestroy()}
}
