package pl.tvmad.xtream

import android.app.*
import android.os.*
import android.content.*
import android.text.InputType
import android.widget.*
import java.util.concurrent.Executors

class MainActivity:Activity(){
 private lateinit var list:ListView; private lateinit var status:TextView; private val pool=Executors.newSingleThreadExecutor()
 private var channels=listOf<Channel>(); private var groups=listOf<String>(); private var sources=mutableListOf<Source>(); private var selectedSource:Source?=null; private var piconMode=2
 private enum class Screen { SOURCES, GROUPS, CHANNELS }; private var screen=Screen.SOURCES

 override fun onCreate(b:Bundle?){
  super.onCreate(b); setContentView(R.layout.activity_main); list=findViewById(R.id.list); status=findViewById(R.id.status); sources=SourceStore.load(this)
  findViewById<Button>(R.id.addXtream).setOnClickListener{xtreamDialog()}; findViewById<Button>(R.id.addM3u).setOnClickListener{m3uDialog()}
  findViewById<Button>(R.id.piconMode).setOnClickListener{v->piconMode=(piconMode+1)%3;(v as Button).text="Picony: "+arrayOf("lokalne","źródło","oba")[piconMode]}
  list.setOnItemClickListener{_,_,i,_-> when(screen){
   Screen.SOURCES -> loadSource(sources[i])
   Screen.GROUPS -> showChannels(groups[i])
   Screen.CHANNELS -> startActivity(Intent(this,PlayerActivity::class.java).putExtra("url",channels[i].url).putExtra("name",channels[i].name))
  }}
  list.setOnItemLongClickListener{_,_,i,_-> if(screen==Screen.SOURCES){confirmDelete(i);true}else false}
  showSources()
 }

 private fun field(h:String)=EditText(this).apply{hint=h;setSingleLine(true)}
 private fun xtreamDialog(){
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,0,28,0)}; val n=field("Nazwa serwera, np. Dom"); val h=field("http://serwer:port"); val u=field("Użytkownik"); val p=field("Hasło").apply{inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
  box.addView(n);box.addView(h);box.addView(u);box.addView(p)
  AlertDialog.Builder(this).setTitle("Dodaj Xtream Codes").setView(box).setPositiveButton("Zapisz i wczytaj"){_,_->
   val host=h.text.toString().trim(); val src=Source("xtream", n.text.toString().trim().ifBlank{host}, host, u.text.toString(), p.text.toString()); saveAndLoad(src)
  }.setNegativeButton("Anuluj",null).show()
 }
 private fun m3uDialog(){
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,0,28,0)}; val n=field("Nazwa listy, np. IPTV"); val u=field("Pełny URL listy M3U"); box.addView(n);box.addView(u)
  AlertDialog.Builder(this).setTitle("Dodaj M3U").setView(box).setPositiveButton("Zapisz i wczytaj"){_,_-> val url=u.text.toString().trim(); saveAndLoad(Source("m3u",n.text.toString().trim().ifBlank{"M3U ${sources.size+1}"},url=url)) }.setNegativeButton("Anuluj",null).show()
 }
 private fun saveAndLoad(src:Source){
  val same=sources.indexOfFirst{it.type==src.type && ((src.type=="xtream"&&it.host==src.host&&it.user==src.user)||(src.type=="m3u"&&it.url==src.url))}
  if(same>=0) sources[same]=src else sources.add(src); SourceStore.save(this,sources); loadSource(src)
 }
 private fun confirmDelete(i:Int){ val s=sources[i]; AlertDialog.Builder(this).setTitle("Usunąć serwer?").setMessage(s.name).setPositiveButton("Usuń"){_,_->sources.removeAt(i);SourceStore.save(this,sources);showSources()}.setNegativeButton("Anuluj",null).show() }

 private fun showSources(){ screen=Screen.SOURCES; selectedSource=null; channels=emptyList(); status.text="Serwery: ${sources.size}  •  dotknij aby wczytać, przytrzymaj aby usunąć"; list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,sources.map{"${if(it.type=="xtream") "XCODES" else "M3U"}  •  ${it.name}"}) }
 private fun loadSource(src:Source){ selectedSource=src; status.text="Ładowanie ${src.name}…"; pool.execute{try{val x=if(src.type=="xtream")Api.xtream(src.host,src.user,src.pass)else Api.m3u(src.url);runOnUiThread{channels=x;showGroups()}}catch(e:Exception){runOnUiThread{status.text="Błąd: ${e.message}"}}} }
 private fun showGroups(){ screen=Screen.GROUPS; groups=channels.map{it.group.ifBlank{"Other"}}.distinct().sortedBy{it.lowercase()}; status.text="${selectedSource?.name ?: ""}  •  Live TV: ${groups.size} grup / ${channels.size} kanałów"; list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,groups.map{g->"$g   (${channels.count{it.group.ifBlank{"Other"}==g}})"}) }
 private fun showChannels(group:String){ screen=Screen.CHANNELS; val filtered=channels.filter{it.group.ifBlank{"Other"}==group}; channels=filtered; status.text="$group  •  ${filtered.size} kanałów"; list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,filtered.map{it.name}) }
 override fun onBackPressed(){ when(screen){Screen.CHANNELS -> loadSource(selectedSource ?: return); Screen.GROUPS -> showSources(); Screen.SOURCES -> super.onBackPressed()} }
}
