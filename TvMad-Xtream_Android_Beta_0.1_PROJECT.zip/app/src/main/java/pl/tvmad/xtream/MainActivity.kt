package pl.tvmad.xtream

import android.app.*
import android.os.*
import android.content.*
import android.graphics.BitmapFactory
import android.text.InputType
import android.view.*
import android.widget.*
import androidx.media3.common.*
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.common.util.UnstableApi
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@UnstableApi
class MainActivity:Activity(){
 private lateinit var list:ListView; private lateinit var channelList:ListView; private lateinit var posterGrid:GridView; private lateinit var status:TextView; private lateinit var sourceBar:View; private lateinit var dashboard:View; private lateinit var livePane:View; private lateinit var listPanel:View
 private lateinit var rootFrame:FrameLayout; private lateinit var baseContent:View; private lateinit var miniVideoSlot:View
 private lateinit var homeTimeBlock:View; private lateinit var homeServers:Button; private lateinit var homeClock:TextView; private lateinit var homeDay:TextView; private lateinit var homeDate:TextView; private lateinit var liveListCard:View
 private lateinit var miniPlayerView:PlayerView; private lateinit var miniPicon:ImageView; private lateinit var miniChannel:TextView; private lateinit var miniNow:TextView; private lateinit var miniDesc:TextView; private lateinit var miniProgress:ProgressBar
 private lateinit var liveFsInfo:View; private lateinit var fsNumber:TextView; private lateinit var fsPicon:ImageView; private lateinit var fsChannel:TextView; private lateinit var fsNow:TextView; private lateinit var fsNext:TextView; private lateinit var fsProgress:ProgressBar; private lateinit var fsAudio:Button; private lateinit var fsSubtitles:Button; private lateinit var fsClock:TextView; private lateinit var fsDate:TextView
 private lateinit var liveBufferingBox:View; private lateinit var liveBufferingText:TextView
 private val pool=Executors.newFixedThreadPool(2); private val epgPool=Executors.newFixedThreadPool(2); private val scanPool=Executors.newSingleThreadExecutor(); private val catalogPool=scanPool; private val externalEpgPool=Executors.newSingleThreadExecutor{r->Thread(r,"TvMad-XMLTV").apply{priority=Thread.NORM_PRIORITY}}; private val handler=Handler(Looper.getMainLooper())
 private var miniPlayer:ExoPlayer?=null; private var miniGeneration=0; private var miniCurrentChannel:Channel?=null; private var piconAdapter:PiconAdapter?=null; private var posterAdapter:PosterGridAdapter?=null
 private var visibleChannels=listOf<Channel>(); private var groups=listOf<LiveGroup>(); private var currentLiveGroup:LiveGroup?=null; private var sources=mutableListOf<Source>(); private var selectedSource:Source?=null; private var piconMode=2
 private var vodCats=listOf<MediaCategory>(); private var vodItems=listOf<MediaItem>(); private var currentVodCat:MediaCategory?=null
 private var seriesCats=listOf<MediaCategory>(); private var seriesItems=listOf<SeriesItem>(); private var currentSeriesCat:MediaCategory?=null; private var seasons=listOf<SeasonItem>(); private var seasonEpisodes:Map<String,List<EpisodeItem>> = emptyMap(); private var episodes=listOf<EpisodeItem>(); private var selectedSeries:SeriesItem?=null
 private var favorites=mutableListOf<Channel>(); private val epgText=ConcurrentHashMap<String,String>(); private val epgEvents=ConcurrentHashMap<String,List<EpgEvent>>(); private val epgPending=ConcurrentHashMap.newKeySet<String>()
 private var web:WebConfigServer?=null; private val catalogSyncing=ConcurrentHashMap.newKeySet<String>(); private val liveGroupsSyncing=ConcurrentHashMap.newKeySet<String>(); private val externalEpgSyncing=ConcurrentHashMap.newKeySet<String>()
 private enum class Screen { SOURCES, HOME, LIVE_GROUPS, LIVE_CHANNELS, VOD_CATS, VOD_ITEMS, SERIES_CATS, SERIES_ITEMS, SEASONS, EPISODES, FAVORITES }
 private var screen=Screen.SOURCES
 private data class Pos(val first:Int=0,val top:Int=0)
 private var liveGroupsPos=Pos();private var liveGroupSelected=0;private var liveGroupAnchorTop=0;private var liveChannelSelected=0;private var vodCatsPos=Pos();private var vodItemSelected=0;private var seriesCatsPos=Pos();private var seriesItemSelected=0;private var seriesItemsPos=Pos();private var seasonsPos=Pos()
 private var liveFullscreen=false;private var liveSurfaceReady=false;private var liveListenerInstalled=false;private var liveHasPlayed=false;private var liveRetryCount=0;private var liveRetryScheduled=false;private var suppressLiveBufferUntil=0L;private var liveRecoveryArmed=false
 private val hideLiveInfo=Runnable{if(liveFullscreen)liveFsInfo.visibility=View.GONE}
 private val liveProgressTick=object:Runnable{override fun run(){if(liveFullscreen)updateFullscreenInfo(miniCurrentChannel);handler.postDelayed(this,15000)}}
 private val liveBufferTick=object:Runnable{override fun run(){if(liveBufferingBox.visibility==View.VISIBLE){liveBufferingText.text="Buforowanie ${(miniPlayer?.bufferedPercentage?:0).coerceIn(0,100)}%";handler.postDelayed(this,250)}}}
 private val liveRetry=Runnable{liveRetryScheduled=false;if(liveBufferingBox.visibility==View.VISIBLE&&liveRetryCount<3){liveRetryCount++;LivePlayerSession.restartCurrent();scheduleLiveRetry()}}

 override fun onCreate(b:Bundle?){
  super.onCreate(b);setContentView(R.layout.activity_main)
  rootFrame=findViewById(R.id.rootFrame);baseContent=findViewById(R.id.baseContent);miniVideoSlot=findViewById(R.id.miniVideoSlot);homeTimeBlock=findViewById(R.id.homeTimeBlock);homeServers=findViewById(R.id.homeServers);homeClock=findViewById(R.id.homeClock);homeDay=findViewById(R.id.homeDay);homeDate=findViewById(R.id.homeDate);liveListCard=findViewById(R.id.liveListCard)
  list=findViewById(R.id.list);channelList=findViewById(R.id.channelList);posterGrid=findViewById(R.id.posterGrid);status=findViewById(R.id.status);sourceBar=findViewById(R.id.sourceBar);dashboard=findViewById(R.id.dashboard);livePane=findViewById(R.id.livePane);listPanel=findViewById(R.id.listPanel)
  miniPlayerView=findViewById(R.id.miniPlayer);miniPicon=findViewById(R.id.miniPicon);miniChannel=findViewById(R.id.miniChannel);miniNow=findViewById(R.id.miniNow);miniDesc=findViewById(R.id.miniDesc);miniProgress=findViewById(R.id.miniProgress)
  liveFsInfo=findViewById(R.id.liveFsInfo);fsNumber=findViewById(R.id.fsNumber);fsPicon=findViewById(R.id.fsPicon);fsChannel=findViewById(R.id.fsChannel);fsNow=findViewById(R.id.fsNow);fsNext=findViewById(R.id.fsNext);fsProgress=findViewById(R.id.fsProgress);fsAudio=findViewById(R.id.fsAudio);fsSubtitles=findViewById(R.id.fsSubtitles);fsClock=findViewById(R.id.fsClock);fsDate=findViewById(R.id.fsDate);liveBufferingBox=findViewById(R.id.liveBufferingBox);liveBufferingText=findViewById(R.id.liveBufferingText)
  miniPlayerView.useController=false;miniPlayerView.setKeepContentOnPlayerReset(true);miniPlayerView.resizeMode=androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
  fsAudio.setOnClickListener{showLiveTrackDialog(C.TRACK_TYPE_AUDIO,"Ścieżka audio")};fsSubtitles.setOnClickListener{showLiveTrackDialog(C.TRACK_TYPE_TEXT,"Napisy")}
  sources=SourceStore.load(this);favorites=FavoriteStore.load(this)
  findViewById<Button>(R.id.addXtream).setOnClickListener{xtreamDialog()};findViewById<Button>(R.id.addM3u).setOnClickListener{m3uDialog()};findViewById<Button>(R.id.addE2).setOnClickListener{e2Dialog()}
  findViewById<Button>(R.id.piconMode).setOnClickListener{v->piconMode=(piconMode+1)%3;(v as Button).text="Picony: "+arrayOf("lokalne","źródło","oba")[piconMode];if(screen==Screen.LIVE_CHANNELS||screen==Screen.FAVORITES)refreshChannelsAdapter()}
  homeServers.setOnClickListener{showSources()};findViewById<View>(R.id.tileLive).setOnClickListener{loadLive()};findViewById<View>(R.id.tileVod).setOnClickListener{loadVodCategories()};findViewById<View>(R.id.tileSeries).setOnClickListener{loadSeriesCategories()}
  list.setOnItemClickListener{_,_,i,_->onItem(i)};list.setOnItemLongClickListener{_,_,i,_->onLongItem(i)};posterGrid.setOnItemClickListener{_,_,i,_->onItem(i)};posterGrid.setOnItemSelectedListener(object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){if(screen==Screen.VOD_ITEMS)vodItemSelected=pos else if(screen==Screen.SERIES_ITEMS)seriesItemSelected=pos;updatePosterSelection(pos)}})
  channelList.setOnItemClickListener{_,_,i,_->onChannelItem(i)};channelList.setOnItemLongClickListener{_,_,i,_->if(screen==Screen.LIVE_CHANNELS&&i in visibleChannels.indices){showChannelOptions(visibleChannels[i]);true}else false}
  channelList.setOnItemSelectedListener(object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(p:AdapterView<*>?){};override fun onItemSelected(p:AdapterView<*>?,v:View?,pos:Int,id:Long){if(screen==Screen.LIVE_CHANNELS&&pos in visibleChannels.indices){updateMiniInfo(visibleChannels[pos]);loadVisibleEpg()}}})
  channelList.setOnKeyListener{_,key,e->if(e.action==KeyEvent.ACTION_DOWN&&(key==KeyEvent.KEYCODE_DPAD_CENTER||key==KeyEvent.KEYCODE_ENTER)){val pos=channelList.selectedItemPosition;if(pos>=0){onChannelItem(pos);true}else false}else false}
  web=WebConfigServer(applicationContext,5557){runOnUiThread{sources=SourceStore.load(this);selectedSource?.let{cur->sources.firstOrNull{sourceScanKey(it)==sourceScanKey(cur)}?.let{fresh->selectedSource=fresh;scheduleExternalEpgRefresh(fresh)}};if(screen==Screen.SOURCES)showSources();refreshChannelsAdapter()}}.also{it.start()}
  startAtHome()
 }


 private fun startAtHome(){
  val saved=LastLiveStore.load(this)
  val src=saved?.let{sv->sources.firstOrNull{LastLiveStore.sourceMatches(sv.source,it)}}?:sources.firstOrNull()
  selectedSource=src;visibleChannels=emptyList();currentLiveGroup=null
  if(src!=null){
   groups=LiveCacheStore.loadGroups(this,src).filterNot{it.name.equals("Other",true)}
  }else groups=emptyList()
  showHome()
  if(src!=null){
   if(groups.isEmpty()) scheduleLiveRefresh(src) else scheduleIdleRefresh(src)
   scheduleExternalEpgRefresh(src)
  }
 }

 private fun fetchAndCacheLiveGroups(src:Source):List<LiveGroup>{
  if(src.type=="m3u"){
   val catalog=Api.m3uCatalog(src.url)
   val fresh=catalog.groups.filterNot{it.name.equals("Other",true)}
   LiveCacheStore.saveGroups(this,src,fresh)
   val byGroup=catalog.channels.groupBy{it.group.lowercase(Locale.ROOT)}
   for(g in fresh){
    val rows=byGroup[g.name.lowercase(Locale.ROOT)].orEmpty().map{it.copy(group=g.name,groupId=g.id)}
    LiveCacheStore.saveGroupChannels(this,src,g,rows)
   }
   return fresh
  }
  val fresh=Api.liveGroups(src).filterNot{it.name.equals("Other",true)}
  LiveCacheStore.saveGroups(this,src,fresh)
  return fresh
 }

 private fun ensureLiveGroups(then:()->Unit){
  val src=selectedSource?:run{status.text="Najpierw wybierz serwer";showSources();return}
  if(groups.isNotEmpty()){then();return}
  val key=sourceScanKey(src)
  if(liveGroupsSyncing.contains(key)){handler.postDelayed({if(selectedSource==src)ensureLiveGroups(then)},250);return}
  status.text="Telewizja  •  ładowanie grup…"
  if(!liveGroupsSyncing.add(key))return
  scanPool.execute{
   try{
    val fresh=fetchAndCacheLiveGroups(src)
    runOnUiThread{if(selectedSource==src){groups=fresh;then()}}
   }catch(e:Exception){runOnUiThread{if(selectedSource==src)status.text="Telewizja  •  ${e.message.orEmpty()}"}}
   finally{liveGroupsSyncing.remove(key)}
  }
 }

 private fun findGroupFor(c:Channel):LiveGroup? {
  if(c.groupId.isNotBlank())groups.firstOrNull{it.id==c.groupId}?.let{return it}
  return groups.firstOrNull{it.name.equals(c.group,true)}
 }

 private fun openLastLiveOrGroups(){
  val src=selectedSource?:run{status.text="Najpierw wybierz serwer";showSources();return}
  ensureLiveGroups{
   val saved=LastLiveStore.load(this)
   val c=saved?.takeIf{LastLiveStore.sourceMatches(it.source,src)}?.channel
   val g=c?.let{findGroupFor(it)}
   if(c==null||g==null){showLiveGroups();return@ensureLiveGroups}
   liveGroupSelected=groups.indexOfFirst{it.id==g.id}.coerceAtLeast(0)
   // Po starcie ustawiamy grupę w okolicy środka listy, nie na początku wszystkich grup.
   liveGroupAnchorTop=(resources.displayMetrics.density*95f).toInt()
   openLiveGroup(g,c.url,true,c)
  }
 }

 private fun openLiveGroup(group:LiveGroup, selectUrl:String="", autoFullscreen:Boolean=false, fallbackChannel:Channel?=null){
  val src=selectedSource?:return
  currentLiveGroup=group
  val cached=LiveCacheStore.loadGroupChannels(this,src,group)
  if(cached.isNotEmpty()){
   showChannels(group,cached,selectUrl)
   scheduleGroupRefresh(src,group)
   if(autoFullscreen){
    val c=cached.firstOrNull{it.url==selectUrl}?:fallbackChannel
    if(c!=null)channelList.post{startMini(c);enterLiveFullscreen(c,false);loadEpgForChannels(listOf(c))}
   }
   return
  }
  if(src.type=="m3u"&&liveGroupsSyncing.contains(sourceScanKey(src))){
   status.text="${group.name}  •  kończenie lekkiego skanu…"
   handler.postDelayed({if(selectedSource==src&&currentLiveGroup?.id==group.id)openLiveGroup(group,selectUrl,autoFullscreen,fallbackChannel)},250)
   return
  }
  screen=Screen.LIVE_CHANNELS;applyTheme(2);setMode(live=true);visibleChannels=emptyList();refreshChannelsAdapter(false)
  status.text="${group.name}  •  ładowanie kanałów…"
  pool.execute{
   try{
    val actualGroup:LiveGroup
    val fresh:List<Channel>
    if(src.type=="m3u"){
     val freshGroups=fetchAndCacheLiveGroups(src)
     actualGroup=freshGroups.firstOrNull{it.id==group.id}?:freshGroups.firstOrNull{it.name.equals(group.name,true)}?:group
     fresh=LiveCacheStore.loadGroupChannels(this,src,actualGroup)
     runOnUiThread{if(selectedSource==src)groups=freshGroups}
    }else{
     actualGroup=group;fresh=Api.liveChannels(src,group);LiveCacheStore.saveGroupChannels(this,src,group,fresh)
    }
    runOnUiThread{
     if(selectedSource==src&&currentLiveGroup?.id==group.id){
      currentLiveGroup=actualGroup;liveGroupSelected=groups.indexOfFirst{it.id==actualGroup.id}.takeIf{it>=0}?:liveGroupSelected
      showChannels(actualGroup,fresh,selectUrl)
      if(autoFullscreen){
       val c=fresh.firstOrNull{it.url==selectUrl}?:fallbackChannel
       if(c!=null)channelList.post{startMini(c);enterLiveFullscreen(c,false);loadEpgForChannels(listOf(c))}
      }
     }
    }
   }catch(e:Exception){runOnUiThread{if(selectedSource==src&&currentLiveGroup?.id==group.id)status.text="${group.name}  •  ${e.message.orEmpty()}"}}
  }
 }

 private fun scheduleGroupRefresh(src:Source,group:LiveGroup){
  if(src.type!="xtream"&&src.type!="e2")return
  pool.execute{try{LiveCacheStore.saveGroupChannels(this,src,group,Api.liveChannels(src,group))}catch(_:Exception){}}
 }

 private fun currentList():ListView=if(screen==Screen.LIVE_CHANNELS||screen==Screen.LIVE_GROUPS)channelList else list
 private fun position():Pos{val l:AbsListView=if(screen==Screen.VOD_ITEMS||screen==Screen.SERIES_ITEMS)posterGrid else currentList();return if(l.childCount>0)Pos(l.firstVisiblePosition,l.getChildAt(0).top)else Pos()}
 private fun restore(p:Pos){val l:AbsListView=if(screen==Screen.VOD_ITEMS||screen==Screen.SERIES_ITEMS)posterGrid else currentList();l.post{l.setSelectionFromTop(p.first,p.top)}}
 private fun setMode(sourcesMode:Boolean=false,home:Boolean=false,live:Boolean=false){sourceBar.visibility=if(sourcesMode)View.VISIBLE else View.GONE;dashboard.visibility=if(home)View.VISIBLE else View.GONE;homeServers.visibility=if(home)View.VISIBLE else View.GONE;homeTimeBlock.visibility=View.VISIBLE;updateClocks();livePane.visibility=if(live)View.VISIBLE else View.GONE;listPanel.visibility=if(!home&&!live)View.VISIBLE else View.GONE;val posters=!home&&!live&&(screen==Screen.VOD_ITEMS||screen==Screen.SERIES_ITEMS);posterGrid.visibility=if(posters)View.VISIBLE else View.GONE;list.visibility=if(!home&&!live&&!posters)View.VISIBLE else View.GONE}
 private fun updatePosterSelection(pos:Int){posterAdapter?.setSelectedPosition(pos);val first=posterGrid.firstVisiblePosition;for(i in 0 until posterGrid.childCount){val child=posterGrid.getChildAt(i);val selected=(first+i)==pos;child.isSelected=selected;val vg=child as? ViewGroup;val titleView=vg?.getChildAt(1) as? TextView;titleView?.isSelected=selected}}
 private fun applyTheme(kind:Int){val bg=when(kind){1->R.drawable.bg_home_premium;2->R.drawable.bg_live_premium;3->R.drawable.bg_vod_premium;4->R.drawable.bg_series_premium;else->R.drawable.bg_root};rootFrame.setBackgroundResource(bg);listPanel.setBackgroundResource(when(kind){2->R.drawable.panel_live_glass;3->R.drawable.panel_vod_glass;4->R.drawable.panel_series_glass;else->R.drawable.panel_glass});liveListCard.setBackgroundResource(R.drawable.panel_live_glass)}
 private fun updateClocks(){val now=Date();homeClock.text=SimpleDateFormat("HH:mm",Locale.getDefault()).format(now);homeDay.text=SimpleDateFormat("EEEE",Locale.getDefault()).format(now).replaceFirstChar{if(it.isLowerCase())it.titlecase(Locale.getDefault()) else it.toString()};homeDate.text=SimpleDateFormat("d MMM yyyy",Locale.getDefault()).format(now);fsClock.text=SimpleDateFormat("HH:mm",Locale.getDefault()).format(now);fsDate.text=SimpleDateFormat("d MMM yyyy",Locale.getDefault()).format(now)}
 private fun field(h:String)=EditText(this).apply{hint=h;setSingleLine(true)}
 private fun xtreamDialog(){val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,0,28,0)};val n=field("Nazwa serwera, np. Dom");val h=field("http://serwer:port");val u=field("Użytkownik");val p=field("Hasło").apply{inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD};val e=field("Dodatkowe EPG XMLTV URL (.xml lub .gz)");listOf(n,h,u,p,e).forEach{box.addView(it)};AlertDialog.Builder(this).setTitle("Dodaj Xtream Codes").setView(box).setPositiveButton("Zapisz i wczytaj"){_,_->val host=h.text.toString().trim();saveAndLoad(Source("xtream",n.text.toString().trim().ifBlank{host},host,u.text.toString(),p.text.toString(),epgUrl=e.text.toString().trim()))}.setNegativeButton("Anuluj",null).show()}
 private fun m3uDialog(){val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,0,28,0)};val n=field("Nazwa listy");val u=field("Pełny URL listy M3U");val e=field("Dodatkowe EPG XMLTV URL (.xml lub .gz)");listOf(n,u,e).forEach{box.addView(it)};AlertDialog.Builder(this).setTitle("Dodaj M3U").setView(box).setPositiveButton("Zapisz i wczytaj"){_,_->val url=u.text.toString().trim();saveAndLoad(Source("m3u",n.text.toString().trim().ifBlank{"M3U ${sources.size+1}"},url=url,epgUrl=e.text.toString().trim()))}.setNegativeButton("Anuluj",null).show()}

 private fun e2Dialog(){
  val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,0,28,0)}
  val n=field("Nazwa dekodera, np. SF8008");val h=field("IP / host, np. 192.168.8.115")
  val wp=field("Port OpenWebIF (domyślnie 80)").apply{inputType=InputType.TYPE_CLASS_NUMBER;setText("80")}
  val sp=field("Port streamu (domyślnie 8001)").apply{inputType=InputType.TYPE_CLASS_NUMBER;setText("8001")}
  val u=field("Użytkownik OpenWebIF (np. root)");val pa=field("Hasło OpenWebIF").apply{inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD}
  val zap=CheckBox(this).apply{text="Przełączaj kanał także na dekoderze (ZAP)";isChecked=false}
  val piconLabel=TextView(this).apply{text="Picony Enigma2:";setPadding(0,12,0,0)}
  val picons=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("Z WebInterface Enigma2","Lokalne TvMad"));setSelection(0)}
  listOf<View>(n,h,wp,sp,u,pa,zap,piconLabel,picons).forEach{box.addView(it)}
  val dlg=AlertDialog.Builder(this).setTitle("Dodaj Enigma2 / OpenWebIF").setView(box).setPositiveButton("Zapisz i wczytaj",null).setNeutralButton("Test połączenia",null).setNegativeButton("Anuluj",null).create()
  dlg.setOnShowListener{
   fun value()=Source("e2",n.text.toString().trim().ifBlank{h.text.toString().trim()},h.text.toString().trim(),u.text.toString().trim(),pa.text.toString(),webPort=wp.text.toString().toIntOrNull()?:80,streamPort=sp.text.toString().toIntOrNull()?:8001,e2ZapOnBox=zap.isChecked,e2PiconSource=if(picons.selectedItemPosition==1)"local" else "web")
   dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener{val src=value();pool.execute{try{val r=Api.e2Test(src);runOnUiThread{wp.setText(r.source.webPort.toString());Toast.makeText(this,r.message,Toast.LENGTH_LONG).show()}}catch(e:Exception){runOnUiThread{Toast.makeText(this,e.message?:"Brak połączenia",Toast.LENGTH_LONG).show()}}}}
   dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{val src=value();pool.execute{try{val r=Api.e2Test(src);runOnUiThread{wp.setText(r.source.webPort.toString());dlg.dismiss();saveAndLoad(r.source)}}catch(e:Exception){runOnUiThread{Toast.makeText(this,e.message?:"Brak połączenia",Toast.LENGTH_LONG).show()}}}}
  };dlg.show()
 }
 private fun editSource(i:Int){if(i !in sources.indices)return;val old=sources[i];val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(28,0,28,0)}
  if(old.type=="xtream"){val n=field("Nazwa serwera").apply{setText(old.name)};val h=field("http://serwer:port").apply{setText(old.host)};val u=field("Użytkownik").apply{setText(old.user)};val p=field("Hasło").apply{inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD;setText(old.pass)};val e=field("Dodatkowe EPG XMLTV URL (.xml lub .gz)").apply{setText(old.epgUrl)};listOf(n,h,u,p,e).forEach{box.addView(it)};AlertDialog.Builder(this).setTitle("Edytuj Xtream Codes").setView(box).setPositiveButton("Zapisz"){_,_->val host=h.text.toString().trim();val updated=old.copy(name=n.text.toString().trim().ifBlank{host},host=host,user=u.text.toString(),pass=p.text.toString(),epgUrl=e.text.toString().trim());sources[i]=updated;SourceStore.save(this,sources);if(sourceScanKey(selectedSource?:old)==sourceScanKey(old))selectedSource=updated;showSources()}.setNegativeButton("Anuluj",null).show()}
  else if(old.type=="e2"){
   val n=field("Nazwa dekodera").apply{setText(old.name)};val h=field("IP / host").apply{setText(old.host)};val wp=field("Port OpenWebIF").apply{inputType=InputType.TYPE_CLASS_NUMBER;setText(old.webPort.toString())};val sp=field("Port streamu").apply{inputType=InputType.TYPE_CLASS_NUMBER;setText(old.streamPort.toString())};val u=field("Użytkownik OpenWebIF").apply{setText(old.user)};val pa=field("Hasło OpenWebIF").apply{inputType=InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD;setText(old.pass)}
   val zap=CheckBox(this).apply{text="Przełączaj kanał także na dekoderze (ZAP)";isChecked=old.e2ZapOnBox}
   val piconLabel=TextView(this).apply{text="Picony Enigma2:";setPadding(0,12,0,0)};val picons=Spinner(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_spinner_dropdown_item,arrayOf("Z WebInterface Enigma2","Lokalne TvMad"));setSelection(if(old.e2PiconSource.equals("local",true))1 else 0)}
   listOf<View>(n,h,wp,sp,u,pa,zap,piconLabel,picons).forEach{box.addView(it)}
   val dlg=AlertDialog.Builder(this).setTitle("Edytuj Enigma2 / OpenWebIF").setView(box).setPositiveButton("Zapisz",null).setNeutralButton("Test połączenia",null).setNegativeButton("Anuluj",null).create()
   dlg.setOnShowListener{
    fun value()=old.copy(name=n.text.toString().trim().ifBlank{h.text.toString().trim()},host=h.text.toString().trim(),user=u.text.toString().trim(),pass=pa.text.toString(),webPort=wp.text.toString().toIntOrNull()?:80,streamPort=sp.text.toString().toIntOrNull()?:8001,e2ZapOnBox=zap.isChecked,e2PiconSource=if(picons.selectedItemPosition==1)"local" else "web")
    dlg.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener{val src=value();pool.execute{try{val r=Api.e2Test(src);runOnUiThread{wp.setText(r.source.webPort.toString());Toast.makeText(this,r.message,Toast.LENGTH_LONG).show()}}catch(e:Exception){runOnUiThread{Toast.makeText(this,e.message?:"Brak połączenia",Toast.LENGTH_LONG).show()}}}}
    dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{val src=value();pool.execute{try{val r=Api.e2Test(src);runOnUiThread{val updated=r.source;sources[i]=updated;SourceStore.save(this,sources);if(sourceScanKey(selectedSource?:old)==sourceScanKey(old))selectedSource=updated;dlg.dismiss();showSources()}}catch(e:Exception){runOnUiThread{Toast.makeText(this,e.message?:"Brak połączenia",Toast.LENGTH_LONG).show()}}}}
   };dlg.show()
  }
  else{val n=field("Nazwa listy").apply{setText(old.name)};val u=field("Pełny URL listy M3U").apply{setText(old.url)};val e=field("Dodatkowe EPG XMLTV URL (.xml lub .gz)").apply{setText(old.epgUrl)};listOf(n,u,e).forEach{box.addView(it)};AlertDialog.Builder(this).setTitle("Edytuj M3U").setView(box).setPositiveButton("Zapisz"){_,_->val url=u.text.toString().trim();val updated=old.copy(name=n.text.toString().trim().ifBlank{"M3U"},url=url,epgUrl=e.text.toString().trim());sources[i]=updated;SourceStore.save(this,sources);if(sourceScanKey(selectedSource?:old)==sourceScanKey(old))selectedSource=updated;showSources()}.setNegativeButton("Anuluj",null).show()}
 }
 private fun showSourceOptions(i:Int){if(i !in sources.indices)return;val s=sources[i];AlertDialog.Builder(this).setTitle(s.name).setItems(arrayOf("Edytuj","Usuń")){_,which->if(which==0)editSource(i)else confirmDelete(i)}.setNegativeButton("Anuluj",null).show()}
 private fun saveAndLoad(src:Source){val same=sources.indexOfFirst{sourceScanKey(it)==sourceScanKey(src)};val saved=if(same>=0&&src.epgUrl.isBlank())src.copy(epgUrl=sources[same].epgUrl,expiry=sources[same].expiry) else src;if(same>=0)sources[same]=saved else sources.add(saved);SourceStore.save(this,sources);loadSource(saved)}
 private fun firstScanPrefs()=getSharedPreferences("first_server_scan_v1",Context.MODE_PRIVATE)
 private fun firstScanDone(src:Source)=firstScanPrefs().getBoolean(sourceScanKey(src),false)
 private fun markFirstScanDone(src:Source){firstScanPrefs().edit().putBoolean(sourceScanKey(src),true).apply()}
 private fun runFirstServerScan(src:Source){
  selectedSource=src;epgText.clear();epgEvents.clear();epgPending.clear();visibleChannels=emptyList();currentLiveGroup=null
  showSources()
  val dlg=AlertDialog.Builder(this).setTitle("Pierwsze skanowanie serwera...").setMessage("Proszę czekać.").setCancelable(false).create();dlg.show()
  val key=sourceScanKey(src);if(!liveGroupsSyncing.add(key)){dlg.dismiss();return}
  scanPool.execute{
   var liveCount=0;var vodCatCount=0;var seriesCatCount=0;var liveGroups=emptyList<LiveGroup>()
   try{
    liveGroups=fetchAndCacheLiveGroups(src)
    if(src.type=="m3u"){for(g in liveGroups)liveCount+=LiveCacheStore.loadGroupChannels(this,src,g).size}
    else{for(g in liveGroups){try{val rows=Api.liveChannels(src,g);LiveCacheStore.saveGroupChannels(this,src,g,rows);liveCount+=rows.size}catch(_:Exception){}}}
    if(Api.xtreamParams(src)!=null){
     try{val v=Api.vodCategories(src);CatalogCacheStore.saveVodCategories(this,src,v);vodCatCount=v.size}catch(_:Exception){}
     try{val se=Api.seriesCategories(src);CatalogCacheStore.saveSeriesCategories(this,src,se);seriesCatCount=se.size}catch(_:Exception){}
    }
    markFirstScanDone(src)
    runOnUiThread{
     if(selectedSource==src){groups=liveGroups}
     if(dlg.isShowing){dlg.setTitle("Skanowanie zakończone");dlg.setMessage("Kanały LIVE: $liveCount\nKategorie VOD: $vodCatCount\nKategorie seriali: $seriesCatCount")
      handler.postDelayed({if(dlg.isShowing)dlg.dismiss();if(selectedSource==src){showSources();scheduleExternalEpgRefresh(src)}},2200L)}
    }
   }catch(e:Exception){
    runOnUiThread{if(dlg.isShowing){dlg.setTitle("Skanowanie zakończone");dlg.setMessage("Nie udało się dokończyć pierwszego skanu.\n${e.message.orEmpty()}");handler.postDelayed({if(dlg.isShowing)dlg.dismiss();showSources()},2600L)}}
   }finally{liveGroupsSyncing.remove(key)}
  }
 }
 private fun confirmDelete(i:Int){val s=sources[i];AlertDialog.Builder(this).setTitle("Usunąć serwer?").setMessage(s.name).setPositiveButton("Usuń"){_,_->sources.removeAt(i);SourceStore.save(this,sources);showSources()}.setNegativeButton("Anuluj",null).show()}
 private fun showSources(){releaseMini();miniCurrentChannel=null;screen=Screen.SOURCES;visibleChannels=emptyList();applyTheme(0);setMode(sourcesMode=true);val addr=web?.address()?.removePrefix("http://")?:"IP urządzenia:5557";status.text="WebInfo: $addr  •  dodawanie serwerów z telefonu/PC przez IP i port";list.adapter=TvListAdapter(this,sources.map{val kind=when(it.type){"xtream"->"XCODES";"e2"->"ENIGMA2";else->"M3U"};val exp=it.expiry.takeIf{x->x.isNotBlank()}?.let{x->"  •  ważny do: $x"}.orEmpty();"$kind  •  ${it.name}$exp"},0);list.requestFocus();refreshSourceExpiries()}
 private fun loadSource(src:Source){
  if(!firstScanDone(src)){runFirstServerScan(src);return}
  selectedSource=src;epgText.clear();epgEvents.clear();epgPending.clear();visibleChannels=emptyList();currentLiveGroup=null
  groups=LiveCacheStore.loadGroups(this,src).filterNot{it.name.equals("Other",true)}
  showHome()
  scheduleExternalEpgRefresh(src)
  if(groups.isEmpty()){status.text="${src.name}  •  trwa lekki skan grup w tle";scheduleLiveRefresh(src)} else scheduleIdleRefresh(src)
 }

 private fun refreshSourceExpiries(){val snap=sources.toList();snap.forEach{src->if(src.type!="e2")pool.execute{val exp=Api.accountExpiry(src);if(exp.isNotBlank()&&exp!=src.expiry)runOnUiThread{val i=sources.indexOfFirst{sourceScanKey(it)==sourceScanKey(src)};if(i>=0){sources[i]=sources[i].copy(expiry=exp);SourceStore.save(this,sources);if(screen==Screen.SOURCES)showSources()}}}}}
 private fun sourceScanKey(src:Source)=when(src.type){"xtream"->"x|${src.host}|${src.user}";"e2"->"e2|${src.host}|${src.webPort}|${src.streamPort}|${src.user}";else->"m|${src.url}"}
 private fun scheduleIdleRefresh(src:Source){
  // Na słabszych Android Boxach nie skanujemy dużych list równolegle ze startem UI/playera.
  // Cichy refresh rusza dopiero po chwili i tylko gdy użytkownik nadal jest na ekranie głównym.
  handler.postDelayed({
   if(selectedSource==src && screen==Screen.HOME){scheduleLiveRefresh(src);scheduleCatalogSync(src)}
  },45000L)
 }
 private fun scheduleLiveRefresh(src:Source){
  if(groups.isNotEmpty()&&LiveCacheStore.groupsAgeMs(this,src)<30L*60L*1000L)return
  val key=sourceScanKey(src);if(!liveGroupsSyncing.add(key))return
  scanPool.execute{
   try{
    val fresh=fetchAndCacheLiveGroups(src)
    runOnUiThread{if(selectedSource==src&&groups.isEmpty()){groups=fresh;if(screen==Screen.HOME)status.text="${src.name}  •  wybierz dział"};if(selectedSource==src)scheduleExternalEpgRefresh(src)}
   }catch(_:Exception){}
   finally{liveGroupsSyncing.remove(key)}
  }
 }
 private fun scheduleCatalogSync(src:Source){
  if(Api.xtreamParams(src)==null)return
  val k=sourceScanKey(src);if(!catalogSyncing.add(k))return
  catalogPool.execute{
   try{
    // Lekki skan: tylko kategorie. Nie pobieramy całych bibliotek VOD/seriali przy starcie,
    // bo na słabszych boxach powodowało to skoki pamięci i crashe podczas LIVE.
    try{CatalogCacheStore.saveVodCategories(this,src,Api.vodCategories(src))}catch(_:Exception){}
    try{CatalogCacheStore.saveSeriesCategories(this,src,Api.seriesCategories(src))}catch(_:Exception){}
   }finally{catalogSyncing.remove(k)}
  }
 }
 private fun showHome(){releaseMini();screen=Screen.HOME;applyTheme(1);setMode(home=true);updateClocks();status.text="${selectedSource?.name?.takeIf{it.isNotBlank()}?:"Brak wybranego serwera"}  •  wybierz dział";findViewById<View>(R.id.tileLive).requestFocus()}
 private fun loadLive(){openLastLiveOrGroups()}
 private fun showLiveGroups(restorePos:Pos?=null){
  screen=Screen.LIVE_GROUPS;applyTheme(2);setMode(live=true);visibleChannels=emptyList();currentLiveGroup=null;piconAdapter?.close();piconAdapter=null
  groups=groups.filterNot{it.name.equals("Other",true)}
  status.text="Telewizja  •  ${groups.size} grup  •  OK = wejdź do grupy"
  channelList.adapter=TvListAdapter(this,groups.map{it.name},0)
  channelList.setOnScrollListener(null)
  channelList.post{
   channelList.clearChoices();channelList.choiceMode=AbsListView.CHOICE_MODE_NONE
   if(groups.isNotEmpty()){
    val idx=liveGroupSelected.coerceIn(0,groups.lastIndex)
    val top=if(restorePos!=null)liveGroupAnchorTop else (resources.displayMetrics.density*95f).toInt()
    channelList.setSelectionFromTop(idx,top)
   }
   channelList.requestFocus()
  }
  miniCurrentChannel?.let{c->updateMiniInfo(c);loadEpgForChannels(listOf(c));startMini(c)}
 }

 private fun showChannels(group:LiveGroup,channels:List<Channel>,selectUrl:String=""){
  screen=Screen.LIVE_CHANNELS;currentLiveGroup=group;applyTheme(2);setMode(live=true)
  // Zasada twarda: lista dostaje WYŁĄCZNIE kanały pobrane/zapisane dla tej jednej kategorii.
  visibleChannels=channels.filter{it.groupId==group.id || (it.groupId.isBlank()&&it.group.equals(group.name,true))}
  // Gdy użytkownik wchodzi do LIVE, zewnętrzne XMLTV ma być gotowe możliwie od razu.
  // Jeśli cache jest świeży, refreshIfDue kończy się natychmiast. Jeśli URL jest nowy
  // albo minęły 24 h, skan startuje od razu (bez dawnego 8-sekundowego opóźnienia).
  selectedSource?.let { scheduleExternalEpgRefresh(it,true) }
  status.text="${group.name}  •  ${visibleChannels.size} kanałów  •  OK = pełny ekran, przytrzymaj = opcje"
  if(selectUrl.isNotBlank())liveChannelSelected=visibleChannels.indexOfFirst{it.url==selectUrl}.takeIf{it>=0}?:liveChannelSelected
  if(visibleChannels.isNotEmpty())liveChannelSelected=liveChannelSelected.coerceIn(0,visibleChannels.lastIndex) else liveChannelSelected=0
  refreshChannelsAdapter(false);channelList.clearChoices();channelList.choiceMode=AbsListView.CHOICE_MODE_NONE
  channelList.setOnScrollListener(object:AbsListView.OnScrollListener{override fun onScrollStateChanged(v:AbsListView?,state:Int){if(state==AbsListView.OnScrollListener.SCROLL_STATE_IDLE)loadVisibleEpg()};override fun onScroll(v:AbsListView?,first:Int,count:Int,total:Int){}})
  channelList.post{
   if(visibleChannels.isNotEmpty()){channelList.setSelection(liveChannelSelected);updateMiniInfo(visibleChannels[liveChannelSelected]);loadVisibleEpg()}
   channelList.requestFocus()
  }
  miniCurrentChannel?.takeIf{c->visibleChannels.any{it.url==c.url}}?.let{startMini(it)}
 }

 private fun loadVisibleEpg(){if(screen!=Screen.LIVE_CHANNELS)return;val first=channelList.firstVisiblePosition.coerceAtLeast(0);val count=channelList.childCount.coerceAtLeast(8);val from=(first-3).coerceAtLeast(0);val to=(first+count+6).coerceAtMost(visibleChannels.size);if(from<to)loadEpgForChannels(visibleChannels.subList(from,to))}
 private fun activePiconMode():Int = selectedSource?.takeIf{it.type=="e2"}?.let{if(it.e2PiconSource.equals("local",true))0 else 1} ?: piconMode
 private fun refreshChannelsAdapter(preserve:Boolean=true){if(screen!=Screen.LIVE_CHANNELS&&screen!=Screen.FAVORITES)return;val p=if(preserve)position()else Pos();val items=if(screen==Screen.FAVORITES)favorites else visibleChannels;piconAdapter?.close();piconAdapter=PiconAdapter(this,items,epgText,epgEvents,activePiconMode(),selectedSource);currentList().adapter=piconAdapter;if(preserve)restore(p)}

 private val refreshScheduled=AtomicBoolean(false)
 private fun scheduleEpgUiRefresh(){if(refreshScheduled.compareAndSet(false,true)){handler.postDelayed({refreshScheduled.set(false);if(screen==Screen.LIVE_CHANNELS||screen==Screen.FAVORITES)piconAdapter?.notifyDataSetChanged();if(screen==Screen.LIVE_CHANNELS){val pos=channelList.selectedItemPosition;if(pos in visibleChannels.indices)updateMiniInfo(visibleChannels[pos])}else if(screen==Screen.LIVE_GROUPS){miniCurrentChannel?.let{updateMiniInfo(it)}};if(liveFullscreen)updateFullscreenInfo(miniCurrentChannel)},180)}}
 private fun loadEpgForChannels(items:List<Channel>){
  val src=selectedSource?:return
  items.forEach { c ->
   if(!epgText.containsKey(c.url) && epgPending.add(c.url)){
    epgPool.execute {
     try {
      var ev=Api.epgNowNext(src,c)
      if(ev.isEmpty())ev=ExternalEpgStore.nowNext(this,src,c)
      if(ev.isNotEmpty()){
       epgEvents[c.url]=ev
       if(miniCurrentChannel?.url==c.url)LiveCacheStore.saveLastEpg(this,src,c,ev)
       val e=ev.first()
       val times=if(e.start.isNotBlank()||e.end.isNotBlank()) "${e.start} - ${e.end}  " else ""
       epgText[c.url]="$times${e.title}"
      }
     } finally {
      epgPending.remove(c.url)
      scheduleEpgUiRefresh()
     }
    }
   }
  }
 }

 private fun scheduleExternalEpgRefresh(src:Source,immediate:Boolean=false){
  if(!ExternalEpgStore.isConfigured(src))return
  val key=sourceScanKey(src)+"|"+src.epgUrl
  val runScan={
   if(externalEpgSyncing.add(key)){
    externalEpgPool.execute{
     try{
      val changed=ExternalEpgStore.refreshIfDue(this,src)
      if(changed)runOnUiThread{
       if(selectedSource?.let{sourceScanKey(it)}==sourceScanKey(src)){
        val affected=(visibleChannels + listOfNotNull(miniCurrentChannel)).distinctBy{it.url}
        affected.forEach{c->epgText.remove(c.url);epgEvents.remove(c.url);epgPending.remove(c.url)}
        if(screen==Screen.LIVE_CHANNELS&&visibleChannels.isNotEmpty())loadVisibleEpg()
        miniCurrentChannel?.let{loadEpgForChannels(listOf(it))}
       }
      }
     }catch(_:Exception){}finally{externalEpgSyncing.remove(key)}
    }
   }
  }
  if(immediate)runScan() else handler.postDelayed({runScan()},8000L)
 }

 private fun updateMiniInfo(c:Channel){miniChannel.text=c.name;val ev=epgEvents[c.url].orEmpty();val now=ev.firstOrNull();miniNow.text=if(now==null)epgText[c.url].orEmpty() else (if(now.start.isNotBlank()||now.end.isNotBlank())"${now.start} - ${now.end}  " else "")+now.title;miniDesc.text=now?.description.orEmpty();if(now!=null&&now.startEpoch>0&&now.endEpoch>now.startEpoch){val n=System.currentTimeMillis();miniProgress.progress=(((n-now.startEpoch).coerceIn(0,now.endEpoch-now.startEpoch)*1000)/(now.endEpoch-now.startEpoch)).toInt()}else miniProgress.progress=0;loadMiniPicon(c)}
 private fun loadMiniPicon(c:Channel){miniPicon.setImageDrawable(null);val pm=activePiconMode();val local=if(pm==0||pm==2)PiconRepository.find(this,c.name)else null;if(local!=null){miniPicon.setImageBitmap(BitmapFactory.decodeFile(local.absolutePath));return};if((pm==1||pm==2)&&c.logo.isNotBlank())pool.execute{try{val b=selectedSource?.let{Api.loadRemotePicon(it,c.logo)}?:URL(c.logo).openStream().use{it.readBytes()};runOnUiThread{if((screen==Screen.LIVE_CHANNELS||screen==Screen.LIVE_GROUPS)&&miniChannel.text==c.name)miniPicon.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.size))}}catch(_:Exception){}}}
 private fun startMini(c:Channel){if(screen!=Screen.LIVE_CHANNELS&&screen!=Screen.LIVE_GROUPS)return;miniCurrentChannel=c;miniGeneration++;selectedSource?.takeIf{it.type=="e2"&&it.e2ZapOnBox}?.let{src->pool.execute{try{Api.e2Zap(src,c)}catch(_:Exception){}}};try{val p=LivePlayerSession.ensure(this,c.url,Api.streamAuthHeader(selectedSource));miniPlayer=p;if(miniPlayerView.player!==p)miniPlayerView.player=p;p.volume=1f;installLiveListenerOnce(p);miniPlayerView.visibility=View.VISIBLE;positionLiveSurfaceToMini(false)}catch(_:Exception){}}
 private fun releaseMini(){miniGeneration++;liveFullscreen=false;liveFsInfo.visibility=View.GONE;liveBufferingBox.visibility=View.GONE;miniPlayerView.visibility=View.GONE;miniPlayerView.player=null;try{LivePlayerSession.release()}catch(_:Exception){};miniPlayer=null;liveSurfaceReady=false;liveListenerInstalled=false}

 private fun scheduleVodGroupRefresh(src:Source,cat:MediaCategory){catalogPool.execute{try{CatalogCacheStore.saveVodItems(this,src,cat.id,Api.vodItems(src,cat.id))}catch(_:Exception){}}}
 private fun scheduleSeriesGroupRefresh(src:Source,cat:MediaCategory){catalogPool.execute{try{CatalogCacheStore.saveSeriesItems(this,src,cat.id,Api.seriesItems(src,cat.id))}catch(_:Exception){}}}

 private fun renderVodCats(p:Pos?=null){screen=Screen.VOD_CATS;applyTheme(3);setMode();status.text="Filmy  •  ${vodCats.size} kategorii";list.adapter=TvListAdapter(this,vodCats.map{it.name},1);p?.let{restore(it)};list.requestFocus()}
 private fun loadVodCategories(){
  releaseMini();val src=selectedSource?:return;screen=Screen.VOD_CATS;setMode()
  val cached=CatalogCacheStore.loadVodCategories(this,src)
  if(cached.isNotEmpty()){vodCats=cached;renderVodCats();scheduleCatalogSync(src);return}
  status.text="Ładowanie kategorii filmów…";pool.execute{try{val x=Api.vodCategories(src);CatalogCacheStore.saveVodCategories(this,src,x);runOnUiThread{if(selectedSource==src){vodCats=x;renderVodCats();scheduleCatalogSync(src)}}}catch(e:Exception){runOnUiThread{status.text="Filmy: ${e.message}"}}}
 }
 private fun loadVodItems(cat:MediaCategory){
  val src=selectedSource?:return;currentVodCat=cat;vodItemSelected=0
  val cached=CatalogCacheStore.loadVodItems(this,src,cat.id)
  if(cached.isNotEmpty()){vodItems=cached;renderVodItems();scheduleVodGroupRefresh(src,cat);return}
  status.text="Ładowanie: ${cat.name}…";pool.execute{try{val x=Api.vodItems(src,cat.id);CatalogCacheStore.saveVodItems(this,src,cat.id,x);runOnUiThread{if(selectedSource==src&&currentVodCat?.id==cat.id){vodItems=x;renderVodItems()}}}catch(e:Exception){runOnUiThread{status.text="Błąd filmów: ${e.message}"}}}
 }
 private fun renderVodItems(p:Pos?=null){screen=Screen.VOD_ITEMS;applyTheme(3);setMode();status.text="${currentVodCat?.name.orEmpty()}  •  ${vodItems.size} filmów";posterAdapter=PosterGridAdapter(this,vodItems.map{it.name},vodItems.map{it.icon},false);posterGrid.adapter=posterAdapter;posterGrid.clearChoices();posterGrid.choiceMode=AbsListView.CHOICE_MODE_SINGLE;p?.let{restore(it)};posterGrid.post{val pos=vodItemSelected.coerceIn(0,(vodItems.size-1).coerceAtLeast(0));posterGrid.setSelection(pos);updatePosterSelection(pos);posterGrid.requestFocus()}}
 private fun renderSeriesCats(p:Pos?=null){screen=Screen.SERIES_CATS;applyTheme(4);setMode();status.text="Seriale  •  ${seriesCats.size} kategorii";list.adapter=TvListAdapter(this,seriesCats.map{it.name},2);p?.let{restore(it)};list.requestFocus()}
 private fun loadSeriesCategories(){
  releaseMini();val src=selectedSource?:return;screen=Screen.SERIES_CATS;setMode()
  val cached=CatalogCacheStore.loadSeriesCategories(this,src)
  if(cached.isNotEmpty()){seriesCats=cached;renderSeriesCats();scheduleCatalogSync(src);return}
  status.text="Ładowanie kategorii seriali…";pool.execute{try{val x=Api.seriesCategories(src);CatalogCacheStore.saveSeriesCategories(this,src,x);runOnUiThread{if(selectedSource==src){seriesCats=x;renderSeriesCats();scheduleCatalogSync(src)}}}catch(e:Exception){runOnUiThread{status.text="Seriale: ${e.message}"}}}
 }
 private fun loadSeriesItems(cat:MediaCategory){
  val src=selectedSource?:return;currentSeriesCat=cat;seriesItemSelected=0
  val cached=CatalogCacheStore.loadSeriesItems(this,src,cat.id)
  if(cached.isNotEmpty()){seriesItems=cached;renderSeriesItems();scheduleSeriesGroupRefresh(src,cat);return}
  status.text="Ładowanie: ${cat.name}…";pool.execute{try{val x=Api.seriesItems(src,cat.id);CatalogCacheStore.saveSeriesItems(this,src,cat.id,x);runOnUiThread{if(selectedSource==src&&currentSeriesCat?.id==cat.id){seriesItems=x;renderSeriesItems()}}}catch(e:Exception){runOnUiThread{status.text="Błąd seriali: ${e.message}"}}}
 }
 private fun renderSeriesItems(p:Pos?=null){screen=Screen.SERIES_ITEMS;applyTheme(4);setMode();status.text="${currentSeriesCat?.name.orEmpty()}  •  ${seriesItems.size} seriali";posterAdapter=PosterGridAdapter(this,seriesItems.map{it.name},seriesItems.map{it.cover},true);posterGrid.adapter=posterAdapter;posterGrid.clearChoices();posterGrid.choiceMode=AbsListView.CHOICE_MODE_SINGLE;p?.let{restore(it)};posterGrid.post{val pos=seriesItemSelected.coerceIn(0,(seriesItems.size-1).coerceAtLeast(0));posterGrid.setSelection(pos);updatePosterSelection(pos);posterGrid.requestFocus()}}
 private fun loadSeasons(item:SeriesItem){val src=selectedSource?:return;selectedSeries=item;status.text="Ładowanie sezonów: ${item.name}…";pool.execute{try{val p=Api.seasons(src,item.id);runOnUiThread{seasons=p.first;seasonEpisodes=p.second;renderSeasons()}}catch(e:Exception){runOnUiThread{status.text="Błąd sezonów: ${e.message}"}}}}
 private fun renderSeasons(p:Pos?=null){screen=Screen.SEASONS;applyTheme(4);setMode();status.text="${selectedSeries?.name.orEmpty()}  •  ${seasons.size} sezonów";list.adapter=TvListAdapter(this,seasons.map{it.name},2,true);p?.let{restore(it)};list.requestFocus()}
 private fun showEpisodes(season:SeasonItem){screen=Screen.EPISODES;applyTheme(4);setMode();episodes=seasonEpisodes[season.id].orEmpty();status.text="${selectedSeries?.name.orEmpty()}  •  ${season.name}";list.adapter=TvListAdapter(this,episodes.map{it.name},2,true);list.requestFocus()}
 private fun showFavorites(){releaseMini();screen=Screen.FAVORITES;applyTheme(2);setMode();status.text="Ulubione  •  ${favorites.size} kanałów";piconAdapter?.close();piconAdapter=PiconAdapter(this,favorites,epgText,epgEvents,activePiconMode(),selectedSource);list.adapter=piconAdapter;loadEpgForChannels(favorites);list.requestFocus()}
 private fun toggleFavorite(c:Channel){val i=favorites.indexOfFirst{it.url==c.url};val added=i<0;if(added)favorites.add(c)else favorites.removeAt(i);FavoriteStore.save(this,favorites);Toast.makeText(this,if(added)"Dodano do ulubionych" else "Usunięto z ulubionych",Toast.LENGTH_SHORT).show();if(screen==Screen.FAVORITES)showFavorites()}

 private fun play(url:String,name:String,epg:String="",vod:Boolean=false,channel:Channel?=null){
  if(!vod&&channel!=null){miniCurrentChannel=channel;selectedSource?.let{LastLiveStore.save(this,it,channel)};startMini(channel);enterLiveFullscreen(channel,true);return}
  releaseMini()
  val i=Intent(this,PlayerActivity::class.java).putExtra("url",url).putExtra("name",name).putExtra("epg",epg).putExtra("vod",true)
  selectedSource?.let{src->i.putExtra("sourceType",src.type).putExtra("sourceName",src.name).putExtra("sourceHost",src.host).putExtra("sourceUser",src.user).putExtra("sourcePass",src.pass).putExtra("sourceUrl",src.url)}
  startActivity(i)
 }
 private fun onChannelItem(i:Int){when(screen){
  Screen.LIVE_GROUPS->if(i in groups.indices){
   liveGroupsPos=position();liveGroupSelected=i;liveChannelSelected=0
   val child=channelList.getChildAt(i-channelList.firstVisiblePosition);liveGroupAnchorTop=child?.top?:(resources.displayMetrics.density*95f).toInt()
   openLiveGroup(groups[i])
  }
  Screen.LIVE_CHANNELS->if(i in visibleChannels.indices){liveChannelSelected=i;val c=visibleChannels[i];play(c.url,c.name,epgText[c.url].orEmpty(),false,c)}
  else->{}
 }}
 private fun showDetails(kind:String,title:String,fallbackPoster:String,actionText:String,action:()->Unit){val p=position();val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,16,24,8);setBackgroundResource(R.drawable.panel_dark)};val iv=ImageView(this).apply{adjustViewBounds=true;scaleType=ImageView.ScaleType.CENTER_INSIDE;maxHeight=(resources.displayMetrics.heightPixels*0.45).toInt()};val tt=TextView(this).apply{text=title;textSize=23f;setTextColor(0xFFF5A623.toInt());setPadding(0,8,0,6)};val meta=TextView(this).apply{text="Ładowanie informacji TMDB…";setTextColor(0xFFCCCCCC.toInt())};val desc=TextView(this).apply{setTextColor(0xFFFFFFFF.toInt());setPadding(0,8,0,0)};box.addView(iv);box.addView(tt);box.addView(meta);box.addView(desc);val dlg=AlertDialog.Builder(this).setView(ScrollView(this).apply{addView(box)}).setPositiveButton(actionText){_,_->restore(p);action()}.setNegativeButton("Wróć",null).create();dlg.setOnDismissListener{restore(p)};dlg.show();if(fallbackPoster.isNotBlank())pool.execute{Tmdb.loadImage(fallbackPoster)?.let{b->runOnUiThread{iv.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.size))}}};pool.execute{val m=Tmdb.fetch(kind,title);runOnUiThread{if(m==null){meta.text="TMDB: nie znaleziono danych"}else{tt.text=m.title;meta.text=listOf(m.year,m.rating,m.runtime,m.genres).filter{it.isNotBlank()}.joinToString("  •  ");desc.text=m.overview;if(m.poster.isNotBlank())pool.execute{Tmdb.loadImage(m.poster)?.let{b->runOnUiThread{iv.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.size))}}}}}}}
 private fun onItem(i:Int){when(screen){Screen.SOURCES->if(i<sources.size)loadSource(sources[i]);Screen.LIVE_GROUPS->if(i<groups.size){liveGroupsPos=position();liveGroupSelected=i;liveChannelSelected=0;openLiveGroup(groups[i])};Screen.VOD_CATS->if(i<vodCats.size){vodCatsPos=position();loadVodItems(vodCats[i])};Screen.VOD_ITEMS->if(i<vodItems.size){vodItemSelected=i;val x=vodItems[i];showDetails("movie",x.name,x.icon,"PLAY"){play(x.url,x.name,"",true)}};Screen.SERIES_CATS->if(i<seriesCats.size){seriesCatsPos=position();loadSeriesItems(seriesCats[i])};Screen.SERIES_ITEMS->if(i<seriesItems.size){seriesItemSelected=i;val x=seriesItems[i];seriesItemsPos=position();showDetails("tv",x.name,x.cover,"SEZONY"){loadSeasons(x)}};Screen.SEASONS->if(i<seasons.size){seasonsPos=position();showEpisodes(seasons[i])};Screen.EPISODES->if(i<episodes.size){val ep=episodes[i];val src=selectedSource?:return;play(Api.episodeUrl(src,ep),ep.name,"",true)};Screen.FAVORITES->if(i<favorites.size){val c=favorites[i];play(c.url,c.name,epgText[c.url].orEmpty(),false,c)};else->{}}}
 private fun showChannelOptions(c:Channel){val isFav=favorites.any{it.url==c.url};AlertDialog.Builder(this).setTitle(c.name).setItems(arrayOf(if(isFav)"Usuń z ulubionych" else "Dodaj do ulubionych","Wyświetl EPG")){_,w->if(w==0)toggleFavorite(c)else showEpgSchedule(c)}.setNegativeButton("Anuluj",null).show()}
 private fun showEpgSchedule(c:Channel){val src=selectedSource?:return;val loading=AlertDialog.Builder(this).setTitle("EPG • ${c.name}").setMessage("Ładowanie pełnego EPG…").setNegativeButton("Anuluj",null).create();loading.show();pool.execute{val events=try{Api.epgSchedule(src,c)}catch(_:Exception){emptyList()};runOnUiThread{if(!loading.isShowing)return@runOnUiThread;loading.dismiss();if(events.isEmpty()){AlertDialog.Builder(this).setTitle("EPG • ${c.name}").setMessage("Brak pełnego EPG dla tego kanału.").setPositiveButton("Wróć",null).show();return@runOnUiThread};val rows=events.map{e->(if(e.start.isNotBlank()||e.end.isNotBlank())"${e.start} - ${e.end}   " else "")+e.title};val lv=ListView(this).apply{adapter=ArrayAdapter(this@MainActivity,android.R.layout.simple_list_item_1,rows);dividerHeight=1};val dlg=AlertDialog.Builder(this).setTitle("EPG • ${c.name}").setView(lv).setNegativeButton("Wróć",null).create();lv.setOnItemClickListener{_,_,pos,_->val e=events[pos];val wt=if(e.start.isNotBlank()||e.end.isNotBlank())"${e.start} - ${e.end}" else "";AlertDialog.Builder(this).setTitle(e.title).setMessage(listOf(wt,e.description.ifBlank{"Brak szczegółowego opisu."}).filter{it.isNotBlank()}.joinToString("\n\n")).setPositiveButton("Wróć",null).show()};dlg.show()}}}
 private fun onLongItem(i:Int):Boolean{when(screen){Screen.SOURCES->{if(i<sources.size)showSourceOptions(i);return true};Screen.FAVORITES->{if(i<favorites.size)showChannelOptions(favorites[i]);return true};else->return false}}

 private fun miniSlotRect():android.graphics.Rect{
  val rootLoc=IntArray(2);val slotLoc=IntArray(2);rootFrame.getLocationOnScreen(rootLoc);miniVideoSlot.getLocationOnScreen(slotLoc)
  return android.graphics.Rect(slotLoc[0]-rootLoc[0],slotLoc[1]-rootLoc[1],slotLoc[0]-rootLoc[0]+miniVideoSlot.width,slotLoc[1]-rootLoc[1]+miniVideoSlot.height)
 }
 private fun setLiveSurfaceBounds(x:Int,y:Int,w:Int,h:Int){val lp=miniPlayerView.layoutParams as FrameLayout.LayoutParams;lp.width=w.coerceAtLeast(1);lp.height=h.coerceAtLeast(1);miniPlayerView.layoutParams=lp;miniPlayerView.x=x.toFloat();miniPlayerView.y=y.toFloat();miniPlayerView.scaleX=1f;miniPlayerView.scaleY=1f}
 private fun positionLiveSurfaceToMini(animate:Boolean){if(miniVideoSlot.width<=0||miniVideoSlot.height<=0){miniVideoSlot.post{if(!liveFullscreen)positionLiveSurfaceToMini(animate)};return};val r=miniSlotRect();miniPlayerView.visibility=View.VISIBLE
  if(!animate||!liveSurfaceReady){setLiveSurfaceBounds(r.left,r.top,r.width(),r.height());liveSurfaceReady=true;return}
  val sx=r.width().toFloat()/rootFrame.width.coerceAtLeast(1);val sy=r.height().toFloat()/rootFrame.height.coerceAtLeast(1)
  miniPlayerView.pivotX=0f;miniPlayerView.pivotY=0f;miniPlayerView.animate().cancel();miniPlayerView.animate().x(r.left.toFloat()).y(r.top.toFloat()).scaleX(sx).scaleY(sy).setDuration(260).withEndAction{setLiveSurfaceBounds(r.left,r.top,r.width(),r.height());channelList.requestFocus()}.start()
 }
 private fun enterLiveFullscreen(c:Channel,animate:Boolean){suppressLiveBufferUntil=SystemClock.uptimeMillis()+5000;liveRecoveryArmed=false;hideLiveBuffer();handler.postDelayed({if(liveFullscreen&&miniPlayer?.isPlaying==true)liveRecoveryArmed=true},1800);miniCurrentChannel=c;selectedSource?.let{LastLiveStore.save(this,it,c)};val idx=visibleChannels.indexOfFirst{it.url==c.url};if(idx>=0)liveChannelSelected=idx;updateFullscreenInfo(c);liveFullscreen=true;showLiveInfo(5000);miniPlayerView.bringToFront();liveFsInfo.bringToFront();liveBufferingBox.bringToFront();miniPlayerView.visibility=View.VISIBLE
  if(!liveSurfaceReady){positionLiveSurfaceToMini(false)}
  val r=miniSlotRect();if(animate&&rootFrame.width>0&&rootFrame.height>0){setLiveSurfaceBounds(r.left,r.top,r.width(),r.height());val sx=rootFrame.width.toFloat()/r.width().coerceAtLeast(1);val sy=rootFrame.height.toFloat()/r.height().coerceAtLeast(1);miniPlayerView.pivotX=0f;miniPlayerView.pivotY=0f;miniPlayerView.animate().cancel();miniPlayerView.animate().x(0f).y(0f).scaleX(sx).scaleY(sy).setDuration(260).withEndAction{setLiveSurfaceBounds(0,0,rootFrame.width,rootFrame.height);liveFsInfo.bringToFront();liveBufferingBox.bringToFront()}.start()}else setLiveSurfaceBounds(0,0,rootFrame.width.coerceAtLeast(resources.displayMetrics.widthPixels),rootFrame.height.coerceAtLeast(resources.displayMetrics.heightPixels))
  immersiveLive()
 }
 private fun exitLiveFullscreen(){
  if(!liveFullscreen)return
  liveFullscreen=false;handler.removeCallbacks(hideLiveInfo);liveFsInfo.visibility=View.GONE;liveBufferingBox.visibility=View.GONE;positionLiveSurfaceToMini(true)
  val c=miniCurrentChannel
  if(screen==Screen.LIVE_CHANNELS&&c!=null){
   // Nie odbudowujemy listy po fullscreen. To jest dokładnie ta sama, zamrożona lista
   // konkretnej grupy, z której kanał został uruchomiony.
   val idx=visibleChannels.indexOfFirst{it.url==c.url}
   if(idx>=0)liveChannelSelected=idx
   channelList.post{
    if(idx>=0)channelList.setSelection(idx)
    updateMiniInfo(c);channelList.requestFocus();loadVisibleEpg()
   }
  }else c?.let{updateMiniInfo(it)}
 }


 private fun showLiveInfo(delay:Long=5000){if(!liveFullscreen)return;updateClocks();updateFullscreenInfo(miniCurrentChannel);liveFsInfo.visibility=View.VISIBLE;liveFsInfo.bringToFront();handler.removeCallbacks(hideLiveInfo);handler.postDelayed(hideLiveInfo,delay)}
 private fun updateFullscreenInfo(c:Channel?){c?:return;fsNumber.text=(visibleChannels.indexOfFirst{it.url==c.url}.takeIf{it>=0}?.plus(1)?:0).takeIf{it>0}?.toString().orEmpty();fsChannel.text=c.name;val ev=epgEvents[c.url].orEmpty();val now=ev.getOrNull(0);val next=ev.getOrNull(1);fsNow.text=if(now==null)epgText[c.url].orEmpty() else (if(now.start.isNotBlank()||now.end.isNotBlank())"${now.start} - ${now.end}  " else "")+now.title;fsNext.text=if(next==null)"" else "Następnie: "+(if(next.start.isNotBlank()||next.end.isNotBlank())"${next.start} - ${next.end}  " else "")+next.title;if(now!=null&&now.startEpoch>0&&now.endEpoch>now.startEpoch){val n=System.currentTimeMillis();fsProgress.progress=(((n-now.startEpoch).coerceIn(0,now.endEpoch-now.startEpoch)*1000)/(now.endEpoch-now.startEpoch)).toInt()}else fsProgress.progress=0;loadFsPicon(c)}
 private fun loadFsPicon(c:Channel){fsPicon.setImageDrawable(null);val pm=activePiconMode();val local=if(pm==0||pm==2)PiconRepository.find(this,c.name)else null;if(local!=null){fsPicon.setImageBitmap(BitmapFactory.decodeFile(local.absolutePath));return};if((pm==1||pm==2)&&c.logo.isNotBlank())pool.execute{try{val b=selectedSource?.let{Api.loadRemotePicon(it,c.logo)}?:URL(c.logo).openStream().use{it.readBytes()};runOnUiThread{if(miniCurrentChannel?.url==c.url)fsPicon.setImageBitmap(BitmapFactory.decodeByteArray(b,0,b.size))}}catch(_:Exception){}}}
 private fun switchLiveInline(delta:Int){if(visibleChannels.isEmpty())return;suppressLiveBufferUntil=SystemClock.uptimeMillis()+5000;liveRecoveryArmed=false;liveChannelSelected=(liveChannelSelected+delta+visibleChannels.size)%visibleChannels.size;val c=visibleChannels[liveChannelSelected];miniCurrentChannel=c;selectedSource?.let{LastLiveStore.save(this,it,c)};liveHasPlayed=false;liveRetryCount=0;hideLiveBuffer();selectedSource?.takeIf{it.type=="e2"&&it.e2ZapOnBox}?.let{src->pool.execute{try{Api.e2Zap(src,c)}catch(_:Exception){}}};val p=LivePlayerSession.ensure(this,c.url,Api.streamAuthHeader(selectedSource));miniPlayer=p;if(miniPlayerView.player!==p)miniPlayerView.player=p;loadEpgForChannels(listOf(c));updateFullscreenInfo(c);showLiveInfo(5000)}
 private fun installLiveListenerOnce(p:ExoPlayer){if(liveListenerInstalled)return;liveListenerInstalled=true;p.addListener(object:Player.Listener{
  override fun onIsPlayingChanged(v:Boolean){if(v){liveHasPlayed=true;liveRetryCount=0;hideLiveBuffer();handler.postDelayed({if(miniPlayer?.isPlaying==true)liveRecoveryArmed=true},1500)}}
  override fun onPlaybackStateChanged(state:Int){if(state==Player.STATE_BUFFERING&&liveHasPlayed&&liveRecoveryArmed&&SystemClock.uptimeMillis()>=suppressLiveBufferUntil){showLiveBuffer();scheduleLiveRetry()}else if(state==Player.STATE_READY){hideLiveBuffer()}}
  override fun onTracksChanged(tracks:Tracks){updateLiveTrackButtons(tracks)}
  override fun onPlayerError(error:PlaybackException){if(liveHasPlayed&&liveRecoveryArmed&&SystemClock.uptimeMillis()>=suppressLiveBufferUntil){showLiveBuffer();scheduleLiveRetry(700)}}
 })}
 private fun updateLiveTrackButtons(tracks:Tracks){var ac=0;var tc=0;for(g in tracks.groups){if(g.type==C.TRACK_TYPE_AUDIO)for(i in 0 until g.length)if(g.isTrackSupported(i))ac++;if(g.type==C.TRACK_TYPE_TEXT)for(i in 0 until g.length)if(g.isTrackSupported(i))tc++};fsAudio.visibility=if(ac>1)View.VISIBLE else View.GONE;fsSubtitles.visibility=if(tc>0)View.VISIBLE else View.GONE}
 private data class LiveTrackChoice(val label:String,val group:Tracks.Group?,val index:Int)
 private fun showLiveTrackDialog(type:Int,title:String){val p=miniPlayer?:return;val choices=ArrayList<LiveTrackChoice>();if(type==C.TRACK_TYPE_TEXT)choices+=LiveTrackChoice("Wyłącz napisy",null,-1);for(g in p.currentTracks.groups){if(g.type!=type)continue;for(i in 0 until g.length){if(!g.isTrackSupported(i))continue;val f=g.getTrackFormat(i);val lang=f.language?.uppercase().orEmpty();val label=f.label?.takeIf{it.isNotBlank()}?:if(type==C.TRACK_TYPE_AUDIO)"Audio ${choices.size+1}" else "Napisy ${choices.size+1}";choices+=LiveTrackChoice(if(lang.isBlank())label else "$label  [$lang]",g,i)}};if(choices.isEmpty()||(type==C.TRACK_TYPE_TEXT&&choices.size==1))return;AlertDialog.Builder(this).setTitle(title).setItems(choices.map{it.label}.toTypedArray()){_,w->val c=choices[w];val b=p.trackSelectionParameters.buildUpon().clearOverridesOfType(type);if(c.group==null)b.setTrackTypeDisabled(C.TRACK_TYPE_TEXT,true)else{b.setTrackTypeDisabled(type,false);b.setOverrideForType(TrackSelectionOverride(c.group.mediaTrackGroup,listOf(c.index)))};p.trackSelectionParameters=b.build();showLiveInfo(5000)}.setNegativeButton("Anuluj",null).show()}
 private fun showLiveBuffer(){if(!liveHasPlayed)return;liveBufferingBox.visibility=View.VISIBLE;liveBufferingBox.bringToFront();handler.removeCallbacks(liveBufferTick);handler.post(liveBufferTick)}
 private fun hideLiveBuffer(){liveBufferingBox.visibility=View.GONE;handler.removeCallbacks(liveBufferTick);handler.removeCallbacks(liveRetry);liveRetryScheduled=false}
 private fun scheduleLiveRetry(delay:Long=3500){if(!liveHasPlayed||liveRetryScheduled||liveRetryCount>=3)return;liveRetryScheduled=true;handler.postDelayed(liveRetry,delay)}
 private fun immersiveLive(){window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);if(Build.VERSION.SDK_INT>=30){window.setDecorFitsSystemWindows(false);window.insetsController?.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())}else{@Suppress("DEPRECATION")window.decorView.systemUiVisibility=View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY}}
 override fun dispatchKeyEvent(e:KeyEvent):Boolean{if(liveFullscreen){if(e.action==KeyEvent.ACTION_DOWN){when(e.keyCode){KeyEvent.KEYCODE_DPAD_UP,KeyEvent.KEYCODE_CHANNEL_UP->{switchLiveInline(1);return true};KeyEvent.KEYCODE_DPAD_DOWN,KeyEvent.KEYCODE_CHANNEL_DOWN->{switchLiveInline(-1);return true};KeyEvent.KEYCODE_DPAD_CENTER,KeyEvent.KEYCODE_ENTER->{showLiveInfo(5000);return true};KeyEvent.KEYCODE_BACK->{exitLiveFullscreen();return true}}};return true};return super.dispatchKeyEvent(e)}
 private fun confirmExit(){AlertDialog.Builder(this).setTitle("Wyjść z TvMad-Xtream TV?").setMessage("Czy na pewno chcesz zamknąć aplikację?").setPositiveButton("Tak"){_,_->finishAffinity()}.setNegativeButton("Nie",null).show()}
 @Deprecated("Deprecated in Java") override fun onBackPressed(){if(liveFullscreen){exitLiveFullscreen();return};when(screen){Screen.SOURCES->showHome();Screen.HOME->confirmExit();Screen.LIVE_GROUPS->showHome();Screen.LIVE_CHANNELS->showLiveGroups(liveGroupsPos);Screen.VOD_CATS->showHome();Screen.VOD_ITEMS->renderVodCats(vodCatsPos);Screen.SERIES_CATS->showHome();Screen.SERIES_ITEMS->renderSeriesCats(seriesCatsPos);Screen.SEASONS->renderSeriesItems(seriesItemsPos);Screen.EPISODES->renderSeasons(seasonsPos);Screen.FAVORITES->showHome()}}
 override fun onResume(){super.onResume();if(screen==Screen.VOD_ITEMS||screen==Screen.SERIES_ITEMS){posterGrid.post{posterGrid.requestFocus()}};if((screen==Screen.LIVE_CHANNELS||screen==Screen.LIVE_GROUPS)&&!liveFullscreen)miniCurrentChannel?.let{startMini(it)}}
 override fun onPause(){super.onPause()}
 override fun onDestroy(){releaseMini();web?.stop();piconAdapter?.close();handler.removeCallbacksAndMessages(null);pool.shutdownNow();epgPool.shutdownNow();catalogPool.shutdownNow();externalEpgPool.shutdownNow();super.onDestroy()}
}
