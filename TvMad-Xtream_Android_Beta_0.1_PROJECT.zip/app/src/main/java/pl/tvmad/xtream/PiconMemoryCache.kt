package pl.tvmad.xtream

import android.graphics.Bitmap
import java.util.concurrent.ConcurrentHashMap

/** Session memory cache shared by the normal channel list and fullscreen drawer. */
object PiconMemoryCache {
    private val bitmaps = ConcurrentHashMap<String, Bitmap>()
    fun get(key: String): Bitmap? = bitmaps[key]
    fun put(key: String, bitmap: Bitmap) { bitmaps[key] = bitmap }
}
