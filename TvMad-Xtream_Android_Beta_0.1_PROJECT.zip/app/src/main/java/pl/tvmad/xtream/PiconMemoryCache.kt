package pl.tvmad.xtream

import android.graphics.Bitmap
import android.util.LruCache

/**
 * Small bounded cache shared by LIVE lists/infobars.
 * Do not retain the whole local picon library in RAM: on low-memory TV boxes
 * hundreds/thousands of decoded PNG files can otherwise kill the app.
 */
object PiconMemoryCache {
    private const val MAX_CACHE_KB = 8 * 1024
    private val bitmaps = object : LruCache<String, Bitmap>(MAX_CACHE_KB) {
        override fun sizeOf(key: String, bitmap: Bitmap): Int =
            (bitmap.allocationByteCount / 1024).coerceAtLeast(1)
    }

    @Synchronized fun get(key: String): Bitmap? = bitmaps.get(key)
    @Synchronized fun put(key: String, bitmap: Bitmap) { bitmaps.put(key, bitmap) }
    @Synchronized fun clear() { bitmaps.evictAll() }
}
