package pl.tvmad.xtream

import android.content.Context
import java.io.File
import java.text.Normalizer

object PiconRepository {
    fun dir(context: Context): File = File(context.filesDir, "picons").apply { mkdirs() }

    fun key(name: String): String {
        var s = Normalizer.normalize(NameCleaner.clean(name), Normalizer.Form.NFD)
            .replace("\\p{Mn}+".toRegex(), "")
            .lowercase()
        s = s.replace("[^a-z0-9]+".toRegex(), "_").trim('_')
        return s
    }

    fun find(context: Context, channelName: String): File? {
        val k = key(channelName)
        if (k.isBlank()) return null
        val d = dir(context)
        val exact = listOf("$k.png", "$k.webp", "$k.jpg", "$k.jpeg").map { File(d, it) }.firstOrNull { it.isFile }
        if (exact != null) return exact
        return d.listFiles()?.firstOrNull { f -> f.isFile && key(f.nameWithoutExtension) == k }
    }
}
