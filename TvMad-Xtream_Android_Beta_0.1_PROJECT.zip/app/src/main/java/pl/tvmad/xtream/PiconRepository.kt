package pl.tvmad.xtream

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File
import java.text.Normalizer

object PiconRepository {
    fun dir(context: Context): File = File(context.filesDir, "picons").apply { mkdirs() }

    fun key(name: String): String {
        var s = Normalizer.normalize(NameCleaner.clean(name), Normalizer.Form.NFD)
            .replace("\\p{Mn}+".toRegex(), "")
            .lowercase()
        s = s.replace("[^a-z0-9]+".toRegex(), "_").trim('_')
        return s
    }

    /**
     * WebInterface stores uploaded picons under an already-normalised key.
     * Therefore lookup is O(1): never scan/re-normalise the whole directory.
     * A directory scan here was extremely expensive with 1000+ picons and could
     * freeze/kill low-memory Android boxes simply when entering LIVE.
     */
    fun find(context: Context, channelName: String): File? {
        val k = key(channelName)
        if (k.isBlank()) return null
        val d = dir(context)
        for (ext in arrayOf("png", "webp", "jpg", "jpeg")) {
            val f = File(d, "$k.$ext")
            if (f.isFile) return f
        }
        return null
    }

    /** Decode only about the size actually shown on TV instead of full PNG size. */
    fun decodeScaled(file: File, reqWidth: Int = 160, reqHeight: Int = 100): Bitmap? {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= reqWidth && bounds.outHeight / (sample * 2) >= reqHeight) sample *= 2
            val opts = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            BitmapFactory.decodeFile(file.absolutePath, opts)
        } catch (_: Throwable) { null }
    }
}
