package pl.tvmad.xtream

object NameCleaner {
    private val prefix = Regex("^(?:PL|POL|POLSKA|UK|GB|DE|GER|US|USA|FR|IT|ES)\\s*[:|\\-]\\s*", RegexOption.IGNORE_CASE)
    private val bracketJunk = Regex("\\s*[\\[(](?:HEVC|H265|H264|x265|x264|RAW|VIP|BACKUP|SD|HD|FHD|FULL\\s*HD|UHD|4K|50FPS|60FPS)[\\])]\\s*", RegexOption.IGNORE_CASE)
    private val pipeJunk = Regex("\\s*[|]\\s*(?:VIP|RAW|HEVC|H265|H264|BACKUP|SD|HD|FHD|UHD|4K)\\s*[|]?\\s*", RegexOption.IGNORE_CASE)
    private val tailJunk = Regex("(?:\\s+[-|]?\\s*(?:RAW|HEVC|H265|H264|VIP|BACKUP|50FPS|60FPS))+$", RegexOption.IGNORE_CASE)

    // Dokładne zasady czyszczenia LIVE przeniesione z TvMad-Xtream Enigma2.
    private val liveDropTokens = setOf(
        "PL","POL","POLSKA","UK","GB","DE","GER","GERMANY","FR","ES","IT","NL","PT","SE","SW","NO","DK","FI",
        "CZ","SK","US","USA","CA","AU","VIP","VIPS","PREMIUM","PLUS","PLAY","NA","NEW","TEST","TESTS",
        "HEVC","H265","H.265","X265","H264","H.264","X264","RAW"
    )
    private val liveDropWords = liveDropTokens.map { Regex.escape(it) }.sortedByDescending { it.length }.joinToString("|")
    private val liveDropWordRe = Regex("^(?:$liveDropWords)$", RegexOption.IGNORE_CASE)
    private val liveDropBracketRe = Regex("[\\[(\\{]\\s*(?:$liveDropWords)\\s*[\\])\\}]", RegexOption.IGNORE_CASE)
    private val liveEdgeJunkRe = Regex("^[\\s|\\\\/;:\\[\\]{}()<>*^%\\$@\"'`#~!,.+_-]+|[\\s|\\\\/;:\\[\\]{}()<>*^%\\$@\"'`#~!,.+_-]+$")
    private val liveSepCharsRe = Regex("[|\\\\/;:\\[\\]{}<>*^%\\$@\"'`#~!,]+")

    fun clean(s:String):String {
        var x=s.replace('\u00a0',' ').trim()
        x=x.replace(prefix,"")
        x=x.replace(bracketJunk," ")
        x=x.replace(pipeJunk," ")
        x=x.replace(tailJunk,"")
        x=x.replace(Regex("\\s{2,}")," ").trim(' ','-','|')
        return x.ifBlank{s.trim()}
    }

    private fun liveStripEdgeJunk(input:String):String {
        var s=input
        var old:String?
        do {
            old=s
            s=s.replace(liveEdgeJunkRe,"").replace(Regex("\\s+")," ").trim()
        } while(old!=s)
        return s
    }

    private fun liveStripDropTokensEdges(input:String):String {
        val parts=input.split(Regex("\\s+")).filter{it.isNotBlank()}.toMutableList()
        var changed=true
        while(changed && parts.isNotEmpty()){
            changed=false
            while(parts.isNotEmpty() && liveDropWordRe.matches(parts.first())){parts.removeAt(0);changed=true}
            while(parts.isNotEmpty() && liveDropWordRe.matches(parts.last())){parts.removeAt(parts.lastIndex);changed=true}
        }
        return parts.joinToString(" ")
    }

    fun cleanLive(name:String):String {
        val original=name.replace('\u00a0',' ').trim()
        if(original.isBlank())return ""
        var s=original
        return try {
            s=s.replace('★',' ').replace('☆',' ').replace('•',' ').replace('◉',' ')
            s=s.replace(liveDropBracketRe," ")
            s=s.replace(Regex("\\bFHD\\b",RegexOption.IGNORE_CASE),"HD")
            s=s.replace(Regex("\\bRAW\\b",RegexOption.IGNORE_CASE)," ")
            s=s.replace(Regex("\\b(HD|UHD|4K)\\b\\s*[\\(\\[\\{]\\s*(?:NA|VIP|VIPS|PREMIUM|PLUS|PLAY)\\s*[\\)\\]\\}]",RegexOption.IGNORE_CASE),"$1")
            s=s.replace(Regex("\\b(HD|UHD|4K)\\b\\s+(?:NA|VIP|VIPS|PREMIUM|PLUS|PLAY)\\b.*$",RegexOption.IGNORE_CASE),"$1")
            s=s.replace(liveSepCharsRe," ").replace('(',' ').replace(')',' ')
            s=s.replace(Regex("\\s+")," ").trim()
            s=liveStripEdgeJunk(s)
            s=liveStripDropTokensEdges(s)
            s=liveStripEdgeJunk(s)
            s=liveStripDropTokensEdges(s)
            s=s.replace(Regex("\\s+")," ").trim()
            s.ifBlank{original}
        }catch(_:Exception){original}
    }


    // VOD/seriale: czyścimy wyłącznie nazwę pozycji, nigdy nazwę grupy.
    // Zdejmujemy kolejne techniczne/providerowe prefiksy z początku (np. "NF -", "D+ -",
    // "PL | VIP |"), ale nie usuwamy zwykłych słów z właściwego tytułu.
    private val vodKnownPrefix = Regex(
        "^(?:" +
            "NF|NETFLIX|D\\+|DISNEY\\+|DISNEY\\s*PLUS|" +
            "AP|ATV\\+|APPLE\\s*TV\\+?|APPLE|" +
            "AMZ|AMAZON|PRIME|PRIME\\s*VIDEO|" +
            "HBO|HBO\\s*MAX|MAX|PARAMOUNT\\+|P\\+|" +
            "SKY|CANAL\\+|C\\+|PEACOCK|HULU|SHOWTIME|" +
            "VIP|VIPS|PREMIUM|VOD|MOVIE|MOVIES|SERIES|TV|" +
            "PL|POL|POLSKA|EN|ENG|UK|GB|USA|FR|DE|GER|ES|NL|PT|SE|NO|DK|FI|CZ|SK|RO|HU|TR|AR|BR|LAT|MULTI" +
        ")$", RegexOption.IGNORE_CASE
    )
    private val vodBracketPrefix = Regex("^[\\[({<]\\s*([^\\]})>]{1,28})\\s*[\\]})>]\\s*(?:[-|:•·/\\\\]+\\s*)?", RegexOption.IGNORE_CASE)
    private val vodDelimitedPrefix = Regex("^([^:|\\-–—•·/\\\\]{1,32})\\s*[:|\\-–—•·/\\\\]+\\s*(.+)$")
    private val vodDecorPrefix = Regex("^[\\s★☆✪✦✧◆◇●○•·▪▫►▶▷➤➜→|:;,_~`'\"]+")
    private val vodSpace = Regex("\\s+")

    private fun looksLikeVodPrefix(raw:String):Boolean {
        val t=raw.replace('★',' ').replace('☆',' ').replace('✪',' ').replace('•',' ').trim()
        if(t.isBlank())return true
        if(vodKnownPrefix.matches(t))return true
        // Krótkie, wielkimi literami zapisane oznaczenia serwera/kraju, np. "FR", "NF", "D+".
        // Chronimy jednak skróty będące realnymi tytułami (np. IT / US / UP).
        if(t in setOf("IT","US","UP"))return false
        return t.length<=8 && t.any{it.isLetter()} && t.filter{it.isLetter()}.all{it.isUpperCase()} && t.all{it.isLetterOrDigit() || it in "+._ "}
    }

    fun cleanVodTitle(name:String):String {
        val original=name.replace('\u00a0',' ').trim()
        if(original.isBlank())return ""
        var s=original
        return try {
            s=s.replace(vodDecorPrefix, "").trim()
            repeat(8){
                val before=s
                val bm=vodBracketPrefix.find(s)
                if(bm!=null && bm.range.first==0 && looksLikeVodPrefix(bm.groupValues[1])){
                    s=s.substring(bm.range.last+1).replace(vodDecorPrefix, "").trim()
                }
                val dm=vodDelimitedPrefix.matchEntire(s)
                if(dm!=null && looksLikeVodPrefix(dm.groupValues[1])){
                    s=dm.groupValues[2].replace(vodDecorPrefix, "").trim()
                }
                // Prefiks bez klasycznego myślnika, np. "NF The Movie" / "D+ Encanto".
                val parts=s.split(vodSpace, limit=2)
                if(parts.size==2 && looksLikeVodPrefix(parts[0]) && (vodKnownPrefix.matches(parts[0]) || parts[0].contains('+'))){
                    s=parts[1].replace(vodDecorPrefix, "").trim()
                }
                if(s==before)return@repeat
            }
            s=s.replace(Regex("^[\\s|:;,_~`'\"★☆✪✦✧◆◇●○•·▪▫►▶▷➤➜→\\-–—]+"), "")
            s=s.replace(vodSpace," ").trim()
            s.ifBlank{original}
        }catch(_:Exception){original}
    }

    fun epgKeys(s:String):Set<String>{
        val c=cleanLive(s)
        val variants=linkedSetOf(c,c.replace(Regex("\\bFHD\\b",RegexOption.IGNORE_CASE),"HD"),c.replace(Regex("\\b(?:HD|UHD|4K)\\b",RegexOption.IGNORE_CASE)," "))
        return variants.map{it.lowercase().replace(Regex("[^a-z0-9ąćęłńóśźż]+"),"").trim()}.filter{it.isNotBlank()}.toSet()
    }

    fun piconKey(s:String):String = cleanLive(s).lowercase().replace("+","plus").replace(Regex("[^a-z0-9]+"),"_").trim('_')
}
