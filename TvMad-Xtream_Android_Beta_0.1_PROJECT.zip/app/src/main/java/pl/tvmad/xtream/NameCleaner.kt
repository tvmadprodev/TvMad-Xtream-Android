package pl.tvmad.xtream

object NameCleaner {
    private val prefix = Regex("^(?:PL|POL|POLSKA|UK|GB|DE|GER|US|USA|FR|IT|ES)\\s*[:|\\-]\\s*", RegexOption.IGNORE_CASE)
    private val bracketJunk = Regex("\\s*[\\[(](?:HEVC|H265|H264|x265|x264|RAW|VIP|BACKUP|SD|HD|FHD|FULL\\s*HD|UHD|4K|50FPS|60FPS)[\\])]\\s*", RegexOption.IGNORE_CASE)
    private val pipeJunk = Regex("\\s*[|]\\s*(?:VIP|RAW|HEVC|H265|H264|BACKUP|SD|HD|FHD|UHD|4K)\\s*[|]?\\s*", RegexOption.IGNORE_CASE)
    private val tailJunk = Regex("(?:\\s+[-|]?\\s*(?:RAW|HEVC|H265|H264|VIP|BACKUP|50FPS|60FPS))+$", RegexOption.IGNORE_CASE)

    // Dokładne zasady czyszczenia LIVE przeniesione z TvMad-Xtream Enigma2.
    private val liveDropTokens = setOf(
        "PL","POL","POLSKA","UK","GB","DE","GER","GERMANY","FR","ES","IT","NL","PT","SE","SW","NO","DK","FI",
        "CZ","SK","US","USA","CA","AU","VIP","VIPS","PREMIUM","PLUS","PLAY","NA","NEW","TEST","TESTS",
        "HEVC","H265","H.265","X265","H264","H.264","X264","RAW"
    )
    private val liveDropWords = liveDropTokens.map { Regex.escape(it) }.sortedByDescending { it.length }.joinToString("|")
    private val liveDropWordRe = Regex("^(?:$liveDropWords)$", RegexOption.IGNORE_CASE)
    private val liveDropBracketRe = Regex("[\\[(\\{]\\s*(?:$liveDropWords)\\s*[\\])\\}]", RegexOption.IGNORE_CASE)
    private val liveEdgeJunkRe = Regex("^[\\s|\\\\/;:\\[\\]{}()<>*^%\\$@\"'`#~!,.+_-]+|[\\s|\\\\/;:\\[\\]{}()<>*^%\\$@\"'`#~!,.+_-]+$")
    private val liveSepCharsRe = Regex("[|\\\\/;:\\[\\]{}<>*^%\\$@\"'`#~!,]+")

    fun clean(s:String):String {
        var x=s.replace('\u00a0',' ').trim()
        x=x.replace(prefix,"")
        x=x.replace(bracketJunk," ")
        x=x.replace(pipeJunk," ")
        x=x.replace(tailJunk,"")
        x=x.replace(Regex("\\s{2,}")," ").trim(' ','-','|')
        return x.ifBlank{s.trim()}
    }

    private fun liveStripEdgeJunk(input:String):String {
        var s=input
        var old:String?
        do {
            old=s
            s=s.replace(liveEdgeJunkRe,"").replace(Regex("\\s+")," ").trim()
        } while(old!=s)
        return s
    }

    private fun liveStripDropTokensEdges(input:String):String {
        val parts=input.split(Regex("\\s+")).filter{it.isNotBlank()}.toMutableList()
        var changed=true
        while(changed && parts.isNotEmpty()){
            changed=false
            while(parts.isNotEmpty() && liveDropWordRe.matches(parts.first())){parts.removeAt(0);changed=true}
            while(parts.isNotEmpty() && liveDropWordRe.matches(parts.last())){parts.removeAt(parts.lastIndex);changed=true}
        }
        return parts.joinToString(" ")
    }

    fun cleanLive(name:String):String {
        val original=name.replace('\u00a0',' ').trim()
        if(original.isBlank())return ""
        var s=original
        return try {
            s=s.replace('★',' ').replace('☆',' ').replace('•',' ').replace('◉',' ')
            s=s.replace(liveDropBracketRe," ")
            s=s.replace(Regex("\\bFHD\\b",RegexOption.IGNORE_CASE),"HD")
            s=s.replace(Regex("\\bRAW\\b",RegexOption.IGNORE_CASE)," ")
            s=s.replace(Regex("\\b(HD|UHD|4K)\\b\\s*[\\(\\[\\{]\\s*(?:NA|VIP|VIPS|PREMIUM|PLUS|PLAY)\\s*[\\)\\]\\}]",RegexOption.IGNORE_CASE),"$1")
            s=s.replace(Regex("\\b(HD|UHD|4K)\\b\\s+(?:NA|VIP|VIPS|PREMIUM|PLUS|PLAY)\\b.*$",RegexOption.IGNORE_CASE),"$1")
            s=s.replace(liveSepCharsRe," ").replace('(',' ').replace(')',' ')
            s=s.replace(Regex("\\s+")," ").trim()
            s=liveStripEdgeJunk(s)
            s=liveStripDropTokensEdges(s)
            s=liveStripEdgeJunk(s)
            s=liveStripDropTokensEdges(s)
            s=s.replace(Regex("\\s+")," ").trim()
            s.ifBlank{original}
        }catch(_:Exception){original}
    }

    fun epgKeys(s:String):Set<String>{
        val c=cleanLive(s)
        val variants=linkedSetOf(c,c.replace(Regex("\\bFHD\\b",RegexOption.IGNORE_CASE),"HD"),c.replace(Regex("\\b(?:HD|UHD|4K)\\b",RegexOption.IGNORE_CASE)," "))
        return variants.map{it.lowercase().replace(Regex("[^a-z0-9ąćęłńóśźż]+"),"").trim()}.filter{it.isNotBlank()}.toSet()
    }

    fun piconKey(s:String):String = cleanLive(s).lowercase().replace("+","plus").replace(Regex("[^a-z0-9]+"),"_").trim('_')
}
