package pl.tvmad.xtream

object NameCleaner {
    private val prefix = Regex("^(?:PL|POL|POLSKA|UK|GB|DE|GER|US|USA|FR|IT|ES)\\s*[:|\\-]\\s*", RegexOption.IGNORE_CASE)
    private val bracketJunk = Regex("\\s*[\\[(](?:HEVC|H265|H264|x265|x264|RAW|VIP|BACKUP|SD|HD|FHD|FULL\\s*HD|UHD|4K|50FPS|60FPS)[\\])]\\s*", RegexOption.IGNORE_CASE)
    private val pipeJunk = Regex("\\s*[|]\\s*(?:VIP|RAW|HEVC|H265|H264|BACKUP|SD|HD|FHD|UHD|4K)\\s*[|]?\\s*", RegexOption.IGNORE_CASE)
    private val tailJunk = Regex("(?:\\s+[-|]?\\s*(?:RAW|HEVC|H265|H264|VIP|BACKUP|50FPS|60FPS))+$", RegexOption.IGNORE_CASE)

    fun clean(s:String):String {
        var x=s.replace('\u00a0',' ').trim()
        x=x.replace(prefix,"")
        x=x.replace(bracketJunk," ")
        x=x.replace(pipeJunk," ")
        x=x.replace(tailJunk,"")
        x=x.replace(Regex("\\s{2,}")," ").trim(' ','-','|')
        return x.ifBlank{s.trim()}
    }

    fun piconKey(s:String):String = clean(s).lowercase().replace("+","plus").replace(Regex("[^a-z0-9]+"),"_").trim('_')
}
