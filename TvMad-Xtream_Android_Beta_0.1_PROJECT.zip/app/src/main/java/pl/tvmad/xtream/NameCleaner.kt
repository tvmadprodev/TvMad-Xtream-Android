package pl.tvmad.xtream
object NameCleaner {
 fun clean(s:String):String = s.replace(Regex("\\s+RAW\\s*$", RegexOption.IGNORE_CASE), "").trim()
 fun piconKey(s:String):String = clean(s).lowercase().replace("+","plus").replace(Regex("[^a-z0-9]+"), "_").trim('_')
}
