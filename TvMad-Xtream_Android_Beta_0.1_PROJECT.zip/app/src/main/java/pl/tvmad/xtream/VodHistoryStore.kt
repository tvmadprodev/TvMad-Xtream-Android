package pl.tvmad.xtream

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest

data class VodHistoryEntry(
    val key:String,
    val kind:String,
    val title:String,
    val subtitle:String="",
    val poster:String="",
    val url:String,
    val positionMs:Long,
    val durationMs:Long=0L,
    val sourceKey:String,
    val updatedAt:Long=System.currentTimeMillis()
)

object VodHistoryStore {
    private const val PREF="tvmad_vod_history"
    private const val DATA="entries"

    fun sourceKey(src:Source):String {
        val raw=if(src.type=="xtream") "${src.type}|${src.host}|${src.user}" else "${src.type}|${src.url}"
        return MessageDigest.getInstance("SHA-256").digest(raw.toByteArray()).take(10).joinToString(""){"%02x".format(it)}
    }

    fun sourceKey(type:String,host:String,user:String,url:String):String {
        val raw=if(type=="xtream") "$type|$host|$user" else "$type|$url"
        return MessageDigest.getInstance("SHA-256").digest(raw.toByteArray()).take(10).joinToString(""){"%02x".format(it)}
    }

    private fun loadAll(context:Context):MutableList<VodHistoryEntry>{
        return try{
            val a=JSONArray(context.getSharedPreferences(PREF,Context.MODE_PRIVATE).getString(DATA,"[]")?:"[]")
            val out=mutableListOf<VodHistoryEntry>()
            for(i in 0 until a.length()){
                val o=a.optJSONObject(i)?:continue
                val key=o.optString("key");val url=o.optString("url");if(key.isBlank()||url.isBlank())continue
                val kind=o.optString("kind")
                val cleanTitle=NameCleaner.cleanVodTitle(o.optString("title"))
                val cleanSubtitle=if(kind=="series") NameCleaner.cleanVodTitle(o.optString("subtitle")) else o.optString("subtitle")
                out+=VodHistoryEntry(key,kind,cleanTitle,cleanSubtitle,o.optString("poster"),url,o.optLong("positionMs"),o.optLong("durationMs"),o.optString("sourceKey"),o.optLong("updatedAt"))
            }
            out
        }catch(_:Exception){mutableListOf()}
    }

    private fun saveAll(context:Context,items:List<VodHistoryEntry>){
        val a=JSONArray();items.take(100).forEach{x->a.put(JSONObject().apply{
            put("key",x.key);put("kind",x.kind);put("title",x.title);put("subtitle",x.subtitle);put("poster",x.poster);put("url",x.url);put("positionMs",x.positionMs);put("durationMs",x.durationMs);put("sourceKey",x.sourceKey);put("updatedAt",x.updatedAt)
        })}
        context.getSharedPreferences(PREF,Context.MODE_PRIVATE).edit().putString(DATA,a.toString()).apply()
    }

    fun save(context:Context,entry:VodHistoryEntry){
        val all=loadAll(context);all.removeAll{it.key==entry.key&&it.sourceKey==entry.sourceKey};all.add(0,entry.copy(title=NameCleaner.cleanVodTitle(entry.title),subtitle=if(entry.kind=="series")NameCleaner.cleanVodTitle(entry.subtitle) else entry.subtitle,updatedAt=System.currentTimeMillis()));saveAll(context,all.sortedByDescending{it.updatedAt})
    }

    fun remove(context:Context,sourceKey:String,key:String){val all=loadAll(context);all.removeAll{it.key==key&&it.sourceKey==sourceKey};saveAll(context,all)}

    fun list(context:Context,sourceKey:String,kind:String):List<VodHistoryEntry> = loadAll(context).filter{it.sourceKey==sourceKey&&it.kind==kind}.sortedByDescending{it.updatedAt}
}
