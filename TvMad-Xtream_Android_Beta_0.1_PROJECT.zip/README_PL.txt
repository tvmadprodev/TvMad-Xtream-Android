TvMad Cam 0.1.0

Lekka aplikacja Android do podglądu kamer RTSP.

Funkcje:
- dodawanie kamer: nazwa + URL RTSP
- edycja i usuwanie kamer
- równoległy podgląd 1-6 kamer
- dynamiczna siatka 1x1 / 2x1 / 2x2 / 2x3, w landscape do 3x2
- wymuszony RTSP over TCP dla stabilności
- automatyczny reconnect po utracie streamu
- status LIVE / łączenie / brak sygnału
- dwuklik kamery = fullscreen landscape
- dwuklik lub Back = powrót do siatki
- Back z siatki = wyjście z aplikacji
- fullscreen w trybie immersive
- globalny przełącznik dźwięku; siatka zawsze wyciszona, dźwięk tylko w fullscreen
- kolejność kamer: przytrzymaj uchwyt ≡ i przeciągnij na inną kamerę
- widget kamery na pulpit: wybór konkretnej kamery, klik otwiera ją od razu fullscreen
- konfiguracja zapisywana lokalnie w SharedPreferences
- brak reklam, kont i telemetrii

Wymagania build:
- Java 17
- Gradle 8.9
- Android Gradle Plugin 8.7.3
- compileSdk 35
- Media3 1.5.1 (ExoPlayer + RTSP + UI)

ZIP jest przygotowany bez nadrzędnego folderu, zgodnie z workflow:
unzip -q TvMad-Xtream_Android_Beta_0.1_PROJECT.zip -d build-project
gradle --no-daemon --stacktrace :app:assembleDebug
