TvMad Connect 0.3

Zmiany:
- czarne tło overlayu jest osobną, w 100% nieprzezroczystą warstwą RGBX
- logo jest osobnym PNG z przezroczystym tłem i jest przyciemnione już w samym pliku
- próba globalnego ukrycia kursora air-mouse przez ukryte InputManager API
- TvMad-Xtream jest rozpoznawany po dokładnym stanie pl.tvmad.xtream.PhoneSplashActivity,
  a nie po "ostatniej aplikacji na pierwszym planie"
- dlatego ruch air-mouse / strzałki nie powinny ponownie włączać logo Connect podczas TvMad-Xtream
- przełączniki są zapamiętywane

Wymagane:
- uprawnienie "Wyświetlanie nad innymi aplikacjami"
- przy włączonym pierwszeństwie TvMad-Xtream: "Dostęp do użycia aplikacji"
- na tym telefonie hidden_api_policy=1 zostało już ustawione podczas testów
