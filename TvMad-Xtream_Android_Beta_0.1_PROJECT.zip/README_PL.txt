TvMad Cam 0.2.0

Lekki podgląd kamer dla Androida.

Źródła:
1. RTSP bezpośrednio - przycisk +
2. TvMad Home - przycisk NUC
   - wpisz adres serwera, login i hasło
   - aplikacja loguje się do TvMad Home
   - pobiera listę z /api/tvmad-cam/cameras
   - startuje kamerę przez /api/cameras/{id}/start
   - odtwarza HLS z zachowaniem cookie sesji również dla segmentów
   - przy zwolnieniu playera wysyła /api/live/{session}/stop

TvMad Home nie ujawnia aplikacji lokalnych adresów RTSP.

UI:
- bezpieczne insets status/navigation bar dla różnych telefonów i notchy
- 1-6 kamer w siatce
- dwuklik fullscreen landscape
- Back wraca z fullscreen, a z siatki wychodzi
- widget otwiera wybraną kamerę
