TvMad Connect

Projekt Android pod workflow ZIP/Gradle jak w TvMad-Xtream.

Funkcja:
- w aplikacji jest przełącznik ON/OFF
- ustawienie zapisuje się lokalnie
- gdy ON i telefon wykryje zewnętrzny ekran HDMI, na telefonie pojawia się ciemne logo AMOLED
- overlay znika po odłączeniu HDMI albo po wyłączeniu przełącznika
- TV dalej pokazuje normalny pulpit / mirroring

Wymagane po pierwszym uruchomieniu:
1. Otwórz aplikację.
2. Włącz przełącznik.
3. Zezwól na "draw over other apps".
4. Podłącz HDMI i sprawdź działanie.
