TvMad Connect 0.2

Zmiany względem 0.1:
- nakładka jest w 100% nieprzezroczysta; pod nią nie widać pulpitu telefonu
- tło AMOLED jest czarne, a samo logo TvMad Connect jest lekko przyciemnione
- TvMad-Xtream ma opcjonalne pierwszeństwo: gdy pl.tvmad.xtream.tv jest na pierwszym planie,
  logo TvMad Connect znika i zostaje wyłącznie logo TvMad-Xtream
- po wyjściu z TvMad-Xtream logo TvMad Connect wraca automatycznie, jeśli HDMI nadal jest podłączone
- oba ustawienia są zapamiętywane

Pierwsze uruchomienie:
1. Włącz "Logo TvMad Connect przy HDMI".
2. Jeśli Android poprosi, zezwól na "Wyświetlanie nad innymi aplikacjami".
3. Zostaw "TvMad-Xtream ma pierwszeństwo" = ON.
4. Nadaj TvMad Connect "Dostęp do użycia" (Usage Access), gdy aplikacja o to poprosi.
   Bez tego Android nie pozwala aplikacji wiarygodnie wykryć, że TvMad-Xtream jest aktualnie na pierwszym planie.

Opcjonalnie Usage Access można nadać z ADB:
adb shell appops set com.tvmad.connect GET_USAGE_STATS allow
