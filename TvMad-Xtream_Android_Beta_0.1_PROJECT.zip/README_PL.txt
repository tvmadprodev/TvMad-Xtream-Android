TvMad HDMI Test - projekt w tym samym formacie ZIP co TvMad-Xtream Android.

Cel testu:
- telefon: czarna nakladka TvMad Galaxy
- TV HDMI: normalny pulpit bez nakladki

Przed testem:
adb shell settings put global hidden_api_policy 1

Po testach:
adb shell settings delete global hidden_api_policy
