TvMad Monitor 0.1.1
===================

Prosta aplikacja + półprzezroczysty widget dla Galaxy S9+ / Android 17.

Widget pokazuje:
- zegar z sekundami (aktualizowany przez systemowy TextClock, bez budzenia aplikacji co sekundę),
- datę,
- użycie RAM,
- użycie pamięci wewnętrznej,
- poziom baterii,
- temperaturę baterii.

Odświeżanie:
- zegar/data: na bieżąco przez TextClock,
- statystyki: około co 5 minut przez AlarmManager; Android może opóźnić odświeżenie w głębokim uśpieniu,
- odświeżenie ręczne: przycisk w aplikacji.

Czyszczenie RAM:
- kliknięcie w dowolne miejsce widgetu uruchamia `su -c "am kill-all"`,
- Shizuku zapyta o Superuser przy pierwszym użyciu,
- aplikacja mierzy dostępną pamięć przed i po oraz pokazuje „Zwolniono X MB”,
- nie używa agresywnego drop_caches ani zmian kernela.

Po instalacji:
1. Otwórz aplikację raz.
2. Dodaj widget „TvMad Monitor” na pulpit.
3. Przy pierwszym kliknięciu widgetu zezwól TvMad Monitor na Superuser w Shizuku.

Projekt bez zewnętrznych bibliotek. GitHub/Gradle:
- Android Gradle Plugin 8.6.1
- compileSdk 35
- minSdk 29
- Java 17


Wersja 0.1.2 non-root: czyszczenie RAM przez Shizuku.
Na telefonie bez roota uruchom Shizuku przez Wireless Debugging, a następnie otwórz TvMad Monitor raz i zaakceptuj uprawnienie Shizuku.
