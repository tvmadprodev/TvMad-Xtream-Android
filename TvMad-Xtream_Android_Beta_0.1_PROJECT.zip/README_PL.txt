TvMad Connect 0.3.6

Zmiany:
- widget HDMI i cała programowa obsługa HDMI ON/OFF zostały całkowicie usunięte
- aplikacja nie zapisuje już nic do Samsung DP/HDMI sysfs
- główny przełącznik i pierwszeństwo TvMad-Xtream są zapamiętywane
- gdy główny przełącznik był ON, monitor overlayu uruchamia się automatycznie po restarcie telefonu
- monitor jest również wznawiany po ponownym podłączeniu USB-C/HDMI, aktualizacji aplikacji lub pojawieniu się zasilania
- overlay zachowuje poprawkę air-mouse + OK i pozostaje tylko na AMOLED
- TvMad-Xtream jest rozpoznawany po dokładnym stanie pl.tvmad.xtream.PhoneSplashActivity

Wymagane:
- uprawnienie "Wyświetlanie nad innymi aplikacjami"
- przy włączonym pierwszeństwie TvMad-Xtream: "Dostęp do użycia aplikacji"
- Magisk/root dla istniejącej poprawki pass-through input overlayu
