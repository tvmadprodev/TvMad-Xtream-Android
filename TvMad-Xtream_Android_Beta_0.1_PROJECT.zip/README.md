# TvMad-Xtream TV – Exo Beta

Wersja Android Box / Stick oparta na Media3 ExoPlayer.

Najważniejsze zmiany:
- osobny pakiet `pl.tvmad.xtream.tv`, więc może być zainstalowany obok wersji telefonu,
- bez LibVLC – lżejszy APK i mniejsze zużycie zasobów,
- ekran główny TV z trzema kafelkami: Telewizja / Filmy / Seriale,
- interfejs i focus przygotowany pod D-pad/pilot,
- MiniTV na liście kanałów z debounce 500 ms, aby nie przełączać streamu przy każdym szybkim ruchu pilota,
- lista kanałów: picon + aktualne EPG,
- panel MiniTV: picon wybranego kanału, bieżące wydarzenie, progress i opis,
- EPG pobierane dla całej listy (bez starego limitu 100 kanałów), maks. 4 równoległe zapytania i grupowane odświeżanie UI,
- pełne EPG i opis wydarzeń zachowane,
- VOD zachowuje własny stabilny seekbar nad infobarem,
- pilot w playerze: OK pokazuje infobar, D-pad pozwala wejść na Audio/Napisy, lewo/prawo przewija VOD o 10 s,
- lokalny webinterface na porcie 5557: dodawanie/edycja/usuwanie Xtream/M3U oraz upload piconów PNG/JPG/WEBP lub ZIP,
- własne picony są dopasowywane po oczyszczonej nazwie kanału,
- niebieska ikona i osobna nazwa TvMad-Xtream TV.


## TV Exo 1.1 stability/audio
- Live/VOD remain ExoPlayer/Media3; no VLC.
- Added Jellyfin Media3 FFmpeg audio decoder and prefer software extension for full-screen playback.
- Covers MP1/MP2/MP3, AAC, AC3/EAC3, DTS and other FFmpeg-supported audio formats when platform codecs are missing.
- EPG is now lazy-loaded only around the visible channel window, 2 requests at a time; more loads when scrolling stops.
- Group counts are built in one pass instead of repeatedly scanning all channels.
- MiniTV uses platform decoder only and is muted to reduce decoder/CPU pressure on low-end TV boxes.
- Background general and EPG pools reduced to 2 threads each.

## 1.2 TV Exo FFmpeg
- pilot OK na zaznaczonym kanale zawsze otwiera ten kanał w pełnym ekranie
- poruszanie góra/dół po kanałach nie przełącza MiniTV; zmienia tylko informacje/picon zaznaczonej pozycji
- MiniTV jest utrzymywane także na ekranie grup Live i odtwarza ostatni/bieżący kanał
- MiniTV korzysta z preferowanego rozszerzonego renderera FFmpeg i ma włączony dźwięk
- VOD: DPAD lewo/prawo przewija zawsze o 10 sekund, niezależnie od widoczności infobara
- wiersze kanałów nie przejmują focusu od ListView, co stabilizuje OK/DPAD na boxach
