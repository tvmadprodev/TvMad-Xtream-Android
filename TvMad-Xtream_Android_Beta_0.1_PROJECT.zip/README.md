TvMad-Xtream Android TV Exo 1.5 beta

Zmiany 1.5:
- Live TV nie przechodzi już między dwoma PlayerView/Activity. Jeden PlayerView (TextureView) pozostaje cały czas tą samą powierzchnią obrazu.
- MiniTV <-> fullscreen jest animowane przez zmianę położenia/rozmiaru tego samego widoku, bez przepinania powierzchni dekodera i bez restartu streamu.
- Live fullscreen działa wewnątrz MainActivity; Back animuje obraz z powrotem do MiniTV.
- VOD: przy trzymaniu lewo/prawo obraz jest zatrzymany, przesuwany jest tylko docelowy punkt; po puszczeniu wykonywany jest jeden seek i odtwarzanie rusza z wybranego miejsca. Brak recovery/restartów podczas scrubbingu.
- Lista Live jest cache'owana lokalnie per serwer. Przy następnym uruchomieniu ostatni kanał startuje od razu, a lista odświeża się w tle.
- EPG ostatniego kanału jest cache'owane lokalnie i od razu trafia do infobara; świeże EPG jest pobierane w tle.
- Dotychczasowe EPG i progressbary listy pozostawione bez zmian.
- ExoPlayer + FFmpeg audio pozostaje, VLC nie jest używany.


## 1.6 TV Exo FFmpeg
- Zachowane bez zmian animowane przejście MiniTV ↔ fullscreen na jednym TextureView.
- Szybszy start po zmianie kanału dzięki niskiemu buforowi startowemu Live.
- Naprawione automatyczne wznowienie: po starcie ostatni kanał otwiera się rzeczywiście fullscreen, bez późniejszego zmniejszenia do MiniTV.
- Przywrócony złoty kolor nazwy kanału w Live infobarze.
- VOD: płynniejszy i szybszy podgląd przewijania przy trzymaniu lewo/prawo; pojedyncze kliknięcie nadal 5 s.
- EPG i animacja Live pozostawione bez zmian.
