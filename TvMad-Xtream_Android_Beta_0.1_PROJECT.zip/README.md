# TvMad-Xtream Android Beta 0.1

Pierwszy natywny prototyp Android zbudowany na logice TvMad-Xtream Beta7.

Obecnie: Xtream Live, M3U Live, czyszczenie końcówki RAW, grupy, podstawowy player fullscreen oraz trzy tryby piconów w UI.

Planowane / jeszcze niezaimplementowane w 0.1: Stalker/MAG, VOD/seriale, pełne EPG ze źródła, faktyczne renderowanie lokalnych piconów i cache, MiniTV oraz dopracowany interfejs FullNight.

Docelowy lokalny folder piconów:

`Android/data/pl.tvmad.xtream.beta/files/picons/`

Nazwy są normalizowane przez `NameCleaner.piconKey()`.

## Automatyczny build APK przez GitHub Actions

Projekt zawiera workflow `.github/workflows/build-android.yml`.

1. Utwórz nowe repozytorium na GitHubie.
2. Wgraj całą zawartość tego katalogu do głównego katalogu repozytorium.
3. Po pushu na `main` lub `master` GitHub automatycznie uruchomi build.
4. Możesz też wejść w **Actions → Build TvMad-Xtream Android Beta → Run workflow** i uruchomić build ręcznie.
5. Po zakończeniu builda otwórz jego stronę. Na dole w **Artifacts** będzie plik `TvMad-Xtream-Android-Beta-0.1-APK`.
6. Pobierz artifact, rozpakuj ZIP i zainstaluj `TvMad-Xtream-Android-Beta-0.1.apk` na telefonie.

APK jest budowane jako Android **debug APK** i jest automatycznie podpisywane kluczem debugowym przez Android Gradle Plugin. Nie trzeba dodawać żadnych sekretów ani własnego keystore do wersji testowej.
