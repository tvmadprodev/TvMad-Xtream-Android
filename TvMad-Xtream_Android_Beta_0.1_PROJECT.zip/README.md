TvMad-Xtream Android Beta 0.4

Zmiany:
- ekran źródeł oddzielony od menu: Telewizja / Filmy / Seriale / Ulubione
- grupy Live TV i zapamiętywanie źródeł zachowane
- EPG z Xtream get_short_epg pokazywane przy kanałach (także dla M3U get.php, gdy można odczytać dane API)
- filmy: kategorie -> filmy -> odtwarzanie
- seriale: kategorie -> seriale -> sezony -> odcinki -> odtwarzanie
- ulubione Live TV (długie przytrzymanie kanału)
- player domyślnie 16:9 z czarnym tłem i bez cropowania; przycisk 16:9 / WYPEŁNIJ po dotknięciu ekranu
- infobar znika automatycznie
- pełna rotacja pion/poziom bez powrotu do ekranu głównego
- pytanie Tak/Nie przed zamknięciem aplikacji
- nowa ikona aplikacji

Nazwa archiwum dla istniejącego GitHub Actions pozostaje:
TvMad-Xtream_Android_Beta_0.1_PROJECT.zip
