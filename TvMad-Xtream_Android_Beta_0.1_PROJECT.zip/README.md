# TvMad-Xtream TV 2.0 — PNG Concept

- Ekran główny, sekcje Live/VOD/Seriale, duże panele list, kafle oraz infobary korzystają z własnych PNG zamiast Androidowych gradientów.
- Usunięto napis Premium IPTV / ExoPlayer / FFmpeg z nagłówka.
- Usunięto panel i adres WWW z plansz; w jego miejscu pozostaje zegar i data.
- Live/VOD/Seriale mają osobne tła i akcenty zgodne z zatwierdzonym konceptem.
- Live infobar i VOD infobar mają własne półprzezroczyste PNG i układ zgodny z konceptem.
- Przewijanie VOD oraz nawigacja przycisków pozostawione bez zmian.
- Komunikat buforowania Live jest blokowany przy normalnym wyborze/przełączeniu kanału; recovery uzbraja się dopiero po stabilnym odtwarzaniu.
- EPG, ExoPlayer+FFmpeg, animacja MiniTV ↔ fullscreen i progresy listy pozostawione bez zmian.

# TvMad-Xtream TV 1.9 — PNG Glass + VOD D-pad

- Infobary Live/VOD i główne panele glass są teraz gotowymi 32-bit PNG RGBA z prawdziwym alpha, bez Androidowych gradientów.
- DÓŁ na widocznym infobarze VOD wchodzi w tryb przycisków. LEWO/PRAWO nawiguje po przyciskach, OK uruchamia funkcję, GÓRA/BACK wraca do trybu przewijania.
- Przewijanie VOD pozostaje bez zmian poza blokadą podczas aktywnej nawigacji po przyciskach.

TvMad-Xtream Android TV Exo 1.5 beta

Zmiany 1.5:
- Live TV nie przechodzi już między dwoma PlayerView/Activity. Jeden PlayerView (TextureView) pozostaje cały czas tą samą powierzchnią obrazu.
- MiniTV <-> fullscreen jest animowane przez zmianę położenia/rozmiaru tego samego widoku, bez przepinania powierzchni dekodera i bez restartu streamu.
- Live fullscreen działa wewnątrz MainActivity; Back animuje obraz z powrotem do MiniTV.
- VOD: przy trzymaniu lewo/prawo obraz jest zatrzymany, przesuwany jest tylko docelowy punkt; po puszczeniu wykonywany jest jeden seek i odtwarzanie rusza z wybranego miejsca. Brak recovery/restartów podczas scrubbingu.
- Lista Live jest cache'owana lokalnie per serwer. Przy następnym uruchomieniu ostatni kanał startuje od razu, a lista odświeża się w tle.
- EPG ostatniego kanału jest cache'owane lokalnie i od razu trafia do infobara; świeże EPG jest pobierane w tle.
- Dotychczasowe EPG i progressbary listy pozostawione bez zmian.
- ExoPlayer + FFmpeg audio pozostaje, VLC nie jest używany.


## 1.6 TV Exo FFmpeg
- Zachowane bez zmian animowane przejście MiniTV ↔ fullscreen na jednym TextureView.
- Szybszy start po zmianie kanału dzięki niskiemu buforowi startowemu Live.
- Naprawione automatyczne wznowienie: po starcie ostatni kanał otwiera się rzeczywiście fullscreen, bez późniejszego zmniejszenia do MiniTV.
- Przywrócony złoty kolor nazwy kanału w Live infobarze.
- VOD: płynniejszy i szybszy podgląd przewijania przy trzymaniu lewo/prawo; pojedyncze kliknięcie nadal 5 s.
- EPG i animacja Live pozostawione bez zmian.


## 1.7 TV Neon Exo FFmpeg
- Kompletny lifting UI w kierunku zatwierdzonego mockupu: ciemne premium tło, neonowe kafle LIVE/VOD/SERIALE, zaokrąglone panele i czytelne focusy pilota.
- Live TV zachowuje dotychczasowy układ MiniTV + EPG + picony + progressbary; NIE zmieniono działającej animacji MiniTV ↔ fullscreen.
- Nowy premium infobar Live z akcentem złotym oraz przyciskami audio/napisów tylko gdy są dostępne.
- VOD ma nowy infobar, własny pasek czasu, czas bieżący/całkowity oraz nowy styl przycisków.
- Przewijanie VOD pilotem przebudowane: 100000 kroków paska, aktualizacja ~60 fps, płynne przyspieszenie podczas trzymania; jedno kliknięcie nadal 5 s; faktyczny seek wykonywany dopiero po puszczeniu.
- Listy serwerów, grup, filmów i seriali otrzymały nowe TV-friendly wiersze z niebieskim/fioletowym/złotym focusem.
- Webinterface otrzymał ten sam styl premium/neon i zachowuje dodawanie/edycję/usuwanie serwerów oraz upload piconów/ZIP.
- EPG, ExoPlayer+FFmpeg, cache i logika Live pozostawione bez zmian poza warstwą wizualną.


## 1.8 TV Premium Concept
- Warstwa graficzna przebudowana zgodnie z zatwierdzonym mockupem: duże ciemne kafle z dużymi ikonami i osobnym neonowym akcentem LIVE/VOD/SERIALE.
- Osobne tła i półprzezroczyste panele sekcji: LIVE niebieski/cyjan, FILMY fiolet/magenta, SERIALE złoto/pomarańcz.
- Lista kanałów zachowuje MiniTV, EPG i progresy; otrzymała numerację i premium focus.
- Live infobar przebudowany na szeroki półprzezroczysty panel z numerem, piconem, złotą nazwą, blokiem TERAZ, progressbarem, NASTĘPNIE, zegarem/datą i opcjonalnymi AUDIO/NAPISY.
- VOD infobar przebudowany na szeroki panel z dużym, dobrze widocznym seekbarem i kontrolkami. Mechanika przewijania 1.7 pozostała bez zmian.
- Webinterface przebudowany do układu z boczną nawigacją, serwerami, edycją/usuwaniem i galerią wgranych piconów.
- Komunikat buforowania Live jest tłumiony podczas normalnego wejścia/przełączenia kanału; pokazuje się dopiero przy rzeczywistym rebufferingu po odtwarzaniu. Teksty prób 1/3 itd. usunięte z UI.
- Nie zmieniono EPG, ExoPlayer+FFmpeg ani animacji MiniTV ↔ fullscreen.
