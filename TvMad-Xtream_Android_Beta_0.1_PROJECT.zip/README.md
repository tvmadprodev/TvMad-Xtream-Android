TvMad-Xtream Android TV Exo 1.4 beta

Zmiany 1.4:
- Live TV nadal Media3 ExoPlayer + FFmpeg audio decoder; EPG parsing/pobieranie niezmienione względem 1.3.
- Przejście MiniTV <-> fullscreen używa PlayerView.switchTargetView na jednym ExoPlayerze, bez odpinania starego widoku przed podpięciem nowego.
- VOD: pojedyncze lewo/prawo = 5 s; przytrzymanie przewija szybko (15 s co 100 ms); infobar nie znika podczas trzymania i znika 3 s po puszczeniu. Zwykłe OK nadal pokazuje go na 5 s.
- Live fullscreen: UP = następny kanał, DOWN = poprzedni.
- Buforowanie po przerwaniu już grającego streamu: overlay z animacją i procentem; do 3 automatycznych restartów. Overlay nie jest pokazywany przy normalnym pierwszym starcie kanału/filmu.
- Zapamiętywany jest ostatni oglądany kanał Live i źródło. Przy kolejnym uruchomieniu, jeśli źródło nadal istnieje, aplikacja wczytuje listę i automatycznie otwiera ostatni kanał fullscreen. Oglądanie VOD nie nadpisuje ostatniego kanału Live.
- Po powrocie z fullscreen lista kanałów ustawia pojedynczy fokus na aktualnie grającym kanale; usunięte podwójne zaznaczenie choice/selection.
- Progressbary EPG w liście pozostają bez zmian.
