TvMad-Xtream Android Beta 0.8

Zmiany:
- odtwarzacz Media3/ExoPlayer z paskiem przewijania, play/pause i stop,
- wykrywanie i wybór dostępnych ścieżek audio,
- wykrywanie, wybór i wyłączanie napisów,
- ekran szczegółów TMDB dla filmów i seriali: okładka, opis, ocena, rok, gatunek, czas,
- film otwiera szczegóły i przycisk PLAY; serial otwiera szczegóły i przycisk SEZONY,
- powrót zachowuje pozycję list grup/kategorii/seriali/sezonów,
- pikony ze źródła w liście kanałów,
- zachowane wcześniejsze grupowanie, EPG, serwery, obracanie, 16:9/wypełnij i potwierdzenie wyjścia.


Beta 0.8: synchronizacja EPG z zegarem telefonu (korekta czasu jak w E2 i wybór bieżącej/następnej audycji), naprawione ponowne wywoływanie Live infobaru, jaśniejszy VOD timebar, awaryjny tor audio MediaPlayer dla nieobsługiwanych ścieżek Live.

## Beta 0.9
- Stabilny zewnętrzny suwak VOD nad infobarem; nie wraca na środek po ponownym pokazaniu kontrolek.
- Live TV używa LibVLC 3.7.5 jako silnika odtwarzania dla szerszej obsługi kodeków audio; VOD nadal używa Media3/ExoPlayer.
- Długie przytrzymanie kanału: Dodaj/Usuń z ulubionych lub Wyświetl EPG.
- Pełne EPG kanału z get_simple_data_table (fallback get_short_epg limit 100), przewijana lista i szczegółowy opis po kliknięciu wydarzenia.
