# TvMad-Xtream TV – Exo Beta

Wersja Android Box / Stick oparta na Media3 ExoPlayer.

Najważniejsze zmiany:
- osobny pakiet `pl.tvmad.xtream.tv`, więc może być zainstalowany obok wersji telefonu,
- bez LibVLC – lżejszy APK i mniejsze zużycie zasobów,
- ekran główny TV z trzema kafelkami: Telewizja / Filmy / Seriale,
- interfejs i focus przygotowany pod D-pad/pilot,
- MiniTV na liście kanałów z debounce 500 ms, aby nie przełączać streamu przy każdym szybkim ruchu pilota,
- lista kanałów: picon + aktualne EPG,
- panel MiniTV: picon wybranego kanału, bieżące wydarzenie, progress i opis,
- EPG pobierane dla całej listy (bez starego limitu 100 kanałów), maks. 4 równoległe zapytania i grupowane odświeżanie UI,
- pełne EPG i opis wydarzeń zachowane,
- VOD zachowuje własny stabilny seekbar nad infobarem,
- pilot w playerze: OK pokazuje infobar, D-pad pozwala wejść na Audio/Napisy, lewo/prawo przewija VOD o 10 s,
- lokalny webinterface na porcie 5557: dodawanie/edycja/usuwanie Xtream/M3U oraz upload piconów PNG/JPG/WEBP lub ZIP,
- własne picony są dopasowywane po oczyszczonej nazwie kanału,
- niebieska ikona i osobna nazwa TvMad-Xtream TV.
