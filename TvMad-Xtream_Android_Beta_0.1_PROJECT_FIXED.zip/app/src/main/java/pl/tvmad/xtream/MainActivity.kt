package pl.tvmad.xtream
import android.app.*
import android.os.*
import android.content.*
import android.widget.*
import java.util.concurrent.Executors

class MainActivity:Activity(){
 private lateinit var list:ListView; private lateinit var status:TextView; private val pool=Executors.newSingleThreadExecutor(); private var channels=listOf<Channel>(); private var piconMode=2
 override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_main);list=findViewById(R.id.list);status=findViewById(R.id.status);findViewById<Button>(R.id.addXtream).setOnClickListener{xtreamDialog()};findViewById<Button>(R.id.addM3u).setOnClickListener{m3uDialog()};findViewById<Button>(R.id.piconMode).setOnClickListener{v->piconMode=(piconMode+1)%3;(v as Button).text="Picony: "+arrayOf("lokalne","źródło","oba")[piconMode]};list.setOnItemClickListener{_,_,i,_->startActivity(Intent(this,PlayerActivity::class.java).putExtra("url",channels[i].url).putExtra("name",channels[i].name))}}
 private fun field(h:String)=EditText(this).apply{hint=h}
 private fun xtreamDialog(){val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL};val h=field("http://serwer:port");val u=field("Użytkownik");val p=field("Hasło");box.addView(h);box.addView(u);box.addView(p);AlertDialog.Builder(this).setTitle("Xtream Codes").setView(box).setPositiveButton("Wczytaj"){_,_->load{Api.xtream(h.text.toString(),u.text.toString(),p.text.toString())}}.setNegativeButton("Anuluj",null).show()}
 private fun m3uDialog(){val u=field("URL listy M3U");AlertDialog.Builder(this).setTitle("M3U").setView(u).setPositiveButton("Wczytaj"){_,_->load{Api.m3u(u.text.toString())}}.setNegativeButton("Anuluj",null).show()}
 private fun load(fn:()->List<Channel>){status.text="Ładowanie…";pool.execute{try{val x=fn();runOnUiThread{channels=x;list.adapter=ArrayAdapter(this,android.R.layout.simple_list_item_1,x.map{if(it.group.isBlank()) it.name else "${it.group}  •  ${it.name}"});status.text="Załadowano ${x.size} pozycji"}}catch(e:Exception){runOnUiThread{status.text="Błąd: ${e.message}"}}}}
}
