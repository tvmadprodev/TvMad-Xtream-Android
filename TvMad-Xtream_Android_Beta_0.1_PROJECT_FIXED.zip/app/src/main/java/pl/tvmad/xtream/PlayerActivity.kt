package pl.tvmad.xtream
import android.app.Activity
import android.os.Bundle
import android.net.Uri
import android.widget.*
class PlayerActivity:Activity(){override fun onCreate(b:Bundle?){super.onCreate(b);setContentView(R.layout.activity_player);val v=findViewById<VideoView>(R.id.video);findViewById<TextView>(R.id.channel).text=intent.getStringExtra("name")?:"";v.setVideoURI(Uri.parse(intent.getStringExtra("url")?:""));v.setOnPreparedListener{it.isLooping=false;v.start()};v.setOnErrorListener{_,_,_->Toast.makeText(this,"Nie można uruchomić strumienia",Toast.LENGTH_SHORT).show();true}}}
