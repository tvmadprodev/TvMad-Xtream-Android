package pl.tvmad.xtream
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object Api {
 private fun get(url:String):String { val c=URL(url).openConnection() as HttpURLConnection; c.connectTimeout=15000;c.readTimeout=25000;c.setRequestProperty("User-Agent","Mozilla/5.0 TvMadAndroid"); return c.inputStream.bufferedReader().use{it.readText()} }
 fun xtream(host:String,user:String,pass:String):List<Channel>{
  val h=host.trimEnd('/'); val u=URLEncoder.encode(user,"UTF-8"); val p=URLEncoder.encode(pass,"UTF-8")
  val cats=JSONArray(get("$h/player_api.php?username=$u&password=$p&action=get_live_categories")); val names=mutableMapOf<String,String>()
  for(i in 0 until cats.length()){val o=cats.getJSONObject(i);names[o.optString("category_id")]=o.optString("category_name")}
  val a=JSONArray(get("$h/player_api.php?username=$u&password=$p&action=get_live_streams")); val out=ArrayList<Channel>()
  for(i in 0 until a.length()){val o=a.getJSONObject(i);val id=o.optString("stream_id");out+=Channel(NameCleaner.clean(o.optString("name")),"$h/live/$user/$pass/$id.ts",names[o.optString("category_id")]?:"",o.optString("stream_icon"),o.optString("epg_channel_id"))}
  return out
 }
 fun m3u(url:String):List<Channel>{ val lines=get(url).lines();val out=ArrayList<Channel>();var meta=""; for(x in lines){val l=x.trim();if(l.startsWith("#EXTINF",true)) meta=l else if(l.isNotEmpty()&&!l.startsWith("#")&&meta.isNotEmpty()){val name=meta.substringAfterLast(',');val group=Regex("group-title=\"([^\"]*)\"").find(meta)?.groupValues?.get(1)?:"";val logo=Regex("tvg-logo=\"([^\"]*)\"").find(meta)?.groupValues?.get(1)?:"";val epg=Regex("tvg-id=\"([^\"]*)\"").find(meta)?.groupValues?.get(1)?:"";out+=Channel(NameCleaner.clean(name),l,group,logo,epg);meta=""}};return out }
}
